#!/bin/bash
if [ $UID -ne 0 ]
then
	echo "Please Run as SuperUser"
	exit -1
else
	#machine analysis lib install
	echo `systemctl stop algorithmServer.service`
	echo `systemctl disable algorithmServer.service`
	echo `systemctl daemon-reload`
	echo `rm -r /etc/systemd/system/algorithm.d/`
	echo `rm /etc/systemd/system/algorithmServer.service`
	echo `sudo sleep 1 `
	echo `sudo tar -xvf algorithm.tar`
	echo `mv -b ./algorithm.d /etc/systemd/system/`
	echo `mv -b ./algorithmServer.service /etc/systemd/system/`
	#echo `rm -r ./algorithm`
	echo `chmod -R 777 /etc/systemd/system/algorithm.d/`
	echo `chmod -R 777 /etc/systemd/system/algorithmServer.service`
	echo `systemctl enable algorithmServer.service`
	echo `systemctl daemon-reload`
	echo `systemctl start algorithmServer.service`

fi
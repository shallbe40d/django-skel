#!/bin/bash
#_PATH=$(awk -F':' '{if($3==1000)print $1}' /etc/passwd)
#export PATH = "$PATH:/usr/local/cuda-10.2/bin:/home/$_PATH/.local/bin:/usr/local/cuda-10.2/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin"
python3 -u /etc/systemd/system/algorithm.d/vib_sound_algorithm.py 2>&1 | tee -a log.txt
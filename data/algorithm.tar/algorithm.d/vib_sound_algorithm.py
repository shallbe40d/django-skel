# _*_ coding: UTF-8 -*-
import json
import sys
import os
import numpy as np
import socket
import struct
import time
import datetime
from datetime import date
from collections import deque

from redis import SSLConnection
from file.func_module.vib_rank import vib_rank #진동등급
from file.func_module.vib_fault_analysis import vib_fault_analysis #진동진단
from file.func_module.v_belt_diag import v_belt_diag #V벨트
from file.func_module.fft_threshold_calc import fft_threshold_calc #진동 임계치 설정
from file.func_module.fail_freq_calc import fail_freq_json_path #결함주파수 산출
from file.func_module.noise_threshold_calc import noise_shreshold_calc #소음 임계치 설정
from file.func_module.noise_analysis import noise_analysis #소음 가동 비가동 및 이상 진단

#from vib_rank import vib_rank #진동등급
#from Op_CondIndi import Op_Cond_Start #이상감지
#from vib_fault_analysis import vib_fault_analysis #진동진단
#from v_belt_diag import v_belt_diag #V벨트

'''
2020.09.15 첫 코딩 완료
2020.09.16 인트세인-KC IPC 연동 테스트 완료
2020.09.29 예외처리 구문 추가
2021.02.04 V-Belt알고리즘 요구 소음 파일 1개로 변경
'''

data_queue = deque()

#Queue의 데이터를 저장하고 관리 (내부에 저장되는 데이터가 5개가 넘어가지 않도록)
def input_queue(_path):
	f = open(_path, 'r')
	data = f.readline()
	data = list(map(int, data))
	data = np.array(data)
	data = (data/data.mean())
	if len(data_queue) < 5: #queue에서 데이터가 5개 미만인경우
		data_queue.appendleft(data)
		return 0, np.array(data_queue)
	elif len(data_queue) == 5: #queue에서 데이터가 딱 상한인 5까지 찬 경우
		data_queue.pop()
		data_queue.appendleft(data)
		return 1, np.array(data_queue)
	elif len(data_queue) > 5: #queue에서 데이터가 모종의 사유로 5개를 초과한 경우
		for i in range(len(data_queue)-4):
			data_queue.pop()
		data_queue.appendleft(data_queue)
		return 1, np.array(data_queue)

#패킷 종류 반환
def PTypeCheck(rcv_data):
	#오류검사(앞의 1byte 검사)
	if(rcv_data[0]!=2):
		print("올바른 패킷이 아님")
		return 255
	print("[",datetime.datetime.now(),"]", "패킷종류:",int(rcv_data[1]))
	return int(rcv_data[1])


#합쳐서 날라오는 패킷 분할 하여 전달
def Packet_Slice(rcv_data):
	print("분할전 패킷 길이:",len(rcv_data))
	print("수신 raw: ",rcv_data)
	list_packet = []
	while True:
		if len(rcv_data) > 0:
			offset = 4 + int.from_bytes(rcv_data[2:4], byteorder = 'big')
			#print(int.from_bytes(rcv_data[2:4], byteorder = 'big'))
			#offset = 4 + struct.unpack('h',rcv_data[2:4])
			list_packet.append(rcv_data[0:offset])
			rcv_data = rcv_data[offset:]
		else:
			break
	print("분할결과:",list_packet)
	return list_packet


#프로토콜 종류에 맞추어 구조체 언팩하여 데이터 전달
def Struct_Unpack(type_num, rcv_data):
	print("UnPacking process")
	if(type_num == 1): #2도 체크할 것 <이상소음 감지 요청>
		Packet = Packet_Slice(rcv_data) #패킷 분할처리
		path_length0 = int.from_bytes(Packet[0][2:4], byteorder = 'big')#경로길이 얻기
		path_length1 = int.from_bytes(Packet[1][2:4], byteorder = 'big')#경로길이 얻기
		path_length2 = int.from_bytes(Packet[2][2:4], byteorder = 'big')#경로길이 얻기
		path_length3 = int.from_bytes(Packet[3][2:4], byteorder = 'big')#경로길이 얻기
		path_length4 = int.from_bytes(Packet[4][2:4], byteorder = 'big')#경로길이 얻기
		GW_SoundPath = struct.unpack(str(path_length0)+'s',Packet[0][4:])[0].decode('utf-8')#패키징 해제 후 decode
		#print(Packet)
		#print(Packet[1][4:])
		#print(str(path_length2))
		ConditionStackPath = struct.unpack(str(path_length1)+'s',Packet[1][4:])[0].decode('utf-8')#패키징 해제 후 decode
		SpecPath = struct.unpack(str(path_length2)+'s',Packet[2][4:])[0].decode('utf-8')#패키징 해제 후 decode
		ThresholdPath = struct.unpack(str(path_length3)+'s',Packet[3][4:])[0].decode('utf-8')#패키징 해제 후 decode
		GW_Position = struct.unpack('!BBHB', Packet[4])[3]
		return str(GW_SoundPath), str(ConditionStackPath), str(SpecPath), str(ThresholdPath), GW_Position
	elif(type_num == 17): #18, 19도 체크할 것 <진동등급 요청>
		Packet = Packet_Slice(rcv_data)
		path_length0 = int.from_bytes(Packet[0][2:4], byteorder = 'big')#경로길이 얻기
		path_length1 = int.from_bytes(Packet[1][2:4], byteorder = 'big')#경로길이 얻기
		path_length2 = int.from_bytes(Packet[2][2:4], byteorder = 'big')#경로길이 얻기
		path_length3 = int.from_bytes(Packet[3][2:4], byteorder = 'big')#경로길이 얻기
		IoT_VibPath = struct.unpack(str(path_length0)+'s',Packet[0][4:])[0].decode('utf-8')#패키징 해제 후 decode
		RMSStackPath = struct.unpack(str(path_length1)+'s',Packet[1][4:])[0].decode('utf-8')#패키징 해제 후 decode
		#print(Packet)
		#print(Packet[1][4:])
		#print(str(path_length2))
		print(struct.unpack('!BBHB', Packet[2]))
		SensorPosition = struct.unpack('!BBHB', Packet[2])[3]
		SpecPath = struct.unpack(str(path_length3)+'s',Packet[3][4:])[0].decode('utf-8')#패키징 해제 후 decode
		return IoT_VibPath, RMSStackPath, SensorPosition, SpecPath
	elif(type_num == 33): #34, 35도 체크 할 것 <진동진단 요청>
		Packet = Packet_Slice(rcv_data)
		path_length0 = int.from_bytes(Packet[0][2:4], byteorder = 'big')#경로길이 얻기
		path_length1 = int.from_bytes(Packet[1][2:4], byteorder = 'big')#경로길이 얻기
		path_length2 = int.from_bytes(Packet[2][2:4], byteorder = 'big')#경로길이 얻기
		path_length3 = int.from_bytes(Packet[3][2:4], byteorder = 'big')#경로길이 얻기
		path_length4 = int.from_bytes(Packet[4][2:4], byteorder = 'big')#경로길이 얻기
		IoT_VibPath = struct.unpack(str(path_length0)+'s',Packet[0][4:])[0].decode('utf-8')#패키징 해제 후 decode
		Fault_frequency = struct.unpack(str(path_length1)+'s',Packet[1][4:])[0].decode('utf-8')#패키징 해제 후 decode
		Vib_Thre_Path = struct.unpack(str(path_length2)+'s',Packet[2][4:])[0].decode('utf-8')#패키징 해제 후 decode
		print(struct.unpack('!BBHBB', Packet[3]))
		SensorPosition = struct.unpack('!BBHBB', Packet[3])[3]
		SensorSetup = struct.unpack('!BBHBB', Packet[3])[4]
		SpecPath = struct.unpack(str(path_length4)+'s',Packet[4][4:])[0].decode('utf-8')#패키징 해제 후 decode
		return str(IoT_VibPath), str(Fault_frequency),str(Vib_Thre_Path), SensorPosition, SensorSetup, str(SpecPath)
	elif(type_num == 49): #50, 51도 체크 할 것 <체인 상태진단 요청># 사용안함
		Packet = Packet_Slice(rcv_data)
		path_length1 = int.from_bytes(Packet[0][2:4], byteorder = 'big')#경로길이 얻기
		path_length2 = int.from_bytes(Packet[1][2:4], byteorder = 'big')#경로길이 얻기
		MSpecJsonPath = struct.unpack(str(path_length1)+'s',Packet[0][4:])[0].decode('utf-8')#패키징 해제 후 decode
		IoT_SoundPath = struct.unpack(str(path_length2)+'s',Packet[1][4:])[0].decode('utf-8')#패키징 해제 후 decode
		SensorPosition = struct.unpack('!BBHB', Packet[2])[3]
		return MSpecJsonPath, IoT_SoundPath, SensorPosition
	elif(type_num == 54): #55도 체크할 것 <체인 틀어짐 진단 요청> #사용안함
		Packet = Packet_Slice(rcv_data)
		path_length1 = int.from_bytes(Packet[0][2:4], byteorder = 'big')#경로길이 얻기
		path_length2 = int.from_bytes(Packet[1][2:4], byteorder = 'big')#경로길이 얻기
		IoT_SoundPath_L = struct.unpack(str(path_length1)+'s',Packet[0][4:])[0].decode('utf-8')#패키징 해제 후 decode
		IoT_SoundPath_R = struct.unpack(str(path_length2)+'s',Packet[1][4:])[0].decode('utf-8')#패키징 해제 후 decode
		return IoT_SoundPath_L, IoT_SoundPath_R
	elif(type_num == 65): #66, 67도 체크 할 것 <V벨트 상태진단 요청>
		Packet = Packet_Slice(rcv_data)
		path_length0 = int.from_bytes(Packet[0][2:4], byteorder = 'big')#경로길이 얻기
		path_length1 = int.from_bytes(Packet[1][2:4], byteorder = 'big')#경로길이 얻기
		path_length2 = int.from_bytes(Packet[2][2:4], byteorder = 'big')#경로길이 얻기
		path_length3 = int.from_bytes(Packet[3][2:4], byteorder = 'big')#경로길이 얻기
		path_length4 = int.from_bytes(Packet[4][2:4], byteorder = 'big')#경로길이 얻기
		path_length5 = int.from_bytes(Packet[5][2:4], byteorder = 'big')#경로길이 얻기
		path_length6 = int.from_bytes(Packet[6][2:4], byteorder = 'big')#경로길이 얻기
		#path_length3 = int.from_bytes(Packet[2][2:4], byteorder = 'big')#경로길이 얻기
		IoT_motor_VibPath = struct.unpack(str(path_length0)+'s',Packet[0][4:])[0].decode('utf-8')#패키징 해제 후 decode
		IoT_bearing_VibPath = struct.unpack(str(path_length1)+'s',Packet[1][4:])[0].decode('utf-8')#패키징 해제 후 decode
		IoT_Sound_Path = struct.unpack(str(path_length2)+'s',Packet[2][4:])[0].decode('utf-8')#패키징 해제 후 decode
		Stack_Speed_Path = struct.unpack(str(path_length3)+'s',Packet[3][4:])[0].decode('utf-8')#패키징 해제 후 decode
		Fault_frequency = struct.unpack(str(path_length4)+'s',Packet[4][4:])[0].decode('utf-8')#패키징 해제 후 decode
		Vib_Thre_Path = struct.unpack(str(path_length5)+'s',Packet[5][4:])[0].decode('utf-8')#패키징 해제 후 decode
		SpecPath = struct.unpack(str(path_length6)+'s',Packet[6][4:])[0].decode('utf-8')#패키징 해제 후 decode
		return IoT_motor_VibPath, IoT_bearing_VibPath, IoT_Sound_Path, Stack_Speed_Path, Fault_frequency, Vib_Thre_Path, SpecPath
	elif(type_num == 81): #소음 임계치 산출 알고리즘
		Packet = Packet_Slice(rcv_data)
		Packet_num=len(Packet)
		print("Packet_num:", Packet_num)
		path_length = []
		Sound_path = []
		for i in range(Packet_num): #경로길이 얻기
			print(int.from_bytes(Packet[i][2:4], byteorder = 'big'))
			path_length.append(int.from_bytes(Packet[i][2:4], byteorder = 'big'))
		for i in range(Packet_num-1): #패키징 해제 후 decode 작업
			Sound_path.append(struct.unpack(str(path_length[i])+'s',Packet[i][4:])[0].decode('utf-8'))
		SpecPath = struct.unpack(str(path_length[-1])+'s',Packet[-1][4:])[0].decode('utf-8')#패키징 해제 후 decode
		return Sound_path, SpecPath
	elif(type_num == 97): #진동 임계치 산출 알고리즘
		Packet = Packet_Slice(rcv_data)
		Packet_num=len(Packet)
		path_length = []
		vib_Path = []
		for i in range(Packet_num): #경로길이 얻기
			path_length.append(int.from_bytes(Packet[i][2:4], byteorder = 'big'))
		for i in range(Packet_num-1): #패키징 해제 후 decode 작업
			vib_Path.append(struct.unpack(str(path_length[i])+'s',Packet[i][4:])[0].decode('utf-8'))
		SpecPath = struct.unpack(str(path_length[-1])+'s',Packet[-1][4:])[0].decode('utf-8')#패키징 해제 후 decode
		return vib_Path, SpecPath
	elif(type_num == 113): #결함 주파수 산출 알고리즘
		Packet = Packet_Slice(rcv_data)
		path_length0 = int.from_bytes(Packet[0][2:4], byteorder = 'big')#경로길이 얻기		
		SpecPath = struct.unpack(str(path_length0)+'s',Packet[0][4:])[0].decode('utf-8')#패키징 해제 후 decode
		return SpecPath
	else :
		return 255 #이것 외의 패킷 전송은 무조건 에러코드


#프로토콜 종류에 맞추어 데이터를 구조체로 패킹
def Struct_Pack(algo_num, snd_data) :
	print("Packing process")
	if(algo_num==1): #이상소음감지 판단 결과
		print("이상소음감지 패킷 처리")
		#print(type(snd_data[0]), type(snd_data[1]),type(snd_data[2]))
		WI = float(snd_data[0])
		ls_Op = int(snd_data[1])
		ls_W = int(snd_data[2])
		Err_Code = snd_data[3]
		Err_String = snd_data[4]
		print("이상소음감지 패킷 처리 끝")
		s = struct.Struct('!BBHBBBBHfBBHBBBH'+str(len(Err_String))+'s')
		return s.pack(2, 10, 2, ls_Op, ls_W, 2, 11, 4, WI, 2, 12, 1, Err_Code, 2, 13, len(Err_String), Err_String.encode('utf-8'))
	elif(algo_num==2): #진동등급 결과
		print("진동등급 결과 패킷 처리")
		FFT_path = snd_data[0]
		resultX_ToDay = snd_data[1]
		resultY_ToDay = snd_data[2]
		resultZ_ToDay = snd_data[3]
		gradeX_ToDay = snd_data[4]
		gradeY_ToDay = snd_data[5]
		gradeZ_ToDay = snd_data[6]
		thresholdX_YN = snd_data[7]
		thresholdY_YN = snd_data[8]
		thresholdZ_YN = snd_data[9]
		Err_Code = snd_data[10]
		Err_String = snd_data[11]
		print(resultX_ToDay, resultY_ToDay, resultZ_ToDay, gradeX_ToDay, gradeY_ToDay, gradeZ_ToDay, thresholdX_YN, thresholdY_YN, thresholdZ_YN, FFT_path)
		_str='!BBH'+str(len(FFT_path))+'s'+'BBHfffcccccc'+'BBHBBBH'+str(len(Err_String))+'s'
		s = struct.Struct(_str)
		print("진동등급 패킷 처리 끝")
		return s.pack(2,26,len(FFT_path),FFT_path.encode('utf-8'),2,27,18,resultX_ToDay, resultY_ToDay, resultZ_ToDay, gradeX_ToDay.encode('utf-8'), gradeY_ToDay.encode('utf-8'), gradeZ_ToDay.encode('utf-8'), thresholdX_YN.encode('utf-8'), thresholdY_YN.encode('utf-8'), thresholdZ_YN.encode('utf-8'), 2, 28, 1, Err_Code, 2, 29, len(Err_String), Err_String.encode('utf-8'))
	elif(algo_num==3): #진동진단 판단 결과
		print("진동판단 결과 패킷 처리")
		list_length = snd_data[0]
		fail_list = snd_data[1]
		Err_Code = snd_data[2]
		Err_String = snd_data[3]
		s = struct.Struct('!BBH'+str(list_length)+'B'+'BBHBBBH'+str(len(Err_String))+'s')
		print("고장유형개수:",list_length)
		print("진동판단 결과 패킷 처리 끝")
		return s.pack(2, 42, list_length, *fail_list, 2, 43, 1, Err_Code, 2, 44, len(Err_String), Err_String.encode('utf-8'))
	elif(algo_num==4): #체인 상태진단 결과
		c_elongation = snd_data[0]
		c_length = snd_data[1]
		s = struct.Struct('!BBHff')
		print("체인 신율측정 결과 패킷 처리 끝")
		return s.pack(2, 52, c_elongation, c_length)
	elif(algo_num==5): #스텝체인 좌/우 신율 틀어짐 수치 결과
		c_warp = snd_data[0]
		s = struct.Struct('!BBHf')
		return s.pack(2,56,c_warp)
	elif(algo_num==6): #V벨트 상태진단요청 결과
		print("V벨트 진단요청")
		elongation = snd_data[0]
		tran_effi = snd_data[1]
		rank = snd_data[2]
		Abnormality = snd_data[3]
		Drive_pulley = snd_data[4]
		Driven_pulley = snd_data[5]
		Err_Code = snd_data[6]
		Err_String = snd_data[7]
		s = struct.Struct('!BBHffBBHcBBHcBBHffBBHBBBH'+str(len(Err_String))+'s')
		print("V벨트 진단요청 결과 패킷 처리 끝")
		return s.pack(2, 74, 8, elongation, tran_effi, 2, 75, 1, rank.encode('utf-8'),  2, 76, 1, Abnormality.encode('utf-8'), 2, 77, 8, Drive_pulley, Driven_pulley, 2, 78, 1, Err_Code, 2, 79, len(Err_String), Err_String.encode('utf-8'))
	elif(algo_num==7):
		print("소음 임계치 산출 요청")
		Sound_Thre_path = snd_data[0]
		Sound_Stack_path = snd_data[1]
		Err_Code = snd_data[2]
		Err_String = snd_data[3]
		s = struct.Struct('!BBH'+str(len(Sound_Thre_path))+'s'+'BBH'+str(len(Sound_Stack_path))+'s'+'BBHBBBH'+str(len(Err_String))+'s')
		print("소음 임계치 산출 결과 패킷 처리 끝")
		return s.pack(2, 92, len(Sound_Thre_path), Sound_Thre_path.encode('utf-8'), 2, 93, len(Sound_Stack_path), Sound_Stack_path.encode('utf-8'), 2, 94, 1, Err_Code, 2, 95, len(Err_String), Err_String.encode('utf-8'))
	elif(algo_num==8):
		print("진동 임계치 산출 요청")
		Vib_Thre_path = snd_data[0]
		Vib_Motor_Stack_path = snd_data[1]
		Vib_Bearing_Stack_path = snd_data[2]
		Err_Code = snd_data[3]
		Err_String = snd_data[4]
		s = struct.Struct('!BBH'+str(len(Vib_Thre_path))+'s'+'BBH'+str(len(Vib_Motor_Stack_path))+'s'+'BBH'+str(len(Vib_Bearing_Stack_path))+'s'+'BBHBBBH'+str(len(Err_String))+'s')
		print("진동 임계치 산출 결과 패킷 처리 끝")
		return s.pack(2, 108, len(Vib_Thre_path), Vib_Thre_path.encode('utf-8'), 2, 109, len(Vib_Motor_Stack_path), Vib_Motor_Stack_path.encode('utf-8'), 2, 110, len(Vib_Bearing_Stack_path), Vib_Bearing_Stack_path.encode('utf-8'), 2, 111, 1, Err_Code, 2, 112, len(Err_String), Err_String.encode('utf-8'))
	elif(algo_num==9):
		print("결함주파수 산출 요청")
		Fault_freq_path = snd_data[0]
		Err_Code = snd_data[1]
		Err_String = snd_data[2]		
		s = struct.Struct('!BBH'+str(len(Fault_freq_path))+'s'+'BBHBBBH'+str(len(Err_String))+'s')
		print("결함주파수 산출 결과 패킷 처리 끝")
		return s.pack(2, 122, len(Fault_freq_path), Fault_freq_path.encode('utf-8'), 2, 123, 1, Err_Code, 2, 124, len(Err_String), Err_String.encode('utf-8'))
	elif(algo_num==255): #에러패킷 패킹
		print("error packet type:", snd_data)
		s = struct.Struct('!BBHB')
		return s.pack(2,int(snd_data),1,255)

	else :
		return 255



HOST = '127.0.0.1'
PORT = 9300

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
	s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
	s.bind((HOST, PORT))
	s.listen()
	print("=============================================================")
	print("start server")
	print("start time: ",datetime.datetime.now())
	print("=============================================================")
	while True:
		conn, addr = s.accept()
		with conn:
			print("[",datetime.datetime.now(),"]","debugging test, connected by", addr)
			while True:
				data = conn.recv(2048)
				if not data:
					print("[",datetime.datetime.now(),"]","not data")
					break
				try:
					PType = PTypeCheck(data)
					print("PType: ",PType)
					if (PType == 1) :#이상소음 감지요청 - 완
						print(">>[",datetime.datetime.now(),"]","이상소음 요청 수신")
						GW_SoundPath, ConditionStackPath, SpecPath, ThresholdPath, GW_Position = Struct_Unpack(PType, data)
						#Chk_Value, Snd_Queue_Data = input_queue(GW_SoundPath) #Queue에 데이터 넣고 np array받환받기
						#WI, ls_Op, ls_W, err, err_code, err_string = Op_Cond_Start(Chk_Value, Snd_Queue_Data,ConditionStackPath, SpecPath, ThresholdPath, GW_Position, 50000)
						print(GW_SoundPath, ConditionStackPath, SpecPath, ThresholdPath, GW_Position)
						#err, WI, ls_Op, ls_W = Op_Cond_Start(ConditionStackPath, 50000, GW_SoundPath)#이상소음 감지 알고리즘 실행
						WI_value, ls_Op, ls_W = noise_analysis(GW_SoundPath, ConditionStackPath, SpecPath, ThresholdPath, GW_Position)
						err = 0
						err_code = 0
						err_string = "Success!"
						if (err == 0):
							snd_data = Struct_Pack(1,[WI_value, ls_Op, ls_W, err_code, err_string])
							conn.sendall(snd_data)
							print(">>[",datetime.datetime.now(),"]","송신완료")
						else :
							snd_data = Struct_Pack(255,5)
							print(snd_data)
							conn.sendall(snd_data)
							print(">>[",datetime.datetime.now(),"]","에러 패킷 송신완료")	
					elif (PType == 17) : #진동등급 요청 - 완
						print(">>[",datetime.datetime.now(),"]","진동등급 요청 수신")
						IoT_VibPath, RMSStackPath, SensorPosition, SpecPath = Struct_Unpack(PType, data)
						print(IoT_VibPath, RMSStackPath, SensorPosition, SpecPath)
						err_string = "Success!"
						err_code, resultX_ToDay, resultY_ToDay, resultZ_ToDay, gradeX_ToDay, gradeY_ToDay, gradeZ_ToDay, thresholdX_YN, thresholdY_YN, thresholdZ_YN, FFT_path = vib_rank(IoT_VibPath, SensorPosition, RMSStackPath, SpecPath)
						err = 0
						if (err == 0):
							snd_data = Struct_Pack(2,[FFT_path, resultX_ToDay, resultY_ToDay, resultZ_ToDay, gradeX_ToDay, gradeY_ToDay, gradeZ_ToDay, thresholdX_YN, thresholdY_YN, thresholdZ_YN, err_code, err_string])
							print(snd_data)
							conn.sendall(snd_data)
							print(">>[",datetime.datetime.now(),"]","송신완료")
						else :
							snd_data = Struct_Pack(255,22)
							print(snd_data)
							conn.sendall(snd_data)
							print(">>[",datetime.datetime.now(),"]","에러 패킷 송신완료")
					elif (PType == 33) : #진동진단 요청 - 완
						print(">>[",datetime.datetime.now(),"]","진동진단 요청 수신")
						IoT_VibPath, Fault_frequency, Vib_Thre_Path, SensorDirection, SensorLocation, SpecPath = Struct_Unpack(PType, data)
						print(IoT_VibPath, Fault_frequency, Vib_Thre_Path, SensorDirection, SensorLocation, SpecPath)
						err_code = 0
						err_string = "Success!"
						err_code, list_length, fail_list = vib_fault_analysis(SpecPath, Fault_frequency, Vib_Thre_Path, IoT_VibPath, SensorLocation)
						err = 0
						if (err == 0):
							snd_data = Struct_Pack(3,[list_length, fail_list, err_code, err_string])
							print(snd_data)
							conn.sendall(snd_data)
							print(">>[",datetime.datetime.now(),"]","송신완료")
						else :
							snd_data = Struct_Pack(255,37)
							print(snd_data)
							conn.sendall(snd_data)
							print(">>[",datetime.datetime.now(),"]","에러 패킷 송신완료")
					elif (PType == 49) : #체인 상태진단 요청 <미사용>
						#MSpecJsonPath, IoT_SoundPath, SensorPosition
						continue
					elif (PType == 54) : #체인 틀어짐 진단 요청 <미사용>
						#IoT_SoundPath_L, IoT_SoundPath_R
						continue
					elif (PType == 65) : #V벨트 상태진단 요청 - 완
						print(">>[",datetime.datetime.now(),"]","V벨트상태진단 요청 수신")
						IoT_motor_VibPath, IoT_bearing_VibPath, IoT_Sound_Path, Stack_Speed_Path, Fault_frequency, Vib_Thre_Path, SpecPath = Struct_Unpack(PType, data)
						print(IoT_motor_VibPath, IoT_bearing_VibPath, IoT_Sound_Path, Stack_Speed_Path, Fault_frequency, Vib_Thre_Path, SpecPath)
						rank = 'A'
						Abnormality = 'N'
						err_string = "Success!"
						err_code, elongation, tran_effi, Drive_pulley, Driven_pulley = v_belt_diag(SpecPath, IoT_motor_VibPath, IoT_bearing_VibPath, IoT_Sound_Path)
						err = 0
						if(err == 0) :
							snd_data = Struct_Pack(6,[elongation, tran_effi, rank, Abnormality, Drive_pulley, Driven_pulley, err_code, err_string])
							print(snd_data)
							conn.sendall(snd_data)
							print(">>[",datetime.datetime.now(),"]","송신완료")
						else : 
							snd_data = Struct_Pack(255,71)
							print(snd_data)
							conn.sendall(snd_data)
							print(">>[",datetime.datetime.now(),"]","에러 패킷 송신완료")
					elif (PType == 81):#소음 임계치 산출 요청 - 완
						print(">>[",datetime.datetime.now(),"]","소음 임계치 산출 요청 수신")
						noise_path, Spec_Path = Struct_Unpack(PType, data)
						print(noise_path, Spec_Path)
						#테스트 데이터 입력
						Sound_Thre_path, Sound_Stack_path = noise_shreshold_calc(noise_path, Spec_Path)
						#Sound_Thre_path = os.path.abspath("./file/sond_threshold.json")
						#Sound_Stack_path = os.path.abspath("./file/StackCondition.txt")
						err_code = 0						
						err_string = "Success!"
						#테스트 데이터 입력 끝
						err = 0
						if(err == 0) :
							snd_data = Struct_Pack(7,[Sound_Thre_path, Sound_Stack_path, err_code, err_string])
							print(snd_data)
							conn.sendall(snd_data)
							print(">>[",datetime.datetime.now(),"]","송신완료")
						else :
							snd_data = Struct_Pack(255,72)
							print(snd_data)
							conn.sendall(snd_data)
							print(">>[",datetime.datetime.now(),"]","에러 패킷 송신완료")
					elif (PType == 97):#진동 임계치 산출 요청 - 완
						print(">>[",datetime.datetime.now(),"]","진동 임계치 산출 요청 수신")
						vib_path, Spec_Path = Struct_Unpack(PType, data)
						print(vib_path, Spec_Path)
						err_code = 0						
						err_string = "Success!"
						vib_motor_path = []
						vib_bearing_path = []
						for i in range(len(vib_path)):
							if (i%2!=0):
    								vib_motor_path.append(vib_path[i])
							else:
    								vib_bearing_path.append(vib_path[i])
						[Vib_Motor_Stack_path, vib_Bearing_Stack_path], Vib_Thre_path=fft_threshold_calc(vib_motor_path, vib_bearing_path, Spec_Path)
						err = 0
						if(err == 0) :
							snd_data = Struct_Pack(8,[Vib_Thre_path, Vib_Motor_Stack_path,vib_Bearing_Stack_path, err_code, err_string])
							print(snd_data)
							conn.sendall(snd_data)
							print(">>[",datetime.datetime.now(),"]","송신완료")
						else : 
							snd_data = Struct_Pack(255,73)
							print(snd_data)
							conn.sendall(snd_data)
							print(">>[",datetime.datetime.now(),"]","에러 패킷 송신완료")
					elif (PType == 113):#결함주파수 산출 - 완
						print(">>[",datetime.datetime.now(),"]","결함주파수 산출 요청 수신")
						Spec_Path = Struct_Unpack(PType, data)
						print(Spec_Path)
						err_code = 0						
						err_string = "Success!"
						Fault_freq_path = fail_freq_json_path(Spec_Path)
						err = 0
						if(err == 0) :
							snd_data = Struct_Pack(9,[Fault_freq_path, err_code, err_string])
							print(snd_data)
							conn.sendall(snd_data)
							print(">>[",datetime.datetime.now(),"]","송신완료")
						else : 
							snd_data = Struct_Pack(255,70)
							print(snd_data)
							conn.sendall(snd_data)
							print(">>[",datetime.datetime.now(),"]","에러 패킷 송신완료")
					else : 
						print(">>Protocol Typer Error!")
				except Exception as e:
					exc_type, exc_obj, exc_tb = sys.exc_info()
					fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
					print("------------------------------------------------------")
					print("Time: ",datetime.datetime.now())
					print("------------------------------------------------------")
					print('fail error:',e)
					print(exc_type, fname, exc_tb.tb_lineno)
					print("------------------------------------------------------")
# vib_fault_analysis : 기계설비 고장유형 진동 진단(main function)
import sys
import os
import numpy as np
from scipy import signal

from file.func_module.acc_int import acc_int
from file.func_module.fail_freq_calc import fail_freq_calc
from file.func_module.fault_fp_diagnosis import motor_fault_fp_diagnosis, rotor_fault_fp_diagnosis, bearing_fault_fp_diagnosis, \
    belt_fault_fp_diagnosis, fan_fault_fp_diagnosis
from file.func_module.read_json import read_json
import file.func_module.redis_fct as rdf

# import matplotlib.pyplot as plt


def print_fault_type(fail_list):
    """ 진동 결함 유형 print

    :param list[int] fail_list: 진동 결함 진단 결과 - 결함 유형 list
    :return:
    """
    # 결함유형
    for fl in range(len(fail_list)):
        if fail_list[fl] == 255:
            print("정상")
        elif fail_list[fl] <= 31:
            # print("기어 결함")
            if fail_list[fl] == 1:
                print("기어 이 마모")
            elif fail_list[fl] == 2:
                print("기어 이 과부하")
            elif fail_list[fl] == 3:
                print("기어 편심 및 백래쉬")
            elif fail_list[fl] == 4:
                print("기어 정렬불량")
            elif fail_list[fl] == 5:
                print("기어 이 크랙, 빠짐, 부러짐")
            elif fail_list[fl] == 6:
                print("기어 편심 또는 헐거움")
            elif fail_list[fl] == 7:
                print("양측 기어 마멸")
        elif fail_list[fl] <= 63 and fail_list[fl] > 31:
            # print("전동기 결함")
            if fail_list[fl] == 33:
                print("고정자 편심")
            elif fail_list[fl] == 34:
                print("회전자 편심")
            elif fail_list[fl] == 35:
                print("회전자 바 균열, 절단")
            elif fail_list[fl] == 36:
                print("풀리거나 개방된 회전자 바")
            elif fail_list[fl] == 37:
                print("회전자의 국부과열로 인한 휨 상태")
            elif fail_list[fl] == 38:
                print("전기적 위상 문제")
            elif fail_list[fl] == 39:
                print("고정자 코일 풀림")
            elif fail_list[fl] == 40:
                print("고정자 단락(stator short)")
        elif fail_list[fl] <= 95 and fail_list[fl] > 63:
            # print("회전체 결함")
            if fail_list[fl] == 65:
                print("질량불평형")
            elif fail_list[fl] == 66:
                print("축정렬불량(편각)")
            elif fail_list[fl] == 67:
                print("축정렬불량(편심)")
            elif fail_list[fl] == 68:
                print("회전 헐거움(부적절한 끼워맞춤, 베어링 헐거움)")
            elif fail_list[fl] == 69:
                print("회전 헐거움(과다 간극, 심각한 헐거움)")
            elif fail_list[fl] == 70:
                print("구조적 헐거움(유연체, 강성 부족, 텐션부족)")
            elif fail_list[fl] == 71:
                print("축상에서 비틀린 베어링")
        elif fail_list[fl] <= 127 and fail_list[fl] > 95:
            # print("베어링 결함")
            if fail_list[fl] == 97:
                print("베어링 외륜 결함")
            elif fail_list[fl] == 98:
                print("베어링 내륜 결함")
            elif fail_list[fl] == 99:
                print("베어링 볼 결함")
            elif fail_list[fl] == 100:
                print("베어링 부적절 윤활")
            elif fail_list[fl] == 101:
                print("베어링 헐거움(축과 베어링)")
            elif fail_list[fl] == 102:
                print("베어링 헐거움(베어링과 하우징)")
        elif fail_list[fl] <= 159 and fail_list[fl] > 127:
            if fail_list[fl] == 129:
                print("축 베어링 외륜 결함")
            elif fail_list[fl] == 130:
                print("축 베어링 내륜 결함")
            elif fail_list[fl] == 131:
                print("축 베어링 볼 결함")
            elif fail_list[fl] == 132:
                print("축 베어링 부적절 윤활")
            elif fail_list[fl] == 133:
                print("축 베어링 헐거움(축과 베어링)")
            elif fail_list[fl] == 134:
                print("축 베어링 헐거움(베어링과 하우징)")
            elif fail_list[fl] == 135:
                print("축 베어링 회전 헐거움(과다 간극, 심각한 헐거움)")
            elif fail_list[fl] == 136:
                print("축 베어링 구조적 헐거움(유연체, 강성 부족, 텐션부족)")
            elif fail_list[fl] == 137:
                print("송풍기 결함")
        elif fail_list[fl] <= 191 and fail_list[fl] > 159:
            # print("V벨트 결함")
            if fail_list[fl] == 161:
                print("V벨트 마모 및 풀림")
            elif fail_list[fl] == 162:
                print("V벨트 불평형")
            elif fail_list[fl] == 163:
                print("V벨트 편심 및 이탈")
            elif fail_list[fl] == 164:
                print("V벨트 공진")


def iot_sensor_axis_find(axis_info, fft_x, fft_y, fft_z):
    sh_fft = np.array([])
    vr_fft = np.array([])
    hr_fft = np.array([])
    if axis_info['shaft'] == "x" and axis_info['horizon'] == "y":
        sh_fft = fft_x
        vr_fft = fft_z
        hr_fft = fft_y
    elif axis_info['shaft'] == "x" and axis_info['horizon'] == "z":
        sh_fft = fft_x
        vr_fft = fft_y
        hr_fft = fft_z
    elif axis_info['shaft'] == "y" and axis_info['horizon'] == "x":
        sh_fft = fft_y
        vr_fft = fft_z
        hr_fft = fft_x
    elif axis_info['shaft'] == "y" and axis_info['horizon'] == "z":
        sh_fft = fft_y
        vr_fft = fft_x
        hr_fft = fft_z
    elif axis_info['shaft'] == "z" and axis_info['horizon'] == "x":
        sh_fft = fft_z
        vr_fft = fft_y
        hr_fft = fft_x
    elif axis_info['shaft'] == "z" and axis_info['horizon'] == "y":
        sh_fft = fft_z
        vr_fft = fft_x
        hr_fft = fft_y

    return sh_fft, vr_fft, hr_fft


def vib_overall_calc(fft_data):
    # overall 계산식
    fft_data = fft_data[10:1001]
    sum_fft = (np.sum(fft_data ** 2)) / 1.5
    overall = np.round(np.sqrt(sum_fft), 4)

    return overall


def vib_fault_analysis(mechanical_spec_path, fault_freq_path, fft_threshold_path, data_file_absolute_path, sensor_pos):
    """ 진동 결함 진단

    :param string mechanical_spec_path: 설비 정보 json 파일 절대 경로
    :param string data_file_absolute_path: 진동 데이터 파일 절대 경로
    :param string fault_freq_path: 결함주파수 json 파일 절대 경로
    :param string fft_threshold_path: 진동 임계치 json 파일 절대 경로
    :param int sensor_pos: 센서 부착 위치 정보
    :return:
    """

    try:
        # Sample rate(Hz)
        Fs = 2000

        # 기계 설비 스펙 정보 불러오기(json)
        mes = read_json(mechanical_spec_path)
        motor_info = [[float(mes['Motor']['Power']),
                       float(mes['Motor']['F_L']),
                       mes['Motor']['Reducer_YN'],
                       float(mes['Motor']['m_volt']),
                       float(mes['Motor']['RatedSpeed']),
                       float(mes['Motor']['RPM']),
                       float(mes['Motor']['P']),
                       int(mes['Motor']['RotorBars']),
                       int(mes['Motor']['Blades']),
                       int(mes['Motor']['CN']),
                       int(mes['Motor']['ReducerStageNum']),
                       float(mes['Motor']['ReducerRatioL']),
                       float(mes['Motor']['ReducerRatioR']),
                       int(mes['Motor']['mpt_type'])]]

        # redis에서 회전주파수 read
        rd = rdf.rd_conn('localhost', 6379, 0)
        rd_drv = rdf.rd_get(rd, "drv")
        rd_drvn = rdf.rd_get(rd, "drvn")

        if rd_drv is not None or rd_drvn is not None:
            if rd_drv is not None:
                mes['Facility']['DriveRPM'] = float(rd_drv.decode()) * 60
            if rd_drvn is not None:
                mes['Facility']['DrivenRPM'] = float(rd_drvn.decode()) * 60

        N_S_RPM, N_S, F_r, F_S, F_P, RBPF, BPF, CPF, m_GMF, ndcl_freq_list, DrivenPulleyRPM, nb_freq_list, vbelt_f, Fan_F_r = fail_freq_calc(
            mes['Facility'], mes['Motor'], mes['Decelerator'], mes['Bearing'], mes['Pulley'], mes['Vbelt'], mes['Fan'], [[]], [[]])
        motor_fail_freq = [[N_S_RPM, N_S, F_r, F_S, F_P, RBPF, BPF, CPF, m_GMF]]
        ndcl_fail_freq = ndcl_freq_list
        nb_fail_freq = nb_freq_list
        acm_fail_freq = [[DrivenPulleyRPM, vbelt_f, Fan_F_r]]

        # 진동 결함진단 임계치 불러오기(json)
        vib_th_arry = read_json(fft_threshold_path)

        # FFT Hz 최대값
        hz_max = 950
        # FFT Hz 최소값
        hz_min = 10

        # 진동 데이터 분석
        # 분석대상 파일 읽기
        f = open(data_file_absolute_path, 'r')
        lines = f.readlines()
        _x = []
        _y = []
        _z = []
        for i in range(len(lines)):
            _x.append(lines[i].split(' ')[0])
            _y.append(lines[i].split(' ')[1])
            _z.append(lines[i].split(' ')[2])

        _x = np.array(_x)
        _y = np.array(_y)
        _z = np.array(_z)
        _x = _x.astype(float)
        _y = _y.astype(float)
        _z = _z.astype(float)

        # 진동 데이터 FFT 변환 및 분석
        # 진동 X, Y, Z축 FFT
        fft_x = acc_int(_x, Fs)
        fft_y = acc_int(_y, Fs)
        fft_z = acc_int(_z, Fs)

        fft_x = fft_x * 30
        fft_y = fft_y * 30
        fft_z = fft_z * 30

        # promi = 0.005
        # x_peaks, properties = signal.find_peaks(x_fft, prominence=promi)

        # 결함 진단 함수
        # 0xFF는 에러
        if sensor_pos == 255:  # 에러
            print("센서 위치 오류(0xFF)")
            fail_result_list = [1, 2, 3]
            return 255, len(fail_result_list), fail_result_list
        elif sensor_pos == 1:  # 전동기/감속기
            sh_fft, vr_fft, hr_fft = iot_sensor_axis_find(mes['MO-RE'], fft_x, fft_y, fft_z)
            sh_overall = vib_overall_calc(sh_fft)
            vr_overall = vib_overall_calc(vr_fft)
            hr_overall = vib_overall_calc(hr_fft)

            # find peaks
            sh_peaks, properties = signal.find_peaks(sh_fft)
            # vr_peaks, properties = signal.find_peaks(vr_fft)
            hr_peaks, properties = signal.find_peaks(hr_fft)

            # plt.figure()
            # plt.plot(sh_fft)
            # plt.plot(sh_peaks, sh_fft[sh_peaks], "x")
            # plt.show()

            # plt.figure()
            # plt.plot(vr_fft)
            # plt.plot(vr_peaks, vr_fft[vr_peaks], "x")
            # plt.show()

            # plt.figure()
            # plt.plot(hr_fft)
            # plt.plot(hr_peaks, hr_fft[hr_peaks], "x")
            # plt.show()

            # 전동기 결함
            mf_list = motor_fault_fp_diagnosis(sensor_pos, mes['MO-RE']['horizon'], vib_th_arry, hr_fft, hr_peaks, hz_max,
                                               hz_min, motor_fail_freq[0][2], motor_fail_freq[0][4], motor_info,
                                               motor_fail_freq[0][5], motor_fail_freq[0][3], motor_fail_freq[0][7])

            # 회전체 결함
            rf_list = rotor_fault_fp_diagnosis(sensor_pos, mes['MO-RE']['shaft'], mes['MO-RE']['horizon'], vib_th_arry,
                                               sh_fft, sh_peaks, sh_overall, vr_overall, hr_fft, hr_peaks, hr_overall,
                                               hz_max, hz_min, motor_fail_freq[0][2], acm_fail_freq[0][0])

            # 베어링 결함
            bf_list = bearing_fault_fp_diagnosis(sensor_pos, mes['MO-RE']['horizon'], vib_th_arry, hr_fft, hr_peaks,
                                                 hz_max, hz_min, nb_fail_freq, motor_fail_freq[0][2],
                                                 acm_fail_freq[0][0], motor_info, ndcl_fail_freq)

            # V-벨트 결함
            belt_f_list = belt_fault_fp_diagnosis(sensor_pos, mes['MO-RE']['shaft'], mes['MO-RE']['horizon'], vib_th_arry,
                                                  sh_fft, sh_peaks, hr_fft, hr_peaks, hz_max, hz_min,
                                                  acm_fail_freq[0][1], motor_fail_freq[0][2], acm_fail_freq[0][0],
                                                  acm_fail_freq[0][2])

            # 기어 결함
            # gf_list = gear_fault_fp_diagnosis(
            #     overlap_fft_x, x_peaks, 0, angular_resolution, hz_max, hz_min, m_GMF, F_r, ndcl_freq_list)

            if mf_list == -1 or rf_list == -1 or bf_list == -1 or belt_f_list == -1:
                print("전동기 부품별 결함 진단 에러 발생")
                print("전동기 결함(mf_list) : ", mf_list, " | 회전체 결함(rf_list) : ", rf_list, " | 베어링 결함(bf_list) : ", bf_list, " | V-벨트 결함(belt_f_list) : ", belt_f_list)
                fail_result_list = []
                return 255, len(fail_result_list), fail_result_list
            else:
                # fail_result_list = mf_list + gf_list + rf_list + bf_list + belt_f_list
                fail_result_list = mf_list + rf_list + bf_list + belt_f_list

                if not fail_result_list:
                    l = [int('0b11111111', 2)]
                    fail_result_list = fail_result_list + l
                else:
                    # 진단결과 중복 제거
                    fail_set = set(fail_result_list)  # 집합 set으로 변환
                    fail_result_list = list(fail_set)  # list로 변환

                print_fault_type(fail_result_list)

                return 0, len(fail_result_list), fail_result_list

        elif sensor_pos == 2 or sensor_pos == 3:  # 축베어링
            sh_fft, vr_fft, hr_fft = iot_sensor_axis_find(mes['L-SH-BE'], fft_x, fft_y, fft_z)
            sh_overall = vib_overall_calc(sh_fft)
            vr_overall = vib_overall_calc(vr_fft)
            hr_overall = vib_overall_calc(hr_fft)

            # find peaks
            sh_peaks, properties = signal.find_peaks(sh_fft)
            # vr_peaks, properties = signal.find_peaks(vr_fft)
            hr_peaks, properties = signal.find_peaks(hr_fft)

            # 베어링 결함
            bf_list = bearing_fault_fp_diagnosis(sensor_pos, mes['L-SH-BE']['horizon'], vib_th_arry, hr_fft, hr_peaks,
                                                 hz_max, hz_min, nb_fail_freq, motor_fail_freq[0][2],
                                                 acm_fail_freq[0][0], motor_info, ndcl_fail_freq)

            # 회전체 결함
            rf_list = rotor_fault_fp_diagnosis(sensor_pos, mes['L-SH-BE']['shaft'], mes['L-SH-BE']['horizon'],
                                               vib_th_arry, sh_fft, sh_peaks, sh_overall, vr_overall, hr_fft, hr_peaks,
                                               hr_overall, hz_max, hz_min, motor_fail_freq[0][2], acm_fail_freq[0][0])

            # 송풍기 결함
            ff_list = fan_fault_fp_diagnosis(sensor_pos, mes['L-SH-BE']['horizon'], vib_th_arry, hr_fft, hr_peaks, hz_max,
                                             hz_min, acm_fail_freq[0][2])

            if bf_list == -1 or rf_list == -1 or ff_list == -1:
                print("축베어링 부품별 결함 진단 에러 발생")
                print("베어링 결함(bf_list) : ", bf_list, " | 회전체 결함(rf_list) : ", rf_list, " | 송풍기 결함(ff_list) : ", ff_list)
                fail_result_list = []
                return 255, len(fail_result_list), fail_result_list
            else:
                fail_result_list = bf_list + rf_list + ff_list

                if not fail_result_list:
                    l = [int('0b11111111', 2)]
                    fail_result_list = fail_result_list + l
                else:
                    # 진단결과 중복 제거
                    fail_set = set(fail_result_list)  # 집합 set으로 변환
                    fail_result_list = list(fail_set)  # list로 변환

                print_fault_type(fail_result_list)

                return 0, len(fail_result_list), fail_result_list

        # elif sensor_pos == 4:  # 베이스
        #     # 회전체 결함
        #     rf_list = rotor_fault_fp_diagnosis()
        #
        #     fail_result_list = rf_list
        #
        #     if not fail_result_list:
        #         l = [int('0b11111111', 2)]
        #         fail_result_list = fail_result_list + l
        #     else:
        #         # 진단결과 중복 제거
        #         fail_set = set(fail_result_list)  # 집합 set으로 변환
        #         fail_result_list = list(fail_set)  # list로 변환
        #
        #     print_fault_type(fail_result_list)
        #
        #     return 0, len(fail_result_list), fail_result_list

        else:  # 255, 0, 1, 2 값 외의 값이 들어왔을 때
            print("센서 위치 오류(0xFF, 0x00, 0x01, 0x02 이외의 값)")
            fail_result_list = []
            return 255, len(fail_result_list), fail_result_list

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print('fail error:', e)
        print(exc_type, fname, exc_tb.tb_lineno)
        print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
        fail_result_list = []
        return 255, len(fail_result_list), fail_result_list

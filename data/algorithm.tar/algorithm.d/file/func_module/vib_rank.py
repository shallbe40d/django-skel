# _*_ coding: UTF-8 -*-

import os
import numpy as np
import sys

import time

from file.func_module.acc_int import acc_int
from file.func_module.read_json import read_json

"""
Code History
# 2020.09.24 기기 스펙 별 조건 추가
# 2020.09.29 예외처리 구문 추가
# 2020.10.22 입력버그 수정
"""

def vib_rank(IoT_VibPath, SensorPosition, RMSStackPath, MEspecPath):
	""" 진동 ISO 등급 산출

	:param IoT_VibPath: IoT 진동 센서 데이터 파일 절대 경로
	:param SensorPosition: IoT 진동 센서 부착 위치
	:param RMSStackPath: 진동 RMS 누적 파일 절대 경로
	:param MEspecPath : 설비 정보 json 파일 절대 경로
	:return:
	"""
	try:
		Fs = 2000

		# 설비 정보 json 파일 조회
		mes = read_json(MEspecPath)

		# 분석대상 파일 읽기
		f = open(IoT_VibPath, 'r')
		lines = f.readlines()
		_x = []
		_y = []
		_z = []
		for i in range(len(lines)):
			_x.append(lines[i].split(' ')[0])
			_y.append(lines[i].split(' ')[1])
			_z.append(lines[i].split(' ')[2])

		_x = np.array(_x)
		_y = np.array(_y)
		_z = np.array(_z)
		_x = _x.astype('float')
		_y = _y.astype('float')
		_z = _z.astype('float')
	
		# 진동 X, Y, Z축 FFT
		x1 = acc_int(_x, Fs)
		y1 = acc_int(_y, Fs)
		z1 = acc_int(_z, Fs)
		x1 = x1 * 30
		y1 = y1 * 30
		z1 = z1 * 30

		# X축 overall 계산식
		x2 = x1[10:1001]
		sumX = (np.sum(x2**2)) / 1.5
		resultX = np.round(np.sqrt(sumX), 3)
		# Y축 overall 계산식
		y2 = y1[10:1001]
		sumY = (np.sum(y2**2)) / 1.5
		resultY = np.round(np.sqrt(sumY), 3)
		# Z축 overall 계산식
		z2 = z1[10:1001]
		sumZ = (np.sum(z2**2)) / 1.5
		resultZ = np.round(np.sqrt(sumZ), 3)
	
		# overall 등급
		gradeX = 'A'
		gradeY = 'A'
		gradeZ = 'A'

		# ISO 14694 BV-3 강성지지 축베어링
		if SensorPosition == 2 or SensorPosition == 3:
			if resultX >=4.5 and resultX < 7.1:
				gradeX = 'B'
			elif resultX >= 7.1 and resultX < 9.0:
				gradeX = 'C'
			elif resultX >= 9.0:
				gradeX = 'D'
			if resultY >=4.5 and resultY < 7.1:
				gradeY = 'B'
			elif resultY >= 7.1 and resultY < 9.0:
				gradeY = 'C'
			elif resultY >= 9.0:
				gradeY = 'D'
			if resultZ >=4.5 and resultZ < 7.1:
				gradeZ = 'B'
			elif resultZ >= 7.1 and resultZ < 9.0:
				gradeZ = 'C'
			elif resultZ >= 9.0:
				gradeZ = 'D'
		else:
			# ISO 10816-3 중형기계(15~300kW) 탄성지지 전동기/감속기, 베이스, 구동풀리(사용x), 피동풀리(사용x)
			if float(mes['Motor']['Power']) >= 15:
				if resultX >=2.3 and resultX < 4.5:
					gradeX = 'B'
				elif resultX >= 4.5 and resultX < 7.1:
					gradeX = 'C'
				elif resultX >= 7.1:
					gradeX = 'D'
				if resultY >=2.3 and resultY < 4.5:
					gradeY = 'B'
				elif resultY >= 4.5 and resultY < 7.1:
					gradeY = 'C'
				elif resultY >= 7.1:
					gradeY = 'D'
				if resultZ >=2.3 and resultZ < 4.5:
					gradeZ = 'B'
				elif resultZ >= 4.5 and resultZ < 7.1:
					gradeZ = 'C'
				elif resultZ >= 7.1:
					gradeZ = 'D'
			# ISO 10816-3(용량 작음 15kw 미만) 전동기/감속기
			else:
				if resultX >= 1.4 and resultX < 2.8:
					gradeX = 'B'
				elif resultX >= 2.8 and resultX < 4.5:
					gradeX = 'C'
				elif resultX >= 4.5:
					gradeX = 'D'
				if resultY >= 1.4 and resultY < 2.8:
					gradeY = 'B'
				elif resultY >= 2.8 and resultY < 4.5:
					gradeY = 'C'
				elif resultY >= 4.5:
					gradeY = 'D'
				if resultZ >= 1.4 and resultZ < 2.8:
					gradeZ = 'B'
				elif resultZ >= 2.8 and resultZ < 4.5:
					gradeZ = 'C'
				elif resultZ >= 4.5:
					gradeZ = 'D'

		# 누적 RMS 경로 불러오기
		resultX_accumulate = []
		resultY_accumulate = []
		resultZ_accumulate = []
	
		with open(RMSStackPath, 'r') as f:
			for line2 in f:
				tmp = line2.split()
				x = float(tmp[0])
				resultX_accumulate.append(x)
				y = float(tmp[1])
				resultY_accumulate.append(y)
				z = float(tmp[2])
				resultZ_accumulate.append(z)
	
		resultX_5Day = resultX_accumulate[ (len(resultX_accumulate)-5) : (len(resultX_accumulate)) ]
		resultY_5Day = resultY_accumulate[ (len(resultX_accumulate)-5) : (len(resultX_accumulate)) ]
		resultZ_5Day = resultZ_accumulate[ (len(resultX_accumulate)-5) : (len(resultX_accumulate)) ]
	
		# 임계치 계산 후 overall값과 비교
		thresholdX_YorN = 'N'
		thresholdY_YorN = 'N'
		thresholdZ_YorN = 'N'
	
		if ((np.std(resultX_5Day) * 2.5) + (np.mean(resultX_5Day))) < resultX:
			thresholdX_YorN = 'Y'
		if ((np.std(resultY_5Day) * 2.5) + (np.mean(resultY_5Day))) < resultY:
			thresholdY_YorN = 'Y'
		if ((np.std(resultZ_5Day) * 2.5) + (np.mean(resultZ_5Day))) < resultZ:
			thresholdZ_YorN = 'Y'
	
		# 누적 overall 데이터 텍스트 저장하기
		#fid = open(RMSStackPath, 'a')
		#fid.write( str(resultX) + "\t"  + str(resultY) + "\t"  + str(resultZ) + "\n")
		#fid.close()
	
		# fft 텍스트 파일 저장하기
		time_str = time.strftime('%Y%m%d-%H%M%S', time.localtime(time.time()))
		fft_path = os.getcwd() + "/" + time_str + "i" + str(SensorPosition)+".txt"

		fid = open(fft_path, 'wt')
		resultXYZ_str = str(resultX) + "\t" + str(resultY) + "\t" + str(resultZ) + "\n"
		resultNumArray = np.arange(0, 1001)
		XYZ1 = np.c_[x1.reshape(1001, 1), y1.reshape(1001,1), z1.reshape(1001, 1)]
		np.set_printoptions(formatter={'float_kind': lambda x: "{0:0.5f}".format(x)})
		XYZ1 = np.array(XYZ1)
		for row in np.arange(10, 1001):
			XYZ1_str = str(XYZ1[row])
			fid.write(XYZ1_str[1:24] + "\n")
		
		fid.close()
		fft_file_name = fft_path
	
		return 0, resultX, resultY, resultZ, gradeX, gradeY, gradeZ, thresholdX_YorN, thresholdY_YorN, thresholdZ_YorN, fft_file_name
	except Exception as e:
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
		print('fail error:', e)
		print(exc_type, fname, exc_tb.tb_lineno)
		print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
		return 255, 0.0, 0.0, 0.0, 'D', 'D', 'D', 'Y', 'Y', 'Y', 'FFT_path is fail!'
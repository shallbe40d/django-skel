# _*_ coding: UTF-8 -*-
import json
import numpy as np
from numpy.core.arrayprint import DatetimeFormat
import soundfile as sf
import scipy as sp
import os
import math

from scipy.signal import blackman
from scipy import signal
from scipy.spatial import distance
from scipy.fftpack import fft
from scipy.io.wavfile import write
from scipy.signal import find_peaks
#import matplotlib.pyplot as plt

def rms(data):
    _rms = lambda d: np.sqrt ((d ** 2) .sum ()/d.size)
    return _rms(data)



def file_read(_path): #소음 num파일 import
    f=open(_path,"r", encoding="utf-8")
    data = f.readlines()
    f.close()
    for i in range(len(data)):
        data[i] = int(data[i].replace("\n",""))
    data = np.array(data)
    # data, fs = sf.read(_path, channels=1, samplerate=50000, format='RAW', subtype='PCM_16') #게이트웨이용 테스트코드
    sos = signal.bessel(5, 20, "hp", fs=50000, output="sos")
    sig = signal.sosfiltfilt(sos, data)
    return sig



def json_read(_path): #RPM파일을 얻기 위하여 Json import
    drive_RPM = []
    with open(_path) as json_file:
        json_data = json.load(json_file)
        drive_RPM = json_data['Facility']['DriveRPM']
    drive_RPM = float(drive_RPM)
    if drive_RPM ==0.0: #해당 json에 구동 RPM이 없을 경우
        drive_RPM = 1800.0
    return drive_RPM



def json_write(_path, sndop_minthre, sndop_maxthre, sndop_targetfreq, sndop_freqthre, snd_failthre): # Json Write
    data = {}
    data["snd_oper_thre"] = {"min_threshold": str(sndop_minthre), "max_threshold":str(sndop_maxthre), "target_frequency":str(sndop_targetfreq), "frequency_threshold":str(sndop_freqthre)}
    data["snd_fail_thre"] = {"teshold":str(snd_failthre)}
    with open(_path, "w", encoding="utf-8") as outfile:
        json.dump(data, outfile, indent=4)



def txt_write(_path, condi_data): #txt Write
    outfile = open(_path, "w", encoding="utf-8")
    for i in range(len(condi_data)):
        outfile.write(str(condi_data[i])+"\n")
    outfile.close()



def corr_welch_analysis(src, fs):
    #segment_size = 32768
    #segment_size = 131072
    segment_size = 65536
    src = np.array(src) #convert np.array
    #print(type(src[0]))
    if type(src[0]) !="<class 'numpy.float32'>": #check string
        src = src.astype('float32') #convert "float32"
        if(src.max()>=1.0):
            src = (src-src.mean())/2047.0 #data -1 ~ 1 rescale 
    src_corr= signal.correlate(src, src, mode="full")
    # plt.plot(src_corr)
    # plt.show()
    noverlap = segment_size /2
    f, Pxx = signal.welch(src_corr,
                            fs = fs,
                            nperseg = segment_size,
                            average = 'median',
                            window='hanning',
                            nfft = segment_size,
                            scaling = 'spectrum',
                            noverlap = noverlap)
    #print(len(f),len(Pxx))
    # plt.plot(f, Pxx)
    # plt.show()
    # # set 0 dB to energy of sine wave with maximum amplitude - 파워 스팩트럼 출력(log스케일 출력시 아래 주석 제거)
    # ref = (1/np.sqrt(2)**2)   # simply 0.5 ;)
    # p = 10 * np.log10(Pxx/ref)
    # fill_to = -90 * (np.ones_like(p))  # anything below -150dB is irrelevant
    # plt.fill_between(f, p, fill_to )
    # plt.xlim([f[2], f[-1]])
    # plt.ylim([-90, 6])
    # #plt.xscale('log')   # uncomment if you want log scale on x-axis
    # plt.xlabel('f, Hz')
    # plt.ylabel('Power spectrum, dB')
    # plt.grid(True)
    # plt.show()
    return f, Pxx

"""
지정된 주파수와 해당 범위에서 Peak를 탐색하고 해당 피크중 가장 큰 피크값의 인덱스를 반환한다.
-1 반환: 인자 type error
-2 반환: 해당 범위에서 peak를 찾지 못함
정수값 반환: 해당 Peak의 인덱스 값
"""
def rng_peak_detect(src, fs, _targetHz, _range, height=0): 
    minHz = 0
    maxHz = 0
    N = len(src)
    Nq_fs = fs/2.0
    x_hz = np.linspace(0,Nq_fs,len(src))
    # print(type(_range))
    if str(type(_range)).find("list") != -1 :
        minHz = float(_range[0])
        maxHz = float(_range[1])
        minLen = math.floor(len(src)*(_targetHz+minHz)/Nq_fs)
        maxLen = math.ceil(len(src)*(_targetHz+maxHz)/Nq_fs)
        # minLen = round(len(src)*(_targetHz+minHz)/Nq_fs)
        # maxLen = round(len(src)*(_targetHz+maxHz)/Nq_fs)
        # print("minlen: ",minLen)
        # print("maxlen: ",maxLen)
        tmp = src[int(minLen):int(maxLen)]
        peaks, _ = find_peaks(tmp)
        if len(peaks) == 0:
            return -2
        # plt.plot(x_hz, src)
        # plt.show()
        peaks = peaks+minLen
        # print(tmp, peaks)
        #plt.plot(src)
        #plt.plot(peaks, src[peaks], "X")
        #plt.show()
        # print(x_hz[peaks])
        max_value_peak = peaks[0]
        for i in peaks:
            if src[i] >= src[max_value_peak] and x_hz[i] <= _targetHz+maxHz and x_hz[i] >= _targetHz+minHz:
                max_value_peak = i
        return max_value_peak
    elif str(type(_range)).find("float") != -1  or str(type(_range)).find("int") != -1 :
        minHz = _range
        minLen = math.floor(len(src)*(_targetHz+minHz)/Nq_fs)
        maxLen = math.ceil(len(src)*_targetHz/Nq_fs)
        # print("minlen: ",minLen)
        # print("maxlen: ",maxLen)
        tmp = src[int(minLen):int(maxLen)]
        peaks, _ = find_peaks(tmp)
        if len(peaks) == 0:
            return -2
        peaks = peaks+minLen
        # plt.plot(src)
        # plt.plot(peaks, src[peaks], "X")
        # plt.show()
        # print(x_hz[peaks])
        max_value_peak = peaks[0]
        for i in peaks:
            if src[i] >= src[max_value_peak] and x_hz[i] <= _targetHz+maxHz and x_hz[i] >= _targetHz+minHz:
                max_value_peak = i
        return max_value_peak
    else:
        return -1



def noise_shreshold_calc(noise_path, Spec_Path):
    try:
        #저장파일 경로 정의
        _path = "./file/sond_threshold.json"
        _stackpath = "./file/StackCondition.txt"
        drive_RPM = json_read(Spec_Path)
        drive_Hz = drive_RPM/60.0
        print("drive_RPM:", drive_RPM)
        noise_data = []
        print("test0")
        for noise_data_path in noise_path:
            #print("sigdata min: ", sig.min(),"sigdata max: ",sig.max())
            #noise_data.append(sig)
            noise_data.append(file_read(noise_data_path))

        # plt.plot(np.linspace(0,5,250000),noise_data[0])
        # plt.show()
        _rms = []
        _drive_freq_value = []
        _drive_freq_power = []
        peak_min = []
        peak_max = []
        print("test1")
        for data in noise_data:
            #각 데이터의 최대, 최소 피크치 저장
            peak_min.append(data.min())
            peak_max.append(data.max())
            f, Pxx = corr_welch_analysis(data,50000) #자기상관 파워스펙트럼값 반환(X값과 Y값)
            noise_rms = rms(Pxx)
            #주파수 RMS저장
            _rms.append(noise_rms)
            print("noise_rms: ",noise_rms)
            #구동풀리 RPM 1X탐색
            peak_value = rng_peak_detect(Pxx, 50000, drive_Hz, [-2.0, 2.0])
            #print(peak_value)
            #탐색한 주파수 저장
            _drive_freq_value.append(f[peak_value])
            print("탐색된 주파수: ",f[peak_value])
            #탐색한 주파수의 크기 저장
            _drive_freq_power.append(Pxx[peak_value])
            print("탐색된 주파수 크기: ",Pxx[peak_value])
        _rms = np.array(_rms)
        _drive_freq_value = np.array(_drive_freq_value)
        _drive_freq_power = np.array(_drive_freq_power)
        peak_min = np.array(peak_min)
        peak_max = np.array(peak_max)
        json_write(_path, peak_min.min(), peak_max.max(), _drive_freq_value.mean(), _drive_freq_power.mean(), _rms.mean()+_rms.std()*1.5)
        txt_write(_stackpath, _rms)
        # plt.plot(f, Pxx)
        # plt.plot(f[peak_value],Pxx[peak_value], "X")
        # plt.show()
        #피동풀리 RPM 3X탐색
        #peak_value = rng_peak_detect(Pxx, 50000, 32.5454, -2)
        #peak_value = rng_peak_detect(Pxx, 50000, 50.0, [-50.0,50.0])
        # print(peak_value)
        # print(f[peak_value])
        # plt.plot(f, Pxx)
        # plt.plot(f[peak_value],Pxx[peak_value], "X")
        # plt.show()
        _path = os.path.abspath(_path)
        _stackpath = os.path.abspath(_stackpath)
    except Exception as e:
        print('fail error:',e)
    return _path, _stackpath


# ######TEST CODE START######

# _pathlist =["D:\\인천교통공사 공조기\\동막역 json\\소음\\환기\\0_CBBOX-A434F1AB7043_210315_1716N_D.num",
#             "D:\\인천교통공사 공조기\\동막역 json\\소음\\환기\\0_CBBOX-A434F1AB7043_210315_1725N_D.num",
#             "D:\\인천교통공사 공조기\\동막역 json\\소음\\환기\\0_CBBOX-A434F1AB7043_210316_0039N_D.num",
#             "D:\\인천교통공사 공조기\\동막역 json\\소음\\환기\\0_CBBOX-A434F1AB7043_210316_0049N_D.num",
#             "D:\\인천교통공사 공조기\\동막역 json\\소음\\환기\\0_CBBOX-A434F1AB7043_210316_0100N_D.num"
#             ]
# noise_shreshold_calc(_pathlist, "D:\\인천교통공사 공조기\\6월 게이트웨이 알고리즘 서버\\algorithm\\algorithm.d\\file\\Mechanical_Equipment_Spec.json")
# ######TEST CODE END######
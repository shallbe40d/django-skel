
"""
음향신호 기반 공조설비 전동모터 이상진단 솔루션 기능 데모 프로그램.
sewonoh@etri.re.kr

Notes: Python 3.6.9, Ubuntu 18.04 64bit OS 기준으로 작성되었습니다.

(실행방법) $ python demo.py
"""

import gw_ai_solution as gas
import numpy as np
import warnings
warnings.filterwarnings("ignore")


def file_read(_path): #소음 num파일 import
    f=open(_path,"r", encoding="utf-8")
    data = f.readlines()
    f.close()
    for i in range(len(data)):
        data[i] = int(data[i].replace("\n",""))
    data = np.array(data)
    data = data.astype('int16')
    return data



def demo_case1():
    """
    임의의 수치값을 이용하여 본 솔루션의 기능을 시연합니다.

    Notes:
        음향신호는 integer 형식으로 측정 및 전달되는 것을 전제합니다.
        (50kHz sampling rates, 5 seconds, 12비트 integer)

    Returns:
        전동기 이상음 판단 결과: integer {0, 1, 2};
            0: 가동되지 않는 싱태 (=정지상태),
            1: 가동되고 있는 정상 수준의 상태,
            2: 가동되고 있는 비정상 수준의 상태.
    """
    print("="*20, demo_case1.__name__)
    
    #signal_int16 = np.random.randint(0, 4095, 250000, dtype='int16')
    signal_int16 = file_read("/home/intsain/workspace/ictr/gateway/main/data/regular/210729/ICTR01_I_G_210729124833.num")
    print(">> input shape: {}, dtype: {}".format(np.shape(signal_int16), signal_int16.dtype))

    result = gas.analyze(signal_int16)
    print(">> result: ", result)


def demo_case2(dataset_path):
    """
    음향신호 몇 건을 이용하여 본 솔루션의 기능을 시연합니다.

    Args:
        dataset_path:
            음향신호 저장 위치

    Returns:
        전동기 이상음 판단 결과: integer {0, 1, 2};
            0: 가동되지 않는 싱태 (=정지상태),
            1: 가동되고 있는 정상 수준의 상태,
            2: 가동되고 있는 비정상 수준의 상태.
    """
    print("="*20, demo_case2.__name__)

    import os
    dataset_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), dataset_path))
    files = os.listdir(dataset_dir)
    files2 = []
    for file in files:
        if ".raw" in file:
            files2.append(file)
    for file in files2:
        file_path = os.path.join(dataset_dir, file)
        signal_int16 = np.fromfile(file_path, dtype='int16')
        print(">> {file}: {pred}".format(file=file, pred=gas.analyze(signal_int16)))


if __name__ == '__main__':

#    gas.get_version()

    demo_case1()

    demo_case2("/home/intsain/workspace/ictr/gateway/main/data/regular/210729")

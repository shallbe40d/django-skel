import json
import numpy as np


def wirte_json_fail_freq(file_path, N_S_RPM, N_S, F_r, F_S, F_P, RBPF, BPF, CPF, m_GMF, ndcl_freq_list, DrivenPulleyRPM, nb_freq_list, vbelt_f, Fan_F_r):
    """ 결함주파수 json 파일 생성

    :param string file_path:
    :param float N_S_RPM: 전동기 슬립없는 동기 속도(Hz)
    :param float N_S: 전동기 축 회전주파수(슬립 x)(Hz)
    :param float F_r: 전동기 축 회전주파수(슬립 o) = 명판(Hz)
    :param float F_S: 전동기 슬립주파수(Hz)
    :param float F_P: 전동기 극통과주파수(Hz)
    :param float RBPF: 전동기 로터바 통과주파수(Hz)
    :param float BPF: 전동기 블레이드 통과주파수(Hz)
    :param float CPF: 전동기 코일 통과주파수(Hz)
    :param float m_GMF: 전동기 최종 출력 축 GMF (풀리의 경우 계산 X)(Hz)
    :param list ndcl_freq_list: 감속기 결함주파수
    :param float DrivenPulleyRPM: 피동풀리 RPM(Hz)
    :param list nb_freq_list: 베어링 결함주파수
    :param float vbelt_f: V벨트 주파수(Hz)
    :param float Fan_F_r: 공조기 팬 결함주파수(Hz)
    :return:
    """

    data = {}

    data['motor_fail_freq'] = {
        "N_S_RPM": -1.0 if N_S_RPM < 0 else float(N_S_RPM),
        "N_S": -1.0 if N_S < 0 else float(N_S),
        "F_r": -1.0 if F_r < 0 else float(F_r),
        "F_S": -1.0 if F_S < 0 else float(F_S),
        "F_P": -1.0 if F_P < 0 else float(F_P),
        "RBPF": -1.0 if RBPF < 0 else float(RBPF),
        "BPF": -1.0 if BPF < 0 else float(BPF),
        "CPF": -1.0 if CPF < 0 else float(CPF),
        "m_GMF": -1.0 if m_GMF < 0 else float(m_GMF)
    }

    data['ndcl_fail_freq'] = []
    ndcl_freq_arr = np.asarray(ndcl_freq_list)
    if ndcl_freq_arr.shape[0] > 0:
        for i in range(ndcl_freq_arr.shape[0]):
            data['ndcl_fail_freq'].append({
                "name": str(ndcl_freq_arr[i][0]),
                "ReducerStageGMF": -1.0 if float(ndcl_freq_arr[i][1]) < 0 else float(ndcl_freq_arr[i][1]),
                "ReducerStageF_r": -1.0 if float(ndcl_freq_arr[i][2]) < 0 else float(ndcl_freq_arr[i][2]),
                "ReducerF_ht": -1.0 if float(ndcl_freq_arr[i][3]) < 0 else float(ndcl_freq_arr[i][3])
            })
    else:
        data['ndcl_fail_freq'].append({
            "name": "d1",
            "ReducerStageGMF": -1.0,
            "ReducerStageF_r": -1.0,
            "ReducerF_ht": -1.0
        })

    data['nb_fail_freq'] = []
    nb_fail_arr = np.asarray(nb_freq_list)
    for i in range(nb_fail_arr.shape[0]):
        data['nb_fail_freq'].append({
            "name": str(nb_fail_arr[i][0]),
            "nBearingF_n": -1.0 if float(nb_fail_arr[i][1]) < 0 else float(nb_fail_arr[i][1]),
            "BPFI": -1.0 if float(nb_fail_arr[i][2]) < 0 else float(nb_fail_arr[i][2]),
            "BPFO": -1.0 if float(nb_fail_arr[i][3]) < 0 else float(nb_fail_arr[i][3]),
            "BSF": -1.0 if float(nb_fail_arr[i][4]) < 0 else float(nb_fail_arr[i][4]),
            "FTF": -1.0 if float(nb_fail_arr[i][5]) < 0 else float(nb_fail_arr[i][5])
        })

    data['acm_fail_freq'] = {
        "DrivenPulleyRPM": -1.0 if DrivenPulleyRPM < 0 else float(DrivenPulleyRPM),
        "vbelt_f": -1.0 if vbelt_f < 0 else float(vbelt_f),
        "Fan_F_r": -1.0 if Fan_F_r < 0 else float(Fan_F_r)
    }

    with open(file_path, 'w', encoding="utf-8") as outfile:
        json.dump(data, outfile, indent=4)


def wirte_json_vib_fft_threshold(file_path, rpm_range_arry, data_position_arry, th_x_arry, th_y_arry, th_z_arry):
    data = {}

    data['rpm_range'] = {
        "Subharmonics": -1 if rpm_range_arry[0] < 0 else int(rpm_range_arry[0]),
        "1xRPM": -1 if rpm_range_arry[1] < 0 else int(rpm_range_arry[1]),
        "2xRPM": -1 if rpm_range_arry[2] < 0 else int(rpm_range_arry[2]),
        "3-4xRPM": -1 if rpm_range_arry[3] < 0 else int(rpm_range_arry[3]),
        "5-12xRPM": -1 if rpm_range_arry[4] < 0 else int(rpm_range_arry[4]),
        "HFD": -1 if rpm_range_arry[5] < 0 else int(rpm_range_arry[5]),
        "END": -1 if rpm_range_arry[6] < 0 else int(rpm_range_arry[6])
    }

    for i in range(len(data_position_arry)):
        data[data_position_arry[i]] = {}

        data[data_position_arry[i]]['x_axis_threshold'] = {
            "Subharmonics": -1.0 if th_x_arry[i * 6] < 0 else th_x_arry[(i * 6)],
            "1xRPM": -1.0 if th_x_arry[(i * 6) + 1] < 0 else th_x_arry[(i * 6) + 1],
            "2xRPM": -1.0 if th_x_arry[(i * 6) + 2] < 0 else th_x_arry[(i * 6) + 2],
            "3-4xRPM": -1.0 if th_x_arry[(i * 6) + 3] < 0 else th_x_arry[(i * 6) + 3],
            "5-12xRPM": -1.0 if th_x_arry[(i * 6) + 4] < 0 else th_x_arry[(i * 6) + 4],
            "HFD": -1.0 if th_x_arry[(i * 6) + 5] < 0 else th_x_arry[(i * 6) + 5]
        }

        data[data_position_arry[i]]['y_axis_threshold'] = {
            "Subharmonics": -1.0 if th_y_arry[(i * 6)] < 0 else th_y_arry[(i * 6)],
            "1xRPM": -1.0 if th_y_arry[(i * 6) + 1] < 0 else th_y_arry[(i * 6) + 1],
            "2xRPM": -1.0 if th_y_arry[(i * 6) + 2] < 0 else th_y_arry[(i * 6) + 2],
            "3-4xRPM": -1.0 if th_y_arry[(i * 6) + 3] < 0 else th_y_arry[(i * 6) + 3],
            "5-12xRPM": -1.0 if th_y_arry[(i * 6) + 4] < 0 else th_y_arry[(i * 6) + 4],
            "HFD": -1.0 if th_y_arry[(i * 6) + 5] < 0 else th_y_arry[(i * 6) + 5]
        }

        data[data_position_arry[i]]['z_axis_threshold'] = {
            "Subharmonics": -1.0 if th_z_arry[(i * 6)] < 0 else th_z_arry[(i * 6)],
            "1xRPM": -1.0 if th_z_arry[(i * 6) + 1] < 0 else th_z_arry[(i * 6) + 1],
            "2xRPM": -1.0 if th_z_arry[(i * 6) + 2] < 0 else th_z_arry[(i * 6) + 2],
            "3-4xRPM": -1.0 if th_z_arry[(i * 6) + 3] < 0 else th_z_arry[(i * 6) + 3],
            "5-12xRPM": -1.0 if th_z_arry[(i * 6) + 4] < 0 else th_z_arry[(i * 6) + 4],
            "HFD": -1.0 if th_z_arry[(i * 6) + 5] < 0 else th_z_arry[(i * 6) + 5]
        }

    with open(file_path, 'w', encoding="utf-8") as outfile:
        json.dump(data, outfile, indent=4)
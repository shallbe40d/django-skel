def reducer_fail_type():
    return 0
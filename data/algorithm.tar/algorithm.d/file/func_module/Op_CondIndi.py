#-*- coding:utf-8 -*-
#import librosa
#import scipy
#import librosa
#from scipy.io import wavfile
#from scipy.spatial.distance import euclidean
from scipy import signal
from scipy.signal import hilbert
import numpy as np
import scipy.stats as stats
import math
#import numexpr as ne
import time
import os
import sys
import datetime
"""
Code History
2020.09.10 동작감지 코드 작성 완료
2020.09.11 코드 초안 작성 완료
2020.09.29 예외처리 구문 추가
2020.10.07 이상감지 불가이므로 이상여부는 무조건 정상으로 출력되도록 수정
2020.10.12 가동역 임계치 값 조정,1.6 -> 5.0 (임계편차 고려)
"""

#동작여부를 얻기 위한 지수계산
def OpIndicator(sr, data, start = 5500, end = 6500):
	#filter설정
	print("fs0:",sr)
	sos = signal.butter(10, [start, end], 'bp', fs=sr, output='sos') #필터 설정(구동중의 회전패턴 주파수 캐치)
	print("fs0-1:",sr)
	filtered = signal.sosfilt(sos, data) #필터적용
	#envelope
	analytic_signal = hilbert(filtered) 
	amplitude_envelope = np.abs(analytic_signal)
	#소음구간 분할(1초)
	re_envelope = amplitude_envelope.reshape(-1,sr*1)
	arr = np.array([])
	#지수 조정 변수
	rms_c = 50.0
	kurto_c = 1.0
	skew_c = 1.0
	for i in re_envelope:
		rms = i.std() * rms_c
		kurto = stats.kurtosis(i) * kurto_c
		skewness = stats.skew(i) * skew_c
		#제안지수 계산
		prop_indicator = math.sqrt((rms**2)+(kurto**2)+(skewness**2))
		#결과출력
		#print("rms:\t", rms , "\tkurtosis:\t" , kurto , "\tskewness:\t" , skewness, "\t제안지표:\t", prop_indicator)
		arr = np.append(arr, np.array(prop_indicator))
	result = np.mean(arr)
	return result


#동작여부 반환
def OpCheck(sr, data):
	Ind_mean = OpIndicator(sr, data)
	#임계라인 기준 판단 설정-1.6은 현장마다 수정필요.(거리마다 다르게 들어올 것으로 판단)
	print("Ind_mean : ",Ind_mean)
	if(Ind_mean>3.0):
		result = 1
	else:
		result = 0
	return result


#누적 데이터 읽기	
def ReadStackCondition(src):
	print("src : ",src)
	f = open(src, 'r')
	lines = f.readlines()
	for i in range(len(lines)):
		lines[i] = lines[i].replace('\n','')

	#print(lines)
	f.close()
	result = np.array(lines)
	result = result.astype('float32')
	if (len(result)<5): #누적 관리 할 데이터가 부족한 시점에서의 임의 데이터 생성
		result = np.array([0.8116697, 0.85307574, 0.8047258, 0.71376204, 0.8055172])
	#print(result)
	#print(result.dtype)
	#전체데이터 중 최근의 데이터 5개만 가지고 오기
	result[-5:]
	return result
	
'''
def WarnIndicator(sr, data):
	filtered = np.zeros(data.shape[0])
	#감시 주파수 대역 복수 임의 설정 (사양이 된다면 필요에 따라 늘릴것)
	sos = signal.butter(10, [19500,24500], 'bp', fs=sr, output='sos') #필터 설정
	tmp = signal.sosfilt(sos, data) #필터적용
	filtered = ne.evaluate("filtered + tmp")
	sos2 = signal.butter(10, [17000,19000], 'bp', fs=sr, output='sos') #필터 설정
	tmp = signal.sosfilt(sos2, data) #필터적용
	filtered = ne.evaluate("filtered + tmp")
	sos3 = signal.butter(10, [11000,13000], 'bp', fs=sr, output='sos') #필터 설정
	tmp = signal.sosfilt(sos3, data) #필터적용
	filtered = ne.evaluate("filtered + tmp")
	sos4 = signal.butter(10, [5500,6500], 'bp', fs=sr, output='sos') #필터 설정
	tmp = signal.sosfilt(sos4, data) #필터적용
	filtered = ne.evaluate("filtered + tmp")
	sos5 = signal.butter(10, [3000,4000], 'bp', fs=sr, output='sos') #필터 설정
	tmp = signal.sosfilt(sos5, data) #필터적용
	filtered = ne.evaluate("filtered + tmp")
	#filtered += signal.sosfilt(sos5, data) #필터적용
	filtered = filtered / 5.0 #진폭 평균 맞추기
	#envelope
	analytic_signal = hilbert(filtered) 
	amplitude_envelope = np.abs(analytic_signal)
	#소음구간 분할(1초)
	re_envelope = amplitude_envelope.reshape(-1,sr*1)
	#지수 조정 변수
	rms_c = 1.0
	kurto_c = 1.0
	skew_c = 1.0
	arr = np.array([])
	for i in re_envelope:
		#RMS, Kurtosis, Skewness계산
		rms = i.std() * rms_c
		kurto = stats.kurtosis(i) * kurto_c
		skewness = stats.skew(i) * skew_c
		#제안지표 계산
		prop_indicator = math.sqrt((rms**2)+(kurto**2)+(skewness**2))
		#결과출력
		arr = np.append(arr, np.array(prop_indicator))
	result = np.mean(arr)
	return result
	#return arr
'''
def WarnIndicator(sr, data):
	filtered = np.zeros(len(data))
	#감시 주파수 대역 복수 임의 설정 (사양이 된다면 필요에 따라 늘릴것)
	print("fs:", sr)
	sos = signal.butter(10, [19500,24500], 'bp', fs=sr, output='sos') #필터 설정
	filtered += signal.sosfilt(sos, data) #필터적용
	sos2 = signal.butter(10, [17000,19000], 'bp', fs=sr, output='sos') #필터 설정
	filtered += signal.sosfilt(sos2, data) #필터적용
	sos3 = signal.butter(10, [11000,13000], 'bp', fs=sr, output='sos') #필터 설정
	filtered += signal.sosfilt(sos3, data) #필터적용
	sos4 = signal.butter(10, [5500,6500], 'bp', fs=sr, output='sos') #필터 설정
	filtered += signal.sosfilt(sos4, data) #필터적용
	sos5 = signal.butter(10, [3000,4000], 'bp', fs=sr, output='sos') #필터 설정
	filtered += signal.sosfilt(sos5, data) #필터적용
	filtered = filtered / 5.0 #진폭 평균 맞추기
	#envelope
	analytic_signal = hilbert(filtered) 
	amplitude_envelope = np.abs(analytic_signal)
	#소음구간 분할(1초)
	re_envelope = amplitude_envelope.reshape(-1,sr*1)
	#지수 조정 변수
	rms_c = 1.0
	kurto_c = 1.0
	skew_c = 1.0
	arr = np.array([])
	for i in re_envelope:
		#RMS, Kurtosis, Skewness계산
		rms = i.std() * rms_c
		kurto = stats.kurtosis(i) * kurto_c
		skewness = stats.skew(i) * skew_c
		#제안지표 계산
		prop_indicator = math.sqrt((rms**2)+(kurto**2)+(skewness**2))
		#결과출력
		arr = np.append(arr, np.array(prop_indicator))
	result = np.mean(arr)
	return result

def WarnCheck(RSC, WI):
	#2초 간격 5초 측정 데이터의 5개 지표 값에서 2.5 sigma구간 이내라면 이상 없음 범위 밖이라면 아웃라이어 이상 통보 
	if((RSC.mean()-RSC.std()*2.5) < WI < (RSC.mean()+RSC.std()*2.5) ):
		result = 0
	else:
		result = 1
	return result


def Op_Cond_Start(src, sr, path):
	try:
		#sr, data = wavfile.read("./SavedRange-5.wav") #파일 불러오기
		print("GW 사운드 경로:",path)
		f=open(path,'r')
		data = f.readlines()
		data = list(map(int, data))
		data = np.array(data)
		data = (data / 204.75) - 10
		Start_Time = time.time()
		ls_Op = OpCheck(sr,data)
		print("가동여부 : ", time.time() - Start_Time)
		WI = WarnIndicator(sr, data)
		print("이상판단지수 계산 : ", time.time() - Start_Time)
		RSC = ReadStackCondition(src)
		print("누적 데이터 읽기 : ", time.time() - Start_Time)
		ls_W = WarnCheck(RSC, WI)
		End_Time = time.time()
		print("임계치 계산,최종 처리시간 : ",End_Time - Start_Time)
		print(WI, ls_Op, ls_W) #출력결과 확인
		#return 0, WI, ls_Op, ls_W #이상수지, 동작여부, 이상여부
		return 0, WI, ls_Op, 0
	except Exception as e:
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
		print("------------------------------------------------------")
		print("------------------------------------------------------")
		print('fail error:',e)
		print(exc_type, fname, exc_tb.tb_lineno)
		print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
		print("------------------------------------------------------")
		return 255, 0, 0, 0

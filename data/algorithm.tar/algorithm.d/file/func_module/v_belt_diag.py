#vib_diag : 기계설비 고장유형 진동 진단(main)
import os
import sys

from file.func_module.belt_elongation_analysis import cal_length
from file.func_module.read_json import read_json
import file.func_module.redis_fct as rdf
from file.func_module.shaft_speed_actual import shaft_speed_jsback_v1, shaft_speed_jsback_v2


def v_belt_diag(mes_json_path, motor_vib_data_path, s_bearing_vib_data_path, pulley_sound_data_path):
    try:
        # 기계 설비 스펙 정보 불러오기(json)
        mes = read_json(mes_json_path)
        if float(mes['Facility']['DriveRPM']) > 0:
            mes['Motor']['RPM'] = mes['Facility']['DriveRPM']

        # Sample rate(Hz)
        Fs = 2000   # 진동
        n_Fs = 50000    # 소음
        # 신율
        elongation = 0
        mept = 100
        drv_actual = 0
        drvn_actual = 0

        if float(mes['Motor']['RPM']) > 0 and float(mes['Pulley']['DrivePulleyPCD']) > 0 and float(mes['Pulley']['DrivenPulleyPCD']) > 0 and float(mes['Vbelt']['vbelt_length']) > 0:
            # drv_actual, drvn_actual = shaft_speed_jsback_v1(motor_vib_data_path, s_bearing_vib_data_path, Fs,
            #                                                 float(mes['Motor']['RPM']),
            #                                                 float(mes['Pulley']['DrivePulleyPCD']),
            #                                                 float(mes['Pulley']['DrivenPulleyPCD']))

            drv_actual, drvn_actual = shaft_speed_jsback_v2(motor_vib_data_path, s_bearing_vib_data_path, Fs,
                                                            float(mes['Motor']['RPM']),
                                                            float(mes['Pulley']['DrivePulleyPCD']),
                                                            float(mes['Pulley']['DrivenPulleyPCD']),
                                                            pulley_sound_data_path, n_Fs)

            if drv_actual > 0 and drvn_actual > 0:
                rd = rdf.rd_conn('localhost', 6379, 0)
                rd_drv = rdf.rd_set(rd, "drv", drv_actual)
                rd_drvn = rdf.rd_set(rd, "drvn", drvn_actual)

                # 동력전달효율 산출
                design_ratio = float(mes['Pulley']['DrivenPulleyPCD']) / float(mes['Pulley']['DrivePulleyPCD'])
                actual_ratio = drv_actual / drvn_actual
                mept_diff = actual_ratio - design_ratio
                if mept_diff > 0:
                    mept = 100 - (mept_diff * 100)

                if float(mes['Pulley']['DrivePulleyPCD']) > 0 and float(mes['Pulley']['DrivenPulleyPCD']) and float(mes['Vbelt']['vbelt_length']) > 0:
                    # 신율
                    elongation = cal_length(float(mes['Pulley']['DrivePulleyPCD']), float(mes['Pulley']['DrivenPulleyPCD']), drv_actual, drvn_actual, float(mes['Vbelt']['vbelt_length']))

                    # 신율이 줄었다고 계산된 경우,
                    if elongation <= 0:
                        elongation = 0

                    print("신율 : ", elongation)
                    print("동력전달효율 : ", mept)
                    print("구동풀리속도 : ", drv_actual)
                    print("피동풀리속도 : ", drvn_actual)
                    return 0, elongation, mept, drv_actual, drvn_actual
                else:
                    print("pulley_info(구동/피동 풀리 피치원) is Zero | OR | vbelt_info[0][1](벨트 전체길이) is Zero")
                    print("계산된 신율 없음")
                    return 255, -1.0, -1.0, -1.0, -1.0
            else:
                print("drv_actual(구동축 회전주파수 계산값) is Zero | OR | drvn_actual(피구동축 회전주파수 계산값) is Zero")
                print("계산된 신율 없음")
                return 255, -1.0, -1.0, -1.0, -1.0
        else:
            print("기계설비 정보 불충분")
            print("전동기 RPM : ", float(mes['Motor']['RPM']))
            print("구동축 풀리 피치원 : ", float(mes['Pulley']['DrivePulleyPCD']))
            print("피구동축 풀리 피치원 : ", float(mes['Pulley']['DrivenPulleyPCD']))
            print("계산된 신율 없음")
            return 255, -1.0, -1.0, -1.0, -1.0
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print('fail error:', e)
        print(exc_type, fname, exc_tb.tb_lineno)
        print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
        return 255, -1.0, -1.0, -1.0, -1.0
import numpy as np
import sys
import os


def harmonics_freq_calc(fft_data, peaks, freq, hz_min, hz_max, harmonics):
    """ 조화성분 peak frequency 검출

    :param fft_data: 진동 FFT 데이터
    :param peaks: 진동 FFT 데이터 Peak array
    :param float freq: 1x 결함 주파수
    :param int hz_min: FFT 주파수 최소값
    :param int hz_max: FFT 주파수 최대값
    :param int harmonics: 구하려는 nx 조화성분
    :return: nxfreq_list, pk_bool_list
    """
    # 조화성분 frequency list
    nxfreq_list = []
    for i in range(1, harmonics + 1):
        tmp_freq = int(np.floor(i * freq))
        if tmp_freq > hz_max:
            break
        nxfreq_list = nxfreq_list + [tmp_freq]

    pk_bool_list = [0 for i in range(len(nxfreq_list))]

    # peak와 frequency 일치 확인 및 범위(-1, +1 => 전, 후)에서 진폭 max 값 찾기
    for n in range(len(nxfreq_list)):
        if nxfreq_list[n] < hz_min or nxfreq_list[n] > hz_max:
            pk_bool_list[n] = 0

        elif nxfreq_list[n] > 0:
            freq_list = np.array([nxfreq_list[n] - 1, nxfreq_list[n], nxfreq_list[n] + 1])
            peaks_index_list = np.array([])

            for i in range(len(freq_list)):
                peaks_index_list = np.append(peaks_index_list, np.where(peaks == freq_list[i]))

            peaks_index_list = peaks_index_list.astype('int32')
            amp_list = np.array([])

            for i in range(len(peaks_index_list)):
                if peaks_index_list[i] >= 0:
                    amp_list = np.append(amp_list, fft_data[peaks[peaks_index_list[i]]])

            if len(amp_list) > 0:
                amp_max = np.max(amp_list)
                amp_max_index = np.where(amp_max == amp_list)
                nxfreq_list[n] = int(peaks[peaks_index_list[amp_max_index[0][0]]])
                pk_bool_list[n] = 1

    return nxfreq_list, pk_bool_list


def peaks_interval_calc(peaks, interval_freq, hz_max, harmonics):
    """ peak 사이값 개수 산출

    :param peaks: 진동 FFT peak frequency
    :param float interval_freq: 기준 사이값 주파수
    :param int hz_max: FFT 주파수 최대값
    :return: (int)peak_interval_sum - peak 사이값이 기준 사이값(freq)과 같은 갯수
    """

    try:
        # 조화성분 end point
        it_freq_num = 0
        for i in range(1, harmonics + 1):
            if (i * interval_freq) > (hz_max - 1):
                break
            elif (i * interval_freq) < (hz_max - 1):
                it_freq_num = it_freq_num + 1

        it_freq = np.floor(interval_freq)

        peak_interval_sum = 0
        # peak와 frequency 일치 확인 및 범위(-2, -1, +1, +2 => 전, 후)에서 진폭 max 값 찾기
        if it_freq - 2 > 0:
            freq_list = np.array([it_freq - 2, it_freq - 1, it_freq, it_freq + 1, it_freq + 2])
            peaks_index_list = np.array([])
            for i in range(len(freq_list)):
                peaks_index_list = np.append(peaks_index_list, np.where(peaks == freq_list[i]))
            peaks_index_list = peaks_index_list.astype('int32')

            peaks_index = peaks_index_list[0]

            for i in range(len(peaks) - peaks_index - 2):
                peak_interval = peaks[peaks_index + (i + 1)] - peaks[peaks_index]
                if peak_interval == it_freq or peak_interval == (it_freq - 1) or peak_interval == (it_freq + 1):
                    peak_interval_sum = peak_interval_sum + 1
                    peaks_index = peaks_index + (i + 1)
                    break
                elif peak_interval > (it_freq + 1):
                    peaks_index = peaks_index + 1
                    break

        return it_freq_num, peak_interval_sum
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print('fail error:', e)
        print(exc_type, fname, exc_tb.tb_lineno)
        print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
        return 0, 0


def sidebands_freq_calc(fft_data, peaks, hz_min, hz_max, nxfreq, pk_bool, sb_freq):
    """ 측대파 Peak frequency 검출

    :param fft_data: 진동 FFT 데이터
    :param peaks: 진동 FFT peak frequency
    :param int hz_min: 진동 FFT 주파수 최소값
    :param int hz_max: 진동 FFT 주파수 최대값
    :param float nxfreq: 측대파의 기준 결함 주파수
    :param int pk_bool: Peak 유무
    :param float sb_freq: 측대파 주파수
    :return:
    """
    sb_l_freq = np.floor(nxfreq - sb_freq)
    sb_r_freq = np.floor(nxfreq + sb_freq)
    sb_l_pk_bool = 0
    sb_r_pk_bool = 0
    if nxfreq > 0 and pk_bool == 1 and sb_l_freq >= hz_min + 1 and sb_r_freq < hz_max - 1:
        # 좌측 사이드밴드
        sb_freq_list = np.array([nxfreq - sb_freq - 1, nxfreq - sb_freq, nxfreq - sb_freq + 1])
        peaks_index_list = np.array([])
        for i in range(len(sb_freq_list)):
            peaks_index_list = np.append(peaks_index_list, np.where(peaks == sb_freq_list[i]))
        peaks_index_list = peaks_index_list.astype('int32')

        amp_list = np.array([])
        for i in range(len(peaks_index_list)):
            if peaks_index_list[i] >= 0:
                amp_list = np.append(amp_list, fft_data[peaks[peaks_index_list[i]]])

        if len(amp_list) > 0:
            amp_max = np.max(amp_list)
            amp_max_index = np.where(amp_max == amp_list)
            sb_l_freq = peaks[peaks_index_list[amp_max_index[0][0]]]
            sb_l_pk_bool = 1

        # 우측 사이드밴드
        sb_freq_list = np.array(
            [nxfreq + sb_freq - 1, nxfreq + sb_freq, nxfreq + sb_freq + 1])
        peaks_index_list = np.array([])
        for i in range(len(sb_freq_list)):
            peaks_index_list = np.append(peaks_index_list, np.where(peaks == sb_freq_list[i]))
        peaks_index_list = peaks_index_list.astype('int32')

        amp_list = np.array([])
        for i in range(len(peaks_index_list)):
            if peaks_index_list[i] >= 0:
                amp_list = np.append(amp_list, fft_data[peaks[peaks_index_list[i]]])

        if len(amp_list) > 0:
            amp_max = np.max(amp_list)
            amp_max_index = np.where(amp_max == amp_list)
            sb_r_freq = peaks[peaks_index_list[amp_max_index[0][0]]]
            sb_r_pk_bool = 1

    return int(sb_l_freq), int(sb_r_freq), sb_l_pk_bool, sb_r_pk_bool
# _*_ coding: UTF-8 -*-

import numpy as np
from scipy import signal, fft


# acc_int 와 비교했을 때, 비교 : acc_int * 30 == rms_avg_fft
def rms_avg_fft(data, data_len):
	""" 인하대학교 백지선 박사 fft

	:param data: 진동 데이터 배열
	:param int data_len: 진동 데이터 조각 크기(fs = 2000Hz, 1Hz 주파수 간격 -> data_len = 2000)
	:return:
	"""
	data_seg = np.zeros((int(np.floor(data.shape[0]/data_len)), data_len))

	for i in range(int(np.floor(data.shape[0]/data_len))):
		data_seg[i] = data[data_len * i:data_len + (data_len * i)]

	data_seg_fft = fft.fft(data_seg)
	data_seg_fft_mag = np.sqrt(np.multiply(data_seg_fft, data_seg_fft.conjugate())) / data_len * 2

	data_seg_fft_mag = data_seg_fft_mag[:, 0:int(np.floor(data_len/2))]
	for i in range(data_seg_fft_mag.shape[0]):
		data_seg_fft_mag[i][0] = 0.0

	rms = np.sqrt(np.mean((abs(data_seg_fft_mag) ** 2) / data_len, 0))
	rtn = rms / np.sqrt(2)

	return rtn


def rms_avg_windowing_fft(data, data_len):
	""" hanning window 적용 fft

	:param data: 진동 데이터 배열
	:param int data_len: 진동 데이터 조각 크기(fs = 2000Hz, 1Hz 주파수 간격 -> data_len = 2000)
	:return:
	"""
	data = data - np.mean(data)

	# 66% 겹칠 때
	data_overlap = int(data_len * (66 / 100))
	data_step = data_len - data_overlap
	data_seg = np.zeros((int(np.floor(data.shape[0] / data_step)), data_len))

	for i in range(data.shape[0] // data_step):
		if (data_len * (i + 1) - (data_overlap * i)) > data.shape[0]:
			data_temp = data[(data_len * i) - (data_overlap * i):]
			data_seg[i] = np.append(data_temp, np.ones(data_len - data_temp.shape[0]))
		else:
			data_seg[i] = data[(data_len * i) - (data_overlap * i):(data_len * (i + 1) - (data_overlap * i))]

	data_seg = np.multiply(data_seg, signal.windows.hann(data_len))  # 해닝

	data_seg_fft = fft.fft(data_seg)
	data_seg_fft_mag = np.sqrt(np.multiply(data_seg_fft, data_seg_fft.conjugate())) / data_len * 2

	data_seg_fft_mag = data_seg_fft_mag[:, 0:int(np.floor(data_len / 2))]
	for i in range(data_seg_fft_mag.shape[0]):
		data_seg_fft_mag[i][0] = 0.0

	rms = np.sqrt(np.mean((abs(data_seg_fft_mag) ** 2) / data_len, 0))

	# hanning 진폭 보정 : * 1.8534
	rtn = (rms / np.sqrt(2)) * 1.8534

	return rtn
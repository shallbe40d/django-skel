import numpy as np
from scipy import signal
import math


def vib_three_axis_file_read(path):
    # 분석대상 파일 읽기
    f = open(path, 'r')
    lines = f.readlines()
    _x = []
    _y = []
    _z = []
    for i in range(len(lines)):
        _x.append(lines[i].split(' ')[0])
        _y.append(lines[i].split(' ')[1])
        _z.append(lines[i].split(' ')[2])

    _x = np.array(_x)
    _y = np.array(_y)
    _z = np.array(_z)
    _x = _x.astype(float)
    _y = _y.astype(float)
    _z = _z.astype(float)

    return _x, _y, _z


def fft_mag(x, fs):
    """

    :param x: 시계열 진동 데이터
    :param fs: 샘플레이트
    :return:
    """
    x_length = len(x)
    yf = np.fft.fft(x)
    temp = np.multiply(yf, yf.conjugate())
    yfm = np.sqrt(temp.astype(float)) / x_length * 2

    if x_length % 2 == 0:
        f = np.linspace(0, (x_length - 1) * fs / x_length, x_length)
        f = f[:x_length / 2 - 1]
        yfm = yfm[:x_length / 2 - 1]
    else:
        f = np.linspace(1 / 2 * fs / x_length, (x_length - 1) * fs / x_length + 1 / 2 * fs / x_length, x_length)
        f = f[:math.ceil(x_length / 2 - 1)]
        yfm = yfm[:math.ceil(x_length / 2 - 1)]

    return yfm, f


def anc_notch(x, fs, f, mu):
    """

    :param x: 시계열 진동 데이터
    :param fs: 샘플레이트
    :param f: 주파수
    :param mu:
    :return:
    """
    lf = 1
    t = np.linspace(0, len(x) / fs - 1 / fs, len(x))

    w1 = 0
    w2 = 0

    ref_sin = np.sin(2 * np.pi * f * t)
    ref_cos = np.cos(2 * np.pi * f * t)

    out = np.zeros(np.shape(x))
    e = np.zeros(np.shape(x))

    for i in range(len(x)):
        out[i] = w1 * ref_sin[i] + w2 * ref_cos[i]
        e[i] = x[i] + out[i]
        w1 = w1 * lf - mu * e[i] * ref_sin[i]
        w2 = w2 * lf - mu * e[i] * ref_cos[i]

    return e


def shaft_speed_actual(yf, f, detect_region, target_order):
    low_array = abs(f - detect_region[0])
    high_array = abs(f - detect_region[1])

    idx_low = np.where(min(low_array) == low_array)
    idx_low = idx_low[0][0]
    idx_high = np.where(min(high_array) == high_array)
    idx_high = idx_high[0][0]

    yf_seg = yf[idx_low:idx_high + 1]
    f_seg = f[idx_low:idx_high + 1]

    shaft_speed_peaks = signal.find_peaks(yf_seg, height=max(yf_seg) * 0.01)

    val_peak_arry = np.array([])
    for i in range(len(shaft_speed_peaks[0])):
        val_tmp = yf_seg[shaft_speed_peaks[0][i]]
        val_peak_arry = np.append(val_peak_arry, val_tmp)

    # actual : 회전 속도(Hz)
    actual = -1

    peak_order = val_peak_arry[np.argsort(-val_peak_arry)]
    if len(peak_order) > 1:
        if peak_order[1] > 0.5 * peak_order[0]:
            print("회전 속도 peak 개수 2개 이상 존재함")
        elif np.mean(yf_seg) * 4 > peak_order[0]:
            print("회전 속도 우세한 peak 존재하지 않음")
        # else:
        idx_peak = np.where(max(val_peak_arry) == yf_seg)
        idx_peak = idx_peak[0][0]

        actual = f_seg[idx_peak] / target_order
    else:   # 소음일때만, peak 산출 range가 짧으므로
        idx_peak = np.where(max(val_peak_arry) == yf_seg)
        idx_peak = idx_peak[0][0]

        actual = f_seg[idx_peak] / target_order

    return actual


def shaft_speed_actual_noise(noise_data_path, Fs, target_order, drvn_by_drv):
    """

    :param noise_data_path:
    :param Fs:
    :param target_order:
    :param drvn_by_drv:
    :return:
    """

    # 소음데이터 파일 read
    f = open(noise_data_path, "r", encoding="utf-8")
    data = f.readlines()
    f.close()
    for i in range(len(data)):
        data[i] = int(data[i].replace("\n", ""))
    y = data
    y = y - np.mean(y)

    corr = signal.correlate(y, y, mode='full')

    yf, f = fft_mag(corr, Fs)

    # upper bound(Hz)
    range_hz_high = drvn_by_drv * target_order * 0.05
    # lower bound(Hz)
    range_hz_low = drvn_by_drv * target_order * 0.1

    drvn_detect_region = np.array([drvn_by_drv * target_order - range_hz_low, drvn_by_drv * target_order + range_hz_high])

    noise_drvn_actual = shaft_speed_actual(yf, f, drvn_detect_region, target_order)

    return noise_drvn_actual


def shaft_speed_jsback_v1(drv_data_path, drvn_data_path, Fs, drv_RPM, drv_pulley, drvn_pulley):
    """ 백지선 박사 축 회전주파수 산출 1차 버전

    :param drv_data_path: 구동축 진동 데이터 파일 경로
    :param drvn_data_path: 피구동축 진동 데이터 파일 경로
    :param Fs: 진동 데이터 샘플레이트(Hz)
    :param drv_RPM: 구동축 회전속도(rpm)
    :param drv_pulley: 구동축 풀리 피치원(mm)
    :param drvn_pulley: 피구동축 풀리 피치원(mm)
    :return:
    """
    # set range
    drv_range_percent = 2
    drv_target_order = 1

    drvn_range_percent_high = 5
    drvn_range_percent_low = 10
    drvn_target_order = 1

    drv_freq = drv_RPM / 60
    d_ratio = drv_pulley / drvn_pulley
    drvn_freq = drv_freq * d_ratio

    drv_x, drv_y, drv_z = vib_three_axis_file_read(drv_data_path)
    y = np.sqrt(drv_x ** 2 + drv_y ** 2 + drv_z ** 2)
    y = y - np.mean(y)

    corr = signal.correlate(y, y, mode='full')

    yf, f = fft_mag(corr, Fs)

    drv_detect_region = np.array([(1 - drv_range_percent / 100) * drv_freq * drv_target_order, (1 + drv_range_percent / 100) * drv_freq * drv_target_order])

    # drv_actual : 구동축 회전 속도(Hz)
    drv_actual = shaft_speed_actual(yf, f, drv_detect_region, drv_target_order)

    print("설계 또는 측정된 구동축 회전 속도(Hz) : ", drv_freq)
    print("진동 분석 구동축 회전 속도(Hz) : ", drv_actual)

    #### driven 회전 속도 산출
    if drv_actual > 0:
        drvn_x, drvn_y, drvn_z = vib_three_axis_file_read(drvn_data_path)
        y = np.sqrt(drvn_x ** 2 + drvn_y ** 2 + drvn_z ** 2)
        y = y - np.mean(y)

        for i in range(11):
            # remove drive shaft rotation freq
            y = anc_notch(y, Fs, drv_actual * (i + 1), 0.001)

        corr = signal.correlate(y, y, mode='full')
        yf, f = fft_mag(corr, Fs)

        drvn_by_drv = drv_actual * d_ratio

        drvn_detect_region = [(1 - drvn_range_percent_low / 100) * drvn_by_drv * drvn_target_order, (1 + drvn_range_percent_high / 100) * drvn_by_drv * drvn_target_order]

        # drvn_actual : 피구동축 회전 속도(Hz)
        drvn_actual = shaft_speed_actual(yf, f, drvn_detect_region, drvn_target_order)

        print("설계 또는 측정된 피구동축 회전 속도(Hz) : ", drvn_freq)
        print("진동 분석 피구동축 회전 속도(Hz) : ", drvn_actual)

        return drv_actual, drvn_actual

    else:
        print("구동축 회전 속도를 산출할 수 없으므로 피구동축 회전 속도 산출 불가능")

        return drv_actual, -1


def shaft_speed_jsback_v2(drv_data_path, drvn_data_path, v_Fs, drv_RPM, drv_pulley, drvn_pulley, drvn_noise_data_path, n_Fs):
    """ 백지선 박사 축 회전주파수 산출 2차 버전(소음센서 피구동축 회전주파수 검출 진동과 교차 검증)

    :param drv_data_path: 구동축 진동 데이터 파일 경로
    :param drvn_data_path: 피구동축 진동 데이터 파일 경로
    :param v_Fs: 진동 데이터 샘플레이트(Hz)
    :param drv_RPM: 구동축 회전속도(rpm)
    :param drv_pulley: 구동축 풀리 피치원(mm)
    :param drvn_pulley: 피구동축 풀리 피치원(mm)
    :param drvn_noise_data_path: 피구동축 소음 데이터 파일 경로
    :param n_Fs: 소음 데이터 샘플레이트(Hz)
    :return:
    """
    # set range
    drv_range_percent = 2
    drv_target_order = 1

    drvn_range_percent_high = 5
    drvn_range_percent_low = 10
    drvn_target_order = 1

    drv_freq = drv_RPM / 60
    d_ratio = drv_pulley / drvn_pulley
    drvn_freq = drv_freq * d_ratio

    drv_x, drv_y, drv_z = vib_three_axis_file_read(drv_data_path)
    y = np.sqrt(drv_x ** 2 + drv_y ** 2 + drv_z ** 2)
    y = y - np.mean(y)

    corr = signal.correlate(y, y, mode='full')

    yf, f = fft_mag(corr, v_Fs)

    flag_re = True
    drv_actual = 0
    while flag_re:
        if drv_target_order == 2:
            flag_re = False

        drv_detect_region = np.array([(1 - drv_range_percent / 100) * drv_freq * drv_target_order, (1 + drv_range_percent / 100) * drv_freq * drv_target_order])

        # drv_actual : 구동축 회전 속도(Hz)
        drv_actual = shaft_speed_actual(yf, f, drv_detect_region, drv_target_order)

        if drv_actual > 0:
            break
        elif drv_actual <= 0:
            if drv_target_order >= 2:
                break
            else:
                drv_target_order = 2

    print("구동축 target order : ", drv_target_order)
    print("설계 또는 측정된 구동축 회전 속도(Hz) : ", drv_freq)
    print("진동 분석 구동축 회전 속도(Hz) : ", drv_actual)

    #### driven 회전 속도 산출
    if drv_actual > 0:
        drvn_x, drvn_y, drvn_z = vib_three_axis_file_read(drvn_data_path)
        y = np.sqrt(drvn_x ** 2 + drvn_y ** 2 + drvn_z ** 2)
        y = y - np.mean(y)

        for i in range(11):
            # remove drive shaft rotation freq
            y = anc_notch(y, v_Fs, drv_actual * (i + 1), 0.001)

        corr = signal.correlate(y, y, mode='full')
        yf, f = fft_mag(corr, v_Fs)

        drvn_by_drv = drv_actual * d_ratio

        drvn_detect_region = [(1 - drvn_range_percent_low / 100) * drvn_by_drv * drvn_target_order, (1 + drvn_range_percent_high / 100) * drvn_by_drv * drvn_target_order]

        # drvn_actual : 피구동축 회전 속도(Hz)
        drvn_actual = shaft_speed_actual(yf, f, drvn_detect_region, drvn_target_order)

        print("피구동축 target order : ", drvn_target_order)
        print("설계 또는 측정된 피구동축 회전 속도(Hz) : ", drvn_freq)
        print("진동 분석 피구동축 회전 속도(Hz) : ", drvn_actual)

        noise_drvn_target_order = 2
        noise_drvn_actual = shaft_speed_actual_noise(drvn_noise_data_path, n_Fs, noise_drvn_target_order, drvn_by_drv)
        print("소음 분석 피구동축 회전 속도(Hz) : ", noise_drvn_actual)
        print("진동/소음 피구동축 회전 속도 차(Hz) - 절대값 : ", abs(drvn_actual - noise_drvn_actual))

        return drv_actual, drvn_actual

    else:
        print("구동축 회전 속도를 산출할 수 없으므로 피구동축 회전 속도 산출 불가능")
        return drv_actual, -1
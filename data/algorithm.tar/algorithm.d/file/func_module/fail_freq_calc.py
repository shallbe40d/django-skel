import os

import numpy as np

from file.func_module.read_json import read_json
from file.func_module.write_json import wirte_json_fail_freq


def Na(a, b):
    """최대공약수 산출

    :param a: 큰 수
    :param b: 작은 수
    :return: 최대공약수
    """
    if a % b == 0:
        return b
    else:
        return Na(b, a % b)


def bearing_fail_feq(F_r, bn, B_d, P_d, ContactAngle):
    """ 베어링 결함 주파수 산출(BPFI : 내륜통과주파수, BPFO : 외륜통과주파수, BSF : 볼통과주파수, FTF : 기본주행주파수)

    :param float F_r: 축 회전 주파수
    :param float bn: 베어링 볼 개수(개)
    :param float B_d: 베어링 볼 직경(mm)
    :param float P_d: 베어링 피치원(mm)
    :param float ContactAngle: 베어링 접촉각(°)
    :return: BPFI, BPFO, BSF, FTF
    """
    BPFI = -1
    BPFO = -1
    BSF = -1
    FTF = -1
    if bn > 0 and B_d > 0 and P_d > 0 and ContactAngle >= 0:
        BPFI = 0.5 * (1 + B_d / P_d * np.cos(ContactAngle * np.pi / 180)) * bn * F_r
        BPFO = 0.5 * (1 - B_d / P_d * np.cos(ContactAngle * np.pi / 180)) * bn * F_r
    if B_d > 0 and P_d > 0 and ContactAngle >= 0:
        BSF = 0.5 * (P_d / B_d) * (1 - (B_d / P_d * np.cos(ContactAngle * np.pi / 180)) ** 2) * F_r
        FTF = 0.5 * (1 - B_d / P_d * np.cos(ContactAngle * np.pi / 180)) * F_r
    return BPFI, BPFO, BSF, FTF


def fail_freq_calc(facility_info, motor_info, decelerator_info, bearing_info, pulley_info, vbelt_info, fan_info, DchainSprocket_info, STchainSprocket_info):
    """ 결함주파수 산출

    :param list facility_info: 설비 정보
        [i][0]  Type            설비 종류(ex. 에스컬레이터(es), 공조기(acm)
        [i][1]  DriveRPM        구동축 회전속도(RPM)
        [i][2]  DrivenRPM       피구동축 회전속도(RPM)
    :param list motor_info: 전동기 정보
        [i][0]  Power               전동기 동력(kW)
        [i][1]  F_L                 전동기 전원 주파수(Hz)
        [i][2]  Reducer_YN          감속 여부(Y/N)
        [i][3]  m_volt              전압(V)
        [i][4]  RatedSpeed          정격 속도(m/min)
        [i][5]  RPM                 전동기 회전 속도(RPM)
        [i][6]  P                   전동기 극 수(극)
        [i][7]  RotorBars           전동기 로터 수(개)
        [i][8]  Blades              전동기 블레이드 수(개)
        [i][9]  CN                  전동기 극당 코일 수(개)
        [i][10] ReducerStageNum     감속기 감속 기어 단 수(단)
        [i][11] ReducerRatioL       감속기 감속비 좌변
        [i][12] ReducerRatioR       감속기 감속비 우변
        [i][13] mpt_type            전동기 동력전달장치(moter power train type | 1 : sprocket, 2 : pulley)
    :param list decelerator_info: 감속기 정보
        [i][0]  name                        감속기 n단
        (
            d1 = 감속기 1단,
            d2 = 감속기 2단,
            d3 = 감속기 3단
        )
        [i][1]  nReducerStageT_Pinion       감속기 기어 n단의 피니언 잇 수(개)
        [i][2]  nReducerStageT_Gear         감속기 기어 n단의 기어 잇 수(개)
        [i][3]  nReducerStagePinionF_n      감속기 기어 n단 피니언 고유 진동수(Hz)
        [i][4]  nReducerStageGearF_n        감속기 기어 n단 기어 고유 진동수(Hz)
    :param list bearing_info: 베어링 정보
        [i][0]  name            베어링 위치
        (
            mhlsb = 전동기 반부하측 베어링, mlsb = 전동기 부하측 베어링,
            d1plb = 감속기 1단 피니언 좌측 베어링, d1prb = 감속기 1단 피니언 우측 베어링,
            d1glb = 감속기 1단 기어 좌측 베어링, d1grb = 감속기 1단 기어 우측 베어링,
            d2plb = 감속기 2단 피니언 좌측 베어링, d2prb = 감속기 2단 피니언 우측 베어링,
            d2glb = 감속기 2단 기어 좌측 베어링, d2grb = 감속기 2단 기어 우측 베어링,
            d3plb = 감속기 3단 피니언 좌측 베어링, d3prb = 감속기 3단 피니언 우측 베어링,
            d3glb = 감속기 3단 기어 좌측 베어링, d3grb = 감속기 3단 기어 우측 베어링,
            sb = 축 베어링
        )
        [i][1]  nn              베어링 볼 개수(개)
        [i][2]  nB_d            베어링 볼 직경(mm)
        [i][3]  nP_d            베어링 피치원(mm)
        [i][4]  nContactAngle   베어링 접촉각(°)
        [i][5]  nBearingF_n     베어링 고유진동수(Hz)
    :param list pulley_info: 풀리 정보
        [i][0]  DrivePulleyPCD      구동부 풀리 피치원 지름(mm)
        [i][1]  DrivenPylleyPCD     피구동부 풀리 피치원 지름(mm)
    :param list vbelt_info: V-벨트 정보
        [i][0]  vbelt_num           V벨트 열 수(개)
        [i][1]  vbelt_length        V벨트 길이(mm)
        [i][2]  vbelt_nf            V벨트 고유진동수(Hz)
        [i][3]  distance_pulleys    구동-피동 풀리 중심 거리(mm)
    :param list fan_info: 송풍기 팬 정보
        [i][0]  acmFanBladeNum      송풍기 팬 날개 수(개)
    :param list DchainSprocket_info: 구동/피구동 스프라켓 정보
        [i][0]  DriveSprocketNT     구동부 스프라켓 잇 수(개)
        [i][1]  DriveSprocketPCD    구동부 스프라켓 피치원 지름(mm)
        [i][2]  DrivenSprocketNT    피구동부 스프라켓 잇 수(개)
        [i][3]  DrivenSprocketPCD   피구동부 스프라켓 피치원 지름(mm)
    :param list STchainSprocket_info: 스텝체인 스프라켓 정보
        [i][0]  STchainSprocketNT   스텝체인 스프라켓 잇 수(개)
        [i][1]  STchainSprocketPCD  스텝체인 스프라켓 피치원 지름(mm)
    :return: N_S_RPM, N_S, F_r, F_S, F_P, RBPF, BPF, CPF, m_GMF, ndcl_freq_list, DrivenPulleyRPM, nb_freq_list, vbelt_f, Fan_F_r
    """

    motor_speed_slip = float(motor_info['RPM'])
    if float(facility_info['DriveRPM']) > 0:
        motor_speed_slip = float(facility_info['DriveRPM'])

    # 전동기 슬립없는 동기 속도
    # (120 * 전동기 전원 주파수)/전동기 극 수
    N_S_RPM = -1
    if float(motor_info['F_L']) > 0 and float(motor_info['P']) > 0:
        N_S_RPM = (120 * float(motor_info['F_L'])) / float(motor_info['P'])

    # 전동기 축 회전주파수(슬립 x)
    # 전동기 슬립없는 동기 속도/60
    N_S = -1
    if N_S_RPM > 0:
        N_S = N_S_RPM / 60

    # 전동기 축 회전주파수(슬립 o) = 명판
    # 전동기 회전 속도/60
    F_r = -1
    if motor_speed_slip > 0:
        F_r = motor_speed_slip / 60

    # 전동기 슬립주파수
    # (전동기 슬립없는 동기 속도 - 전동기 회전 속도)/60
    F_S = -1
    if N_S_RPM > 0 and motor_speed_slip > 0:
        F_S = (N_S_RPM - motor_speed_slip) / 60

    # 전동기 극통과주파수
    # 전동기 극 수 * (전동기 슬립없는 동기 속도 - 전동기 회전 속도))/60
    F_P = -1
    if float(motor_info['P']) > 0 and N_S_RPM > 0 and motor_speed_slip > 0:
        F_P = (float(motor_info['P']) * (N_S_RPM - motor_speed_slip)) / 60

    # 전동기 로터바 통과주파수
    # 전동기 로터 수 * 전동기 축 회전주파수(슬립 o)
    RBPF = -1
    if float(motor_info['RotorBars']) > 0 and F_r > 0:
        RBPF = float(motor_info['RotorBars']) * F_r

    # 전동기 블레이드 통과주파수
    # 전동기 블레이드 수 * 전동기 축 회전주파수(슬립 x)
    BPF = -1
    if float(motor_info['Blades']) > 0 and N_S > 0:
        BPF = float(motor_info['Blades']) * N_S

    # 전동기 코일 통과주파수
    # (전동기 극 수 * 전동기 극당 코일 수)/60
    CPF = -1
    if float(motor_info['P']) > 0 and float(motor_info['CN']) > 0:
        CPF = (float(motor_info['P']) * float(motor_info['CN'])) / 60

    # 전동기 최종 출력 축 GMF (풀리의 경우 계산 X)
    # 감속기 Y : 구동부 스프라켓 잇 수 * 전동기 축 회전주파수(슬립 x)/감속기 감속비
    # 감속기 N : 구동부 스프라켓 잇 수 * 전동기 축 회전주파수(슬립 x)
    # m_GMF = -1
    # if motor_info[0][13] == 1:  # 1 : sprocket, 2 : pulley
    #     if N_S > 0 and DchainSprocket_info[0][0] > 0 and motor_info[0][11] > 0 and motor_info[0][12] > 0:
    #         if motor_info[0][2] == "Y":
    #             m_GMF = DchainSprocket_info[0][0] * N_S * (motor_info[0][11] / motor_info[0][12])
    #         elif motor_info[0][2] == "N":
    #             m_GMF = DchainSprocket_info[0][0] * N_S

    # 전동기 최종 출력 축 GMF (풀리의 경우 계산 X)
    # 감속기 Y : 구동부 스프라켓 잇 수 * 전동기 축 회전주파수(슬립 o)/감속기 감속비
    # 감속기 N : 구동부 스프라켓 잇 수 * 전동기 축 회전주파수(슬립 o)
    m_GMF = -1
    if int(motor_info['mpt_type']) == 1:  # 1 : sprocket, 2 : pulley
        if F_r > 0 and DchainSprocket_info[0][0] > 0 and float(motor_info['ReducerRatioL']) > 0 and float(motor_info['ReducerRatioR']) > 0:
            if motor_info[0][2] == "Y":
                m_GMF = DchainSprocket_info[0][0] * F_r * (float(motor_info['ReducerRatioL']) / float(motor_info['ReducerRatioR']))
            elif motor_info[0][2] == "N":
                m_GMF = DchainSprocket_info[0][0] * F_r

    # 감속기 고장주파수
    ndcl_freq_list = []
    ReducerStageF_r = -1
    if motor_info['Reducer_YN'] == "Y" and F_r > 0 and int(motor_info['ReducerStageNum']) > 0:
        ndcl_fr = 0
        for i in range(int(motor_info['ReducerStageNum'])):
            if i == 0:
                ndcl_fr = F_r
            elif i >= 1:
                ndcl_fr = ReducerStageF_r

            # 감속기 기어 n단 GMF
            # 감속기 기어 1단 : 전동기 축 회전주파수(슬립 x) * 감속기 기어 1단 피니언 잇수
            # 감속기 기어 n단(n > 1) : 감속기 기어 n-1단 축 회전주파수 * 감속기 기어 n단 피니언 잇수
            ReducerStageGMF = -1
            if float(decelerator_info[i]['nReducerStageT_Pinion']) > 0:
                ReducerStageGMF = ndcl_fr * float(decelerator_info[i]['nReducerStageT_Pinion'])

            # 감속기 기어 n단 축 회전주파수
            # 감속기 기어 n단 GMF / 감속기 기어 n단 기어 잇수
            ReducerStageF_r = -1
            if ReducerStageGMF > 0 and float(decelerator_info[i]['nReducerStageT_Gear']) > 0:
                ReducerStageF_r = ReducerStageGMF / float(decelerator_info[i]['nReducerStageT_Gear'])

            # 감속기 기어 n단 헌팅주파수
            # (감속기 기어n단 GMF * (감속기 기어n단의 피니언 잇수와 감속기 기어n단의 기어 잇수의 소인수)) / (감속기 기어n단의 기어 잇수 * 감속기 기어n단의 피니언 잇수)
            ReducerF_ht = -1
            if ReducerStageGMF > 0 and float(decelerator_info[i]['nReducerStageT_Pinion']) > 0 and float(decelerator_info[i]['nReducerStageT_Gear']) > 0:
                N_a = Na(float(decelerator_info[i]['nReducerStageT_Gear']), float(decelerator_info[i]['nReducerStageT_Pinion']))    # 감속기 기어n단의 피니언 잇수와 감속기 기어n단의 기어 잇수의 소인수
                ReducerF_ht = (ReducerStageGMF * N_a) / (float(decelerator_info[i]['nReducerStageT_Pinion']) * float(decelerator_info[i]['nReducerStageT_Gear']))

            ndcl_freq_list.append([decelerator_info[i][0], ReducerStageGMF, ReducerStageF_r, ReducerF_ht])

    # 피동풀리 RPM(Hz)
    DrivenPulleyRPM = -1
    if int(motor_info['mpt_type']) == 2:
        if float(facility_info['DrivenRPM']) > 0:
            DrivenPulleyRPM = float(facility_info['DrivenRPM']) / 60
        elif F_r > 0 and float(pulley_info['DrivePulleyPCD']) > 0 and float(pulley_info['DrivenPulleyPCD']) > 0:
            DrivenPulleyRPM = F_r * (float(pulley_info['DrivePulleyPCD']) / float(pulley_info['DrivenPulleyPCD']))

    # 베어링 고장주파수
    nb_freq_list = []
    for i in range(len(bearing_info)):
        BPFI = -1  # 베어링 내륜 통과 주파수
        BPFO = -1  # 베어링 외륜 통과 주파수
        BSF = -1  # 베어링 볼 통과 주파수
        FTF = -1  # 베어링 기본 주행 주파수

        if bearing_info[i]['name'] == "mhlsb" or bearing_info[i]['name'] == "mlsb":
            if F_r > 0: # 무부하 : N_S, 부하 : F_r
                BPFI, BPFO, BSF, FTF = bearing_fail_feq(F_r, float(bearing_info[i]['nn']), float(bearing_info[i]['nB_d']), float(bearing_info[i]['nP_d']), float(bearing_info[i]['nContactAngle']))
        elif bearing_info[i]['name'] == "sb":
            if DrivenPulleyRPM > 0:
                BPFI, BPFO, BSF, FTF = bearing_fail_feq(DrivenPulleyRPM, float(bearing_info[i]['nn']), float(bearing_info[i]['nB_d']), float(bearing_info[i]['nP_d']), float(bearing_info[i]['nContactAngle']))

        if motor_info['Reducer_YN'] == "Y":
            if bearing_info[i]['name'] == "d1plb" or bearing_info[i]['name'] == "d1prb":
                if F_r > 0:
                    BPFI, BPFO, BSF, FTF = bearing_fail_feq(F_r, float(bearing_info[i]['nn']), float(bearing_info[i]['nB_d']), float(bearing_info[i]['nP_d']), float(bearing_info[i]['nContactAngle']))
            elif bearing_info[i]['name'] == "d1glb" or bearing_info[i]['name'] == "d1grb" or bearing_info[i]['name'] == "d2plb" or bearing_info[i]['name'] == "d2prb":
                if float(motor_info['ReducerStageNum']) >= 1 and ndcl_freq_list[0][2] > 0:
                    BPFI, BPFO, BSF, FTF = bearing_fail_feq(ndcl_freq_list[0][2], float(bearing_info[i]['nn']), float(bearing_info[i]['nB_d']), float(bearing_info[i]['nP_d']), float(bearing_info[i]['nContactAngle']))
            elif bearing_info[i]['name'] == "d2glb" or bearing_info[i]['name'] == "d2grb" or bearing_info[i]['name'] == "d3plb" or bearing_info[i]['name'] == "d3prb":
                if float(motor_info['ReducerStageNum']) >= 2 and ndcl_freq_list[1][2] > 0:
                    BPFI, BPFO, BSF, FTF = bearing_fail_feq(ndcl_freq_list[1][2], float(bearing_info[i]['nn']), float(bearing_info[i]['nB_d']), float(bearing_info[i]['nP_d']), float(bearing_info[i]['nContactAngle']))
            elif bearing_info[i]['name'] == "d3glb" or bearing_info[i]['name'] == "d3grb":
                if float(motor_info['ReducerStageNum']) >= 3 and ndcl_freq_list[2][2] > 0:
                    BPFI, BPFO, BSF, FTF = bearing_fail_feq(ndcl_freq_list[2][2], float(bearing_info[i]['nn']), float(bearing_info[i]['nB_d']), float(bearing_info[i]['nP_d']), float(bearing_info[i]['nContactAngle']))

        nb_freq_list.append([bearing_info[i]['name'], float(bearing_info[i]['nBearingF_n']), BPFI, BPFO, BSF, FTF])

    # V벨트 주파수(Hz)
    vbelt_f = -1
    if float(motor_info['mpt_type']) == 2 and F_r > 0 and float(pulley_info['DrivePulleyPCD']) > 0 and float(vbelt_info['vbelt_length']) > 0:
        vbelt_f = (np.pi * F_r * float(pulley_info['DrivePulleyPCD'])) / float(vbelt_info['vbelt_length'])

    # 공조기 팬 결함주파수
    Fan_F_r = -1
    if float(motor_info['mpt_type']) == 2 and float(fan_info['acmFanBladeNum']) > 0 and DrivenPulleyRPM > 0:
        Fan_F_r = float(fan_info['acmFanBladeNum']) * DrivenPulleyRPM

    return N_S_RPM, N_S, F_r, F_S, F_P, RBPF, BPF, CPF, m_GMF, ndcl_freq_list, DrivenPulleyRPM, nb_freq_list, vbelt_f, Fan_F_r


def fail_freq_json_path(mechanical_spec_path):
    # 기계 설비 스펙 정보 불러오기(json)
    mes = read_json(mechanical_spec_path)

    N_S_RPM, N_S, F_r, F_S, F_P, RBPF, BPF, CPF, m_GMF, ndcl_freq_list, DrivenPulleyRPM, nb_freq_list, vbelt_f, Fan_F_r = fail_freq_calc(
        mes['Facility'], mes['Motor'], mes['Decelerator'], mes['Bearing'], mes['Pulley'], mes['Vbelt'], mes['Fan'], [],
        [])

    file_path = "./file/fault_freq.json"
    wirte_json_fail_freq(file_path, N_S_RPM, N_S, F_r, F_S, F_P, RBPF, BPF, CPF, m_GMF, ndcl_freq_list, DrivenPulleyRPM,
                         nb_freq_list, vbelt_f, Fan_F_r)
    file_path = os.path.abspath(file_path)

    return file_path
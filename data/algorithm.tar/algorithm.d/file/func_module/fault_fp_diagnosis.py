import numpy as np
import sys
import os
from scipy import signal

from file.func_module.harmonics_freq_calc import harmonics_freq_calc, sidebands_freq_calc, peaks_interval_calc

"""
(list)ndcl_freq_list
    [i][0]  name                감속기 n단
                                (d1 = 감속기 1단, d2 = 감속기 2단, d3 = 감속기 3단)
    [i][1]  ReducerStageGMF     감속기 기어 n단 GMF
    [i][2]  ReducerStageF_r     감속기 기어 n단 축 회전주파수
    [i][3]  ReducerF_ht         감속기 기어 n단 헌팅주파수

(list)nb_freq_list
    [i][0]  name            베어링 위치
                            (
                                mhlsb = 전동기 반부하측 베어링, mlsb = 전동기 부하측 베어링,
                                d1plb = 감속기 1단 피니언 좌측 베어링, d1prb = 감속기 1단 피니언 우측 베어링,
                                d1glb = 감속기 1단 기어 좌측 베어링, d1grb = 감속기 1단 기어 우측 베어링,
                                d2plb = 감속기 2단 피니언 좌측 베어링, d2prb = 감속기 2단 피니언 우측 베어링,
                                d2glb = 감속기 2단 기어 좌측 베어링, d2grb = 감속기 2단 기어 우측 베어링,
                                d3plb = 감속기 3단 피니언 좌측 베어링, d3prb = 감속기 3단 피니언 우측 베어링,
                                d3glb = 감속기 3단 기어 좌측 베어링, d3grb = 감속기 3단 기어 우측 베어링,
                                sb = 축 베어링
                            )
    [i][1]  nBearingF_n     베어링 고유진동수(Hz)
    [i][2]  BPFI            베어링 내륜통과주파수
    [i][3]  BPFO            베어링 외륜통과주파수
    [i][4]  BSF             베어링 구름요소 회전주파수
    [i][5]  FTF             베어링 기본주행주파수
    
(list)motor_info
    [i][0]  Power               전동기 동력(kW)
    [i][1]  F_L                 전동기 전원 주파수(Hz)
    [i][2]  Reducer_YN          감속 여부(Y/N)
    [i][3]  m_volt              전압(V)
    [i][4]  RatedSpeed          정격 속도(m/min)
    [i][5]  RPM                 전동기 회전 속도(RPM)
    [i][6]  P                   전동기 극 수(극)
    [i][7]  RotorBars           전동기 로터 수(개)
    [i][8]  Blades              전동기 블레이드 수(개)
    [i][9]  CN                  전동기 극당 코일 수(개)
    [i][10] ReducerStageNum     감속기 감속 기어 단 수(단)
    [i][11] ReducerRatioL       감속기 감속비 좌변
    [i][12] ReducerRatioR       감속기 감속비 우변
    [i][13] mpt_type            전동기 동력전달장치(moter power train type | 1 : sprocket, 2 : pulley)
"""

"""
    전동기, 벨트, 기어, 회전체 등등 따로 구현
"""


def vib_threshold_find(sensor_pos, axis, fft_th_arry, freq):
    """ 진동 FFT 임계치 찾기

    :param int sensor_pos: 진동 센서 부착 위치
    :param string axis: 진동 데이터 축
    :param fft_th_arry: FFT 임계치 배열
    :param float freq: 임계치를 찾을 결함 주파수
    :return: float rtn_th - 주파수 임계치
    """
    try:
        pos_str = "none"
        if sensor_pos == 1:
            pos_str = "mo-re"
        elif sensor_pos == 2:
            pos_str = "l-sh-be"
        elif sensor_pos == 3:
            pos_str = "r-sh-be"
        elif sensor_pos == 4:
            pos_str = "base"

        axis_str = "none"
        if axis == "x":
            axis_str = "x_axis_threshold"
        elif axis == "y":
            axis_str = "y_axis_threshold"
        elif axis == "z":
            axis_str = "z_axis_threshold"

        rtn_th = 100

        if pos_str == "none" or axis_str == "none":
            pass
        elif freq >= float(fft_th_arry['rpm_range']['Subharmonics']) and freq < float(fft_th_arry['rpm_range']['1xRPM']):
            rtn_th = float(fft_th_arry[pos_str][axis_str]['Subharmonics'])
        elif freq >= float(fft_th_arry['rpm_range']['1xRPM']) and freq < float(fft_th_arry['rpm_range']['2xRPM']):
            rtn_th = float(fft_th_arry[pos_str][axis_str]['1xRPM'])
        elif freq >= float(fft_th_arry['rpm_range']['2xRPM']) and freq < float(fft_th_arry['rpm_range']['3-4xRPM']):
            rtn_th = float(fft_th_arry[pos_str][axis_str]['2xRPM'])
        elif freq >= float(fft_th_arry['rpm_range']['3-4xRPM']) and freq < float(fft_th_arry['rpm_range']['5-12xRPM']):
            rtn_th = float(fft_th_arry[pos_str][axis_str]['3-4xRPM'])
        elif freq >= float(fft_th_arry['rpm_range']['5-12xRPM']) and freq < float(fft_th_arry['rpm_range']['HFD']):
            rtn_th = float(fft_th_arry[pos_str][axis_str]['5-12xRPM'])
        elif freq >= float(fft_th_arry['rpm_range']['HFD']) and freq < float(fft_th_arry['rpm_range']['END']):
            rtn_th = float(fft_th_arry[pos_str][axis_str]['HFD'])

        return rtn_th
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print('fail error:', e)
        print(exc_type, fname, exc_tb.tb_lineno)
        print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
        return 100


def th_count_calc(hz_min, freq, harmonics):
    """ 조화성분 갯수 임계치

    :param int hz_min: FFT 최소 보장 주파수
    :param float freq: 1x 결함 주파수
    :param int harmonics: 조화성분
    :return:
    """

    try:
        # 최소 보장 Hz보다 높은 조화성분만 갯수를 센다
        th_count = 0
        for i in range(1, harmonics + 1):
            if i * freq >= hz_min:
                th_count = th_count + 1

        # 갯수중 과반수 이상으로 설정
        return th_count / 2
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print('fail error:', e)
        print(exc_type, fname, exc_tb.tb_lineno)
        print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
        return 0


def motor_fault_fp_diagnosis(sensor_pos, axis, fft_th_arry, fft_data, peaks, hz_max, hz_min, F_r, F_P, motor_info, RBPF, F_S, CPF):
    """ 전동기 결함 진단

    :param sensor_pos: 진동 센서 부착 위치
    :param axis: 진동 FFT 데이터 축(x, y, z)
    :param fft_th_arry: FFT 임계치 데이터
    :param fft_data: 진동 FFT 데이터
    :param peaks: 진동 FFT Peak frequency
    :param int hz_max: 진동 FFT 주파수 최대값
    :param int hz_min: 진동 FFT 주파수 최소값
    :param float F_r: 회전주파수
    :param float F_P: 극통과주파수
    :param motor_info: 전동기 정보
    :param float RBPF:
    :param float F_S:
    :param float CPF:
    :return:
    """

    try:
        # 고장 유형
        fail_list = []
        # sideband 진폭 임계치 %(defualt : 0.5 => 50%)
        sb_amp_th_pro = 0.5

        ##############################################################################################################

        # 고정자 편심 & 회전자 편심
        if motor_info[0][1] > 0:
            # 2xFL
            harmonics = 2
            nxfreq_list, pk_bool_list = harmonics_freq_calc(fft_data, peaks, motor_info[0][1], hz_min, hz_max, harmonics)

            # 극통과주파수 측대파
            if F_P > 0:
                sb_l_freq, sb_r_freq, sb_l_pk_bool, sb_r_pk_bool = sidebands_freq_calc(fft_data, peaks, hz_min, hz_max, nxfreq_list[1], pk_bool_list[1], F_P)

                th_freq = vib_threshold_find(sensor_pos, axis, fft_th_arry, nxfreq_list[1])
                th_sb_l = vib_threshold_find(sensor_pos, axis, fft_th_arry, sb_l_freq) * sb_amp_th_pro
                th_sb_r = vib_threshold_find(sensor_pos, axis, fft_th_arry, sb_r_freq) * sb_amp_th_pro

                # 2xfl에서 높은 진동
                if pk_bool_list[1] == 1 and fft_data[nxfreq_list[1]] > th_freq:
                    # 극통과주파수 측대파 X
                    if sb_l_pk_bool == 0 or sb_r_pk_bool == 0:
                        print("고정자 편심")
                        l = [int('0b00100001', 2)]  # M1
                        fail_list = fail_list + l
                    # 극통과주파수 측대파 O
                    elif sb_l_pk_bool == 1 and sb_r_pk_bool == 1 and fft_data[sb_l_freq] > th_sb_l and fft_data[sb_r_freq] > th_sb_r:
                        print("회전자 편심")
                        l = [int('0b00100010', 2)]  # M2
                        fail_list = fail_list + l

        ###############################################################################################################

        # 회전자 바 균열, 절단
        if F_r > 0:
            # 전동기 축 회전주파수(슬립 o) = F_r 조화성분 1X ~ 3X
            harmonics = 3
            nxfreq_list, pk_bool_list = harmonics_freq_calc(fft_data, peaks, F_r, hz_min, hz_max, harmonics)

            th_over_list = [0 for i in range(len(nxfreq_list))]  # 조화성분 임계치 초과 유무
            for nx in range(len(nxfreq_list)):
                th_freq = vib_threshold_find(sensor_pos, axis, fft_th_arry, nxfreq_list[nx])
                if pk_bool_list[nx] == 1 and fft_data[nxfreq_list[nx]] > th_freq:
                    th_over_list[nx] = 1

            # 조화성분 갯수 확인
            nxF_r_count = sum(th_over_list)

            # 극통과주파수 측대파
            sb_num = 0
            if F_P > 0:
                l_th_over_list = [0 for i in range(len(nxfreq_list))]
                r_th_over_list = [0 for i in range(len(nxfreq_list))]
                for nx in range(len(nxfreq_list)):
                    if pk_bool_list[nx] > 0:
                        sb_l_freq, sb_r_freq, sb_l_pk_bool, sb_r_pk_bool = sidebands_freq_calc(fft_data, peaks, hz_min, hz_max, nxfreq_list[nx], pk_bool_list[nx], F_P)

                        th_sb_l = vib_threshold_find(sensor_pos, axis, fft_th_arry, sb_l_freq) * sb_amp_th_pro
                        if sb_l_pk_bool == 1 and fft_data[sb_l_freq] > th_sb_l:
                            l_th_over_list[nx - 1] = 1

                        th_sb_r = vib_threshold_find(sensor_pos, axis, fft_th_arry, sb_r_freq) * sb_amp_th_pro
                        if sb_r_pk_bool == 1 and fft_data[sb_r_freq] > th_sb_r:
                            r_th_over_list[nx - 1] = 1

                sb_l_array = np.array(l_th_over_list)
                sb_r_array = np.array(r_th_over_list)

                sb_array = sb_l_array + sb_r_array

                for i in range(len(sb_array)):
                    if sb_array[i] == 2:
                        sb_num = sb_num + 1

            # 1xRPM(축회전주파수?)과 배수성분에 극통과주파수의 측대파 생성
            th_count = th_count_calc(hz_min, F_r, harmonics)
            if nxF_r_count > th_count and sb_num > th_count:
                print("회전자 바 균열, 절단")
                l = [int('0b00100011', 2)]  # M3
                fail_list = fail_list + l

        ###############################################################################################################

        # 풀리거나 개방된 회전자 바
        if RBPF > 0:
            # 로터바 통과주파수 = RBPF 조화성분 1X ~ 10X
            harmonics = 10
            nxfreq_list, pk_bool_list = harmonics_freq_calc(fft_data, peaks, RBPF, hz_min, hz_max, harmonics)

            th_over_list = [0 for i in range(len(nxfreq_list))]  # 조화성분 임계치 초과 유무
            for nx in range(len(nxfreq_list)):
                th_freq = vib_threshold_find(sensor_pos, axis, fft_th_arry, nxfreq_list[nx])
                if pk_bool_list[nx] == 1 and fft_data[nxfreq_list[nx]] > th_freq:
                    th_over_list[nx] = 1

            # 조화성분 갯수 확인
            nxRBPF_count = sum(th_over_list)

            # 2fl 측대파
            sb_num = 0
            if (2 * motor_info[0][1]) > 0:
                l_th_over_list = [0 for i in range(len(nxfreq_list))]
                r_th_over_list = [0 for i in range(len(nxfreq_list))]
                for nx in range(len(nxfreq_list)):
                    if pk_bool_list[nx] > 0:
                        sb_l_freq, sb_r_freq, sb_l_pk_bool, sb_r_pk_bool = sidebands_freq_calc(fft_data, peaks, hz_min, hz_max, nxfreq_list[nx], pk_bool_list[nx], (2 * motor_info[0][1]))

                        th_sb_l = vib_threshold_find(sensor_pos, axis, fft_th_arry, sb_l_freq) * sb_amp_th_pro
                        if sb_l_pk_bool == 1 and fft_data[sb_l_freq] > th_sb_l:
                            l_th_over_list[nx - 1] = 1

                        th_sb_r = vib_threshold_find(sensor_pos, axis, fft_th_arry, sb_r_freq) * sb_amp_th_pro
                        if sb_r_pk_bool == 1 and fft_data[sb_r_freq] > th_sb_r:
                            r_th_over_list[nx - 1] = 1

                sb_l_array = np.array(l_th_over_list)
                sb_r_array = np.array(r_th_over_list)

                sb_array = sb_l_array + sb_r_array

                for i in range(len(sb_array)):
                    if sb_array[i] == 2:
                        sb_num = sb_num + 1

                # 로터바 통과주파수와 배수성분에 전력계통 주파수 2배의 측대파 생성
                th_count = th_count_calc(hz_min, RBPF, harmonics)
                if nxRBPF_count > th_count and sb_num > th_count:
                    print("풀리거나 개방된 회전자 바")
                    l = [int('0b00100100', 2)]  # M4
                    fail_list = fail_list + l

        ###############################################################################################################

        # 회전자의 국부과열로 인한 휨상태
        if motor_info[0][1] > 0:
            # 2xfl
            harmonics = 2
            nxfreq_list, pk_bool_list = harmonics_freq_calc(fft_data, peaks, motor_info[0][1], hz_min, hz_max, harmonics)

            # 슬립주파수 측대파
            if F_S > 0:
                sb_l_freq, sb_r_freq, sb_l_pk_bool, sb_r_pk_bool = sidebands_freq_calc(fft_data, peaks, hz_min, hz_max, nxfreq_list[1], pk_bool_list[1], F_S)

                th_freq = vib_threshold_find(sensor_pos, axis, fft_th_arry, nxfreq_list[1])
                th_sb_l = vib_threshold_find(sensor_pos, axis, fft_th_arry, sb_l_freq) * sb_amp_th_pro
                th_sb_r = vib_threshold_find(sensor_pos, axis, fft_th_arry, sb_r_freq) * sb_amp_th_pro

                # 2xfl에서 높은 진동 and 슬립주파수 측대파 O
                if pk_bool_list[1] == 1 and fft_data[nxfreq_list[1]] > th_freq:
                    if sb_l_pk_bool == 1 and sb_r_pk_bool == 1 and fft_data[sb_l_freq] > th_sb_l and fft_data[sb_r_freq] > th_sb_r:
                        print("회전자의 국부과열로 인한 휨상태")
                        l = [int('0b00100101', 2)]  # M5
                        fail_list = fail_list + l

        ###############################################################################################################

        # 전기적 위상 문제
        if motor_info[0][1] > 0:
            # 2xfl
            harmonics = 2
            nxfreq_list, pk_bool_list = harmonics_freq_calc(fft_data, peaks, motor_info[0][1], hz_min, hz_max, harmonics)

            # 전력계통주파수 1/3의 측대파
            if (motor_info[0][1] / 3) > 0:
                sb_l_freq, sb_r_freq, sb_l_pk_bool, sb_r_pk_bool = sidebands_freq_calc(fft_data, peaks, hz_min, hz_max, nxfreq_list[1], pk_bool_list[1], (motor_info[0][1] / 3))

                th_freq = vib_threshold_find(sensor_pos, axis, fft_th_arry, nxfreq_list[1])
                th_sb_l = vib_threshold_find(sensor_pos, axis, fft_th_arry, sb_l_freq) * sb_amp_th_pro
                th_sb_r = vib_threshold_find(sensor_pos, axis, fft_th_arry, sb_r_freq) * sb_amp_th_pro

                # 2xfl에서 높은 진동 and 전력계통주파수 1/3의 측대파 O
                if pk_bool_list[1] == 1 and fft_data[nxfreq_list[1]] >= th_freq:
                    if sb_l_pk_bool == 1 and sb_r_pk_bool == 1 and fft_data[sb_l_freq] > th_sb_l and fft_data[sb_r_freq] > th_sb_r:
                        print("전기적 위상 문제")
                        l = [int('0b00100110', 2)]  # M6
                        fail_list = fail_list + l

        ###############################################################################################################

        # 고정자 코일 풀림
        if CPF > 0:
            # 코일통과주파수 1x
            harmonics = 1
            nxfreq_num, nxfreq_list, pk_bool_list = harmonics_freq_calc(fft_data, peaks, CPF, hz_min, hz_max, harmonics)

            # 1xRPM : 전동기 축 회전주파수 측대파
            if F_r > 0:
                sb_l_freq, sb_r_freq, sb_l_pk_bool, sb_r_pk_bool = sidebands_freq_calc(fft_data, peaks, hz_min, hz_max, nxfreq_list[0], pk_bool_list[0], F_r)

                th_freq = vib_threshold_find(sensor_pos, axis, fft_th_arry, nxfreq_list[0])
                th_sb_l = vib_threshold_find(sensor_pos, axis, fft_th_arry, sb_l_freq) * sb_amp_th_pro
                th_sb_r = vib_threshold_find(sensor_pos, axis, fft_th_arry, sb_r_freq) * sb_amp_th_pro

                # 코일통과주파수에서 높은 진동 및 1X축 회전주파수 측대파 형성
                if pk_bool_list[0] == 1 and fft_data[nxfreq_list[0]] >= th_freq:
                    if sb_l_pk_bool == 1 and sb_r_pk_bool == 1 and fft_data[sb_l_freq] > th_sb_l and fft_data[sb_r_freq] > th_sb_r:
                        print("고정자 코일 풀림")
                        l = [int('0b00100111', 2)]  # M7
                        fail_list = fail_list + l

        ############################################################################################################

        # 고정자 단락(stator short)
        # if motor_info[0][1] > 0:
        #     # 2xFL
        #     harmonics = 6
        #     nxfreq_list, pk_bool_list = harmonics_freq_calc(fft_data, peaks, motor_info[0][1], hz_min, hz_max, harmonics)
        #
        #     th_1x_freq = vib_threshold_find(sensor_pos, axis, fft_th_arry, nxfreq_list[1])
        #     th_2x_freq = vib_threshold_find(sensor_pos, axis, fft_th_arry, nxfreq_list[3])
        #     th_3x_freq = vib_threshold_find(sensor_pos, axis, fft_th_arry, nxfreq_list[5])
        #     if pk_bool_list[1] == 1 and fft_data[nxfreq_list[1]] > th_1x_freq:
        #         if (pk_bool_list[3] == 1 and fft_data[nxfreq_list[3]] > th_2x_freq) or (pk_bool_list[5] == 1 and fft_data[nxfreq_list[5]] > th_3x_freq):
        #             print("고정자 단락(stator short)")
        #             l = [int('0b00101000', 2)]  # M8
        #             fail_list = fail_list + l

        ###############################################################################################################

        if not fail_list:
            l = []  # [int('0b11111111', 2)]
            fail_list = fail_list + l
        else:
            # 진단결과 중복 제거
            fail_set = set(fail_list)  # 집합 set으로 변환
            fail_list = list(fail_set)  # list로 변환

        return fail_list
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print('fail error:', e)
        print(exc_type, fname, exc_tb.tb_lineno)
        print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
        return -1


def belt_fault_fp_diagnosis(sensor_pos, sh_axis, hr_axis, fft_th_arry, sh_fft_data, sh_peaks, hr_fft_data, hr_peaks, hz_max, hz_min, belt_freq, F_r, DrivenPulleyRPM, Fan_F_r):
    """ 벨트 결함 진단

    :param sensor_pos: 진동 센서 부착 위치
    :param sh_axis: 축방향 진동 FFT 데이터 축(x, y, z)
    :param hr_axis: 반경방향 진동 FFT 데이터 축(x, y, z)
    :param fft_th_arry: FFT 임계치 데이터
    :param sh_fft_data: 축방향 진동 FFT 데이터
    :param sh_peaks: 축방향 진동 FFT Peak frequency
    :param hr_fft_data: 반경방향 진동 FFT 데이터
    :param hr_peaks: 반경방향 진동 FFT Peak frequency
    :param int hz_max: 진동 FFT 주파수 최대값
    :param int hz_min: 진동 FFT 주파수 최소값
    :param belt_freq:
    :param F_r:
    :param DrivenPulleyRPM:
    :param Fan_F_r:
    :return:
    """

    try:
        # 고장 유형
        fail_list = []

        ##############################################################################################################

        # 벨트 마모 및 풀림 - 반경방향
        if belt_freq > 0:
            # 벨트주파수 => 조화성분 1X ~ 4X
            harmonics = 4

            # 축방향
            nxfreq_list, pk_bool_list = harmonics_freq_calc(sh_fft_data, sh_peaks, belt_freq, hz_min, hz_max, harmonics)

            # 피동축 주파수와 겹치는지 확인
            drvn_nxfreq_list, _pk_bool_list = harmonics_freq_calc(sh_fft_data, sh_peaks, DrivenPulleyRPM, hz_min, hz_max, 1)

            th_freq = vib_threshold_find(sensor_pos, sh_axis, fft_th_arry, nxfreq_list[1])
            if pk_bool_list[1] == 1 and hr_fft_data[nxfreq_list[1]] > th_freq and nxfreq_list[1] != drvn_nxfreq_list[0]:
                print("벨트 마모 및 풀림")
                l = [int('0b10100001', 2)]  # V1
                fail_list = fail_list + l

            th_freq = vib_threshold_find(sensor_pos, sh_axis, fft_th_arry, nxfreq_list[2])
            if pk_bool_list[2] == 1 and hr_fft_data[nxfreq_list[2]] > th_freq and nxfreq_list[2] != drvn_nxfreq_list[0]:
                print("벨트 마모 및 풀림")
                l = [int('0b10100001', 2)]  # V1
                fail_list = fail_list + l

            th_freq = vib_threshold_find(sensor_pos, sh_axis, fft_th_arry, nxfreq_list[3])
            if pk_bool_list[3] == 1 and hr_fft_data[nxfreq_list[3]] > th_freq and nxfreq_list[3] != drvn_nxfreq_list[0]:
                print("벨트 마모 및 풀림")
                l = [int('0b10100001', 2)]  # V1
                fail_list = fail_list + l

            # 반경방향
            nxfreq_list, pk_bool_list = harmonics_freq_calc(hr_fft_data, hr_peaks, belt_freq, hz_min, hz_max, harmonics)

            # 피동축 주파수와 겹치는지 확인
            drvn_nxfreq_list, _pk_bool_list = harmonics_freq_calc(hr_fft_data, hr_peaks, DrivenPulleyRPM, hz_min, hz_max, 1)

            th_freq = vib_threshold_find(sensor_pos, hr_axis, fft_th_arry, nxfreq_list[1])
            if pk_bool_list[1] == 1 and hr_fft_data[nxfreq_list[1]] > th_freq and nxfreq_list[1] != drvn_nxfreq_list[0]:
                print("벨트 마모 및 풀림")
                l = [int('0b10100001', 2)]  # V1
                fail_list = fail_list + l

            th_freq = vib_threshold_find(sensor_pos, hr_axis, fft_th_arry, nxfreq_list[2])
            if pk_bool_list[2] == 1 and hr_fft_data[nxfreq_list[2]] > th_freq and nxfreq_list[2] != drvn_nxfreq_list[0]:
                print("벨트 마모 및 풀림")
                l = [int('0b10100001', 2)]  # V1
                fail_list = fail_list + l

            th_freq = vib_threshold_find(sensor_pos, hr_axis, fft_th_arry, nxfreq_list[3])
            if pk_bool_list[3] == 1 and hr_fft_data[nxfreq_list[3]] > th_freq and nxfreq_list[3] != drvn_nxfreq_list[0]:
                print("벨트 마모 및 풀림")
                l = [int('0b10100001', 2)]  # V1
                fail_list = fail_list + l

        ##############################################################################################################

        # 벨트 불평형 - 축방향
        if F_r > 0:
            # 1xRPM(축 회전 주파수)에서 큰 진동
            harmonics = 1
            nxfreq_list, pk_bool_list = harmonics_freq_calc(sh_fft_data, sh_peaks, F_r, hz_min, hz_max,
                                                                        harmonics)

            th_freq = vib_threshold_find(sensor_pos, sh_axis, fft_th_arry, nxfreq_list[0])
            if pk_bool_list[0] == 1 and sh_fft_data[nxfreq_list[0]] > th_freq:
                print("벨트 불평형(구동부 peak)")
                l = [int('0b10100010', 2)]  # V2
                fail_list = fail_list + l

        if DrivenPulleyRPM > 0:
            # 1xRPM(피동풀리 회전 주파수)에서 큰 진동
            harmonics = 1
            nxfreq_list, pk_bool_list = harmonics_freq_calc(sh_fft_data, sh_peaks, DrivenPulleyRPM, hz_min,
                                                                        hz_max, harmonics)

            th_freq = vib_threshold_find(sensor_pos, sh_axis, fft_th_arry, nxfreq_list[0])
            if pk_bool_list[0] == 1 and sh_fft_data[nxfreq_list[0]] >= th_freq:
                print("벨트 불평형(피구동부 peak)")
                l = [int('0b10100010', 2)]  # V2
                fail_list = fail_list + l

        ##############################################################################################################

        # 벨트 편심 및 이탈 - 반경방향
        if Fan_F_r > 0:
            # 1xFan 주파수에서 큰 진동
            harmonics = 1
            nxfreq_list, pk_bool_list = harmonics_freq_calc(hr_fft_data, hr_peaks, Fan_F_r, hz_min, hz_max,
                                                                        harmonics)

            th_freq = vib_threshold_find(sensor_pos, hr_axis, fft_th_arry, nxfreq_list[0])
            if pk_bool_list[0] == 1 and hr_fft_data[nxfreq_list[0]] > th_freq:
                print("벨트 편심 및 이탈(1xfan 주파수)")
                l = [int('0b10100011', 2)]  # V3
                fail_list = fail_list + l

        if F_r > 0 and DrivenPulleyRPM > 0:
            # 1xRPM(축 회전 주파수)에서 큰 진동
            harmonics = 1
            nxfreq_list, pk_bool_list = harmonics_freq_calc(hr_fft_data, hr_peaks, F_r, hz_min, hz_max,
                                                                        harmonics)

            th_over_list = [0, 0]

            th_freq = vib_threshold_find(sensor_pos, hr_axis, fft_th_arry, nxfreq_list[0])
            if pk_bool_list[0] == 1 and hr_fft_data[nxfreq_list[0]] > th_freq:
                th_over_list[0] = 1

            # 1xRPM(피동풀리 회전 주파수)에서 큰 진동
            harmonics = 1
            nxfreq_list, pk_bool_list = harmonics_freq_calc(hr_fft_data, hr_peaks, DrivenPulleyRPM, hz_min, hz_max,
                                                                        harmonics)

            th_freq = vib_threshold_find(sensor_pos, hr_axis, fft_th_arry, nxfreq_list[0])
            if pk_bool_list[0] == 1 and hr_fft_data[nxfreq_list[0]] > th_freq:
                th_over_list[1] = 1

            if th_over_list[0] == 1 and th_over_list[1] == 1:
                print("벨트 편심 및 이탈(구동부, 피구동부 peak)")
                l = [int('0b10100011', 2)]  # V3
                fail_list = fail_list + l

        ##############################################################################################################

        # 공진
        # 벨트고유진동수... 노답
        """
        반경방향에서 진동발생
        벨트도 고유진동수를 가지는데 이는 벨트강성, 벨트질량 및 운전중 발생한 벨트의 처짐에 의해 결정됨
        벨트고유진동수는 구동이나 종동 중 하나의 1x rpm 가까이 있음
        벨트의 인장측에서 큰 떨림이 발생
        벨트 rpm의 고조파가 벨트고유진동수와 일치할때도 이런현상이 발생
        → 벨트의 인장 또는 풀리 중심간의 길이 변경하거나 idler 풀리 추가 설치 
        """

        ############################################################################################################

        if not fail_list:
            l = []  # [int('0b11111111', 2)]
            fail_list = fail_list + l
        else:
            # 진단결과 중복 제거
            fail_set = set(fail_list)  # 집합 set으로 변환
            fail_list = list(fail_set)  # list로 변환

        return fail_list
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print('fail error:', e)
        print(exc_type, fname, exc_tb.tb_lineno)
        print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
        return -1


def gear_fault_fp_diagnosis(sensor_pos, axis, fft_th_arry, fft_data, peaks, hz_max, hz_min, m_GMF, F_r, ndcl_freq_list):
    """ 기어 결함 진단

    :param sensor_pos:
    :param axis:
    :param fft_th_arry:
    :param fft_data:
    :param peaks:
    :param hz_max:
    :param hz_min:
    :param m_GMF:
    :param F_r:
    :param ndcl_freq_list:
    :return:
    """

    try:
        # 고장 유형
        fail_list = []
        # sideband 진폭 임계치 %(defualt : 0.5 => 50%)
        sb_amp_th_pro = 0.5

        ######################################################################################

        # 기어 이 부러짐 및 편심/백래쉬
        # 감속기
        for gs in range(len(ndcl_freq_list)):
            for p in range(2):
                rpm_f = ndcl_freq_list[gs][2]
                if gs == 0 and p == 0:
                    rpm_f = F_r
                elif gs > 0 and p == 0:
                    rpm_f = ndcl_freq_list[gs - 1][2]

                if rpm_f > 0:
                    # 1xRPM에서 peak
                    harmonics = 1
                    nxfreq_list, pk_bool_list = harmonics_freq_calc(fft_data, peaks, rpm_f, hz_min, hz_max, harmonics)

                    nxRPM_pb = 0
                    th_freq = vib_threshold_find(sensor_pos, axis, fft_th_arry, nxfreq_list[0])
                    if pk_bool_list[0] == 1 and fft_data[nxfreq_list[0]] > th_freq:
                        nxRPM_pb = 1

                    if ndcl_freq_list[gs][1] > 0:
                        # 1xGMF
                        harmonics = 1
                        nxfreq_list, pk_bool_list = harmonics_freq_calc(fft_data, peaks, ndcl_freq_list[gs][1], hz_min, hz_max, harmonics)

                        # GMF에 회전속도의 측대파 형성 확인
                        l_th_over = 0
                        r_th_over = 0
                        sb_l_freq, sb_r_freq, sb_l_pk_bool, sb_r_pk_bool = sidebands_freq_calc(fft_data, peaks, hz_min, hz_max, nxfreq_list[0], pk_bool_list[0], rpm_f)

                        th_freq = vib_threshold_find(sensor_pos, axis, fft_th_arry, sb_l_freq)
                        if sb_l_pk_bool == 1 and fft_data[sb_l_freq] > th_freq * sb_amp_th_pro:
                            l_th_over = 1

                        th_freq = vib_threshold_find(sensor_pos, axis, fft_th_arry, sb_r_freq)
                        if sb_r_pk_bool == 1 and fft_data[sb_r_freq] > th_freq * sb_amp_th_pro:
                            r_th_over = 1

                        if nxRPM_pb == 1 and l_th_over + r_th_over == 2:
                            print("기어 이 크랙, 빠짐, 부러짐(감속기)")
                            l = [int('0b00000101', 2)]  # G5
                            fail_list = fail_list + l
                            print("기어 편심 및 백래쉬(감속기)")
                            l = [int('0b00000011', 2)]  # G3
                            fail_list = fail_list + l

        # 스프라켓
        if F_r > 0:
            # 1xRPM에서 peak
            harmonics = 1
            nxfreq_list, pk_bool_list = harmonics_freq_calc(fft_data, peaks, F_r, hz_min, hz_max, harmonics)

            nxRPM_pb = 0
            th_freq = vib_threshold_find(sensor_pos, axis, fft_th_arry, nxfreq_list[0])
            if pk_bool_list[0] == 1 and fft_data[nxfreq_list[0]] > th_freq:
                nxRPM_pb = 1

            if m_GMF > 0:
                # 1xGMF
                harmonics = 1
                nxfreq_list, pk_bool_list = harmonics_freq_calc(fft_data, peaks, m_GMF, hz_min, hz_max, harmonics)

                # GMF에 회전속도의 측대파 형성 확인
                l_th_over = 0
                r_th_over = 0
                sb_l_freq, sb_r_freq, sb_l_pk_bool, sb_r_pk_bool = sidebands_freq_calc(fft_data, peaks, hz_min,
                                                                                       hz_max, nxfreq_list[0],
                                                                                       pk_bool_list[0], F_r)

                th_freq = vib_threshold_find(sensor_pos, axis, fft_th_arry, sb_l_freq)
                if sb_l_pk_bool == 1 and fft_data[sb_l_freq] > th_freq * sb_amp_th_pro:
                    l_th_over = 1

                th_freq = vib_threshold_find(sensor_pos, axis, fft_th_arry, sb_r_freq)
                if sb_r_pk_bool == 1 and fft_data[sb_r_freq] > th_freq * sb_amp_th_pro:
                    r_th_over = 1

                if nxRPM_pb == 1 and l_th_over + r_th_over == 2:
                    print("기어 이 크랙, 빠짐, 부러짐(스프라켓)")
                    l = [int('0b00000101', 2)]  # G5
                    fail_list = fail_list + l
                    print("기어 편심 및 백래쉬(스프라켓)")
                    l = [int('0b00000011', 2)]  # G3
                    fail_list = fail_list + l

        ######################################################################################

        # 기어 이 마멸(치면 손상) = 기어 이 마모 및 기어 이 과부하
        if not fail_list:
            # 감속기
            for gs in range(len(ndcl_freq_list)):
                if ndcl_freq_list[gs][1] > 0:
                    # 1xGMF
                    harmonics = 1
                    nxfreq_list, pk_bool_list = harmonics_freq_calc(fft_data, peaks, ndcl_freq_list[gs][1], hz_min, hz_max, harmonics)

                    gmf_th_over = 0
                    th_freq = vib_threshold_find(sensor_pos, axis, fft_th_arry, nxfreq_list[0])
                    if pk_bool_list[0] == 1 and fft_data[nxfreq_list[0]] > th_freq:
                        gmf_th_over = 1

                    # GMF에 회전속도의 간격으로 측대파 형성 확인
                    for p in range(2):
                        sb_f = ndcl_freq_list[gs][2]
                        if gs == 0 and p == 0:
                            sb_f = F_r
                        elif gs > 0 and p == 0:
                            sb_f = ndcl_freq_list[gs - 1][2]

                        if sb_f > 0:
                            l_th_over_list = [0 for i in range(10)]
                            r_th_over_list = [0 for i in range(10)]
                            for i in range(1, 11):
                                sb_freq = i * sb_f
                                sb_l_freq, sb_r_freq, sb_l_pk_bool, sb_r_pk_bool = sidebands_freq_calc(fft_data, peaks, hz_min, hz_max, nxfreq_list[0], pk_bool_list[0], sb_freq)

                                th_freq = vib_threshold_find(sensor_pos, axis, fft_th_arry, sb_l_freq)
                                if sb_l_pk_bool == 1 and fft_data[sb_l_freq] > th_freq * sb_amp_th_pro:
                                    l_th_over_list[i - 1] = 1

                                th_freq = vib_threshold_find(sensor_pos, axis, fft_th_arry, sb_r_freq)
                                if sb_r_pk_bool == 1 and fft_data[sb_r_freq] > th_freq * sb_amp_th_pro:
                                    r_th_over_list[i - 1] = 1

                            sb_l_array = np.array(l_th_over_list)
                            sb_r_array = np.array(r_th_over_list)

                            sb_array = sb_l_array + sb_r_array

                            sb_sum = 0
                            for xx in range(len(sb_array)):
                                if sb_array[xx] == 2:
                                    sb_sum = sb_sum + 1

                            if gmf_th_over == 1 and sb_sum > 5 or sum(sb_array) > 11:
                                print("기어 이 마모(감속기)")
                                l = [int('0b00000001', 2)]  # G1
                                fail_list = fail_list + l
                            elif gmf_th_over == 1 and l_th_over_list[0] == 1 and r_th_over_list[0] == 1 and sb_sum < 2:
                                print("기어 이 과부하(감속기)")
                                l = [int('0b00000010', 2)]  # G2
                                fail_list = fail_list + l

            # 스프라켓
            if m_GMF > 0:
                # 1xGMF
                harmonics = 1
                nxfreq_list, pk_bool_list = harmonics_freq_calc(fft_data, peaks, m_GMF, hz_min, hz_max, harmonics)

                gmf_th_over = 0
                th_freq = vib_threshold_find(sensor_pos, axis, fft_th_arry, nxfreq_list[0])
                if pk_bool_list[0] == 1 and fft_data[nxfreq_list[0]] > th_freq:
                    gmf_th_over = 1

                # GMF에 회전속도의 간격으로 측대파 형성 확인
                if F_r > 0:
                    l_th_over_list = [0 for i in range(10)]
                    r_th_over_list = [0 for i in range(10)]
                    for i in range(1, 11):
                        sb_freq = i * F_r
                        sb_l_freq, sb_r_freq, sb_l_pk_bool, sb_r_pk_bool = sidebands_freq_calc(fft_data, peaks, hz_min,
                                                                                               hz_max, nxfreq_list[0],
                                                                                               pk_bool_list[0], sb_freq)

                        th_freq = vib_threshold_find(sensor_pos, axis, fft_th_arry, sb_l_freq)
                        if sb_l_pk_bool == 1 and fft_data[sb_l_freq] > th_freq * sb_amp_th_pro:
                            l_th_over_list[i - 1] = 1

                        th_freq = vib_threshold_find(sensor_pos, axis, fft_th_arry, sb_r_freq)
                        if sb_r_pk_bool == 1 and fft_data[sb_r_freq] > th_freq * sb_amp_th_pro:
                            r_th_over_list[i - 1] = 1

                    sb_l_array = np.array(l_th_over_list)
                    sb_r_array = np.array(r_th_over_list)

                    sb_array = sb_l_array + sb_r_array

                    sb_sum = 0
                    for xx in range(len(sb_array)):
                        if sb_array[xx] == 2:
                            sb_sum = sb_sum + 1

                    if gmf_th_over == 1 and sb_sum > 5 or sum(sb_array) > 11:
                        print("기어 이 마모(스프라켓)")
                        l = [int('0b00000001', 2)]  # G1
                        fail_list = fail_list + l
                    elif gmf_th_over == 1 and l_th_over_list[0] == 1 and r_th_over_list[0] == 1 and sb_sum < 2:
                        print("기어 이 과부하(스프라켓)")
                        l = [int('0b00000010', 2)]  # G2
                        fail_list = fail_list + l

        ######################################################################################

        # 기어 정렬불량
        # 감속기
        for gs in range(len(ndcl_freq_list)):
            if ndcl_freq_list[gs][1] > 0:
                # 기어 축 회전주파수 = 조화성분 1X ~ 3X
                harmonics = 3
                nxfreq_list, pk_bool_list = harmonics_freq_calc(fft_data, peaks, ndcl_freq_list[gs][1], hz_min, hz_max, harmonics)

                # 1x보다 2x, 3x GMF에서 진폭 높음
                if (pk_bool_list[2] == 1 and fft_data[nxfreq_list[2]] > fft_data[nxfreq_list[0]] * 1.3) or (
                        pk_bool_list[1] == 1 and fft_data[nxfreq_list[1]] > fft_data[nxfreq_list[0]] * 1.3):
                    print("기어 정렬불량(감속기)")
                    l = [int('0b00000100', 2)]  # G4
                    fail_list = fail_list + l

        # 스프라켓
        if m_GMF > 0:
            # 기어 축 회전주파수 = 조화성분 1X ~ 3X
            harmonics = 3
            nxfreq_list, pk_bool_list = harmonics_freq_calc(fft_data, peaks, m_GMF, hz_min, hz_max, harmonics)

            # 1x보다 2x, 3x GMF에서 진폭 높음
            if (pk_bool_list[2] == 1 and fft_data[nxfreq_list[2]] > fft_data[nxfreq_list[0]] * 1.3) or (
                    pk_bool_list[1] == 1 and fft_data[nxfreq_list[1]] > fft_data[nxfreq_list[0]] * 1.3):
                print("기어 정렬불량(스프라켓)")
                l = [int('0b00000100', 2)]  # G4
                fail_list = fail_list + l

        ######################################################################################

        # 양측 기어 마멸(헌팅주파수) = HTF
        # 감속기
        for gs in range(len(ndcl_freq_list)):
            if ndcl_freq_list[gs][3] > 0:
                harmonics = 1
                nxfreq_list, pk_bool_list = harmonics_freq_calc(fft_data, peaks, ndcl_freq_list[gs][3], hz_min, hz_max,
                                                                harmonics)

                th_freq = vib_threshold_find(sensor_pos, axis, fft_th_arry, nxfreq_list[0])
                if pk_bool_list[0] == 1 and fft_data[nxfreq_list[0]] > th_freq:
                    print("양측 기어 마멸(감속기)")
                    l = [int('0b00000111', 2)]  # G7
                    fail_list = fail_list + l

        # 스프라켓
        if m_GMF > 0:
            harmonics = 1
            nxfreq_list, pk_bool_list = harmonics_freq_calc(fft_data, peaks, m_GMF, hz_min, hz_max, harmonics)

            th_freq = vib_threshold_find(sensor_pos, axis, fft_th_arry, nxfreq_list[0])
            if pk_bool_list[0] == 1 and fft_data[nxfreq_list[0]] > th_freq:
                print("양측 기어 마멸(스프라켓)")
                l = [int('0b00000111', 2)]  # G7
                fail_list = fail_list + l

        ######################################################################################

        if not fail_list:
            l = []  # [int('0b11111111', 2)]
            fail_list = fail_list + l
        else:
            # 진단결과 중복 제거
            fail_set = set(fail_list)  # 집합 set으로 변환
            fail_list = list(fail_set)  # list로 변환

        return fail_list
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print('fail error:', e)
        print(exc_type, fname, exc_tb.tb_lineno)
        print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
        return -1


def fan_fault_fp_diagnosis(sensor_pos, axis, fft_th_arry, fft_data, peaks, hz_max, hz_min, Fan_F_r):
    """ 송풍기 결함 진단

    :param sensor_pos:
    :param axis:
    :param fft_th_arry:
    :param fft_data:
    :param peaks:
    :param hz_max:
    :param hz_min:
    :param Fan_F_r:
    :return:
    """

    try:
        # 고장 유형
        fail_list = []

        ############################################################################################################

        if Fan_F_r > 0:
            # 1xFan 주파수에서 큰 진동
            harmonics = 1
            nxfreq_list, pk_bool_list = harmonics_freq_calc(fft_data, peaks, Fan_F_r, hz_min, hz_max, harmonics)

            th_freq = vib_threshold_find(sensor_pos, axis, fft_th_arry, nxfreq_list[0])
            if pk_bool_list[0] == 1 and fft_data[nxfreq_list[0]] > th_freq:
                print("송풍기 결함")
                l = [int('0b10001001', 2)]  # S9
                fail_list = fail_list + l

        ############################################################################################################

        if not fail_list:
            l = []  # [int('0b11111111', 2)]
            fail_list = fail_list + l
        else:
            # 진단결과 중복 제거
            fail_set = set(fail_list)  # 집합 set으로 변환
            fail_list = list(fail_set)  # list로 변환

        return fail_list
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print('fail error:', e)
        print(exc_type, fname, exc_tb.tb_lineno)
        print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
        return -1


def rotor_fault_fp_diagnosis(sensor_pos, sh_axis, hr_axis, fft_th_arry, sh_fft_data, sh_peaks, sh_rms,
                             vr_rms, hr_fft_data, hr_peaks, hr_rms, hz_max, hz_min, F_r, DrivenPulleyRPM):
    """ 회전체 결함 진단

    :param sensor_pos: 진동 센서 부착 위치
    :param sh_axis: 축방향 진동 FFT 데이터 축(x, y, z)
    :param hr_axis: 반경방향 진동 FFT 데이터 축(x, y, z)
    :param fft_th_arry: FFT 임계치 데이터
    :param sh_fft_data: 축방향 진동 FFT 데이터
    :param sh_peaks: 축방향 진동 FFT Peak frequency
    :param float sh_rms: 축방향 진동 RMS 값(Overall)
    :param float vr_rms: 수직방향 진동 RMS 값(Overall)
    :param hr_fft_data: 반경방향 진동 FFT 데이터
    :param hr_peaks: 반경방향 진동 FFT Peak frequency
    :param float hr_rms: 반경방향 진동 RMS 값(Overall)
    :param int hz_max: 진동 FFT 주파수 최대값
    :param int hz_min: 진동 FFT 주파수 최소값
    :param F_r:
    :param DrivenPulleyRPM:
    :return:
    """

    try:
        # 고장 유형
        fail_list = []

        ######################################################################################

        # 질량불평형 - 반경방향
        if F_r > hz_min:
            # 전동기 축 회전주파수(슬립 o) = F_r
            harmonics = 1
            nxfreq_list, pk_bool_list = harmonics_freq_calc(hr_fft_data, hr_peaks, F_r, hz_min, hz_max, harmonics)

            # 1X 성분이 총 진동량의 80% 이상 및 축,수직 < 반경방향 (2~3배 높음)
            if hr_fft_data[nxfreq_list[0]] >= hr_rms * 0.8 and (hr_rms > sh_rms * 2 or hr_rms > vr_rms * 2):
                print("질량불평형")
                l = [int('0b01000001', 2)]  # R1
                fail_list = fail_list + l

        # 질량불평형 - 반경방향
        if DrivenPulleyRPM > hz_min:
            # 피구동 축 회전주파수(슬립 o) = DrivenPulleyRPM
            harmonics = 1
            nxfreq_list, pk_bool_list = harmonics_freq_calc(hr_fft_data, hr_peaks, DrivenPulleyRPM, hz_min, hz_max, harmonics)

            # 1X 성분이 총 진동량의 80% 이상 및 축,수직 < 반경방향 (2~3배 높음)
            if hr_fft_data[nxfreq_list[0]] >= hr_rms * 0.8 and (hr_rms > sh_rms * 2 or hr_rms > vr_rms * 2):
                print("질량불평형")
                l = [int('0b01000001', 2)]  # R1
                fail_list = fail_list + l

        ######################################################################################

        # 축정렬불량(편각) - 축방향
        if F_r > 0:
            # 전동기 구동부 축 회전주파수(슬립 o) = F_r 조화성분 1X ~ 3X
            harmonics = 3
            nxfreq_list, pk_bool_list = harmonics_freq_calc(sh_fft_data, sh_peaks, F_r, hz_min, hz_max, harmonics)

            # 2X or 3X 성분이 1X 성분의 약 30~50% 초과
            if sh_fft_data[nxfreq_list[1]] > sh_fft_data[nxfreq_list[0]] * 0.5 or sh_fft_data[nxfreq_list[2]] > sh_fft_data[nxfreq_list[0]] * 0.5:
                th_1x_freq = vib_threshold_find(sensor_pos, sh_axis, fft_th_arry, nxfreq_list[0])
                th_2x_freq = vib_threshold_find(sensor_pos, sh_axis, fft_th_arry, nxfreq_list[1])
                if sh_fft_data[nxfreq_list[0]] > th_1x_freq and sh_fft_data[nxfreq_list[1]] > th_2x_freq:
                    print("축정렬불량(편각) 구동부")
                    l = [int('0b01000010', 2)]  # R2
                    fail_list = fail_list + l

        if DrivenPulleyRPM > 0:
            # 전동기 피구동부 축 회전주파수 = DrivenPulleyRPM 조화성분 1X ~ 3X
            harmonics = 3
            nxfreq_list, pk_bool_list = harmonics_freq_calc(sh_fft_data, sh_peaks, DrivenPulleyRPM, hz_min, hz_max, harmonics)

            # 2X or 3X 성분이 1X 성분의 약 30~50% 초과
            if sh_fft_data[nxfreq_list[1]] > sh_fft_data[nxfreq_list[0]] * 0.5 or sh_fft_data[nxfreq_list[2]] > sh_fft_data[nxfreq_list[0]] * 0.5:
                th_1x_freq = vib_threshold_find(sensor_pos, sh_axis, fft_th_arry, nxfreq_list[0])
                th_2x_freq = vib_threshold_find(sensor_pos, sh_axis, fft_th_arry, nxfreq_list[1])
                if sh_fft_data[nxfreq_list[0]] > th_1x_freq and sh_fft_data[nxfreq_list[1]] > th_2x_freq:
                    print("축정렬불량(편각) 피구동부")
                    l = [int('0b01000010', 2)]  # R2
                    fail_list = fail_list + l

        ######################################################################################

        # 축정렬불량(편심) - 반경방향
        if F_r > 0:
            # 전동기 축 회전주파수(슬립 o) = F_r 조화성분 1X ~ 8X
            harmonics = 8
            nxfreq_list, pk_bool_list = harmonics_freq_calc(hr_fft_data, hr_peaks, F_r, hz_min, hz_max, harmonics)

            th_over_list = [0 for i in range(len(nxfreq_list))]  # 조화성분 임계치 초과 유무
            for nx in range(len(nxfreq_list)):
                if pk_bool_list[nx] > 0:
                    th_freq = vib_threshold_find(sensor_pos, hr_axis, fft_th_arry, nxfreq_list[nx])
                    if pk_bool_list[nx] == 1 and hr_fft_data[nxfreq_list[nx]] > th_freq:
                        th_over_list[nx] = 1

            # 조화성분 갯수 확인
            nxF_r_count = sum(th_over_list)

            # 2xRPM이 1xRPM보다 높음
            if hr_fft_data[nxfreq_list[1]] > hr_fft_data[nxfreq_list[0]] * 0.5:
                th_count = th_count_calc(hz_min, F_r, harmonics)
                if nxF_r_count > th_count:
                    print("축정렬불량(편심)")
                    l = [int('0b01000011', 2)]  # R3
                    fail_list = fail_list + l

        ######################################################################################

        # 축상에서 비틀린 베어링 - 축방향
        if F_r > 0:
            # 전동기 축 회전주파수(슬립 o) = F_r 조화성분 1X ~ 2X
            harmonics = 2
            nxfreq_list, pk_bool_list = harmonics_freq_calc(sh_fft_data, sh_peaks, F_r, hz_min, hz_max, harmonics)

            th_over_list = [0 for i in range(len(nxfreq_list))]  # 조화성분 임계치 초과 유무
            for nx in range(len(nxfreq_list)):
                if pk_bool_list[nx] > 0:
                    th_freq = vib_threshold_find(sensor_pos, sh_axis, fft_th_arry, nxfreq_list[nx])
                    if pk_bool_list[nx] == 1 and sh_fft_data[nxfreq_list[nx]] > th_freq:
                        th_over_list[nx] = 1

            # 조화성분 갯수 확인
            nxF_r_count = sum(th_over_list)

            # 1xRPM과 2xRPM 진폭이 높음
            if nxF_r_count == 2:
                print("축상에서 비틀린 베어링")
                l = [int('0b01000111', 2)]  # R7
                fail_list = fail_list + l

        ######################################################################################

        # 구조적 헐거움(유연체, 강성부족, 텐션부족) = 볼트풀림 - 반경방향
        freq = F_r
        if sensor_pos == 2 or sensor_pos == 3:
            freq = DrivenPulleyRPM

        if freq > 0:
            harmonics = 1
            nxfreq_list, pk_bool_list = harmonics_freq_calc(hr_fft_data, hr_peaks, freq, hz_min, hz_max, harmonics)

            Fr_pb = 0
            th_freq = vib_threshold_find(sensor_pos, hr_axis, fft_th_arry, nxfreq_list[0])
            if pk_bool_list[0] == 1 and hr_fft_data[nxfreq_list[0]] > th_freq:
                Fr_pb = 1

            # 진동 rms 반경 > 수직
            if hr_rms > vr_rms and Fr_pb == 1:
                print("구조적 헐거움(유연체, 강성부족, 텐션부족)")
                fail_code = '0b01000110'
                if sensor_pos == 2 or sensor_pos == 3:
                    fail_code = '0b10001000'
                l = [int(fail_code, 2)]  # R6 or S8
                fail_list = fail_list + l

        ######################################################################################

        # 회전헐거움(부적절한 끼워맞춤, 베어링 헐거움) - 반경방향(임시)
        if F_r > 0:
            # 전동기 축 회전주파수(슬립 o) = F_r 조화성분 1X ~ 20X
            harmonics = 20
            nxfreq_list, pk_bool_list = harmonics_freq_calc(hr_fft_data, hr_peaks, F_r, hz_min, hz_max, harmonics)

            th_over_list = [0 for i in range(len(nxfreq_list))]  # 조화성분 임계치 초과 유무
            for nx in range(len(nxfreq_list)):
                if pk_bool_list[nx] > 0:
                    th_freq = vib_threshold_find(sensor_pos, hr_axis, fft_th_arry, nxfreq_list[nx])
                    if pk_bool_list[nx] == 1 and hr_fft_data[nxfreq_list[nx]] > th_freq:
                        th_over_list[nx] = 1

            # 조화성분 갯수 확인
            nxF_r_count = sum(th_over_list)

            th_count = th_count_calc(hz_min, F_r, harmonics)
            if nxF_r_count > th_count:
                print("회전헐거움(부적절한 끼워맞춤, 베어링 헐거움)")
                l = [int('0b01000100', 2)]  # R4
                fail_list = fail_list + l

        ######################################################################################

        # 회전헐거움(과다 간극, 심각한 헐거움) - 반경방향(임시)
        freq = F_r
        if sensor_pos == 2 or sensor_pos == 3:
            freq = DrivenPulleyRPM

        if freq > 0:
            # 전동기 축 회전주파수(슬립 o) = F_r 조화성분 1 ~ 10X 1/2 F_r
            harmonics = 10
            nxfreq_list, pk_bool_list = harmonics_freq_calc(hr_fft_data, hr_peaks, freq / 2, hz_min, hz_max, harmonics)

            th_over_list = [0 for i in range(len(nxfreq_list))]  # 조화성분 임계치 초과 유무
            for nx in range(len(nxfreq_list)):
                if pk_bool_list[nx] > 0:
                    th_freq = vib_threshold_find(sensor_pos, hr_axis, fft_th_arry, nxfreq_list[nx])
                    if pk_bool_list[nx] == 1 and hr_fft_data[nxfreq_list[nx]] > th_freq:
                        th_over_list[nx] = 1

            # 조화성분 갯수 확인
            nxF_r_count = sum(th_over_list)

            th_count = th_count_calc(hz_min, freq / 2, harmonics)
            if nxF_r_count > th_count:
                print("회전헐거움(과다 간극, 심각한 헐거움)")
                fail_code = '0b01000101'
                if sensor_pos == 2 or sensor_pos == 3:
                    fail_code = '0b10000111'
                l = [int(fail_code, 2)]  # R5 or S7
                fail_list = fail_list + l

            # 전동기 축 회전주파수(슬립 o) = F_r 조화성분 1 ~ 10X 1/3 F_r
            harmonics = 10
            nxfreq_list, pk_bool_list = harmonics_freq_calc(hr_fft_data, hr_peaks, freq / 3, hz_min, hz_max, harmonics)

            th_over_list = [0 for i in range(len(nxfreq_list))]  # 조화성분 임계치 초과 유무
            for nx in range(len(nxfreq_list)):
                if pk_bool_list[nx] > 0:
                    th_freq = vib_threshold_find(sensor_pos, hr_axis, fft_th_arry, nxfreq_list[nx])
                    if pk_bool_list[nx] == 1 and hr_fft_data[nxfreq_list[nx]] > th_freq:
                        th_over_list[nx] = 1

            # 조화성분 갯수 확인
            nxF_r_count = sum(th_over_list)

            th_count = th_count_calc(hz_min, freq / 3, harmonics)
            if nxF_r_count > th_count:
                print("회전헐거움(과다 간극, 심각한 헐거움)")
                fail_code = '0b01000101'
                if sensor_pos == 2 or sensor_pos == 3:
                    fail_code = '0b10000111'
                l = [int(fail_code, 2)]  # R5 or S7
                fail_list = fail_list + l

        ######################################################################################

        if not fail_list:
            l = []  # [int('0b11111111', 2)]
            fail_list = fail_list + l
        else:
            # 진단결과 중복 제거
            fail_set = set(fail_list)  # 집합 set으로 변환
            fail_list = list(fail_set)  # list로 변환

        return fail_list
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print('fail error:', e)
        print(exc_type, fname, exc_tb.tb_lineno)
        print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
        return -1


def bearing_fault_fp_diagnosis(sensor_pos, axis, fft_th_arry, fft_data, peaks, hz_max, hz_min, nb_freq_list, F_r, DrivenPulleyRPM, motor_info, ndcl_freq_list):
    """ 베어링 결함 진단

    :param sensor_pos:
    :param axis:
    :param fft_th_arry:
    :param fft_data:
    :param peaks:
    :param hz_max:
    :param hz_min:
    :param nb_freq_list:
    :param F_r:
    :param DrivenPulleyRPM:
    :param motor_info:
    :param ndcl_freq_list:
    :return:
    """

    try:
        # 고장 유형
        fail_list = []

        ######################################################################################

        # 베어링 외륜 결함
        for bp in range(len(nb_freq_list)):
            if nb_freq_list[bp][3] > 0:
                # 베어링 외륜결함주파수 = BPFO 조화성분 1X ~ 10X
                harmonics = 10
                nxfreq_list, pk_bool_list = harmonics_freq_calc(fft_data, peaks, nb_freq_list[bp][3], hz_min, hz_max, harmonics)

                th_over_list = [0 for i in range(len(nxfreq_list))]  # 조화성분 임계치 초과 유무
                for nx in range(len(nxfreq_list)):
                    if pk_bool_list[nx] > 0:
                        th_freq = vib_threshold_find(sensor_pos, axis, fft_th_arry, nxfreq_list[nx])
                        if pk_bool_list[nx] == 1 and fft_data[nxfreq_list[nx]] > th_freq:
                            th_over_list[nx] = 1

                # 조화성분 갯수 확인
                nxBPFO_count = sum(th_over_list)

                th_count = th_count_calc(hz_min, nb_freq_list[bp][3], harmonics)
                if nxBPFO_count > th_count:
                    if (sensor_pos == 2 or sensor_pos == 3) and nb_freq_list[bp][0] == "sb":
                        print(nb_freq_list[bp][0] + " 베어링 외륜 결함 조화성분")
                        l = [int('0b10000001', 2)]  # S1
                        fail_list = fail_list + l
                    else:
                        print(nb_freq_list[bp][0] + " 베어링 외륜 결함 조화성분")
                        l = [int('0b01100001', 2)]  # B1
                        fail_list = fail_list + l

        ######################################################################################

        # 베어링 내륜 결함
        for bp in range(len(nb_freq_list)):
            if nb_freq_list[bp][2] > 0:
                # 베어링 내륜결함주파수 = BPFI 조화성분 1X ~ 10X
                harmonics = 10
                nxfreq_list, pk_bool_list = harmonics_freq_calc(fft_data, peaks, nb_freq_list[bp][2], hz_min, hz_max, harmonics)

                th_over_list = [0 for i in range(len(nxfreq_list))]  # 조화성분 임계치 초과 유무
                for nx in range(len(nxfreq_list)):
                    if pk_bool_list[nx] > 0:
                        th_freq = vib_threshold_find(sensor_pos, axis, fft_th_arry, nxfreq_list[nx])
                        if pk_bool_list[nx] == 1 and fft_data[nxfreq_list[nx]] > th_freq:
                            th_over_list[nx] = 1

                # 조화성분 갯수 확인
                nxBPFI_count = sum(th_over_list)

                th_count = th_count_calc(hz_min, nb_freq_list[bp][2], harmonics)
                if nxBPFI_count > th_count:
                    if (sensor_pos == 2 or sensor_pos == 3) and nb_freq_list[bp][0] == "sb":
                        print(nb_freq_list[bp][0] + " 베어링 내륜 결함 조화성분")
                        l = [int('0b10000010', 2)]  # S2
                        fail_list = fail_list + l
                    else:
                        print(nb_freq_list[bp][0] + " 베어링 내륜 결함 조화성분")
                        l = [int('0b01100010', 2)]  # B2
                        fail_list = fail_list + l

        ######################################################################################

        # 베어링 볼 결함
        for bp in range(len(nb_freq_list)):
            if nb_freq_list[bp][4] > 0:
                # 베어링 볼결함주파수 = BSF 조화성분 1X ~ 10X
                harmonics = 10
                nxfreq_list, pk_bool_list = harmonics_freq_calc(fft_data, peaks, nb_freq_list[bp][4], hz_min, hz_max, harmonics)

                th_over_list = [0 for i in range(len(nxfreq_list))]  # 조화성분 임계치 초과 유무
                for nx in range(len(nxfreq_list)):
                    if pk_bool_list[nx] > 0:
                        th_freq = vib_threshold_find(sensor_pos, axis, fft_th_arry, nxfreq_list[nx])
                        if pk_bool_list[nx] == 1 and fft_data[nxfreq_list[nx]] > th_freq:
                            th_over_list[nx] = 1

                # 조화성분 갯수 확인
                nxBSF_count = sum(th_over_list)

                th_count = th_count_calc(hz_min, nb_freq_list[bp][2], harmonics)
                if nxBSF_count > th_count:
                    if (sensor_pos == 2 or sensor_pos == 3) and nb_freq_list[bp][0] == "sb":
                        print(nb_freq_list[bp][0] + " 베어링 볼 결함 BSF 조화성분")
                        l = [int('0b10000011', 2)]  # S3
                        fail_list = fail_list + l
                    else:
                        print(nb_freq_list[bp][0] + " 베어링 볼 결함 BSF 조화성분")
                        l = [int('0b01100011', 2)]  # B3
                        fail_list = fail_list + l

        ######################################################################################

        # 부적절한 윤활
        for bp in range(len(nb_freq_list)):
            if nb_freq_list[bp][2] > 0:
                # 베어링 내륜결함주파수 = BPFI
                harmonics = 1
                nxfreq_list, pk_bool_list = harmonics_freq_calc(fft_data, peaks, nb_freq_list[bp][2], hz_min, hz_max, harmonics)

                nxBPFI_pb = 0  # BPFI peak bool
                th_freq = vib_threshold_find(sensor_pos, axis, fft_th_arry, nxfreq_list[0])
                if pk_bool_list[0] == 1 and fft_data[nxfreq_list[0]] > th_freq:
                    nxBPFI_pb = 1

                # 베어링 축 회전주파수 산출
                r_speed = 0
                if F_r > 0 and nb_freq_list[bp][0] == "mhlsb" or nb_freq_list[bp][0] == "mlsb":
                    r_speed = F_r
                elif DrivenPulleyRPM > 0 and nb_freq_list[bp][0] == "sb":
                    r_speed = DrivenPulleyRPM

                if motor_info[0][2] == "Y":
                    if F_r > 0 and nb_freq_list[bp][0] == "d1plb" or nb_freq_list[bp][0] == "d1prb":
                        r_speed = F_r
                    elif motor_info[0][10] >= 1 and nb_freq_list[bp][0] == "d1glb" or nb_freq_list[bp][0] == "d1grb" or \
                            nb_freq_list[bp][0] == "d2plb" or nb_freq_list[bp][0] == "d2prb":
                        r_speed = ndcl_freq_list[0][2]
                    elif motor_info[0][10] >= 2 and nb_freq_list[bp][0] == "d2glb" or nb_freq_list[bp][0] == "d2grb" or \
                            nb_freq_list[bp][0] == "d3plb" or nb_freq_list[bp][0] == "d3prb":
                        r_speed = ndcl_freq_list[1][2]
                    elif motor_info[0][10] >= 3 and nb_freq_list[bp][0] == "d3glb" or nb_freq_list[bp][0] == "d3grb":
                        r_speed = ndcl_freq_list[2][2]

                # 축 회전주파수 간격으로 peak 검출
                harmonics = 10
                it_freq_num, peak_count = peaks_interval_calc(peaks, r_speed, hz_max, harmonics)

                if nxBPFI_pb == 1 and peak_count > it_freq_num / 2:
                    if (sensor_pos == 2 or sensor_pos == 3) and nb_freq_list[bp][0] == "sb":
                        print("부적절한 윤활")
                        l = [int('0b10000100', 2)]  # S4
                        fail_list = fail_list + l
                    else:
                        print("부적절한 윤활")
                        l = [int('0b01100100', 2)]  # B4
                        fail_list = fail_list + l

        ######################################################################################

        # 헐거움(축과 베어링) & 헐거움(베어링과 하우징)
        for bp in range(len(nb_freq_list)):
            r_speed = 0
            if F_r > 0 and nb_freq_list[bp][0] == "mhlsb" or nb_freq_list[bp][0] == "mlsb":
                r_speed = F_r
            elif DrivenPulleyRPM > 0 and nb_freq_list[bp][0] == "sb":
                r_speed = DrivenPulleyRPM

            if motor_info[0][2] == "Y":
                if F_r > 0 and nb_freq_list[bp][0] == "d1plb" or nb_freq_list[bp][0] == "d1prb":
                    r_speed = F_r
                elif motor_info[0][10] >= 1 and nb_freq_list[bp][0] == "d1glb" or nb_freq_list[bp][0] == "d1grb" or \
                        nb_freq_list[bp][0] == "d2plb" or nb_freq_list[bp][0] == "d2prb":
                    r_speed = ndcl_freq_list[0][2]
                elif motor_info[0][10] >= 2 and nb_freq_list[bp][0] == "d2glb" or nb_freq_list[bp][0] == "d2grb" or \
                        nb_freq_list[bp][0] == "d3plb" or nb_freq_list[bp][0] == "d3prb":
                    r_speed = ndcl_freq_list[1][2]
                elif motor_info[0][10] >= 3 and nb_freq_list[bp][0] == "d3glb" or nb_freq_list[bp][0] == "d3grb":
                    r_speed = ndcl_freq_list[2][2]

            if r_speed > 0:
                # 베어링 축 회전주파수 = 조화성분 1X ~ 4X
                harmonics = 4
                nxfreq_list, pk_bool_list = harmonics_freq_calc(fft_data, peaks, r_speed, hz_min, hz_max, harmonics)

                th_over_list = [0 for i in range(len(nxfreq_list))]  # 조화성분 임계치 초과 유무
                for nx in range(len(nxfreq_list)):
                    if pk_bool_list[nx] > 0:
                        th_freq = vib_threshold_find(sensor_pos, axis, fft_th_arry, nxfreq_list[nx])
                        if pk_bool_list[nx] == 1 and fft_data[nxfreq_list[nx]] > th_freq:
                            th_over_list[nx] = 1

                # 1x, 3x RPM 진폭 높음
                if th_over_list[0] == 1 and th_over_list[2] == 1 and fft_data[nxfreq_list[2]] > fft_data[nxfreq_list[0]]:
                    if (sensor_pos == 2 or sensor_pos == 3) and nb_freq_list[bp][0] == "sb":
                        print("헐거움(축과 베어링)")
                        l = [int('0b10000101', 2)]  # S5
                        fail_list = fail_list + l
                    else:
                        print("헐거움(축과 베어링)")
                        l = [int('0b01100101', 2)]  # B5
                        fail_list = fail_list + l

                # 1x, 4x RPM 진폭 높음
                if th_over_list[0] == 1 and th_over_list[3] == 1 and fft_data[nxfreq_list[3]] > fft_data[nxfreq_list[0]]:
                    if (sensor_pos == 2 or sensor_pos == 3) and nb_freq_list[bp][0] == "sb":
                        print("헐거움(베어링과 하우징)")
                        l = [int('0b10000110', 2)]  # S6
                        fail_list = fail_list + l
                    else:
                        print("헐거움(베어링과 하우징)")
                        l = [int('0b01100110', 2)]  # B6
                        fail_list = fail_list + l

        ######################################################################################

        if not fail_list:
            l = []  # [int('0b11111111', 2)]
            fail_list = fail_list + l
        else:
            # 진단결과 중복 제거
            fail_set = set(fail_list)  # 집합 set으로 변환
            fail_list = list(fail_set)  # list로 변환

        return fail_list
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print('fail error:', e)
        print(exc_type, fname, exc_tb.tb_lineno)
        print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
        return -1
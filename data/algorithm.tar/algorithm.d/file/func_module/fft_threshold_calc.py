import os

import numpy as np
from scipy.signal import lfilter, butter

from file.func_module.acc_int import acc_int
from file.func_module.fail_freq_calc import fail_freq_calc
from file.func_module.read_json import read_json
from file.func_module.vib_fault_analysis import vib_overall_calc

from file.func_module.write_json import wirte_json_vib_fft_threshold


def butter_bandpass(lowcut, highcut, fs, order=5):
    nyq = 0.5 * fs
    low = lowcut / nyq
    high = highcut / nyq
    b, a = butter(order, [low, high], btype='band')
    return b, a


def butter_bandpass_filter(data, lowcut, highcut, fs, order=5):
    b, a = butter_bandpass(lowcut, highcut, fs, order=order)
    y = lfilter(b, a, data)
    return y


def fft_threshold_calc(data_path1_array, data_path2_array, json_path):
    """ 진동 FFT 임계치 산출

    :param array data_path1_array: 전동기/감속기 진동 데이터 경로 배열
    :param array data_path2_array: 축베어링 진동 데이터 경로 배열
    :param string json_path: 설비 정보 json 파일 경로
    :return:
    """

    # Sample rate(Hz)
    Fs = 2000

    # sigma(표준편차) 계수
    nx = 1

    # 기계 설비 스펙 정보 불러오기(json)
    mes = read_json(json_path)
    # facility_info, mo_re_axis_info, l_sh_be_axis_info, motor_info, decelerator_info, bearing_info, pulley_info, vbelt_info, fan_info, \
    # DchainSprocket_info, STchainSprocket_info, Dchain_info, STchain_info = read_json_sp(json_path)

    # 결함 주파수 산출
    N_S_RPM, N_S, F_r, F_S, F_P, RBPF, BPF, CPF, m_GMF, ndcl_freq_list, DrivenPulleyRPM, nb_freq_list, vbelt_f, Fan_F_r = fail_freq_calc(
        mes['Facility'], mes['Motor'], mes['Decelerator'], mes['Bearing'], mes['Pulley'], mes['Vbelt'], mes['Fan'],
        [[]], [[]])
    # N_S_RPM, N_S, F_r, F_S, F_P, RBPF, BPF, CPF, m_GMF, ndcl_freq_list, DrivenPulleyRPM, nb_freq_list, vbelt_f, \
    # Fan_F_r = fail_freq_calc(
    #     facility_info, motor_info, decelerator_info, bearing_info, pulley_info, vbelt_info, fan_info, DchainSprocket_info,
    #     STchainSprocket_info)

    # 전동기/감속기 누적 RMS 값
    rtn_rms_array = np.array([])

    rpm_range_arry = np.array([])
    data_position_arry = np.array([])
    th_all_x = np.array([])
    th_all_y = np.array([])
    th_all_z = np.array([])

    for j in range(2):
        vib_data_position = 1
        data_path_array = data_path1_array

        if j == 1:
            vib_data_position = 2
            data_path_array = data_path2_array

        resultX_list = []
        resultY_list = []
        resultZ_list = []

        th_x_arry = np.zeros(6)
        th_y_arry = np.zeros(6)
        th_z_arry = np.zeros(6)

        for n in range(len(data_path_array)):

            # 분석대상 파일 읽기
            f = open(data_path_array[n], 'r')
            lines = f.readlines()
            _x = []
            _y = []
            _z = []
            for i in range(len(lines)):
                _x.append(lines[i].split(' ')[0])
                _y.append(lines[i].split(' ')[1])
                _z.append(lines[i].split(' ')[2])

            _x = np.array(_x)
            _y = np.array(_y)
            _z = np.array(_z)
            _x = _x.astype('float')
            _y = _y.astype('float')
            _z = _z.astype('float')

            # 진동 데이터 FFT 변환 및 분석
            # 진동 X, Y, Z축 FFT
            fft_x = acc_int(_x, Fs)
            fft_y = acc_int(_y, Fs)
            fft_z = acc_int(_z, Fs)

            fft_x = fft_x * 30
            fft_y = fft_y * 30
            fft_z = fft_z * 30

            # X축 overall
            resultX = vib_overall_calc(fft_x)
            # Y축 overall
            resultY = vib_overall_calc(fft_y)
            # Z축 overall
            resultZ = vib_overall_calc(fft_z)

            data_position_str = "none"
            if vib_data_position == 1:
                data_position_str = "mo-re"  # 전동기/감속기
            elif vib_data_position == 2:
                data_position_str = "l-sh-be"   # 좌측 축 베어링
            elif vib_data_position == 3:
                data_position_str = "r-sh-be"   # 우측 축 베어링
            elif vib_data_position == 4:
                data_position_str = "base"  # 베이스

            # 누적 overall 데이터 리스트 생성
            resultX_list = resultX_list + [resultX]
            resultY_list = resultY_list + [resultY]
            resultZ_list = resultZ_list + [resultZ]

            # 진동 임계치 범위
            rpm = F_r
            std_x_arry = np.array([])
            std_y_arry = np.array([])
            std_z_arry = np.array([])

            rpm_range_arry = np.array([10, round(rpm - (rpm / 2)), round((2 * rpm) - (rpm / 2)), round((3 * rpm) - (rpm / 2)), round((5 * rpm) - (rpm / 2)), round((13 * rpm) - (rpm / 2)), round(Fs / 2)])

            for i in range(6):
                # if i == 0:  # Subharmonics
                #     lowcut = 10
                #     highcut = round(rpm - (rpm / 2))
                # elif i == 1:    # 1xRPM
                #     lowcut = round(rpm - (rpm / 2))
                #     highcut = round(rpm + (rpm / 2))
                # elif i == 2:    # 2xRPM
                #     lowcut = round((2 * rpm) - (rpm / 2))
                #     highcut = round((2 * rpm) + (rpm / 2))
                # elif i == 3:    # 3~4xRPM
                #     lowcut = round((3 * rpm) - (rpm / 2))
                #     highcut = round((4 * rpm) + (rpm / 2))
                # elif i == 4:    # 5~12xRPM
                #     lowcut = round((5 * rpm) - (rpm / 2))
                #     highcut = round((12 * rpm) + (rpm / 2))
                # elif i == 5:    # HFD
                #     lowcut = round((13 * rpm) - (rpm / 2))
                #     highcut = round(Fs / 2)

                # Bandpass Filter
                # bpf_fft_x = butter_bandpass_filter(fft_x, rpm_range_arry[i], rpm_range_arry[i+1], Fs, order=10)
                # bpf_fft_y = butter_bandpass_filter(fft_y, rpm_range_arry[i], rpm_range_arry[i+1], Fs, order=10)
                # bpf_fft_z = butter_bandpass_filter(fft_z, rpm_range_arry[i], rpm_range_arry[i+1], Fs, order=10)

                # std
                std_x = np.mean(fft_x[rpm_range_arry[i]:rpm_range_arry[i+1]]) + nx * np.std(fft_x[rpm_range_arry[i]:rpm_range_arry[i+1]])
                std_y = np.mean(fft_y[rpm_range_arry[i]:rpm_range_arry[i+1]]) + nx * np.std(fft_y[rpm_range_arry[i]:rpm_range_arry[i+1]])
                std_z = np.mean(fft_z[rpm_range_arry[i]:rpm_range_arry[i+1]]) + nx * np.std(fft_z[rpm_range_arry[i]:rpm_range_arry[i+1]])
                std_x_arry = np.append(std_x_arry, std_x)
                std_y_arry = np.append(std_y_arry, std_y)
                std_z_arry = np.append(std_z_arry, std_z)

            th_x_arry = th_x_arry + std_x_arry
            th_y_arry = th_y_arry + std_y_arry
            th_z_arry = th_z_arry + std_z_arry

        # 누적 overall 데이터 텍스트 저장
        fid = open("./rmsstack_" + data_position_str + ".txt", 'w')
        for i in range(len(resultX_list)):
            fid.write(str(resultX_list[i]) + "\t" + str(resultY_list[i]) + "\t" + str(resultZ_list[i]) + "\n")
        fid.close()

        rtn_rms_array = np.append(rtn_rms_array, os.path.abspath("rmsstack_" + data_position_str + ".txt"))

        data_position_arry = np.append(data_position_arry, data_position_str)
        th_all_x = np.append(th_all_x, th_x_arry)
        th_all_y = np.append(th_all_y, th_y_arry)
        th_all_z = np.append(th_all_z, th_z_arry)

    # 진동 임계치 json 저장
    wirte_json_vib_fft_threshold("./vib_threshold.json", rpm_range_arry, data_position_arry, th_all_x, th_all_y, th_all_z)
    rtn_threshold = os.path.abspath("vib_threshold.json")

    print("rms 파일명 : ", rtn_rms_array)
    print("임계치 파일명 : ", rtn_threshold)

    return rtn_rms_array, rtn_threshold
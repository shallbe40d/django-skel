import numpy as np


def cal_length(d_Pitch, D_Pitch, V_d_r_Hz, V_D_r_Hz, V_total):
    """

    :param d_Pitch: 구동풀리 피치원
    :param D_Pitch: 피동풀리 피치원
    :param V_d_r_Hz: 구동풀리 회전속도(Hz)
    :param V_D_r_Hz: 피동풀리 회전속도(Hz)
    :param V_total: V벨트 전체길이
    :return: Elongation - 신율
    """
    # 변수설정
    M = 1780  # 명판 - 미사용
    FL = 60  # 전원주파수 Hz - 미사용
    # d_Pitch = 140 #구동풀리 피치원(라벨)
    # D_Pitch = 205 #피동풀리 피치원(라벨)
    # V_total = 2067 #V벨트 전체길이(DB에서 가져오기)
    # d_r=1598;%%실제 회전속도(타코미터) RPM
    # 회전속도 계산
    # V_d_r_Hz = 1748/60.0 #IoT진동 FFT파형에서 구동풀리 회전속도 Hz
    # V_D_r_Hz = 1109/60.0 #IoT진동 FFT파형에서 피동풀리 회전속도 Hz

    # 초기 조건 계산
    B0 = V_total - 1.57 * (D_Pitch + d_Pitch)  # 축간거리 구하기 위한 B0 계산
    C0 = (B0 + np.sqrt(B0 ** 2 - 2 * (D_Pitch - d_Pitch) ** 2)) / 4  # 초기 축간거리
    L0 = (2 * C0) + (1.57 * (D_Pitch + d_Pitch)) + ((D_Pitch - d_Pitch) ** 2 / (4 * C0))  # 초기 벨트 길이 계산
    Ls0 = np.sqrt(C0 ** 2 - ((D_Pitch - d_Pitch) ** 2 / 4))  # 초기 스팬길이
    delta0 = 0.016 * Ls0  # 초기 처짐량

    R1 = D_Pitch / d_Pitch  # 구동 풀리 피치원/피동 풀리 피치원
    R2 = V_d_r_Hz / V_D_r_Hz  # (인장 V벨트)구동 회전속도/피동 회전속도

    R1R2_ratio = R2 / R1  # 인장V벨트 감속비 대 정상 V벨트 감속비

    N_d_Pitch = d_Pitch / R1R2_ratio  # 새로운 구동풀리 피치원

    # 2차방정식 계수 계산
    a = 4 * 2
    b = (4 * ((1.57 * (N_d_Pitch + D_Pitch)) - V_total))
    c = ((D_Pitch - N_d_Pitch) ** 2)

    # 근의 공식 계산
    r1, r2 = quadroots(a, b, c)

    # 두 근과 C0의 차의 절대값
    x1 = np.abs(r1 - C0)
    x2 = np.abs(r2 - C0)

    # 이차방정식 근(새로운 축간거리)의 2개 중에 알맞은 값 선정
    C = select_c(x1, x2, r1, r2, C0)

    # 늘어난 V벨트 전체 길이
    L = (2 * C) + 1.57 * (D_Pitch + d_Pitch) + ((D_Pitch - d_Pitch) ** 2 / (4 * C))

    # V벨트 인장길이량 및 신율 계산
    length = L - V_total
    Elongation = length / V_total * 100

    # 현재 B 구하기
    B = L - 1.57 * (D_Pitch + d_Pitch)

    # 현재 스팬길이
    Ls = np.sqrt(C ** 2 - ((D_Pitch - d_Pitch) ** 2 / 4))

    # 현재 처짐량
    delta = 0.016 * Ls

    print("초기 처짐량:", delta0, "mm")
    print("현재 처짐량:", delta, "mm")
    print("초기 벨트길이:", L0, "mm")
    print("현재 벨트길이:", L, "mm")
    print("인장길이:", length, "mm")
    print("산출된 신율:", Elongation, "%")
    return Elongation


def quadroots(a, b, c):
    if (a == 0):
        if (b != 0):
            return -c / b, 0.0
        else:
            return 0.0, 0.0
    else:
        d = b * b - 4 * a * c
        if (d > 0):
            r1 = (-b + np.sqrt(d)) / (2 * a)
            r2 = (-b - np.sqrt(d)) / (2 * a)
            return r1, r2
        else:
            r1 = -b / (2 * a)
            r2 = r1
            i1 = np.sqrt(np.abs(d)) / (2 * a)
            i2 = -i1
            return r1, r2


def select_c(x1, x2, r1, r2, C0):
    if (x1 > x2):
        return r2
    elif (x1 < x2):
        return r1
    else:
        return C0

# _*_ coding: UTF-8 -*-

import numpy as np
import math


def acc_int(data, fs) :
	from numpy.fft import fft
	df = fs / data.shape[0]
	data_fft = (fft(data))/(data.shape[0])
	data_fft_mag = np.multiply(data_fft, data_fft.conjugate()) ** 0.5

	faxis = np.arange(0, (fs-1/data.shape[0]), df)

	data_fft_mag = data_fft_mag[0:(math.ceil(data.shape[0]/2))]*2
	faxis = faxis[0:(math.ceil(data.shape[0]/2))]

	rtn = np.zeros((math.floor(fs/2)+1))

	for n1 in np.arange(4, math.floor(fs/2-1)+1) :
		tmp = 0
		for n2 in np.arange( math.ceil((n1-0.5)/df+1), math.ceil((n1+0.5)/df)+1 ) :
			tmp = tmp + ( data_fft_mag[n2-1] / np.sqrt(2) / (2*np.pi*faxis[n2-1])) ** 2
		rtn[n1] = np.sqrt(tmp)

	return rtn

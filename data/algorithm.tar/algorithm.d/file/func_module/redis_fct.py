import os
import sys

import redis


def rd_conn(host, port, db):
    """redis connetion

    :param string host:
    :param int port:
    :param int db:
    :return:
    """
    rtn = redis.StrictRedis(host=host, port=port, db=db)

    return rtn


def rd_set(rd, key, val):
    """redis key, value 쓰기

    :param redis.StrictRedis rd:
    :param string key:
    :param val:
    :return: 성공여부(True, class 'NoneType')
    """

    try:
        rtn = rd.set(key, val)

        return rtn

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print('fail error:', e)
        print(exc_type, fname, exc_tb.tb_lineno)
        print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
        return None


def rd_get(rd, key):
    """redis key의 value 읽기

    :param redis.StrictRedis rd:
    :param string key:
    :return: 성공여부(True, class 'NoneType')
    """

    try:
        rtn = rd.get(key)

        return rtn

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print('fail error:', e)
        print(exc_type, fname, exc_tb.tb_lineno)
        print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
        return None


def rd_flushdb(rd):
    """redis DB 전체 데이터 삭제

    :param redis.StrictRedis rd:
    :return: 성공여부(True, False)
    """

    rtn = rd.flushdb()

    return rtn
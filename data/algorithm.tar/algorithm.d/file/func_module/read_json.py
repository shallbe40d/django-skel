import json


def read_json(file_path):
    """ json 파일 조회

    :param string file_path: json 파일 절대 경로
    :return:
    """

    json_data = open(file_path)
    json_decoded = json.load(json_data)

    return json_decoded


# def read_json_sp(file_path):
#     """ 설비 정보 json 파일 조회
#
#     :parameter string file_path: 설비 스펙 json 파일 경로
#     :returns: facility_info, motor_info, decelerator_info, bearing_info, pulley_info, vbelt_info, fan_info, DchainSprocket_info, STchainSprocket_info, Dchain_info, STchain_info
#     """
#
#     facility_info = []  # 설비 정보
#
#     mo_re_axis_info = []     # 전동기/감속기 센서 축 방향 정보
#     l_sh_be_axis_info = []      # 좌측 축베어링 센서 축 방향 정보
#
#     motor_info = []  # 전동기 스펙
#     decelerator_info = []  # 감속기 스펙
#     bearing_info = []  # 베어링 스펙
#
#     # 공조기
#     pulley_info = []  # 풀리 스펙
#     vbelt_info = []  # V벨트 스펙
#     fan_info = []  # 송풍기 팬 스펙
#
#     # 에스컬레이터
#     DchainSprocket_info = []  # 구동체인 스프라켓 스펙
#     STchainSprocket_info = []  # 스텝체인 스프라켓 스펙
#     Dchain_info = []  # 구동체인 스펙
#     STchain_info = []  # 스텝체인 스펙
#
#     with open(file_path, "r") as st_json:
#         st_python = json.load(st_json)
#
#         for element in st_python['Facility']:
#             facility_info.append([
#                 "N" if not element['Type'] else element["Type"],                    # 설비 종류(ex. 에스컬레이터(es), 공조기(acm)
#                 -1 if not element['DriveRPM'] else float(element["DriveRPM"]),      # 구동축 회전속도(RPM)
#                 -1 if not element['DrivenRPM'] else float(element["DrivenRPM"])     # 피구동축 회전속도(RPM)
#             ])
#
#         for element in st_python['MO-RE']:
#             mo_re_axis_info.append([
#                 "x" if not element['shaft'] else element["shaft"],
#                 "y" if not element['vertical'] else element["vertical"],
#                 "z" if not element['horizon'] else element["horizon"]
#             ])
#
#         for element in st_python['L-SH-BE']:
#             l_sh_be_axis_info.append([
#                 "x" if not element['shaft'] else element["shaft"],
#                 "y" if not element['vertical'] else element["vertical"],
#                 "z" if not element['horizon'] else element["horizon"]
#             ])
#
#         for element in st_python['Motor']:
#             motor_info.append([
#                 -1 if not element['Power'] else float(element["Power"]),                    #전동기 동력(kW)
#                 -1 if not element['F_L'] else float(element['F_L']),                        #전동기 전원 주파수(Hz)
#                 "N" if not element['Reducer_YN'] else element['Reducer_YN'],                #감속 여부(Y/N)
#                 -1 if not element['m_volt'] else float(element['m_volt']),                  #전압(V)
#                 -1 if not element['RatedSpeed'] else float(element['RatedSpeed']),          #정격 속도(m/min)
#                 -1 if not element['RPM'] else float(element['RPM']),                        #전동기 회전 속도(RPM)
#                 -1 if not element['P'] else int(element['P']),                              #전동기 극 수(극)
#                 -1 if not element['RotorBars'] else int(element['RotorBars']),              #전동기 로터 수(개)
#                 -1 if not element['Blades'] else int(element['Blades']),                    #전동기 블레이드 수(개)
#                 -1 if not element['CN'] else int(element['CN']),                            #전동기 극당 코일 수(개)
#                 -1 if not element['ReducerStageNum'] else int(element['ReducerStageNum']),  #감속기 감속 기어 단 수(단)
#                 -1 if not element['ReducerRatioL'] else float(element["ReducerRatioL"]),    #감속기 감속비 좌변
#                 -1 if not element['ReducerRatioR'] else float(element["ReducerRatioR"]),    #감속기 감속비 우변
#                 -1 if not element['mpt_type'] else int(element["mpt_type"])                 #전동기 동력전달장치
#             ])
#
#         if motor_info[0][2] == "Y":
#             i = 0
#             for element in st_python['Decelerator']:
#                 decelerator_info.append([
#                     -1 if not element['name'] else element["name"],                                             #감속기 n단
#                     -1 if not element['nReducerStageT_Pinion'] else int(element["nReducerStageT_Pinion"]),      #감속기 기어 n단의 피니언 잇 수(개)
#                     -1 if not element['nReducerStageT_Gear'] else int(element["nReducerStageT_Gear"]),          #감속기 기어 n단의 기어 잇 수(개)
#                     -1 if not element['nReducerStagePinionF_n'] else float(element["nReducerStagePinionF_n"]),  #감속기 기어n단 피니언 고유 진동수(Hz)
#                     -1 if not element['nReducerStageGearF_n'] else float(element["nReducerStageGearF_n"])       #감속기 기어n단 기어 고유 진동수(Hz)
#                 ])
#                 i +=1
#
#         for element in st_python['Bearing']:
#             bearing_info.append([
#                 -1 if not element['name'] else element["name"],                             #베어링 위치
#                 -1 if not element['nn'] else int(element["nn"]),                            #베어링 볼 개수(개)
#                 -1 if not element['nB_d'] else float(element["nB_d"]),                      #베어링 볼 직경(mm)
#                 -1 if not element['nP_d'] else float(element["nP_d"]),                      #베어링 피치원(mm)
#                 -1 if not element['nContactAngle'] else float(element["nContactAngle"]),    #베어링 접촉각(°)
#                 -1 if not element['nBearingF_n'] else float(element["nBearingF_n"])         #베어링 고유진동수(Hz)
#             ])
#
#         if facility_info[0][0] == "acm":
#             for element in st_python['Pulley']:
#                 pulley_info.append([
#                     -1 if not element['DrivePulleyPCD'] else float(element["DrivePulleyPCD"]),      #구동부 풀리 피치원 지름(mm)
#                     -1 if not element['DrivenPulleyPCD'] else float(element["DrivenPulleyPCD"])     #피구동부 풀리 피치원 지름(mm)
#                 ])
#
#             for element in st_python['Vbelt']:
#                 vbelt_info.append([
#                     -1 if not element['vbelt_num'] else int(element["vbelt_num"]),                  #V벨트 열 수(개)
#                     -1 if not element['vbelt_length'] else float(element["vbelt_length"]),          #V벨트 길이(mm)
#                     -1 if not element['vbelt_nf'] else float(element["vbelt_nf"]),                  #V벨트 고유진동수(Hz)
#                     -1 if not element['distance_pulleys'] else float(element["distance_pulleys"])   #구동-피동 풀리 중심 거리(mm)
#                 ])
#
#             for element in st_python['Fan']:
#                 fan_info.append([
#                     -1 if not element['acmFanBladeNum'] else int(element["acmFanBladeNum"])  # 송풍기 팬 날개 수(개)
#                 ])
#
#         if facility_info[0][0] == "es":
#             for element in st_python['DchainSprocket']:
#                 DchainSprocket_info.append([
#                     -1 if not element['DriveSprocketNT'] else float(element["DriveSprocketNT"]),        # 구동부 스프라켓 잇수(개)
#                     -1 if not element['DriveSprocketPCD'] else float(element["DriveSprocketPCD"]),      # 구동부 스프라켓 피치원 지름(mm)
#                     -1 if not element['DrivenSprocketNT'] else float(element["DrivenSprocketNT"]),      # 피구동부 스프라켓 잇수(개)
#                     -1 if not element['DrivenSprocketPCD'] else float(element["DrivenSprocketPCD"])     # 피구동부 스프라켓 피치원 지름(mm)
#                 ])
#
#             for element in st_python['STchainSprocket']:
#                 STchainSprocket_info.append([
#                     -1 if not element['STchainSprocketNT'] else float(element["STchainSprocketNT"]),    # 스텝체인 스프라켓 잇수(개)
#                     -1 if not element['STchainSprocketPCD'] else float(element["STchainSprocketPCD"])   # 스텝체인 스프라켓 피치원 지름(mm)
#                 ])
#
#             for element in st_python['Dchain']:
#                 Dchain_info.append([
#                     -1 if not element['rs_chain_num'] else float(element["rs_chain_num"]),      # 구동체인 링크 개수(개)
#                     -1 if not element['rs_chain_pitch'] else float(element["rs_chain_pitch"])   # 구동체인 피치 길이(mm)
#                 ])
#
#             for element in st_python['STchain']:
#                 STchain_info.append([
#                     -1 if not element['name'] else element["name"],                             # 스텝체인 위치(LSTC : 좌 / RSTC : 우)
#                     -1 if not element['st_chain_num'] else float(element["st_chain_num"]),      # 스텝체인 링크 개수(개)
#                     -1 if not element['st_chain_pitch'] else float(element["st_chain_pitch"]),  # 스텝체인 피치 길이(mm)
#                     -1 if not element['st_chain_stnum'] else float(element["st_chain_stnum"]),  # 스텝체인 스텝 수(개)
#                     -1 if not element['st_chain_material'] else element["st_chain_material"]    # 스텝체인 롤러 재질(M : 금속 / U : 우레탄)
#                 ])
#
#     return facility_info, mo_re_axis_info, l_sh_be_axis_info, motor_info, decelerator_info, bearing_info, pulley_info, vbelt_info, fan_info, DchainSprocket_info, STchainSprocket_info, Dchain_info, STchain_info
#
#
# def read_json_fault_freq(file_path):
#     """결함주파수 json 파일 조회
#
#     :param file_path: 결함주파수 json 파일 절대경로
#     :return: motor_fail_freq, ndcl_fail_freq, nb_fail_freq, acm_fail_freq
#     """
#
#     motor_fail_freq = []
#     ndcl_fail_freq = []
#     nb_fail_freq = []
#     acm_fail_freq = []
#
#     with open(file_path, "r") as st_json:
#         st_python = json.load(st_json)
#
#         for element in st_python['motor_fail_freq']:
#             motor_fail_freq.append([
#                 -1 if not element['N_S_RPM'] else float(element["N_S_RPM"]),    # 전동기 슬립없는 동기 속도
#                 -1 if not element['N_S'] else float(element["N_S"]),            # 전동기 축 회전주파수(슬립 x)
#                 -1 if not element['F_r'] else float(element["F_r"]),            # 전동기 축 회전주파수(슬립 o) = 명판
#                 -1 if not element['F_S'] else float(element["F_S"]),            # 전동기 슬립주파수
#                 -1 if not element['F_P'] else float(element["F_P"]),            # 전동기 극통과주파수
#                 -1 if not element['RBPF'] else float(element["RBPF"]),          # 전동기 로터바 통과주파수
#                 -1 if not element['BPF'] else float(element["BPF"]),            # 전동기 블레이드 통과주파수
#                 -1 if not element['CPF'] else float(element["CPF"]),            # 전동기 코일 통과주파수
#                 -1 if not element['m_GMF'] else float(element["m_GMF"])         # 전동기 최종 출력 축 GMF (풀리의 경우 계산 X)
#             ])
#
#         for element in st_python['ndcl_fail_freq']:
#             ndcl_fail_freq.append([
#                 'N' if not element['name'] else element["name"],                                # 감속기 기어 단 수
#                 -1 if not element['ReducerStageGMF'] else float(element["ReducerStageGMF"]),    # 감속기 기어 n단 GMF
#                 -1 if not element['ReducerStageF_r'] else float(element["ReducerStageF_r"]),    # 감속기 기어 n단 축 회전주파수
#                 -1 if not element['ReducerF_ht'] else float(element["ReducerF_ht"])             # 감속기 기어 n단 헌팅주파수
#             ])
#
#         for element in st_python['nb_fail_freq']:
#             nb_fail_freq.append([
#                 'N' if not element['name'] else element["name"],                        # 베어링 위치
#                 -1 if not element['nBearingF_n'] else float(element["nBearingF_n"]),    # 베어링 고유진동수(Hz)
#                 -1 if not element['BPFI'] else float(element["BPFI"]),                  # 베어링 내륜 통과 주파수
#                 -1 if not element['BPFO'] else float(element["BPFO"]),                  # 베어링 외륜 통과 주파수
#                 -1 if not element['BSF'] else float(element["BSF"]),                    # 베어링 볼 통과 주파수
#                 -1 if not element['FTF'] else float(element["FTF"])                     # 베어링 기본 주행 주파수
#             ])
#
#         for element in st_python['acm_fail_freq']:
#             acm_fail_freq.append([
#                 -1 if not element['DrivenPulleyRPM'] else float(element["DrivenPulleyRPM"]),    # 피동풀리 RPM(Hz)
#                 -1 if not element['vbelt_f'] else float(element["vbelt_f"]),                    # 벨트 주파수(Hz)
#                 -1 if not element['Fan_F_r'] else float(element["Fan_F_r"])                     # 공조기 팬 결함주파수
#             ])
#
#     return motor_fail_freq, ndcl_fail_freq, nb_fail_freq, acm_fail_freq
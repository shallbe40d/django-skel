#import tensorflow as tf
from file.func_module._noise_analysis import *
from file.func_module._noise_analysis import gas_core
from file.func_module._noise_analysis import gw_ai_solution as gas
import warnings
import os
import sys
from datetime import date
import time
import datetime
import numpy as np
from scipy import signal
warnings.filterwarnings("ignore")

def rms(data):
    _rms = lambda d: np.sqrt ((d ** 2) .sum ()/d.size)
    return _rms(data)


def file_read(_path): #소음 num파일 import
    f=open(_path,"r", encoding="utf-8")
    data = f.readlines()
    f.close()
    for i in range(len(data)):
        data[i] = int(data[i].replace("\n",""))
    data = np.array(data)
    data = data.astype('int16')
    return data


def file_read2(_path): #소음 num파일 import
    f=open(_path,"r", encoding="utf-8")
    data = f.readlines()
    f.close()
    for i in range(len(data)):
        data[i] = int(data[i].replace("\n",""))
    data = np.array(data)
    data = data.astype('float32')
    sos = signal.bessel(5, 20, "hp", fs=50000, output="sos")
    sig = signal.sosfiltfilt(sos, data)
    return sig


def corr_welch_analysis(src, fs):
    #segment_size = 32768
    #segment_size = 131072
    segment_size = 65536
    src = np.array(src) #convert np.array
    #print(type(src[0]))
    if type(src[0]) !="<class 'numpy.float32'>": #check string
        src = src.astype('float32') #convert "float32"
        if(src.max()>=1.0):
            src = (src-src.mean())/2047.0 #data -1 ~ 1 rescale 
    src_corr= signal.correlate(src, src, mode="full")
    # plt.plot(src_corr)
    # plt.show()
    noverlap = segment_size /2
    f, Pxx = signal.welch(src_corr,
                            fs = fs,
                            nperseg = segment_size,
                            average = 'median',
                            window='hanning',
                            nfft = segment_size,
                            scaling = 'spectrum',
                            noverlap = noverlap)
    return f, Pxx


def noise_analysis(GW_SoundPath, ConditionStackPath, SpecPath, ThresholdPath, GW_Position):
    try:
        data = file_read(GW_SoundPath)
        hp_data = file_read(GW_SoundPath)
        f,Pxx = corr_welch_analysis(hp_data, 50000)
        _rms = rms(Pxx)
       # cnt = 0
       # for i in data:
       #     print("cnt: ",cnt,"\t",int(i))
       #     cnt=cnt+1
        print("data length: ", len(data))
        result = gas.analyze(data)
        print("result:",result)
        if int(result)  == 0:
            print("정지, rms:", _rms)
            return _rms, 0, 0
        elif int(result)  == 1:
            print("가동중, rms:",_rms)
            return _rms, 1, 0
        elif int(result)  == 2:
            print("가동중(이상), rms:",_rms)
            return _rms, 1, 1

    except Exception as e:
        print("Time: ", datetime.datetime.now())
        print("noise_analysis_error: ", e)
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type, fname, exc_tb.tb_lineno)
        return 1

/Op_CondIndi.py/ : 이상소음감지
vibration_analysis.py, acc_int.py : 진동등급  -> acc_int.py, execute.py, /vib_rank.py/
acm_sp.json, fail_freq_calc.py, fail_type_analysis.py, read_json.py, vib_diag.py : 진동진단
packet_cilent.zip는 서버 패킷 테스트용 클라이언트.
#include "SocketClientController.h"

#include "util/Util.h"

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

CSocketClientController::CSocketClientController()
{
	mIsConnected = false;
	mIsStart = false;
}

CSocketClientController::~CSocketClientController()
{
}

void CSocketClientController::Init(std::string ip, int port)
{
	mServerIp = ip;
	mPort = port;
}

int CSocketClientController::Start()
{
	mConnectionThread = new std::thread(&CSocketClientController::ConnectionThread, this);
}

void CSocketClientController::ConnectionThread()
{
	LOGD(TAG, "Start Connection Thread");
	mSocketFd = 0;

	mSocketFd = socket(AF_INET, SOCK_STREAM, 0);
	if (mSocketFd == -1)
	{
		LOGE(TAG, "Socket open error -> Stop Connection Thread");
		return;
	}

	LOGD(TAG, "fd: %d", mSocketFd);

	struct sockaddr_in serverIp;

	int inetSuccess = inet_aton(mServerIp.c_str(), &serverIp.sin_addr);

	if (inetSuccess == 0)
	{
		// if hostname is not in IP strings and dots format, try resolve it
#if 0
		struct hostent *host;
		struct in_addr **addrList;
		if ( (host = gethostbyname( address.c_str() ) ) == NULL){
			ret.success = false;
			ret.msg = "Failed to resolve hostname";
			return ret;
		}
		addrList = (struct in_addr **) host->h_addr_list;
		serverIp.sin_addr = *addrList[0];
#endif
		LOGE(TAG, "IP address not valid -> Stop Connection Thread");
		return;
	}

	serverIp.sin_family = AF_INET;
	serverIp.sin_port = htons(mPort);

	while (mIsConnected == false)
	{
		LOGD(TAG, "Try Connect %s:%d", mServerIp.c_str(), mPort);
		int connectRet = connect(mSocketFd, (struct sockaddr *)&serverIp, sizeof(serverIp));

		if (connectRet == 0)
		{
			mReadThread = new std::thread(&CSocketClientController::ReadThread, this);
			mIsConnected = true;
			break;
		}
		sleep(SOCKET_CONNECTION_RETRY_INTERVAL);
	}

	LOGD(TAG, "Stop Connection Thread");
}

void CSocketClientController::ReadThread()
{
	LOGD(TAG, "Start ReadThread");

	mIsStart = true;

	while (mIsStart == true)
	{
		char msg[MAX_PACKET_SIZE];

		int numOfBytesReceived = recv(mSocketFd, msg, MAX_PACKET_SIZE, 0);

		if (numOfBytesReceived < 1)
		{
			mIsStart = false;

			if (numOfBytesReceived == 0)
			{
				//ret.msg = "Server closed connection";
			}
			else
			{
				//ret.msg = strerror(errno);
			}

			//publishServerDisconnected(ret);
			//finish();
			break;
		}
		else
		{
			char info[64];
			snprintf(info, 64, "[RD][%s:%d]", mServerIp.c_str(), mPort);
			PrintPacket(TAG, info, (char *)msg, numOfBytesReceived);
			NotifyListener(msg, numOfBytesReceived);
		}
	}

	mIsConnected = false;
	close(mSocketFd);
	mConnectionThread = new std::thread(&CSocketClientController::ConnectionThread, this);

	LOGD(TAG, "Stop ReadThread");
}

size_t CSocketClientController::Write(const char *msg, const int size, const char *tag)
{
	char info[64];
	snprintf(info, 64, "[WR][%s:%d]", mServerIp.c_str(), mPort);
	PrintPacket(TAG, info, (char *)msg, size);

	int numOfBytesSent = send(mSocketFd, msg, size, 0);

	if (numOfBytesSent < 0 )
	{ // send failed
		//ret.success = false;
		//ret.msg = strerror(errno);
		//return ret;
	}
	if ((uint)numOfBytesSent < size)
	{ // not all bytes were sent
		//ret.success = false;
		char msg[100];
		LOGE(TAG, "[%d/%d] Sent", numOfBytesSent, size);
		//ret.msg = msg;
		//return ret;
	}
	//ret.success = true;
	//return ret;
}


#if 0

#include "../include/tcp_client.h"


pipe_ret_t TcpClient::sendMsg(const char * msg, size_t size) {
}

/*
 * Publish incoming client message to observer.
 * Observers get only messages that originated
 * from clients with IP address identical to
 * the specific observer requested IP
 */
void TcpClient::publishServerMsg(const char * msg, size_t msgSize) {
    for (uint i=0; i<m_subscibers.size(); i++) {
        if (m_subscibers[i].incoming_packet_func != NULL) {
            (*m_subscibers[i].incoming_packet_func)(msg, msgSize);
        }
    }
}

/*
 * Publish client disconnection to observer.
 * Observers get only notify about clients
 * with IP address identical to the specific
 * observer requested IP
 */
void TcpClient::publishServerDisconnected(const pipe_ret_t & ret) {
    for (uint i=0; i<m_subscibers.size(); i++) {
        if (m_subscibers[i].disconnected_func != NULL) {
            (*m_subscibers[i].disconnected_func)(ret);
        }
    }
}


pipe_ret_t TcpClient::finish(){
    stop = true;
    terminateReceiveThread();
    pipe_ret_t ret;
    if (close(m_sockfd) == -1) { // close failed
        ret.success = false;
        ret.msg = strerror(errno);
        return ret;
    }
    ret.success = true;
    return ret;
}

void TcpClient::terminateReceiveThread() {
    if (m_receiveTask != nullptr) {
        m_receiveTask->detach();
        delete m_receiveTask;
        m_receiveTask = nullptr;
    }
}

TcpClient::~TcpClient() {
    terminateReceiveThread();
}

#endif
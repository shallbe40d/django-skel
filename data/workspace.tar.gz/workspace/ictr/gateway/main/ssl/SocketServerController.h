#ifndef _SOCKET_SERVER_CONTROLLER_H
#define _SOCKET_SERVER_CONTROLLER_H

#include "base/CommunicationBase.h"
#include "common/MessageDefine.h"

#include <list>
#include <string>
#include <thread>
#include <functional>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

class CClientInfo
{
public:
	CClientInfo() {}
	~CClientInfo() {}

#if 0
	bool operator ==(const Client & other);
#endif

	void SetSocketFd(int fd) { mSocketFd = fd; }
	int GetSocketFd() { return mSocketFd; }

	void SetId(const std::string &id) { mId = id; }
	std::string GetId() const { return mId; }

	void SetIp(const std::string &ip) { mIp = ip; }
	std::string GetIp() const { return mIp; }

	void SetConnected() { mIsConnected = true; }
	void SetDisconnected() { mIsConnected = false; }
	bool IsConnected() { return mIsConnected; }

	void SetReceiveHandler(std::function<void(void)> func) { mReceiveHandler = new std::thread(func);}

private:
	std::string mId;
	std::string mIp;
	int mSocketFd;
	bool mIsConnected;
	std::thread *mReceiveHandler = nullptr;
};

class CSocketServerController : public CCommunicationBase
{
public:
	CSocketServerController();
	~CSocketServerController();

	int Init();

	int Start();
	int Stop();

	void PrintClientInfoList();
	void DeleteClientInfo();

	size_t Write(const char *data, const int size, const char *tag);

protected:
	const char* TAG = "SCKSRV";

private:
	const int MAX_NUM_OF_CLIENTS = 10;
	const int MAX_PACKET_SIZE = 1042;
	int mSocketFd;
	struct sockaddr_in mServerAddress;
	int mPort;

	std::list<CClientInfo *> mClientInfoList;

	bool mIsServerStart;
	int ListenPortThread();

	void ReceiveThread();

private: // for crypto
	uint8_t mKey[MAX_CRYPTO_KEY_LENGTH];
	int mKeyLength;
	CRYPTO_MODE_TYPE mCryptoMode;

	bool IsValidCryptoPacket(const void *data, const unsigned int size);
};

#endif

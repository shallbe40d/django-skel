#include "SocketServerController.h"

#include "log/Log.h"
#include "util/Util.h"

#include <string.h>

#include "cryptopp/cryptlib.h"
using CryptoPP::Exception;

#include "cryptopp/hex.h"
using CryptoPP::HexEncoder;
using CryptoPP::HexDecoder;

#include "cryptopp/filters.h"
using CryptoPP::StringSink;
using CryptoPP::StringSource;
using CryptoPP::StreamTransformationFilter;

#include "cryptopp/aes.h"
using CryptoPP::AES;

#include "cryptopp/modes.h"
using CryptoPP::ECB_Mode;

CSocketServerController::CSocketServerController()
{
	memset(mKey, 0x00, MAX_CRYPTO_KEY_LENGTH);
	mKeyLength = 0;
	mCryptoMode = CRYPTO_NONE;
}

CSocketServerController::~CSocketServerController()
{
}

int CSocketServerController::Init()
{
	mPort = 2148;

	const uint8_t key[32] = {0x01, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02};
	memcpy(mKey, key, 32);
	mKeyLength = 32;
	mCryptoMode = CRYPTO_AES256_ECB;

	return 0;
}

int CSocketServerController::Start()
{
	new std::thread([&]() { ListenPortThread(); });

	return 0;
}

int CSocketServerController::Stop()
{
	LOGD(TAG, "FUNC IN");
}

int CSocketServerController::ListenPortThread()
{
	mSocketFd = 0;

	mSocketFd = socket(AF_INET, SOCK_STREAM, 0);
	if (mSocketFd == -1)
	{
		return -1;
	}

	// set socket for reuse (otherwise might have to wait 4 minutes every time socket is closed)
	int option = 1;
	setsockopt(mSocketFd, SOL_SOCKET, SO_REUSEADDR, &option, sizeof(option));

	memset(&mServerAddress, 0, sizeof(struct sockaddr_in));
	mServerAddress.sin_family = AF_INET;
	mServerAddress.sin_addr.s_addr = htonl(INADDR_ANY);
	mServerAddress.sin_port = htons(mPort);

	int bindSuccess = bind(mSocketFd, (struct sockaddr *)&mServerAddress, sizeof(struct sockaddr_in));
	if (bindSuccess == -1)
	{
		return -1;
	}

	int listenSuccess = listen(mSocketFd, MAX_NUM_OF_CLIENTS);
	if (listenSuccess == -1)
	{
		return -1;
	}

	mIsServerStart = true;

	struct sockaddr_in clientAddress;
	socklen_t sosize  = sizeof(clientAddress);

	while (mIsServerStart == true)
	{
		int fd = accept(mSocketFd, (struct sockaddr*)&clientAddress, &sosize);

		if (fd == -1)
		{
			return -1;
		}
		else
		{
			LOGD(TAG, "Client Connected: %d", fd);
			CClientInfo *client = new CClientInfo();
			client->SetSocketFd(fd);
			client->SetConnected();
			client->SetIp(inet_ntoa(clientAddress.sin_addr));
			client->SetReceiveHandler(std::bind(&CSocketServerController::ReceiveThread, this));
			mClientInfoList.push_back(client);
		}
	}

	return 0;
}

void CSocketServerController::ReceiveThread()
{
	CClientInfo *client = mClientInfoList.back();

	//LOGD(TAG, "Start ReceiveThread for Socket FD: %d", client->GetSocketFd());

	while(client->IsConnected())
	{
		char packet[MAX_PACKET_SIZE];

		int numOfBytesReceived = recv(client->GetSocketFd(), packet, MAX_PACKET_SIZE, 0);
		//LOGD(TAG, "recv: %d", numOfBytesReceived);

		if (numOfBytesReceived < 1)
		{
			client->SetDisconnected();

			if (numOfBytesReceived == 0)
			{
				//client->setErrorMessage("Client closed connection");
				//printf("client closed");
			}
			else
			{
				//client->setErrorMessage(strerror(errno));
			}

			close(client->GetSocketFd());

			//publishClientDisconnected(*client);

			//deleteClient(*client);
			break;
		}
		else
		{
			//char info[64];
			//snprintf(info, 64, "[RD][%d:%s]", client->GetSocketFd(), client->GetIp().c_str());
			//PrintPacket(TAG, info, (char *)packet, numOfBytesReceived);

			NotifyListener(packet, numOfBytesReceived);
		}
	}

	LOGD(TAG, "Stop ReceiveThread for Socket FD: %d", client->GetSocketFd());
}

size_t CSocketServerController::Write(const char *data, int size, const char *tag)
{
#if 0
	for (std::list<CClientInfo *>::iterator it = mClientInfoList.begin(); it != mClientInfoList.end(); it++)
	{
		if ((*it)->GetId().compare(id) == 0)
		{
			std::string cipher;

			int packetLength = 0;
			char *packet = NULL;

			try
			{
				ECB_Mode<AES>::Encryption e;
				e.SetKey(mKey, mKeyLength);

				// The StreamTransformationFilter adds padding as required. ECB and CBC Mode must be padded to the block size of the cipher.
				StringSource((uint8_t *)data, size, true, new StreamTransformationFilter(e, new StringSink(cipher)));

				packetLength = cipher.length() + sizeof(struct CRYPTO_HEAD);
				packet = (char *)malloc(packetLength);
				memset(packet, 0x00, packetLength);

				struct CRYPTO_HEAD *head = (struct CRYPTO_HEAD *)packet;
				head->stx = 0x02;
				head->type = CRYPTO_AES256_ECB;
				struct timespec now;
				clock_gettime(CLOCK_REALTIME, &now);
				head->timestamp = now.tv_sec;
				head->length = cipher.length();
				memcpy(packet + sizeof(struct CRYPTO_HEAD), cipher.c_str(), cipher.length());

				int numBytesSent = send((*it)->GetSocketFd(), packet, packetLength, 0);

				if (numBytesSent < 0)
				{ // send failed
					LOGE(TAG, "send failed");
				}
				else if ((uint)numBytesSent < size)
				{ // not all bytes were sent
					LOGE(TAG, "Not all bytes were sent");
				}

			}
			catch(const CryptoPP::Exception& e)
			{
				LOGE(TAG, "AES ERROR: %s", e.what());
			}
		}
	}
#endif
}

void CSocketServerController::PrintClientInfoList()
{
#if 0
	for (uint i=0; i<m_clients.size(); i++) {
		std::string connected = m_clients[i].isConnected() ? "True" : "False";
		std::cout << "-----------------\n" <<
				  "IP address: " << m_clients[i].getIp() << std::endl <<
				  "Connected?: " << connected << std::endl <<
				  "Socket FD: " << m_clients[i].getFileDescriptor() << std::endl <<
				  "Message: " << m_clients[i].getInfoMessage().c_str() << std::endl;
	}
#endif
}

void CSocketServerController::DeleteClientInfo()
{
#if 0
	int clientIndex = -1;
	for (uint i=0; i<m_clients.size(); i++) {
		if (m_clients[i] == client) {
			clientIndex = i;
			break;
		}
	}
	if (clientIndex > -1) {
		m_clients.erase(m_clients.begin() + clientIndex);
		return true;
	}
#endif
}

#if 0
/*
 * Publish incoming client message to observer.
 * Observers get only messages that originated
 * from clients with IP address identical to
 * the specific observer requested IP
 */
void TcpServer::publishClientMsg(const Client & client, const char * msg, size_t msgSize) {
	for (uint i=0; i<m_subscibers.size(); i++) {
		if (m_subscibers[i].wantedIp == client.getIp() || m_subscibers[i].wantedIp.empty()) {
			if (m_subscibers[i].incoming_packet_func != NULL) {
				(*m_subscibers[i].incoming_packet_func)(client, msg, msgSize);
			}
		}
	}
}

/*
 * Publish client disconnection to observer.
 * Observers get only notify about clients
 * with IP address identical to the specific
 * observer requested IP
 */
void TcpServer::publishClientDisconnected(const Client & client) {
	for (uint i=0; i<m_subscibers.size(); i++) {
		if (m_subscibers[i].wantedIp == client.getIp()) {
			if (m_subscibers[i].disconnected_func != NULL) {
				(*m_subscibers[i].disconnected_func)(client);
			}
		}
	}
}


/*
 * Send message to all connected clients.
 * Return true if message was sent successfully to all clients
 */
pipe_ret_t TcpServer::sendToAllClients(const char * msg, size_t size) {
	pipe_ret_t ret;
	for (uint i=0; i<m_clients.size(); i++) {
		ret = sendToClient(m_clients[i], msg, size);
		if (!ret.success) {
			return ret;
		}
	}
	ret.success = true;
	return ret;
}

/*
 * Send message to specific client (determined by client IP address).
 * Return true if message was sent successfully
 */
pipe_ret_t TcpServer::sendToClient(const Client & client, const char * msg, size_t size){
	pipe_ret_t ret;
	int numBytesSent = send(client.getFileDescriptor(), (char *)msg, size, 0);
	if (numBytesSent < 0) { // send failed
		ret.success = false;
		ret.msg = strerror(errno);
		return ret;
	}
	if ((uint)numBytesSent < size) { // not all bytes were sent
		ret.success = false;
		char msg[100];
		sprintf(msg, "Only %d bytes out of %lu was sent to client", numBytesSent, size);
		ret.msg = msg;
		return ret;
	}
	ret.success = true;
	return ret;
}

/*
 * Close server and clients resources.
 * Return true is success, false otherwise
 */
pipe_ret_t TcpServer::finish() {
	pipe_ret_t ret;
	for (uint i=0; i<m_clients.size(); i++) {
		m_clients[i].setDisconnected();
		if (close(m_clients[i].getFileDescriptor()) == -1) { // close failed
			ret.success = false;
			ret.msg = strerror(errno);
			return ret;
		}
	}
	if (close(m_sockfd) == -1) { // close failed
		ret.success = false;
		ret.msg = strerror(errno);
		return ret;
	}
	m_clients.clear();
	ret.success = true;
	return ret;
}
#endif
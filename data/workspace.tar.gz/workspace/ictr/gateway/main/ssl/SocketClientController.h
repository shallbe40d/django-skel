#ifndef _SOCKET_CLIENT_CONTROLLER_H
#define _SOCKET_CLIENT_CONTROLLER_H

#include "base/CommunicationBase.h"

#include <thread>
#include <string>
#include <list>

class CSocketClientController : public CCommunicationBase
{
public:
	CSocketClientController();
	~CSocketClientController();

	void Init(std::string ip, int port);

	int Start();

	size_t Write(const char* msg, const int size, const char *tag = NULL);

protected:
	const char* TAG = "SCKCLI";

private:
	int mSocketFd;
	std::string mServerIp;
	int mPort;

	const int SOCKET_CONNECTION_RETRY_INTERVAL = 3;
	const int MAX_PACKET_SIZE = 1024;

	bool mIsConnected, mIsStart;
	std::thread *mConnectionThread, *mReadThread;
	void ConnectionThread();
	void ReadThread();
};
#endif

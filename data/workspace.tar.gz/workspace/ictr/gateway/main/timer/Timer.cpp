#include "Timer.h"

#include <signal.h>

#include "mq/MessageQueue.h"
#include "log/Log.h"

CTimer* CTimer::instance = nullptr;
void TimerHandler(int sig, siginfo_t* si, void *uc);

CTimer::CTimer()
{
}

CTimer::~CTimer()
{
}

void CTimer::AddTimer(TIMER_ID id, const char *name)
{
	CTimerInfo *timer = new CTimerInfo(id, name);

	mTimerList.insert(std::make_pair(id, timer));
}

void TimerHandler(int sig, siginfo_t* si, void *uc)
{
	CTimerInfo *info = (CTimerInfo *)si->si_value.sival_ptr;

#if 0
	int overrun = timer_getoverrun(*info->GetTimer());
	LOGD("TIMERH", "Overrun: %d", overrun);
#endif

	MessageQueue::GetInstance()->SendMessage(MODULE_SYSTEM, info->GetSender(), CMD_TIMER_EXPIRED, NULL, info->GetTimerId());
}

void CTimer::SetTimer(MODULE_TYPE sender, TIMER_ID id, const int sec, const int msec)
{
	const int SIGNAL_NO = SIGRTMIN;
	struct sigevent te;
	struct itimerspec its;
	sigset_t mask;
	struct sigaction sa;

	std::map<TIMER_ID, CTimerInfo *>::iterator it;
	it = mTimerList.find(id);

	if (it != mTimerList.end())
	{
		CTimerInfo *info = it->second;
		info->SetSender(sender);

		/* Establish handler for timer signal */
		sa.sa_flags = SA_SIGINFO;
		sa.sa_sigaction = TimerHandler;
		sigemptyset(&sa.sa_mask);
		if (sigaction(SIGNAL_NO, &sa, NULL) == -1)
		{
			LOGE(TAG, "sigaction error\n");
			return;
		}

		/* Block timer signal temporarily */
		sigemptyset(&mask);
		sigaddset(&mask, SIGNAL_NO);
		if (sigprocmask(SIG_SETMASK, &mask, NULL) == -1)
		{
			LOGE(TAG, "sigprocmask error\n");
			return;
		}

		/* Create the timer */
		te.sigev_notify = SIGEV_SIGNAL;
		te.sigev_signo = SIGNAL_NO;
		te.sigev_value.sival_ptr = it->second;
		//te.sigev_value.sival_int = id;

		if (timer_create(CLOCK_MONOTONIC, &te, info->GetTimer()) == -1)
		{
			LOGE(TAG, "timer_create error\n");
			return;
		}

		/* Start the timer */
		its.it_interval.tv_sec = sec;
		its.it_interval.tv_nsec = msec * 1000000;
		its.it_value.tv_sec = sec;
		its.it_value.tv_nsec = msec * 1000000;

		if (timer_settime(*info->GetTimer(), 0, &its, NULL) == -1)
		{
			LOGE(TAG, "timer_settime error\n");
			return;
		}
		LOGD(TAG, "Start: %s, sec: %d, msec: %d", info->GetTimerName().c_str(), sec, msec);
#if 0
		/* Unlock the timer signal, so that timer notification can be delivered */
		if (sigprocmask(SIG_UNBLOCK, &mask, NULL) == -1)
		{
			LOGE(TAG, "sigprocmask error\n");
			return;
		}
#endif
	}
}

void CTimer::StopTimer(TIMER_ID id)
{
	std::map<TIMER_ID, CTimerInfo *>::iterator it;
	it = mTimerList.find(id);

	if (it != mTimerList.end())
	{
		CTimerInfo *info = it->second;
		LOGD(TAG, "Stop: %s", info->GetTimerName().c_str());
		timer_delete(*(info->GetTimer()));
	}
}
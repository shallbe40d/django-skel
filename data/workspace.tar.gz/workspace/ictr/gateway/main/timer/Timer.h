#include <map>
#include <string>

#include "common/MessageDefine.h"
#include "common/MessageListener.h"

class CTimerInfo
{
public:
	CTimerInfo(TIMER_ID id, std::string name)
	{
		//printf("constructor\n");
		mTimerId = id;
		mTimerName = name;
		mIsSet = false;
	}
	~CTimerInfo()
	{
		//printf("destructor\n");
	}

	void SetSender(MODULE_TYPE sender) { mSender = sender; }
	MODULE_TYPE GetSender() { return mSender; }

	TIMER_ID GetTimerId() { return mTimerId; }
	std::string GetTimerName() { return mTimerName; }
	timer_t *GetTimer() { return &mTimer; }

private:
	TIMER_ID mTimerId;
	MODULE_TYPE mSender;
	std::string mTimerName;
	timer_t mTimer;
	bool mIsSet;
};

class CTimer
{
public:
	static CTimer* GetInstance()
	{
		if (instance == nullptr)
		{
			instance = new CTimer();
		}

		return instance;
	}

	void AddTimer(TIMER_ID id, const char *name);
	void SetTimer(MODULE_TYPE sender, TIMER_ID id, const int sec, const int msec);
	void StopTimer(TIMER_ID id);

private:
	const char *TAG = "TIMER";

	static CTimer* instance;

	CTimer();
	~CTimer();

	std::map<TIMER_ID, CTimerInfo *> mTimerList;

	std::string GetTimerName(TIMER_ID id);
};
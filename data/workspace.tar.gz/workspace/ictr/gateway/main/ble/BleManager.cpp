#include "BleManager.h"

#include "mq/MessageQueue.h"
#include "timer/Timer.h"
#include "util/Util.h"

CBleManager::CBleManager()
{
	mCurrentProtocol = BLE_PROTOCOL_NONE;
	mRetransmissionBuffer = NULL;
	mRetransmissionBufferSize = 0;
	mRetransmissionCount = 0;
}

CBleManager::~CBleManager()
{
}

void CBleManager::Init(CCommunicationBase *channel)
{
	CTimer::GetInstance()->AddTimer(TIMER_BLE_RETRY, "TIMER_BLE_RETRY");

	mTransmitChannel = channel;
	mTransmitChannel->RegisterListener(this);

	MessageQueue::GetInstance()->RegisterListener(MODULE_BLE, this);

	mReadDataWorker = new std::thread([&]() { ThreadReadDataWorker(); });
}

void CBleManager::Write(const BLE_PROTOCOL_TYPE type, const void *data, const int size)
{
	PrintPacket(TAG, "[WR]", (char *)data, size);

	if (mCurrentProtocol != type)
	{
		mRetransmissionCount = 0;
	}
	mCurrentProtocol = type;

	if (mRetransmissionCount == 0)
	{
		if (mRetransmissionBuffer != NULL)
		{
			LOGD(TAG, "Free mRetransmissionBuffer: %p", mRetransmissionBuffer);
			free(mRetransmissionBuffer);
			mRetransmissionBuffer = NULL;
		}

		mRetransmissionBuffer = (uint8_t *)malloc(sizeof(uint8_t) * size);
		mRetransmissionBufferSize = size;
		memcpy(mRetransmissionBuffer, data, size);
		LOGD(TAG, "mRetransmissionBuffer copied");
	}

	int retryWaitTime = 0;

	switch(type)
	{
	case BLE_PROTOCOL_OPEN_WIFI:
		retryWaitTime = 7;
		break;
#if 0
	case BLE_PROTOCOL_REQUEST_PAIRING:
		retryWaitTime = 4;
		break;
#endif
	default:
		retryWaitTime = 4;
		break;
	}

	LOGD(TAG, "Retry Wait Time: %d", retryWaitTime);
	CTimer::GetInstance()->SetTimer(MODULE_BLE, TIMER_BLE_RETRY, retryWaitTime, 0);

	//if (type != BLE_PROTOCOL_REQUEST_TIME_SYNC)
	{
	mTransmitChannel->Write((char *)data, size);
	}
}

void CBleManager::Read(const void *data, const unsigned int size)
{
	PrintPacket(TAG, "[RD]", (char *)data, size);

	const int DisconnetRetryTimeDiff = 1500;
	const char disconnect[12] = { 0x44, 0x49, 0x53, 0x43, 0x4F, 0x4E, 0x4E, 0x45, 0x43, 0x54, 0x0D, 0x0A };

	uint8_t * packet = (uint8_t *)data;

	unsigned int curPos = 0;

	while (curPos < size)
	{
		// 처음 시작하는 0x00을 제거
		if (*(packet + curPos) == 0x00)
		{
			curPos++;
			continue;
		}

		if (memcmp(packet + curPos, disconnect, 12) == 0)
		{
			struct timespec tsNow;
			clock_gettime(CLOCK_REALTIME, &tsNow);

			int diff = (tsNow.tv_sec - mPairedTime.tv_sec) * 1000 + (tsNow.tv_nsec - mPairedTime.tv_nsec) / (1000 * 1000);

			LOGD(TAG, "DISCONNECT: mPairedTime: %d.%09d, Now: %d.%09d, TimeDiff: %d (ms)", mPairedTime.tv_sec, mPairedTime.tv_nsec, tsNow.tv_sec, tsNow.tv_nsec, diff);

			if (diff < DisconnetRetryTimeDiff)
			{
				// 재시도
				CTimer::GetInstance()->StopTimer(TIMER_BLE_RETRY);
				SendCmdDisconnectPairing(NULL, 0);
			}
			else if (mStatePairing == BLE_STATE_PAIRED)
			{
				mStatePairing = BLE_STATE_DISCONNECTED;
			}
			curPos += 12;
			continue;
		}
		BLE_PROTOCOL_HEADER* header;
		header = (BLE_PROTOCOL_HEADER*)(packet + curPos);

		unsigned int length = (int)ConvertEndian2(header->length);
		int bufSize = sizeof(BLE_PROTOCOL_HEADER);
		length > 0 ? bufSize += length + 2 : bufSize += length + 1;
		// printf("header: %d length:%d buf:%d\n", sizeof(BLE_PROTOCOL_HEADER), length, bufSize);

		if (length > (size - curPos))
		{
			LOGE(TAG, "Serial Data Read Error");
			break;
		}
		uint8_t* subData = new uint8_t[bufSize];
		memcpy(subData, packet + curPos, bufSize);

		mReadDataQueue.push_back(subData);

		curPos += bufSize;
	}
}

void CBleManager::MessageHandler(MODULE_TYPE sender, COMMAND_TYPE cmd, void *data, int size)
{
	switch(cmd)
	{
	case CMD_GET_MAC_ADDRESS:
		{
			LOGD(TAG, "CMD_GET_MAC_ADDRESS");
			this->mMessageSender = sender;
			CmdGetMacAddress(data, size);
		}
		break;
	case CMD_REQUEST_CONNECT_DEVICE:
		{
			LOGD(TAG, "CMD_REQUEST_CONNECT_DEVICE");
			this->mMessageSender = sender;
			memcpy(mPairedDeviceInfo.ble, data, IOT_SENSOR_BLE_MAC_ADDRESS_LENGTH);
			mRetryPairingCount = 0;
			SendCmdRequestSensorDevicePairing(data, size);
		}
		break;
	case CMD_REQUEST_TIME_SYNC:
		{
			LOGD(TAG, "CMD_REQUEST_TIME_SYNC");
			this->mMessageSender = sender;
			SendCmdRequestTimeSync(data, size);
		}
		break;
	case CMD_REQUEST_DISCONNECT_DEVICE:
		{
			LOGD(TAG, "CMD_REQUEST_DISCONNECT_DEVICE");
			this->mMessageSender = sender;
			SendCmdDisconnectPairing(NULL, 0);
		}
		break;
	case CMD_GET_DEVICE_INFO:
		{
			LOGD(TAG, "CMD_GET_DEVICE_INFO");
			this->mMessageSender = sender;
			SendCmdReadSensorInfo(NULL, 0);
		}
		break;
	case CMD_GET_DEVICE_NAME:
		{
			LOGD(TAG, "CMD_GET_DEVICE_NAME");
			this->mMessageSender = sender;
			SendCmdReadDeviceName(NULL, 0);
		}
		break;
	case CMD_GET_FILE_LIST:
		{
			LOGD(TAG, "CMD_GET_FILE_LIST");
			this->mMessageSender = sender;
			SendCmdReadFileInfo(NULL, 0);
		}
		break;
	case CMD_OPEN_WIFI:
		{
			LOGD(TAG, "CMD_OPEN_WIFI");
			this->mMessageSender = sender;
			SendCmdOpenWifi(data, size);
		}
		break;
	case CMD_DOWNLOAD_FILE:
		{
			LOGD(TAG, "");
			this->mMessageSender = sender;
			SendCmdSendFile(data, size);
		}
		break;
	case CMD_SET_MEASUREMENT_CONFIG:
		{
			LOGD(TAG, "CMD_SET_MEASUREMENT_CONFIG Request!");
			this->mMessageSender = sender;
			SendCmdSetMeasurementConfig(data, size);
		}
		break;
	case CMD_RESET_SENSOR_INFO:
		{
			LOGD(TAG, "CMD_RESET_SENSOR_INFO");
			SendCmdResetSensorInfo(data, size);
		}
		break;
	case CMD_TIMER_EXPIRED:
		{
			LOGD(TAG, "CMD_TIMER_EXPIRED");
			CmdTimerExpired(data, size);
		}
		break;
	default:
		{
			CBase::MessageHandler(sender, cmd, data, size);
		}
	}
}

void CBleManager::SendInternalMessage(MODULE_TYPE receiver, COMMAND_TYPE cmd, void *data, int size)
{
	MessageQueue::GetInstance()->SendMessage(MODULE_WIFI, receiver, cmd, data, size);
}

void CBleManager::ThreadReadDataWorker()
{
	uint8_t* data;
	int length;

	while (1)
	{
		data = mReadDataQueue.front();

		BLE_PROTOCOL_HEADER* header;
		header = (BLE_PROTOCOL_HEADER*)data;
		length = ConvertEndian2(header->length);

		switch(header->opcode)
		{
		case BLE_PROTOCOL_SET_DEVICE_NAME_RESPONSE:	// 0x01
			RecvRespSetDeviceName(data + sizeof(BLE_PROTOCOL_HEADER), length);
			break;
		case BLE_PROTOCOL_OPEN_WIFI_RESPONSE:	// 0x02
			RecvRespOpenWifi(data + sizeof(BLE_PROTOCOL_HEADER), length);
			break;
		case  BLE_PROTOCOL_SET_MEASUREMENT_CONFIG_RESPONSE:	// 0x03
			RecvRespSetMeasurementConfig(data + sizeof(BLE_PROTOCOL_HEADER), length);
			break;
		case BLE_PROTOCOL_READ_FILE_INFO_RESPONSE:	// 0x05
			RecvRespReadFileInfo(data + sizeof(BLE_PROTOCOL_HEADER), length);
			break;
		case BLE_PROTOCOL_SEND_FILE_RESPONSE:	// 0x06
			RecvRespSendFile(data + sizeof(BLE_PROTOCOL_HEADER), length);
			break;
		case BLE_PROTOCOL_RESET_SENSOR_INFO_RESPONSE:	// 0x08
			RecvRespResetSensorInfo(data + sizeof(BLE_PROTOCOL_HEADER), length);
			break;
		case BLE_PROTOCOL_READ_SENSOR_INFO_RESPONSE:	//0x0A
			RecvRespReadSensorInfo(data + sizeof(BLE_PROTOCOL_HEADER), length);
			break;
		case BLE_PROTOCOL_READ_DEV_FIRMWARE_VERSION_RESPONSE:	// 0x0E
			RecvRespReadDeviceFirmwareVersion(data + sizeof(BLE_PROTOCOL_HEADER), length);
			break;
		case BLE_PROTOCOL_READ_MAC_ADDR_RESPONSE:	//0x10
			RecvRespRequestModuleMacAddr(data + sizeof(BLE_PROTOCOL_HEADER), length);
			break;
		case BLE_PROTOCOL_WRITE_FIRMWARE_VERSION_RESPONSE:	// 0x11
			break;
		case BLE_PROTOCOL_WRITE_HARDWARE_VERSION_RESPONSE:	// 0x12
			break;
#if 0
		case BLE_PROTOCOL_START_SCAN_RESPONSE:	// 0x20
			RecvRespStartScan(data + sizeof(BLE_PROTOCOL_HEADER), length);
			break;
		case BLE_PROTOCOL_START_SCAN_PAIRING_COMPLETE:	 // 0x22
			RecvRespStartScanPairingComplete(data + sizeof(BLE_PROTOCOL_HEADER), length);
			break;
		case BLE_PROTOCOL_STOP_SCAN_RESPONSE:	// 0x23
			RecvRespStopScan(data + sizeof(BLE_PROTOCOL_HEADER), length);
			break;
#endif
		case BLE_PROTOCOL_REQUEST_PAIRING_RESPONSE:	// 0x2A
			RecvRespRequestSensorDevicePairing(data + sizeof(BLE_PROTOCOL_HEADER), length);
			break;
		case BLE_PROTOCOL_REQUEST_PAIRING_COMPLETE:	// 0x2B
			RecvRespRequestSensorDevicePairingComplete(data + sizeof(BLE_PROTOCOL_HEADER), length);
			break;
		case BLE_PROTOCOL_REQUEST_TIME_SYNC_RESPONSE:	// 0x2C
			RecvRespRequestTimeSync(data + sizeof(BLE_PROTOCOL_HEADER), length);
			break;
		case BLE_PROTOCOL_DISCONNECT_PAIRING_RESPONSE:	//0x2D
			RecvRespDisconnectPairing(data + sizeof(BLE_PROTOCOL_HEADER), length);
			break;
#if 0
		case BLE_PROTOCOL_REQUEST_VALIDATION_RESPONSE:	// 0x2F
			RecvRespRequestValidation(data + sizeof(BLE_PROTOCOL_HEADER), length);
			break;
#endif
		case BLE_PROTOCOL_READ_DEVICE_NAME_RESPONSE:	// 0x2F
			RecvRespReadDeviceName(data + sizeof(BLE_PROTOCOL_HEADER), length);
			break;
		default :
			LOGD(TAG, "Unknown Protocol: 0x%02X", header->opcode);
			break;
		}
	}
}

int CBleManager::FillData(uint8_t **buf, BLE_PROTOCOL_TYPE opcode, void *data, int size)
{
	int bufSize = sizeof(BLE_PROTOCOL_HEADER) + size;
	size > 0 ? bufSize += 2 : bufSize += 1;

	LOGD(TAG, "data: %p, size: %d, packet: %d", data, size, bufSize);

	*buf = new uint8_t[bufSize];

	BLE_PROTOCOL_HEADER *header = (BLE_PROTOCOL_HEADER *)*buf;

	header->preamble = 0xAA;
	header->delimiter1 = 0x2C;
	header->length = ((size & 0xFF00) >> 8) | ((size & 0x00FF) << 8);
	header->delimiter2 = 0x2C;
	header->opcode = opcode;
	header->delimiter3 = 0x2C;

	if (size > 0)
	{
		memcpy(*buf + sizeof(BLE_PROTOCOL_HEADER), data, size);
	}

	(*buf)[bufSize - 2] = 0x2C;
	(*buf)[bufSize - 1] = checksum(*buf, bufSize);

	return bufSize;
}

void CBleManager::CmdTimerExpired(void *data, int size)
{
	switch(size)
	{
	case TIMER_BLE_RETRY:
		{
			CTimer::GetInstance()->StopTimer(TIMER_BLE_RETRY);
			mRetransmissionCount++;
			LOGD(TAG, "[Retransmission] Protocol: %d, Count = %d", mCurrentProtocol, mRetransmissionCount);

			if (mRetransmissionCount > MAX_RETRANSMISSION)
			{
				mRetransmissionCount = 0;
				if (mRetransmissionBuffer != NULL)
				{
					free(mRetransmissionBuffer);
					mRetransmissionBuffer = NULL;
				}
				mRetransmissionBufferSize = 0;
				LOGD(TAG, "Not Retransmit");
				return;
			}

			switch(mCurrentProtocol)
			{
#if 0
			case BLE_PROTOCOL_START_SCAN:
				retryCountPairing++;
				LOGD(TAG, "Retry: BLE_PROTOCOL_START_SCAN: %d Retry", retryCountPairing);
				SendCmdStopScan(NULL, 0);
				break;
#endif
			case BLE_PROTOCOL_REQUEST_PAIRING:
				LOGD(TAG, "[Retransmission] BLE_PROTOCOL_REQUEST_PAIRING -> BLE_PROTOCOL_DISCONNECT_PAIRING");
				SendCmdDisconnectPairing(NULL, 0);
				break;
			case BLE_PROTOCOL_REQUEST_TIME_SYNC:
				LOGD(TAG, "Retry: BLE_PROTOCOL_REQUEST_TIME_SYNC");
				SendCmdRequestTimeSync(&mTargetTime, sizeof(struct timespec));
				break;
			default:
				Write(mCurrentProtocol, mRetransmissionBuffer, mRetransmissionBufferSize);
				break;
			}
		}
		break;
	default:
		{
		}
		break;
	}
}

// ****************************************
// Scan
// ****************************************
#if 0
void CBleManager::SendCmdStartScan(void *data, int size) // 6.1-1, size: 0
{
	uint8_t *packet;
	int length;

	length = FillData(&packet, BLE_PROTOCOL_START_SCAN, data, size);

	Write(BLE_PROTOCOL_START_SCAN, packet, length);

	mStatePairing = BLE_STATE_START_PAIRING;
	delete(packet);
}

void CBleManager::RecvRespStartScan(void* data, int size)
{
	LOGD(TAG, "FUNC_IN");
	PrintPacket(TAG, "PARAM", (char *)data, size);
}

void CBleManager::RecvRespStartScanPairingComplete(void* data, int size)
{
	LOGD(TAG, "FUNC_IN");
	PrintPacket(TAG, "PARAM", (char *)data, size);
	if (mCurrentProtocol == BLE_PROTOCOL_START_SCAN)
	{
		CTimer::GetInstance()->StopTimer(TIMER_BLE_RETRY);
	}
	else
	{
		LOGD(TAG, "Not waited protocol");
	}
	memcpy(macPairedDevice, data, 6);
	mStatePairing = BLE_STATE_PAIRED;
	MessageQueue::GetInstance()->SendMessage(MODULE_BLE, mMessageSender, CMD_REQUEST_START_SCAN_RESPONSE, NULL, 0);
}

void CBleManager::SendCmdRequestValidation(void *data, int size) // 6.1-4, size: 1
{
	uint8_t *packet;
	int length;

	if (data == NULL)
	{
		uint8_t buf[2 + IOT_SENSOR_BLE_MAC_ADDRESS_LENGTH];
		buf[0] = 0x02;	// Gateway
		buf[1] = 0x2C;	// delimiter
		memcpy(buf + 2, mMacModule, IOT_SENSOR_BLE_MAC_ADDRESS_LENGTH);
		LOGD(TAG, "%02X%02X%02X%02X%02X%02X", mMacModule[0], mMacModule[1], mMacModule[2], mMacModule[3], mMacModule[4], mMacModule[5]);

		length = FillData(&packet, BLE_PROTOCOL_REQUEST_VALIDATION, buf, 2 + IOT_SENSOR_BLE_MAC_ADDRESS_LENGTH);
	}
	else
	{
		length = FillData(&packet, BLE_PROTOCOL_REQUEST_VALIDATION, data, size);
	}

	Write(BLE_PROTOCOL_REQUEST_VALIDATION, packet, length);

	delete(packet);
}

void CBleManager::RecvRespRequestValidation(void* data, int size)
{
	LOGD(TAG, "FUNC_IN");
	PrintPacket(TAG, "PARAM", (char *)data, size);

	if (mCurrentProtocol == BLE_PROTOCOL_REQUEST_VALIDATION)
	{
		CTimer::GetInstance()->StopTimer(TIMER_BLE_RETRY);
	}
	else
	{
		LOGD(TAG, "Not waited protocol");
	}

	MessageQueue::GetInstance()->SendMessage(MODULE_BLE, mMessageSender, CMD_REQUEST_VALIDATION_RESPONSE, macPairedDevice.ble, IOT_SENSOR_BLE_MAC_ADDRESS_LENGTH);

	// validation이 완료되면 자동으로 pairing이 끊어진다
	memset(macPairedDevice, 0x00, IOT_SENSOR_BLE_MAC_ADDRESS_LENGTH);
}

void CBleManager::SendCmdStopScan(void *data, int size) // 6.1-6, size: 0
{
	uint8_t *packet;
	int length;

	length = FillData(&packet, BLE_PROTOCOL_STOP_SCAN, data, size);

	Write(BLE_PROTOCOL_STOP_SCAN, packet, length);

	delete(packet);
}

void CBleManager::RecvRespStopScan(void* data, int size)
{
	LOGD(TAG, "FUNC_IN");
	PrintPacket(TAG, "PARAM", (char *)data, size);

	if (mCurrentProtocol == BLE_PROTOCOL_STOP_SCAN)
	{
		CTimer::GetInstance()->StopTimer(TIMER_BLE_RETRY);
	}
	else
	{
		LOGD(TAG, "Not waited protocol");
	}

	LOGD(TAG, "mStatePairing: %s", mStatePairing == BLE_STATE_START_PAIRING ? "BLE_STATE_START_PAIRING" : (mStatePairing == BLE_STATE_PAIRED ? "BLE_STATE_PAIRED" : "BLE_STATE_DISCONNECTED"));
	if (mStatePairing == BLE_STATE_START_PAIRING)
	{
		if (retryCountPairing < 2)
		{
			SendCmdStartScan(NULL, 0);
		}
		else
		{
			mStatePairing = BLE_STATE_DISCONNECTED;
			retryCountPairing = 0;
		}
	}
	else
	{
		mStatePairing = BLE_STATE_DISCONNECTED;
		MessageQueue::GetInstance()->SendMessage(MODULE_BLE, mMessageSender, CMD_REQUEST_STOP_SCAN_RESPONSE, NULL, 0);
	}
}
#endif

// ****************************************
// Pairing
// ****************************************
void CBleManager::SendCmdRequestSensorDevicePairing(void *data, int size)
{
	uint8_t *packet;
	int length;

	length = FillData(&packet, BLE_PROTOCOL_REQUEST_PAIRING, data, size);

	Write(BLE_PROTOCOL_REQUEST_PAIRING, packet, length);

	mStatePairing = BLE_STATE_START_PAIRING;
	delete(packet);
}

void CBleManager::RecvRespRequestSensorDevicePairing(void* data, int size)
{
	LOGD(TAG, "FUNC_IN");
	PrintPacket(TAG, "PARAM", (char *)data, size);

	clock_gettime(CLOCK_REALTIME, &mPairedTime);
}

void CBleManager::RecvRespRequestSensorDevicePairingComplete(void* data, int size)
{
	LOGD(TAG, "FUNC_IN");
	PrintPacket(TAG, "PARAM", (char *)data, size);

	if (mCurrentProtocol == BLE_PROTOCOL_REQUEST_PAIRING)
	{
		CTimer::GetInstance()->StopTimer(TIMER_BLE_RETRY);
	}
	else
	{
		LOGD(TAG, "Not waited protocol");
	}
	memcpy(mPairedDeviceInfo.ble, data, 6);
	mStatePairing = BLE_STATE_PAIRED;
	usleep(100 * 1000);
	MessageQueue::GetInstance()->SendMessage(MODULE_BLE, mMessageSender, CMD_REQUEST_CONNECT_DEVICE_RESPONSE, NULL, 0);
}

void CBleManager::SendCmdDisconnectPairing(void *data, int size)
{
	uint8_t *packet;
	int length;

	length = FillData(&packet, BLE_PROTOCOL_DISCONNECT_PAIRING, data, size);

	Write(BLE_PROTOCOL_DISCONNECT_PAIRING, packet, length);

	delete(packet);
}

void CBleManager::RecvRespDisconnectPairing(void* data, int size)
{
	LOGD(TAG, "FUNC_IN");
	PrintPacket(TAG, "PARAM", (char *)data, size);

	if (mCurrentProtocol == BLE_PROTOCOL_DISCONNECT_PAIRING)
	{
		CTimer::GetInstance()->StopTimer(TIMER_BLE_RETRY);
	}
	else
	{
		LOGD(TAG, "Not waited protocol");
	}

	//LOGD(TAG, "mStatePairing: %s", mStatePairing == BLE_STATE_START_PAIRING ? "BLE_STATE_START_PAIRING" : (mStatePairing == BLE_STATE_PAIRED ? "BLE_STATE_PAIRED" : "BLE_STATE_DISCONNECTED"));
	if (mStatePairing == BLE_STATE_START_PAIRING)
	{
		LOGD(TAG, "mRetryPairingCount: %d / %d", mRetryPairingCount, MAX_RETRY_PAIRING);
		if (mRetryPairingCount < MAX_RETRY_PAIRING)
		{
			mRetryPairingCount++;
			SendCmdRequestSensorDevicePairing(mPairedDeviceInfo.ble, IOT_SENSOR_BLE_MAC_ADDRESS_LENGTH);
		}
		else
		{
			mStatePairing = BLE_STATE_DISCONNECTED;
			mRetryPairingCount = 0;
		}
	}
	else
	{
		mStatePairing = BLE_STATE_DISCONNECTED;
		MessageQueue::GetInstance()->SendMessage(MODULE_BLE, mMessageSender, CMD_REQUEST_DISCONNECT_DEVICE_RESPONSE, NULL, 0);
	}
}

// ****************************************
// Measurement
// ****************************************
void CBleManager::SendCmdSetMeasurementConfig(void *data, int size) // 5.5.04, size: 22
{
	uint8_t *packet;
	int length;

	struct MeasurementDataFileInfo *info = (struct MeasurementDataFileInfo *)data;
	struct timespec tsNow;
	struct tm tmNow;

	clock_gettime(CLOCK_REALTIME, &tsNow);
	localtime_r((time_t *)&tsNow.tv_sec, &tmNow);

	BLE_MEASUREMENT_CONFIG measurementConfig;
	measurementConfig.date[0] = ConvertIntToBcd(tmNow.tm_year - 100);
	measurementConfig.date[1] = ConvertIntToBcd(tmNow.tm_mon+1);
	measurementConfig.date[2] = ConvertIntToBcd(tmNow.tm_mday);
	measurementConfig.date[3] = ConvertIntToBcd(tmNow.tm_wday == 0 ? 7 : tmNow.tm_wday);
	measurementConfig.delimiter1 = 0x2C;
	measurementConfig.time[0] = ConvertIntToBcd(tmNow.tm_hour);
	measurementConfig.time[1] = ConvertIntToBcd(tmNow.tm_min);
	measurementConfig.time[2] = ConvertIntToBcd(tmNow.tm_sec);
	measurementConfig.delimiter2 = 0x2C;
	measurementConfig.storage_interval = 0x00;
	measurementConfig.delimiter3 = 0x2C;
	measurementConfig.storage_time[0] = 0x00;
	measurementConfig.storage_time[1] = 0x00;
	measurementConfig.storage_time[2] = 0x00;
	measurementConfig.delimiter4 = 0x2C;
	measurementConfig.measurement_time[0] = ConvertIntToBcd(info->measurement_time / 60);
	measurementConfig.measurement_time[1] = ConvertIntToBcd(info->measurement_time % 60);
	measurementConfig.delimiter5 = 0x2C;
	measurementConfig.sample_rate = ConvertEndian2(info->sample_rate);
	measurementConfig.delimiter6 = 0x2C;
	measurementConfig.sensor_option = 0x00;

	length = FillData(&packet, BLE_PROTOCOL_SET_MEASUREMENT_CONFIG, &measurementConfig, sizeof(measurementConfig));

	Write(BLE_PROTOCOL_SET_MEASUREMENT_CONFIG, packet, length);

	delete(packet);
}

void CBleManager::RecvRespSetMeasurementConfig(void* data, int size)
{
	LOGD(TAG, "FUNC_IN");
	PrintPacket(TAG, "PARAM", (char *)data, size);

	//isSuccessFirstCmd = true;

	if (mCurrentProtocol == BLE_PROTOCOL_SET_MEASUREMENT_CONFIG)
	{
		CTimer::GetInstance()->StopTimer(TIMER_BLE_RETRY);
	}
	else
	{
		LOGD(TAG, "Not waited protocol");
	}

	MessageQueue::GetInstance()->SendMessage(MODULE_BLE, mMessageSender, CMD_SET_MEASUREMENT_CONFIG_RESPONSE, NULL, 0);
}

void CBleManager::SendCmdReadSensorInfo(void *data, int size) // 5.5.03, size: 0
{
	uint8_t *packet;
	int length;

	length = FillData(&packet, BLE_PROTOCOL_READ_SENSOR_INFO, data, size);

	Write(BLE_PROTOCOL_READ_SENSOR_INFO, packet, length);

	delete(packet);
}

void CBleManager::RecvRespReadSensorInfo(void* data, int size)
{
	LOGD(TAG, "FUNC_IN");
	PrintPacket(TAG, "PARAM", (char *)data, size);

	if (size == sizeof(BLE_SENSOR_INFO))
	{
		BLE_SENSOR_INFO *sensorInfo;
		sensorInfo = (BLE_SENSOR_INFO *)data;
		LOGD(TAG, "battery: %.1f", ConvertBcdToInt(sensorInfo->battery) / 10.0);
		LOGD(TAG, "Date: %02d-%02d-%02d (%d)", ConvertBcdToInt(sensorInfo->date[0]), ConvertBcdToInt(sensorInfo->date[1]), ConvertBcdToInt(sensorInfo->date[2]), ConvertBcdToInt(sensorInfo->date[3]));
		LOGD(TAG, "Time: %02d:%02d:%02d", ConvertBcdToInt(sensorInfo->time[0]), ConvertBcdToInt(sensorInfo->time[1]), ConvertBcdToInt(sensorInfo->time[2]));
		LOGD(TAG, "Storage Interval: %s", sensorInfo->storage_interval == 0x00 ? "NULL" : sensorInfo->storage_interval == 0x01 ? "1 Day" : sensorInfo->storage_interval == 0x02 ? "1 Week" : sensorInfo->storage_interval == 0x03 ?"1 Month" : "ERROR");
		LOGD(TAG, "Storage Time: %02d:%02d:%02d", ConvertBcdToInt(sensorInfo->storage_time[0]), ConvertBcdToInt(sensorInfo->storage_time[1]), ConvertBcdToInt(sensorInfo->storage_time[2]));
		LOGD(TAG, "Measurement Time: %02d:%02d", ConvertBcdToInt(sensorInfo->measurement_time[0]), ConvertBcdToInt(sensorInfo->measurement_time[1]));
		LOGD(TAG, "Sample Rate: %d", ConvertEndian2(sensorInfo->sample_rate));
		LOGD(TAG, "Sensor Option: %x", sensorInfo->sensor_option);
		LOGD(TAG, "Flash Max Size: %d", ConvertEndian4(sensorInfo->flash_max_size));
		LOGD(TAG, "Flash Current Size: %d", ConvertEndian4(sensorInfo->flash_current_size));
		LOGD(TAG, "Pairing Status: %x", sensorInfo->pairing_status);
		LOGD(TAG, "Threshold Setting: %x", sensorInfo->threshold_setting);

		mPairedDeviceInfo.battery = ConvertBcdToInt(sensorInfo->battery);
		mPairedDeviceInfo.measurement_time[0] = ConvertBcdToInt(sensorInfo->measurement_time[0]);
		mPairedDeviceInfo.measurement_time[1] = ConvertBcdToInt(sensorInfo->measurement_time[1]);
		mPairedDeviceInfo.sample_rate = ConvertEndian2(sensorInfo->sample_rate);
	}

	if (size == 1 && ((uint8_t *)data)[0] == 0x01)
	{
		if (mCurrentProtocol == BLE_PROTOCOL_READ_SENSOR_INFO)
		{
			CTimer::GetInstance()->StopTimer(TIMER_BLE_RETRY);
		}
		else
		{
			LOGD(TAG, "Not waited protocol");
		}

		LOGD(TAG, "Battery: %d, Measurement Time: %02d:%02d, Sampling Rate: %d", mPairedDeviceInfo.battery, mPairedDeviceInfo.measurement_time[0], mPairedDeviceInfo.measurement_time[1], mPairedDeviceInfo.sample_rate);
		MessageQueue::GetInstance()->SendMessage(MODULE_BLE, mMessageSender, CMD_GET_DEVICE_INFO_RESPONSE, &mPairedDeviceInfo, sizeof(struct IotSensorInfo));
	}
}

void CBleManager::SendCmdRequestTimeSync(void *data, int size) // 6.2.03, size: 7
{
	struct timespec *tsTargetTime = (struct timespec *)data;
	mTargetTime = *tsTargetTime;

	struct timespec tsCurrentTime;
	clock_gettime(CLOCK_REALTIME, &tsCurrentTime);

	int diff = (mTargetTime.tv_sec - tsCurrentTime.tv_sec) * 1000 + ((mTargetTime.tv_nsec - tsCurrentTime.tv_nsec) + (500 * 1000)) / (1000 * 1000);

	LOGD(TAG, "%d.%09d, %d.%09d, diff: %d", mTargetTime.tv_sec, mTargetTime.tv_nsec, tsCurrentTime.tv_sec, tsCurrentTime.tv_nsec, diff);

	struct tm tmTargetTime, tmCurrentTime;

	localtime_r(&mTargetTime.tv_sec, &tmTargetTime);
	localtime_r(&tsCurrentTime.tv_sec, &tmCurrentTime);

	LOGD(TAG, "TargetTime: %02d-%02d-%02d(%1d) %02d:%02d:%02d.%03d",
		tmTargetTime.tm_year - 100, tmTargetTime.tm_mon + 1, tmTargetTime.tm_mday, tmTargetTime.tm_wday == 0 ? 7 : tmTargetTime.tm_wday, tmTargetTime.tm_hour, tmTargetTime.tm_min, tmTargetTime.tm_sec, mTargetTime.tv_nsec / 1000000);
	LOGD(TAG, "   CurTime: %02d-%02d-%02d(%1d) %02d:%02d:%02d.%03d",
		tmCurrentTime.tm_year - 100, tmCurrentTime.tm_mon + 1, tmCurrentTime.tm_mday, tmCurrentTime.tm_wday == 0 ? 7 : tmCurrentTime.tm_wday, tmCurrentTime.tm_hour, tmCurrentTime.tm_min, tmCurrentTime.tm_sec, tsCurrentTime.tv_nsec / 1000000);
	LOGD(TAG, "      diff: %06d (%02d.%03d)", diff, diff / 1000, diff % 1000);
	if (diff < 0)
	{
		diff = 0;
		LOGD(TAG, "      diff: %06d (set to 0)", diff);
	}

	BLE_TIME_SYNC timeSyncData;

	timeSyncData.year = ConvertIntToBcd(tmCurrentTime.tm_year - 100);
	timeSyncData.month = ConvertIntToBcd(tmCurrentTime.tm_mon + 1);
	timeSyncData.day = ConvertIntToBcd(tmCurrentTime.tm_mday);
	timeSyncData.weekday = ConvertIntToBcd(tmCurrentTime.tm_wday == 0 ? 7 : tmCurrentTime.tm_wday);
	timeSyncData.hour = ConvertIntToBcd(tmCurrentTime.tm_hour);
	timeSyncData.minute = ConvertIntToBcd(tmCurrentTime.tm_min);
	timeSyncData.second = ConvertIntToBcd(tmCurrentTime.tm_sec);
	timeSyncData.delimiter = 0x2C;
	timeSyncData.delay = ConvertEndian4(diff);

	uint8_t *packet;
	int length;

	length = FillData(&packet, BLE_PROTOCOL_REQUEST_TIME_SYNC, (void*)&timeSyncData, sizeof(timeSyncData));

	Write(BLE_PROTOCOL_REQUEST_TIME_SYNC, packet, length);

	delete(packet);
}

void CBleManager::RecvRespRequestTimeSync(void* data, int size)
{
	LOGD(TAG, "FUNC_IN");
	PrintPacket(TAG, "PARAM", (char *)data, size);

	if (mCurrentProtocol == BLE_PROTOCOL_REQUEST_TIME_SYNC)
	{
		CTimer::GetInstance()->StopTimer(TIMER_BLE_RETRY);
	}
	else
	{
		LOGD(TAG, "Not waited protocol");
	}

	MessageQueue::GetInstance()->SendMessage(MODULE_BLE, mMessageSender, CMD_REQUEST_TIME_SYNC_RESPONSE, NULL, 0);
}

// ****************************************
// Sensor Data Download
// ****************************************
void CBleManager::SendCmdReadFileInfo(void *data, int size)
{
	uint8_t *packet;
	int length;

	length = FillData(&packet, BLE_PROTOCOL_READ_FILE_INFO, data, size);

	Write(BLE_PROTOCOL_READ_FILE_INFO, packet, length);

	delete(packet);
}

void CBleManager::RecvRespReadFileInfo(void* data, int size)
{
	LOGD(TAG, "FUNC_IN");
	PrintPacket(TAG, "PARAM", (char *)data, size);

	sprintf(mPairedDeviceInfo.data_info, "device/%02X%02X%02X%02X%02X%02X.flst", mPairedDeviceInfo.ble[0], mPairedDeviceInfo.ble[1], mPairedDeviceInfo.ble[2], mPairedDeviceInfo.ble[3], mPairedDeviceInfo.ble[4], mPairedDeviceInfo.ble[5]);
	LOGD(TAG, "List File: %s", mPairedDeviceInfo.data_info);

	if (size == 34)
	{
		BLE_FILE_INFO* fileInfo;
		fileInfo = (BLE_FILE_INFO*)data;
		LOGD(TAG, "File Index: %d/%d", ConvertEndian2(fileInfo->file_current_index), ConvertEndian2(fileInfo->file_total_index));
		LOGD(TAG, "File Size: %d", ConvertEndian4(fileInfo->file_size));
		LOGD(TAG, "File Date: %02d-%02d-%02d", ConvertBcdToInt(fileInfo->file_date[0]), ConvertBcdToInt(fileInfo->file_date[1]), ConvertBcdToInt(fileInfo->file_date[2]));
		LOGD(TAG, "File Time: %02d:%02d:%02d", ConvertBcdToInt(fileInfo->file_time[0]), ConvertBcdToInt(fileInfo->file_time[1]), ConvertBcdToInt(fileInfo->file_time[2]));
		LOGD(TAG, "Measuring Time: %02d:%02d", ConvertBcdToInt(fileInfo->measurement_time[0]), ConvertBcdToInt(fileInfo->measurement_time[1]));

		char name[13] = {0x00};
		strncpy(name, (char *)fileInfo->file_name, 12);
		LOGD(TAG, "File Name: %s", name);

		FILE *fpFileInfo = fopen(mPairedDeviceInfo.data_info, "a");

		if (fpFileInfo != NULL)
		{
			fprintf(fpFileInfo, "%d,%d,%c,%s\n", ConvertEndian2(fileInfo->file_current_index), ConvertEndian4(fileInfo->file_size), name[11], name);
			fclose(fpFileInfo);
		}
		else
		{
			LOGD(TAG, "File Open Error (fp is Null)");
		}
	}
	else if (size == 1 && ((uint8_t *)data)[0] == 0x01)
	{
		if (mCurrentProtocol == BLE_PROTOCOL_READ_FILE_INFO)
		{
			CTimer::GetInstance()->StopTimer(TIMER_BLE_RETRY);
		}
		else
		{
			LOGD(TAG, "Not waited protocol");
		}

		MessageQueue::GetInstance()->SendMessage(MODULE_BLE, mMessageSender, CMD_GET_FILE_LIST_RESPONSE, mPairedDeviceInfo.data_info, strlen(mPairedDeviceInfo.data_info));
	}
}

void CBleManager::SendCmdOpenWifi(void *data, int size)
{
	struct WifiApInfo *info = (struct WifiApInfo *)data;
	LOGD(TAG, "%02X %02X, SSID: %s[%d], Auth: %d, Pass: %s[%d], IP:%d.%d.%d.%d, Port: %d", info->control[0], info->control[1], info->ssid, strlen(info->ssid), info->auth_type, info->password, strlen(info->password), info->ip_address[0], info->ip_address[1], info->ip_address[2], info->ip_address[3], info->port);

	uint8_t *wifi;
	int len;
	if ((info->control[0] == 0x01) || (info->control[0] == 0x02))
	{
		len = sizeof(BLE_WIFI_CONFIG_FRONT) + strlen(info->ssid) + 1 + strlen(info->password) + 1 + sizeof(BLE_WIFI_CONFIG_REAR);

		wifi = (uint8_t *)malloc(sizeof(uint8_t) * len);

		BLE_WIFI_CONFIG_FRONT *front = (BLE_WIFI_CONFIG_FRONT *)wifi;
		front->status = info->control[0];
		front->delimiter1 = 0x2C;
		front->connection_type = info->control[1];
		front->delimiter2 = 0x2C;

		memcpy(wifi + sizeof(BLE_WIFI_CONFIG_FRONT), info->ssid, strlen(info->ssid));
		*(wifi + sizeof(BLE_WIFI_CONFIG_FRONT) + strlen(info->ssid)) = 0x2C;
		memcpy(wifi + sizeof(BLE_WIFI_CONFIG_FRONT) + strlen(info->ssid) + 1, info->password, strlen(info->password));
		*(wifi + sizeof(BLE_WIFI_CONFIG_FRONT) + strlen(info->ssid) + 1 + strlen(info->password)) = 0x2C;

		BLE_WIFI_CONFIG_REAR *rear = (BLE_WIFI_CONFIG_REAR *)(wifi + + sizeof(BLE_WIFI_CONFIG_FRONT) + strlen(info->ssid) + 1 + strlen(info->password) + 1);
		rear->server_ip[0] = info->ip_address[0];
		rear->server_ip[1] = info->ip_address[1];
		rear->server_ip[2] = info->ip_address[2];
		rear->server_ip[3] = info->ip_address[3];
		rear->delimiter1 = 0x2C;
		rear->server_port = ConvertEndian2(info->port);

		PrintPacket(TAG, "TEST", (char *)wifi, len);
	}

	uint8_t *packet;
	int length;

	length = FillData(&packet, BLE_PROTOCOL_OPEN_WIFI, wifi, len);
	LOGD(TAG, "Length = %d", length);

	PrintPacket(TAG, "FILL", (char *)packet, length);

	Write(BLE_PROTOCOL_OPEN_WIFI, packet, length);

	delete(packet);
}

void CBleManager::RecvRespOpenWifi(void* data, int size)
{
	LOGD(TAG, "FUNC_IN");
	PrintPacket(TAG, "PARAM", (char *)data, size);

	if (mCurrentProtocol == BLE_PROTOCOL_OPEN_WIFI)
	{
		CTimer::GetInstance()->StopTimer(TIMER_BLE_RETRY);
	}
	else
	{
		LOGD(TAG, "Not waited protocol");
	}

	if (size == 9)
	{
		//if ((((uint8_t *)data)[0] == 0x11) || (((uint8_t *)data)[0] == 0x12))
		//if ((*(uint8_t *)data == 0x12) || (*(uint8_t *)data == 0x21))
		{
			MessageQueue::GetInstance()->SendMessage(MODULE_BLE, mMessageSender, CMD_OPEN_WIFI_RESPONSE, data, size);
		}
	}
}

void CBleManager::SendCmdSendFile(void *data, int size)
{
	uint8_t *packet;
	int length;

	length = FillData(&packet, BLE_PROTOCOL_SEND_FILE, data, size);

	Write(BLE_PROTOCOL_SEND_FILE, packet, length);

	delete(packet);
}

void CBleManager::RecvRespSendFile(void* data, int size)
{
	LOGD(TAG, "FUNC_IN");
	PrintPacket(TAG, "PARAM", (char *)data, size);

	if (mCurrentProtocol == BLE_PROTOCOL_SEND_FILE)
	{
		CTimer::GetInstance()->StopTimer(TIMER_BLE_RETRY);
	}
	else
	{
		LOGD(TAG, "Not waited protocol");
	}
	MessageQueue::GetInstance()->SendMessage(MODULE_BLE, mMessageSender, CMD_DOWNLOAD_FILE_RESPONSE, data, size);
}

void CBleManager::SendCmdResetSensorInfo(void *data, int size) // 5.5.05, size: 1
{
	uint8_t *packet;
	int length;

	length = FillData(&packet, BLE_PROTOCOL_RESET_SENSOR_INFO, data, size);

	Write(BLE_PROTOCOL_RESET_SENSOR_INFO, packet, length);

	delete(packet);
}

void CBleManager::RecvRespResetSensorInfo(void* data, int size)
{
	LOGD(TAG, "FUNC_IN");
	PrintPacket(TAG, "PARAM", (char *)data, size);

	if (mCurrentProtocol == BLE_PROTOCOL_RESET_SENSOR_INFO)
	{
		CTimer::GetInstance()->StopTimer(TIMER_BLE_RETRY);
	}
	else
	{
		LOGD(TAG, "Not waited protocol");
	}
	MessageQueue::GetInstance()->SendMessage(MODULE_BLE, mMessageSender, CMD_RESET_SENSOR_INFO_RESPONSE, data, size);
}

// ****************************************
// Not Used
// ****************************************

void CBleManager::RecvRespRequestModuleMacAddr(void* data, int size)
{
	PrintPacket(TAG, "PARAM", (char *)data, size);
	if (mCurrentProtocol == BLE_PROTOCOL_READ_MAC_ADDR)
	{
		CTimer::GetInstance()->StopTimer(TIMER_BLE_RETRY);
	}
	else
	{
		LOGD(TAG, "Not waited protocol");
	}
	memcpy(mMacModule, data, size);
	MessageQueue::GetInstance()->SendMessage(MODULE_BLE, mMessageSender, CMD_GET_MAC_ADDRESS_RESPONSE, data, size);
}

void CBleManager::RecvRespWriteFirmwareVersion(void* data, int size)
{
	LOGD(TAG, "FUNC_IN");
}

void CBleManager::RecvRespSetDeviceName(void* data, int size)
{
	LOGD(TAG, "FUNC_IN");
	PrintPacket(TAG, "PARAM", (char *)data, size); 

	if (mCurrentProtocol == BLE_PROTOCOL_SET_DEVICE_NAME)
	{
		CTimer::GetInstance()->StopTimer(TIMER_BLE_RETRY);
	}
	else
	{
		LOGD(TAG, "Not waited protocol");
	}

	MessageQueue::GetInstance()->SendMessage(MODULE_BLE, mMessageSender, CMD_SET_DEVICE_NAME_RESPONSE, NULL, 0);
}

void CBleManager::RecvRespReadDeviceName(void* data, int size)
{
	LOGD(TAG, "FUNC_IN");
	PrintPacket(TAG, "PARAM", (char *)data, size);

	if (mCurrentProtocol == BLE_PROTOCOL_READ_DEVICE_NAME)
	{
		CTimer::GetInstance()->StopTimer(TIMER_BLE_RETRY);
	}
	else
	{
		LOGD(TAG, "Not waited protocol");
	}
#if 0 // 확인 필요
	memset(bleDeviceName, 0x00, sizeof(bleDeviceName));
	memcpy(bleDeviceName, data, size);
	LOGD(TAG, "BLE Device Name: %s", bleDeviceName);
#endif
	MessageQueue::GetInstance()->SendMessage(MODULE_BLE, mMessageSender, CMD_GET_DEVICE_NAME_RESPONSE, data, size);
}

void CBleManager::RecvRespReadDeviceFirmwareVersion(void* data, int size)
{
	LOGD(TAG, "FUNC_IN");
	PrintPacket(TAG, "PARAM", (char *)data, size);

	//isSuccessFirstCmd = true;

	if (size == 1 && ((uint8_t *)data)[0] == 0x01)
	{
		if (mCurrentProtocol == BLE_PROTOCOL_READ_DEV_FIRMWARE_VERSION)
		{
			CTimer::GetInstance()->StopTimer(TIMER_BLE_RETRY);
		}
		else
		{
			LOGD(TAG, "Not waited protocol");
		}

		MessageQueue::GetInstance()->SendMessage(MODULE_BLE, mMessageSender, CMD_REQUEST_DEVICE_FIRMWARE_VERSION_RESPONSE, data, size);
	}
	else
	{
#if 0	// 확인 필요
		memset(devMcuVersion, 0x00, 16);
		memset(devWifiVersion, 0x00, 16);
		memset(devBleVersion, 0x00, 16);
		memset(devHwVersion, 0x00, 16);

		char *str = (char *)data;
		char *ptr = strtok(str, ",");

		strcpy(devMcuVersion, ptr);
		ptr = strtok(NULL, ",");
		strcpy(devWifiVersion, ptr);
		ptr = strtok(NULL, ",");
		strcpy(devBleVersion, ptr);
		ptr = strtok(NULL, ",");
		strcpy(devHwVersion, ptr);

		LOGD(TAG, "MCU: %s, WIFI: %s, BLE: %s, HW: %s", devMcuVersion, devWifiVersion, devBleVersion, devHwVersion);

		char strFile[256];
		sprintf(strFile, "device/%02X%02X%02X%02X%02X%02X.ver", macPairedDevice[0], macPairedDevice[1], macPairedDevice[2], macPairedDevice[3], macPairedDevice[4], macPairedDevice[5]);
		FILE* fpVersionInfo = fopen(strFile, "w");

		if (fpVersionInfo != NULL)
		{
			fprintf(fpVersionInfo, "MCU=%s\n", devMcuVersion);
			fprintf(fpVersionInfo, "WIFI=%s\n", devWifiVersion);
			fprintf(fpVersionInfo, "BLE=%s\n", devBleVersion);
			fprintf(fpVersionInfo, "HW=%s\n", devHwVersion);

			fclose(fpVersionInfo);
		}
		else
		{
			LOGD(TAG, "File Open Error (fpVersionInfo is Null)\n");
		}
#endif
	}
}

void CBleManager::CmdGetMacAddress(void *data, int size)
{
	uint8_t *packet;
	int length;

	length = FillData(&packet, BLE_PROTOCOL_READ_MAC_ADDR, data, size);

	Write(BLE_PROTOCOL_READ_MAC_ADDR, packet, length);

	delete(packet);
}

void CBleManager::SendCmdWriteFirmwareVersion(void *data, int size) // 4.1.01, size: 17
{
	uint8_t *packet;
	int length;

	length = FillData(&packet, BLE_PROTOCOL_WRITE_FIRMWARE_VERSION, data, size);

	Write(BLE_PROTOCOL_WRITE_FIRMWARE_VERSION, packet, length);

	delete(packet);
}

void CBleManager::SendCmdWriteHardwareVersion(void *data, int size) // 4.1.02, size: 17
{
	uint8_t *packet;
	int length;

	length = FillData(&packet, BLE_PROTOCOL_WRITE_HARDWARE_VERSION, data, size);

	Write(BLE_PROTOCOL_WRITE_HARDWARE_VERSION, packet, length);

	delete(packet);
}

void CBleManager::SendCmdSetDeviceName(void *data, int size) // 5.5.02, size: 0
{
	uint8_t *packet;
	int length;

	length = FillData(&packet, BLE_PROTOCOL_SET_DEVICE_NAME, data, size);

	Write(BLE_PROTOCOL_SET_DEVICE_NAME, packet, length);

	delete(packet);
}

void CBleManager::SendCmdReadDeviceName(void *data, int size)
{
	uint8_t *packet;
	int length;

	length = FillData(&packet, BLE_PROTOCOL_READ_DEVICE_NAME, data, size);

	Write(BLE_PROTOCOL_READ_DEVICE_NAME, packet, length);

	delete(packet);
}

void CBleManager::SendCmdReadDeviceFirmwareVersion(void *data, int size)
{
	uint8_t *packet;
	int length;

	length = FillData(&packet, BLE_PROTOCOL_READ_DEV_FIRMWARE_VERSION, data, size);

	Write(BLE_PROTOCOL_READ_DEV_FIRMWARE_VERSION, packet, length);

	delete(packet);
}

#include "base/Base.h"
#include "base/CommunicationBase.h"

#include "common/SafeQueue.h"

#include <time.h>
#include <string>

#pragma pack(push, 1)

typedef struct _BLE_PROTOCOL_HEADER
{
	uint8_t preamble;
	uint8_t delimiter1;
	uint16_t length;
	uint8_t delimiter2;
	uint8_t opcode;
	uint8_t delimiter3;
} BLE_PROTOCOL_HEADER;

typedef struct _BLE_SENSOR_INFO
{
	uint8_t battery;
	uint8_t delimiter1;
	uint8_t date[4];
	uint8_t delimiter2;
	uint8_t time[3];
	uint8_t delimiter3;
	uint8_t storage_interval;
	uint8_t delimiter4;
	uint8_t storage_time[3];
	uint8_t delimiter5;
	uint8_t measurement_time[2];
	uint8_t delimiter6;
	uint16_t sample_rate;
	uint8_t delimiter7;
	uint8_t sensor_option;
	uint8_t delimiter8;
	uint32_t flash_max_size;
	uint8_t delimiter9;
	uint32_t flash_current_size;
	uint8_t delimiter10;
	uint8_t pairing_status;
	uint8_t delimiter11;
	uint8_t threshold_setting;
} BLE_SENSOR_INFO;

typedef struct _BLE_FILE_INFO
{
	uint16_t file_total_index;
	uint8_t delimiter1;
	uint16_t file_current_index;
	uint8_t delimiter2;
	uint32_t file_size;
	uint8_t delimiter3;
	uint8_t file_date[3];
	uint8_t delimiter4;
	uint8_t file_time[3];
	uint8_t delimiter5;
	uint8_t measurement_time[2];
	uint8_t delimiter6;
	uint8_t file_name[12];
} BLE_FILE_INFO;

typedef struct _BLE_TIME_SYNC
{
	uint8_t year;
	uint8_t month;
	uint8_t day;
	uint8_t weekday;
	uint8_t hour;
	uint8_t minute;
	uint8_t second;
	uint8_t delimiter;
	uint32_t delay;
} BLE_TIME_SYNC;

typedef struct _BLE_MEASUREMENT_CONFIG
{
	uint8_t date[4];
	uint8_t delimiter1;
	uint8_t time[3];
	uint8_t delimiter2;
	uint8_t storage_interval;
	uint8_t delimiter3;
	uint8_t storage_time[3];
	uint8_t delimiter4;
	uint8_t measurement_time[2];
	uint8_t delimiter5;
	uint16_t sample_rate;
	uint8_t delimiter6;
	uint8_t sensor_option;
} BLE_MEASUREMENT_CONFIG;

typedef struct _BLE_WIFI_CONFIG_FRONT
{
	uint8_t status;
	uint8_t delimiter1;
	uint8_t connection_type;
	uint8_t delimiter2;
} BLE_WIFI_CONFIG_FRONT;

typedef struct _BLE_WIFI_CONFIG_REAR
{
	uint8_t server_ip[4];
	uint8_t delimiter1;
	uint16_t server_port;
} BLE_WIFI_CONFIG_REAR;

#pragma pack(pop)

enum BLE_PROTOCOL_TYPE
{
	BLE_PROTOCOL_NONE,
	BLE_PROTOCOL_SET_DEVICE_NAME = 0x01,
	BLE_PROTOCOL_OPEN_WIFI = 0x02,
	BLE_PROTOCOL_SET_MEASUREMENT_CONFIG = 0x03,
	BLE_PROTOCOL_READ_FILE_INFO = 0x05,
	BLE_PROTOCOL_SEND_FILE = 0x06,
	BLE_PROTOCOL_RESET_SENSOR_INFO = 0x08,
	BLE_PROTOCOL_READ_SENSOR_INFO = 0x0A,
	BLE_PROTOCOL_READ_DEV_FIRMWARE_VERSION = 0x0E,	// OPCODE_VERSION_READ
	BLE_PROTOCOL_READ_MAC_ADDR = 0x10,
	BLE_PROTOCOL_WRITE_FIRMWARE_VERSION = 0x11,
	BLE_PROTOCOL_WRITE_HARDWARE_VERSION = 0x12,
	BLE_PROTOCOL_READ_FIRMWARE_VERSION = 0x15,	// 4.1.01
	BLE_PROTOCOL_READ_DEVICE_NAME = 0x18,
	BLE_PROTOCOL_START_SCAN = 0x20,
	BLE_PROTOCOL_START_SCAN_PAIRING_COMPLETE = 0x22,
	BLE_PROTOCOL_STOP_SCAN = 0x23,
	BLE_PROTOCOL_REQUEST_PAIRING = 0x2A,
	BLE_PROTOCOL_REQUEST_PAIRING_COMPLETE = 0x2B,
	BLE_PROTOCOL_REQUEST_TIME_SYNC = 0x2C,
	BLE_PROTOCOL_DISCONNECT_PAIRING = 0x2D,
	BLE_PROTOCOL_REQUEST_VALIDATION = 0x2F,
	BLE_PROTOCOL_SET_DEVICE_NAME_RESPONSE = 0x81,
	BLE_PROTOCOL_OPEN_WIFI_RESPONSE = 0x82,
	BLE_PROTOCOL_SET_MEASUREMENT_CONFIG_RESPONSE = 0x83,
	BLE_PROTOCOL_READ_FILE_INFO_RESPONSE = 0x85,
	BLE_PROTOCOL_SEND_FILE_RESPONSE = 0x86,
	BLE_PROTOCOL_RESET_SENSOR_INFO_RESPONSE = 0x88,
	BLE_PROTOCOL_READ_SENSOR_INFO_RESPONSE = 0x8A,
	BLE_PROTOCOL_READ_DEV_FIRMWARE_VERSION_RESPONSE = 0x8E,
	BLE_PROTOCOL_READ_MAC_ADDR_RESPONSE = 0x90,
	BLE_PROTOCOL_WRITE_FIRMWARE_VERSION_RESPONSE = 0x91,
	BLE_PROTOCOL_WRITE_HARDWARE_VERSION_RESPONSE = 0x92,
	BLE_PROTOCOL_READ_DEVICE_NAME_RESPONSE = 0x98,
	BLE_PROTOCOL_START_SCAN_RESPONSE = 0xA0,
	BLE_PROTOCOL_STOP_SCAN_RESPONSE = 0xA3,
	BLE_PROTOCOL_REQUEST_PAIRING_RESPONSE = 0xAA,
	BLE_PROTOCOL_REQUEST_TIME_SYNC_RESPONSE = 0xAC,
	BLE_PROTOCOL_DISCONNECT_PAIRING_RESPONSE = 0xAD,
	BLE_PROTOCOL_REQUEST_VALIDATION_RESPONSE = 0xAF,
};

enum BLE_STATE
{
	BLE_STATE_DISCONNECTED,
	BLE_STATE_START_PAIRING,
	BLE_STATE_PAIRED,
};

class CBleManager : public CBase, public IDataListener
{
public:
	CBleManager();
	~CBleManager();

	void Init(CCommunicationBase * channel);

private:
	const char *TAG = "BLE";

	CCommunicationBase *mTransmitChannel;

	MODULE_TYPE mMessageSender;

	void Write(const BLE_PROTOCOL_TYPE type, const void *data, const int size);
	void Read(const void *data, const unsigned int size);

	SafeQueue<uint8_t *> mReadDataQueue;
	std::thread* mReadDataWorker;
	void ThreadReadDataWorker();

	uint8_t mMacModule[IOT_SENSOR_BLE_MAC_ADDRESS_LENGTH];

	// Retransmission
	const int MAX_RETRANSMISSION = 2;
	BLE_PROTOCOL_TYPE mCurrentProtocol;
	int mRetransmissionCount, mRetransmissionBufferSize;
	uint8_t *mRetransmissionBuffer;

	// Pairing State & Retry Pairing
	const int MAX_RETRY_PAIRING = 2;
	BLE_STATE mStatePairing;
	struct timespec mPairedTime;
	int mRetryPairingCount;

	// Paired Device Info
	struct IotSensorInfo mPairedDeviceInfo;

	struct timespec mTargetTime;


	void CmdTimerExpired(void *data, int size);

	void MessageHandler(MODULE_TYPE sender, COMMAND_TYPE cmd, void *data, int size);

	void SendInternalMessage(MODULE_TYPE receiver, COMMAND_TYPE cmd, void *data, int size);

	int FillData(uint8_t **buf, BLE_PROTOCOL_TYPE opcode, void *data, int size);

	void CmdGetMacAddress(void *, int);

	void SendCmdRequestSensorDevicePairing(void *, int);
	//void SendCmdRequestModuleMacAddr(void *, int);
	void SendCmdWriteFirmwareVersion(void *data, int size);
	void SendCmdWriteHardwareVersion(void *data, int size);
	void SendCmdSetDeviceName(void *data, int size);
	void SendCmdReadSensorInfo(void *data, int size);
	void SendCmdSetMeasurementConfig(void *data, int size);
	void SendCmdResetSensorInfo(void *data, int size);
	void SendCmdDisconnectPairing(void *data, int size);
#if 0
	void SendCmdStartScan(void *data, int size);
	void SendCmdRequestValidation(void *data, int size);
	void SendCmdStopScan(void *data, int size);
#endif
public:
	void SendCmdRequestTimeSync(void *data, int size);
private:
	void SendCmdReadFileInfo(void *data, int size);
	void SendCmdOpenWifi(void *data, int size);
	void SendCmdSendFile(void *data, int size);
	void SendCmdReadDeviceName(void *data, int size);
	void SendCmdReadDeviceFirmwareVersion(void *data, int size);

#if 0
	void RecvRespStartScan(void* data, int size);
	void RecvRespStartScanPairingComplete(void* data, int size);
	void RecvRespRequestValidation(void* data, int size);
	void RecvRespStopScan(void* data, int size);
#endif
	void RecvRespRequestSensorDevicePairing(void* data, int size);
	void RecvRespRequestSensorDevicePairingComplete(void* data, int size);
	void RecvRespRequestModuleMacAddr(void* data, int size);
	void RecvRespWriteFirmwareVersion(void* data, int size);
	void RecvRespSetDeviceName(void* data, int size);
	void RecvRespReadSensorInfo(void* data, int size);
	void RecvRespSetMeasurementConfig(void* data, int size);
	void RecvRespResetSensorInfo(void* data, int size);
	void RecvRespDisconnectPairing(void* data, int size);
	void RecvRespRequestTimeSync(void* data, int size);
	void RecvRespReadFileInfo(void* data, int size);
	void RecvRespOpenWifi(void* data, int size);
	void RecvRespSendFile(void* data, int size);
	void RecvRespReadDeviceName(void* data, int size);
	void RecvRespReadDeviceFirmwareVersion(void *data, int size);
};

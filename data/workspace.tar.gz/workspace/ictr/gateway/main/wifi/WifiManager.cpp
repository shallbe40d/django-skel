#include "WifiManager.h"

#include "mq/MessageQueue.h"
#include "util/Util.h"
#include "ssl/SocketServerController.h"

CWifiManager::CWifiManager()
{
	mTransmitChannel = NULL;

	mDownloadProgress = 0;
	memset(mSocketFile, 0x00, FILE_PATH_LENGTH);
	memset(mRawFile, 0x00, FILE_PATH_LENGTH);
	mFpSocketFile = NULL;
	mFpRawFile = NULL;
}

CWifiManager::~CWifiManager()
{
}

void CWifiManager::Init(CCommunicationBase *channel)
{
	mTransmitChannel = channel;
	mTransmitChannel->RegisterListener(this);

	CSocketServerController *server = dynamic_cast<CSocketServerController *>(mTransmitChannel);
	if (server != NULL)
	{
		LOGD(TAG, "IoT Sensor Socket Server START");
		server->Start();
	}
	else
	{
		LOGE(TAG, "Socket Start ERROR");
	}

	MessageQueue::GetInstance()->RegisterListener(MODULE_WIFI, this);
}

void CWifiManager::MessageHandler(MODULE_TYPE sender, COMMAND_TYPE cmd, void *data, int size)
{
	switch(cmd)
	{
	case CMD_START_AP:
		{
			LOGD(TAG, "CMD_START_AP");
			CmdStartAp(data, size);
		}
		break;
	case CMD_STOP_AP:
		{
			LOGD(TAG, "CMD_STOP_AP");
			CmdStopAp(data, size);
		}
		break;
	case CMD_DOWNLOAD_FILE:
		{
			LOGD(TAG, "CMD_DOWNLOAD_FILE");
			CmdDownloadFile(data, size);
		}
		break;
	default:
		{
			CBase::MessageHandler(sender, cmd, data, size);
		}
	}
}

void CWifiManager::SendInternalMessage(MODULE_TYPE receiver, COMMAND_TYPE cmd, void *data, int size)
{
	MessageQueue::GetInstance()->SendMessage(MODULE_WIFI, receiver, cmd, data, size);
}

void CWifiManager::Read(const void *data, const unsigned int size)
{
	//LOGD(TAG, "FUNC IN");

	if (mFpSocketFile != NULL)
	{
		fwrite(data, size, 1, mFpSocketFile);
	}

	struct IOT_SENSOR_DATA_HEADER *head = (struct IOT_SENSOR_DATA_HEADER *)data;

	int total = head->payload.total_index[0] * 256 * 256 + head->payload.total_index[1] * 256 + head->payload.total_index[2];
	int current = head->payload.current_index[0] * 256 * 256 + head->payload.current_index[1] * 256 + head->payload.current_index[2];

#if 0
	LOGD(TAG, "Preamble: %02X, Length: %d, Op: %02X, Total: %d, Current: %d, Date: %02X%02X%02X%02X, Time: %02X%02X%02X, Measurement Time: %02X:%02X, Sample Rate: %d, Type: %02X",
		head->prefix.preamble, ConvertEndian2(head->prefix.length), head->prefix.opcode,
		total, current,
		head->payload.start_date[0], head->payload.start_date[1], head->payload.start_date[2], head->payload.start_date[3],
		head->payload.start_time[0], head->payload.start_time[1], head->payload.start_time[2],
		head->payload.measurement_time[0], head->payload.measurement_time[1], ConvertEndian2(head->payload.sample_rate), head->payload.sensor_type);

	if ((total == current) || (current == 0))
	{
		PrintPacket(TAG, "[Last]", (char *)data, size);
	}
#endif

	float rate = (float)current / (float)total;
	if ((int)(rate * 100) != mDownloadProgress)
	{
		LOGD(TAG, "Downloading.. %5d/%5d [%5.1f%]", current, total, rate * 100);
		mDownloadProgress = (int)(rate * 100);
	}

	if (mFpRawFile != NULL)
	{
		fwrite(data + sizeof(struct IOT_SENSOR_DATA_HEADER), ConvertEndian2(head->prefix.length) - sizeof(struct IOT_SENSOR_DATA_HEADER_PAYLOAD), 1, mFpRawFile);
		//PrintPacket(TAG, "[DATA]", (char *)data + sizeof(struct IOT_SENSOR_DATA_HEADER), ConvertEndian2(head->prefix.length) - sizeof(struct IOT_SENSOR_DATA_HEADER_PAYLOAD));
	}

	//LOGD(TAG, "FUNC OUT");
}

void CWifiManager::CmdStartAp(void *data, int size)
{
	// cat /etc/default/isc-dhcp-server
	// cat /etc/dhcp/dhcpd.conf
	// sudo systemctl start isc-dhcp-server

	//hostapd /etc/hostapd/hostapd.conf -B

	//system("sudo killall hostapd");

	//system("sudo systemctl start isc-dhcp-server");

	//int rc = system("sudo hostapd config/hostap.conf -B");

	//LOGD(TAG, "rc: %d", rc);
	//if (rc == 0)
	{
		SendInternalMessage(MODULE_GATEWAY, CMD_START_AP_RESPONSE, NULL, 0);

#if 0
		CSocketServerController *server = dynamic_cast<CSocketServerController *>(mTransmitChannel);
		if (server != NULL)
		{
			LOGD(TAG, "IoT Sensor Socket Server START");
			server->Start();
		}
		else
		{
			LOGE(TAG, "Socket Start ERROR");
		}
#endif
	}
}

void CWifiManager::CmdStopAp(void *data, int size)
{
	if (mFpSocketFile != NULL)
	{
		fclose(mFpSocketFile);
		mFpSocketFile = NULL;
	}

	if (mFpRawFile != NULL)
	{
		fclose(mFpRawFile);
		mFpRawFile = NULL;
	}

	//system("sudo systemctl stop isc-dhcp-server");

	//system("sudo killall hostapd");

	LOGD(TAG, "Raw: %s", mRawFile);

	SendInternalMessage(MODULE_GATEWAY, CMD_STOP_AP_RESPONSE, mRawFile, strlen(mRawFile));
#if 0
	CSocketServerController *server = dynamic_cast<CSocketServerController *>(mTransmitChannel);
	if (server != NULL)
	{
		LOGD(TAG, "IoT Sensor Socket Server STOP");
		server->Stop();
	}
	else
	{
		LOGE(TAG, "Socket Stop ERROR");
	}
#endif
}

void CWifiManager::CmdDownloadFile(const void *data, const int size)
{
	struct MeasurementDataFileInfo *info = (struct MeasurementDataFileInfo *)data;

	LOGD(TAG, "Index: %d, Directory: %s, Equipment Id: %s, Location: %d, Type: %c, Name: %s, Size: %d", info->index, info->sub_dir_name, info->equipment_id, info->location, info->tag, info->file_name, info->size);

	char date[7];
	memset(date, 0x00, 7);
	memcpy(date, info->file_name, 6);

	char dirCurrent[FILE_PATH_LENGTH], dirSave[FILE_PATH_LENGTH];
	getcwd(dirCurrent, FILE_PATH_LENGTH);

	snprintf(dirSave, FILE_PATH_LENGTH, "%s/data/%s/%s", dirCurrent, info->sub_dir_name, date);

	char cmdMkdir[1024];
	sprintf(cmdMkdir, "mkdir -p %s", dirSave);
	system(cmdMkdir);

	memset(mSocketFile, 0x00, FILE_PATH_LENGTH);
	memset(mRawFile, 0x00, FILE_PATH_LENGTH);

	sprintf(mSocketFile, "%s/%s_%d_%c_%s.soc", dirSave, info->equipment_id, info->location, info->tag, info->file_name);
	sprintf(mRawFile, "%s/%s_%d_%c_%s.raw", dirSave, info->equipment_id, info->location, info->tag, info->file_name);
	LOGD(TAG, "Socket File Name: (%d) %s ", strlen(mSocketFile), mSocketFile);
	LOGD(TAG, "RAW File Name: (%d) %s ", strlen(mRawFile), mRawFile);

	mFpSocketFile = fopen(mSocketFile, "wb");
	mFpRawFile = fopen(mRawFile, "wb");
}
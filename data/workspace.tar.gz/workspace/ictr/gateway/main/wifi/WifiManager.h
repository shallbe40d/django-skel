#include "base/Base.h"
#include "base/CommunicationBase.h"

#pragma pack(push, 1)
struct IOT_SENSOR_DATA_HEADER_PREFIX
{
	uint8_t preamble;
	uint8_t delimiter1;
	uint16_t length;
	uint8_t delimiter2;
	uint8_t opcode;
	uint8_t delimiter3;
};

struct IOT_SENSOR_DATA_HEADER_PAYLOAD
{
	uint8_t total_index[3];
	uint8_t delimiter4;
	uint8_t current_index[3];
	uint8_t delimiter5;
	uint8_t start_date[4];
	uint8_t delimiter6;
	uint8_t start_time[3];
	uint8_t delimiter7;
	uint8_t measurement_time[2];
	uint8_t delimiter8;
	uint16_t sample_rate;
	uint8_t delimiter9;
	uint8_t sensor_type;
	uint8_t delimiter10;
};

struct IOT_SENSOR_DATA_HEADER_POSTFIX
{
	uint8_t delimiter11;
	uint8_t crc;
};

struct IOT_SENSOR_DATA_HEADER
{
	struct IOT_SENSOR_DATA_HEADER_PREFIX prefix;
	struct IOT_SENSOR_DATA_HEADER_PAYLOAD payload;
};
#pragma pack(pop)

class CWifiManager : public CBase, public IDataListener
{
public:
	CWifiManager();
	~CWifiManager();

	void Init(CCommunicationBase *channel);

private:
	const char *TAG = "WIFI";

	void MessageHandler(MODULE_TYPE sender, COMMAND_TYPE cmd, void *data, int size);
	void SendInternalMessage(MODULE_TYPE receiver, COMMAND_TYPE cmd, void *data, int size);

	CCommunicationBase *mTransmitChannel;

	int mDownloadProgress;
	char mSocketFile[FILE_PATH_LENGTH], mRawFile[FILE_PATH_LENGTH];
	FILE *mFpSocketFile, *mFpRawFile;

	void Read(const void *data, const unsigned int size);
	void Write(const uint8_t *data, const int size);

	void CmdStartAp(void *data, int size);
	void CmdStopAp(void *data, int size);

	void CmdDownloadFile(const void *data, const int size);
};

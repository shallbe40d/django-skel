#include "GatewayManager.h"
#include "mq/MessageQueue.h"
#include "log/Log.h"
#include "timer/Timer.h"
#include "util/Util.h"
#include "json/json.h"

#include <time.h>
#include <arpa/inet.h>
#include <unistd.h>

CGatewayManager::CGatewayManager()
{
	mWorkInterval = 500;

	mHeartBeatCount[HEART_BEAT_M1MODEM] = 0;
	mHeartBeatCount[HEART_BEAT_EMROUTER] = 0;
	mHeartBeatCount[HEART_BEAT_MCU] = 0;

	memset(&mGatewayInfo, 0x00, sizeof(struct GatewayInfo));
	memset(mGatewayFile, 0x00, sizeof(mGatewayFile));
}

CGatewayManager::~CGatewayManager()
{
}

void CGatewayManager::Init()
{
	ReadGatewayConfigFile();
	WriteGatewayConfigFile();

	mStateMain = GATEWAY_STATE_IDLE;

	mNoiseThresholdMeasurementCount = 0;

	MessageQueue::GetInstance()->RegisterListener(MODULE_GATEWAY, this);

	// Register Timer
	CTimer::GetInstance()->AddTimer(TIMER_HEART_BEAT, "TIMER_HEART_BEAT");
	CTimer::GetInstance()->AddTimer(TIMER_STATUS_CHECK, "TIMER_STATUS_CHECK");
	CTimer::GetInstance()->AddTimer(TIMER_NOISE_THRESHOLD_MEASUREMENT, "TIMER_NOISE_THRESHOLD_MEASUREMENT");
	CTimer::GetInstance()->AddTimer(TIMER_REGULAR_MEASUREMENT, "TIMER_REGULAR_MEASUREMENT");
	CTimer::GetInstance()->AddTimer(TIMER_IOT_SENSOR_MEASUREMENT_WAIT, "TIMER_IOT_SENSOR_MEASUREMENT_WAIT");

	// Register Handler
	AddMessageHandler(CMD_SET_OPERATING_INFO, "CMD_SET_OPERATING_INFO", &CGatewayManager::CmdSetOperatingInfo);
	AddMessageHandler(CMD_SET_MEASUREMENT_INFO, "CMD_SET_MEASUREMENT_INFO", &CGatewayManager::CmdSetMeasurementInfo);

	AddMessageHandler(CMD_TIMER_EXPIRED, "CMD_TIMER_EXPIRED", &CGatewayManager::CmdTimerExpired);
	AddMessageHandler(CMD_GET_MAC_ADDRESS_RESPONSE, "CMD_GET_MAC_ADDRESS_RESPONSE", &CGatewayManager::CmdGetMacAddressResponse);

	AddMessageHandler(CMD_REQUEST_REGULAR_MEASUREMENT_RESPONSE, "CMD_REQUEST_REGULAR_MEASUREMENT_RESPONSE", &CGatewayManager::CmdRegularMeasurementResponse);
	AddMessageHandler(CMD_DIAGNOSE_NOISE_ANOMALY_RESPONSE, "CMD_DIAGNOSE_NOISE_ANOMALY_RESPONSE", &CGatewayManager::CmdDiagnoseNoiseAnomalyResponse);

	//CTimer::GetInstance()->SetTimer(MODULE_GATEWAY, TIMER_HEART_BEAT, mGatewayInfo.operating_info.heart_beat_interval, 0);

	//CTimer::GetInstance()->SetTimer(MODULE_GATEWAY, TIMER_STATUS_CHECK, mGatewayInfo.status_check_info.status_check_interval, 0);
	//CTimer::GetInstance()->SetTimer(MODULE_GATEWAY, TIMER_REGULAR_MEASUREMENT, mGatewayInfo.regular_measurement_info.interval, 0);
	//CTimer::GetInstance()->SetTimer(MODULE_GATEWAY, TIMER_REGULAR_MEASUREMENT_RESULT_REPORT, mGatewayInfo.regular_measurement_info.result_report_interval, 0);

	//RegisterGateway(CMD_REQUEST_REGISTER_GATEWAY);

	//CmdRequestBleSensorMeasurement(CMD_REQUEST_BLE_SENSOR_MEASUREMENT, NULL, 0);
	//DownloadDataFromSingleDevice(CMD_REQUEST_DOWNLOAD_DATA_SINGLE_DEVICE, NULL, 0);
	//DoNoiseThresholdMeasurement(CMD_REQUEST_NOISE_THRESHOLD_MEASUREMENT, NULL, 0);
}

void CGatewayManager::AddMessageHandler(COMMAND_TYPE cmd, const char *name, void (CGatewayManager::*handler)(void *, int))
{
	message_handler<CGatewayManager> h;

	h.cmd = cmd;
	snprintf(h.name, 64, "%s", name);
	h.handler = handler;

	mMessageHandlerList.push_back(h);
}

void CGatewayManager::MessageHandler(MODULE_TYPE sender, COMMAND_TYPE cmd, void *data, int size)
{
	int rc = 0;
	std::vector<message_handler<CGatewayManager>>::iterator it;

	for (it = mMessageHandlerList.begin(); it != mMessageHandlerList.end(); it++)
	{
		if(it->cmd == cmd)
		{
			LOGD(TAG, "%s, data: %p, size: %d", it->name, data, size);
			void (CGatewayManager::*fp)(void *, int) = it->handler;

			(this->*fp)(data, size);
			rc = 1;
		}
	}

	switch(cmd)
	{
	case CMD_REQUEST_IOT_SENSOR_MEASUREMENT:
		{
			LOGD(TAG, "CMD_REQUEST_IOT_SENSOR_MEASUREMENT");
			CmdRequestIotSensorMeasurement(data, size);
		}
		break;
	case CMD_REQUEST_CONNECT_DEVICE_RESPONSE:
		{
			LOGD(TAG, "CMD_REQUEST_CONNECT_DEVICE_RESPONSE Request!! for State %d", mStateMain);
			switch(mStateMain)
			{
			case GATEWAY_STATE_GET_IOT_SENSOR_INFO:
				GetIotSensorInfo(cmd, data, size);
				break;
			case GATEWAY_STATE_RESET_IOT_SENSOR:
				ResetIotSensor(cmd, data, size);
				break;
			case GATEWAY_STATE_EMERGENCY_MEASUREMENT:
			case GATEWAY_STATE_MANUAL_MEASUREMENT:
			case GATEWAY_STATE_PERIODIC_MEASUREMENT:
			case GATEWAY_STATE_VIBRATION_THRESHOLD_MEASUREMENT:
				DoIotSensorMeasurement(cmd, data, size);
				break;
			case GATEWAY_STATE_EMERGENCY_DIAGNOSIS:
			case GATEWAY_STATE_MANUAL_DIAGNOSIS:
			case GATEWAY_STATE_PERIODIC_DIAGNOSIS:
			case GATEWAY_STATE_VIBRATION_THRESHOLD_DIAGNOSIS:
				DownloadDataFromSingleDevice(cmd, data, size);
				break;
			default:
				break;
			}
		}
		break;
	case CMD_REQUEST_TIME_SYNC_RESPONSE:
		{
			LOGD(TAG, "CMD_REQUEST_TIME_SYNC_RESPONSE Request!!");
			DoIotSensorMeasurement(cmd, data, size);
		}
		break;
	case CMD_REQUEST_DISCONNECT_DEVICE_RESPONSE:
		{
			LOGD(TAG, "CMD_REQUEST_DISCONNECT_DEVICE_RESPONSE Request!!");
			switch(mStateMain)
			{
			case GATEWAY_STATE_GET_IOT_SENSOR_INFO:
				GetIotSensorInfo(cmd, data, size);
				break;
			case GATEWAY_STATE_RESET_IOT_SENSOR:
				ResetIotSensor(cmd, data, size);
				break;
			case GATEWAY_STATE_EMERGENCY_MEASUREMENT:
			case GATEWAY_STATE_MANUAL_MEASUREMENT:
			case GATEWAY_STATE_PERIODIC_MEASUREMENT:
			case GATEWAY_STATE_VIBRATION_THRESHOLD_MEASUREMENT:
				DoIotSensorMeasurement(cmd, data, size);
				break;
			case GATEWAY_STATE_EMERGENCY_DIAGNOSIS:
			case GATEWAY_STATE_MANUAL_DIAGNOSIS:
			case GATEWAY_STATE_PERIODIC_DIAGNOSIS:
			case GATEWAY_STATE_VIBRATION_THRESHOLD_DIAGNOSIS:
				DownloadDataFromSingleDevice(cmd, data, size);
				break;
			default:
				break;
			}
		}
		break;
	case CMD_SET_MEASUREMENT_CONFIG_RESPONSE:
		{
			LOGD(TAG, "CMD_SET_MEASUREMENT_CONFIG_RESPONSE");
			DoIotSensorMeasurement(cmd, data, size);
		}
		break;
	case CMD_REQUEST_DOWNLOAD_DATA_SINGLE_DEVICE:
		{
			LOGD(TAG, "CMD_REQUEST_DOWNLOAD_DATA_SINGLE_DEVICE");
			DownloadDataFromSingleDevice(CMD_REQUEST_DOWNLOAD_DATA_SINGLE_DEVICE, NULL, 0);
		}
		break;
	case CMD_REQUEST_DOWNLOAD_DATA_SINGLE_DEVICE_RESPONSE:
		{
			LOGD(TAG, "CMD_REQUEST_DOWNLOAD_DATA_SINGLE_DEVICE_RESPONSE");
			switch(mStateMain)
			{
			case GATEWAY_STATE_EMERGENCY_DIAGNOSIS:
				break;
			case GATEWAY_STATE_MANUAL_DIAGNOSIS:
				DoManualMeasurement(cmd, data, size);
				break;
			case GATEWAY_STATE_PERIODIC_DIAGNOSIS:
				break;
			case GATEWAY_STATE_VIBRATION_THRESHOLD_DIAGNOSIS:
				DoVibrationThresholdMeasurement(cmd, data, size);
				break;
			default:
				break;
			}
		}
		break;
	case CMD_GET_DEVICE_INFO_RESPONSE:
		{
			LOGD(TAG, "CMD_GET_DEVICE_INFO_RESPONSE Request!! for State %d", mStateMain);
			switch(mStateMain)
			{
			case GATEWAY_STATE_GET_IOT_SENSOR_INFO:
				GetIotSensorInfo(cmd, data, size);
				break;
			case GATEWAY_STATE_RESET_IOT_SENSOR:
				ResetIotSensor(cmd, data, size);
				break;
			case GATEWAY_STATE_EMERGENCY_MEASUREMENT:
			case GATEWAY_STATE_MANUAL_MEASUREMENT:
			case GATEWAY_STATE_PERIODIC_MEASUREMENT:
			case GATEWAY_STATE_VIBRATION_THRESHOLD_MEASUREMENT:
				DoIotSensorMeasurement(cmd, data, size);
				break;
			case GATEWAY_STATE_EMERGENCY_DIAGNOSIS:
			case GATEWAY_STATE_MANUAL_DIAGNOSIS:
			case GATEWAY_STATE_PERIODIC_DIAGNOSIS:
			case GATEWAY_STATE_VIBRATION_THRESHOLD_DIAGNOSIS:
				DownloadDataFromSingleDevice(cmd, data, size);
				break;
			default:
				break;
			}
		}
		break;
	case CMD_GET_DEVICE_NAME_RESPONSE:
		{
			LOGD(TAG, "CMD_GET_DEVICE_NAME_RESPONSE");
			DownloadDataFromSingleDevice(cmd, data, size);
		}
		break;
	case CMD_GET_FILE_LIST_RESPONSE:
		{
			LOGD(TAG, "CMD_GET_FILE_LIST_RESPONSE");
			DownloadDataFromSingleDevice(cmd, data, size);
		}
		break;
	case CMD_START_AP_RESPONSE:
		{
			LOGD(TAG, "CMD_START_AP_RESPONSE");
			DownloadDataFromSingleDevice(cmd, NULL, 0);
		}
		break;
	case CMD_STOP_AP_RESPONSE:
		{
			LOGD(TAG, "CMD_STOP_AP_RESPONSE");
			DownloadDataFromSingleDevice(cmd, data, size);
		}
		break;
	case CMD_OPEN_WIFI_RESPONSE:
		{
			LOGD(TAG, "CMD_OPEN_WIFI_RESPONSE");
			DownloadDataFromSingleDevice(cmd, data, size);
		}
		break;
	case CMD_DOWNLOAD_FILE_RESPONSE:
		{
			LOGD(TAG, "CMD_DOWNLOAD_FILE_RESPONSE");
			DownloadDataFromSingleDevice(cmd, data, size);
		}
		break;
	case CMD_SET_IOT_SENSOR_LIST_INFO:
		{
			LOGD(TAG, "CMD_SET_IOT_SENSOR_LIST_INFO");
			CmdSetIotSensorListInfo(data, size);
		}
		break;
	case CMD_REQUEST_REGISTER_GATEWAY_RESPONSE:
		{
			LOGD(TAG, "CMD_REQUEST_REGISTER_GATEWAY_RESPONSE");
			RegisterGateway(CMD_REQUEST_REGISTER_GATEWAY_RESPONSE);
		}
		break;
	case CMD_SET_EQUIPMENT_INFORMATION:
		{
			LOGD(TAG, "CMD_SET_EQUIPMENT_INFORMATION");
			CmdSetEquipmentInformation(data, size);
		}
		break;
	case CMD_REQUEST_NOISE_THRESHOLD_MEASUREMENT:
		{
			LOGD(TAG, "CMD_REQUEST_NOISE_THRESHOLD_MEASUREMENT");
			CmdRequestNoiseThresholdMeasurement(data, size);
		}
		break;
	case CMD_REQUEST_NOISE_THRESHOLD_MEASUREMENT_RESPONSE:
		{
			LOGD(TAG, "CMD_REQUEST_NOISE_THRESHOLD_MEASUREMENT_RESPONSE");
			DoNoiseThresholdMeasurement(cmd, data, size);
		}
		break;
	case CMD_REQUEST_NOISE_THRESHOLD_DIAGNOSIS:
		{
			LOGD(TAG, "CMD_REQUEST_NOISE_THRESHOLD_DIAGNOSIS");
			CmdRequestNoiseThresholdDiagnosis(data, size);
		}
		break;
	case CMD_DIAGNOSE_NOISE_THRESHOLD_RESPONSE:
		{
			LOGD(TAG, "CMD_DIAGNOSE_NOISE_THRESHOLD_RESPONSE");
			CmdDiagnoseNoiseThresholdResponse(data, size);
		}
		break;
	case CMD_TEST_MODULE_COMMUNICATION:
		{
			LOGD(TAG, "CMD_TEST_MODULE_COMMUNICATION");
			CmdTestModuleCommunication(data, size);
		}
		break;
	case CMD_REQUEST_MANUAL_MEASUREMENT:
		{
			LOGD(TAG, "CMD_REQUEST_MANUAL_MEASUREMENT");
		}
		break;
	case CMD_REQUEST_PERIODIC_MEASUREMENT:
		{
			LOGD(TAG, "CMD_REQUEST_PERIODIC_MEASUREMENT");
		}
		break;



#if 0
	case :
		{
			LOGD(TAG, "");
		}
		break;
#endif
	default:
		{
			CBase::MessageHandler(sender, cmd, data, size);
		}
		break;
	}
}

void CGatewayManager::ReadGatewayConfigFile()
{
	FILE *fp = fopen(GATEWAY_INFO_FILE, "r");

	if (fp == NULL)
	{
		LOGE(TAG, "Gateway info file open error: %s", GATEWAY_INFO_FILE);
		return;
	}

	fseek(fp, 0, SEEK_END);
	long int fileSize = ftell(fp);
	fseek(fp, 0, SEEK_SET);

	LOGD(TAG, "file: %s, size: %ld", GATEWAY_INFO_FILE, fileSize);

	char *tmp = (char *)malloc(fileSize);
	fread(tmp, fileSize, 1, fp);

	fclose(fp);

	// Add decryption code

	Json::CharReaderBuilder builder;
	Json::CharReader * reader = builder.newCharReader();
	std::string error;

	Json::Value root;

	bool res = reader->parse(tmp, tmp + fileSize, &root, &error);

	if (res == true)
	{
		try
		{
			//Gateway ID
			ConvertStrMacToCharMac(root["gatewayId"].asCString(), mGatewayInfo.gateway_id, 6);
			memcpy(mGatewayInfo.gateway_version, root["gatewayVersion"].asString().c_str(), strlen(root["gatewayVersion"].asString().c_str()));
			mGatewayInfo.is_config = root["isConfig"].asBool();

			//IoT Sensor List
			Json::Value iotSensorList = root["iotSensorList"];
			if (iotSensorList.size() < 10)
			{
				for (unsigned int index = 0; index < iotSensorList.size(); index++)
				{
					ConvertStrMacToCharMac(iotSensorList[index]["mac"].asCString(), mGatewayInfo.iot_sensor_info_list[index].ble, 6);
					ConvertStrMacToCharMac(iotSensorList[index]["wifi"].asCString(), mGatewayInfo.iot_sensor_info_list[index].wifi, 6);
					mGatewayInfo.iot_sensor_info_list[index].type = *iotSensorList[index]["type"].asString().c_str();
					mGatewayInfo.iot_sensor_info_list[index].location = iotSensorList[index]["location"].asInt();
					mGatewayInfo.iot_sensor_info_list[index].direction = iotSensorList[index]["direction"].asInt();
				}
				mGatewayInfo.num_iot_sensor = iotSensorList.size();
			}

			// Wifi Ap for IoT sensor
			memcpy(mGatewayInfo.iot_sensor_ap_info.ssid, root["iotSensorApInfo"]["ssid"].asString().c_str(), strlen(root["iotSensorApInfo"]["ssid"].asString().c_str()));
			mGatewayInfo.iot_sensor_ap_info.auth_type = root["iotSensorApInfo"]["authType"].asInt();
			memcpy(mGatewayInfo.iot_sensor_ap_info.password, root["iotSensorApInfo"]["password"].asString().c_str(), strlen(root["iotSensorApInfo"]["password"].asString().c_str()));
			inet_pton(AF_INET, root["iotSensorApInfo"]["ipAddress"].asString().c_str(), mGatewayInfo.iot_sensor_ap_info.ip_address);
			mGatewayInfo.iot_sensor_ap_info.port = root["iotSensorApInfo"]["port"].asInt();

			//Operating Info
			memcpy(mGatewayInfo.operating_info.equipment_id, root["operatingInfo"]["equipmentId"].asString().c_str(), strlen(root["operatingInfo"]["equipmentId"].asString().c_str()));
			if(strstr(root["operatingInfo"]["location"].asString().c_str(), "In") >= 0)
			{
				mGatewayInfo.operating_info.location = 1;
			}
			else if(strstr(root["operatingInfo"]["location"].asString().c_str(), "Out") >= 0)
			{
				mGatewayInfo.operating_info.location = 2;
			}
			mGatewayInfo.operating_info.num_data_stored = root["operatingInfo"]["numData"].asInt();

			// Regular Measuremet Info
			sscanf(root["regularMeasurementInfo"]["startTime"].asString().c_str(),"%hhu:%hhu", &mGatewayInfo.regular_measurement_info.start_hour,&mGatewayInfo.regular_measurement_info.start_minute);
			sscanf(root["regularMeasurementInfo"]["stopTime"].asString().c_str(),"%hhu:%hhu",&(mGatewayInfo.regular_measurement_info.stop_hour),&(mGatewayInfo.regular_measurement_info.stop_minute));
			mGatewayInfo.regular_measurement_info.measurement_info.interval = root["regularMeasurementInfo"]["noiseMeasurementInterval"].asInt();
			//mGatewayInfo.regular_measurement_info.result_report_interval = root["regularMeasurementInfo"]["resultReportInterval"].asInt();
			//mGatewayInfo.regular_measurement_info.is_over_day = root["measurementInfo"]["isOverDay"].asInt();
			//mGatewayInfo.regular_measurement_info.sound_measurement_time = root["measurementInfo"]["soundMeasurementTime"].asInt();

			// Noise Threshold Measurement Info
			mGatewayInfo.noise_threshold_measurement_info.measurement_info.interval = root["noiseThresholdMeasurementInfo"]["interval"].asInt();
			mGatewayInfo.noise_threshold_measurement_info.measurement_info.measurement_time = root["noiseThresholdMeasurementInfo"]["measurementTime"].asInt();
			mGatewayInfo.noise_threshold_measurement_info.measurement_info.num_measurement = root["noiseThresholdMeasurementInfo"]["times"].asInt();
			mGatewayInfo.noise_threshold_measurement_info.measurement_info.sampling_rate = root["noiseThresholdMeasurementInfo"]["samplingRate"].asInt();

			// Vibration Threshold Measurement Info
			//mGatewayInfo.vibration_threshold_measurement_info.measurement_info.interval = root["vibrationThresholdMeasurementInfo"]["interval"].asInt();
			mGatewayInfo.vibration_threshold_measurement_info.measurement_info.measurement_time = root["vibrationThresholdMeasurementInfo"]["measurementTime"].asInt();
			mGatewayInfo.vibration_threshold_measurement_info.measurement_info.num_measurement = root["vibrationThresholdMeasurementInfo"]["numMeasurement"].asInt();
			mGatewayInfo.vibration_threshold_measurement_info.measurement_info.sampling_rate = root["vibrationThresholdMeasurementInfo"]["samplingRate"].asInt();

			// IoT Sensor Measurement Info
			mGatewayInfo.iot_sensor_measurement_info.noise_sensor_measurement_info.measurement_time = root["iotSensorMeasurementInfo"]["noiseSensorMeasurementTime"].asInt();
			mGatewayInfo.iot_sensor_measurement_info.noise_sensor_measurement_info.sampling_rate = root["iotSensorMeasurementInfo"]["noiseSensorSamplingRate"].asInt();
			mGatewayInfo.iot_sensor_measurement_info.vibration_sensor_measurement_info.measurement_time = root["iotSensorMeasurementInfo"]["vibrationSensorMeasurementTime"].asInt();
			mGatewayInfo.iot_sensor_measurement_info.vibration_sensor_measurement_info.sampling_rate = root["iotSensorMeasurementInfo"]["vibrationSensorSamplingRate"].asInt();

			strcpy(mGatewayFile[FILE_EQUIPMENT_INFORMATION], root["fileInfo"]["equipmentInfoFile"].asCString());
			strcpy(mGatewayFile[FILE_FAULT_FREQUENCY], root["fileInfo"]["faultFrequencyFile"].asCString());
			strcpy(mGatewayFile[FILE_RMS_SHAFT_BEARING], root["fileInfo"]["rmsShaftBearingFile"].asCString());
			strcpy(mGatewayFile[FILE_RMS_MOTOR], root["fileInfo"]["rmsMotorFile"].asCString());
			strcpy(mGatewayFile[FILE_VIBRATION_THRESHOLD], root["fileInfo"]["vibrationThresholdFile"].asCString());
			strcpy(mGatewayFile[FILE_NOISE_THRESHOLD], root["fileInfo"]["noiseThresholdFile"].asCString());
			strcpy(mGatewayFile[FILE_ACCUMULATED_NOISE_INDICATOR], root["fileInfo"]["accumulatedNoiseIndicatorFile"].asCString());

			mGatewayInfo.status_check_info.status_check_interval = root["statusCheckInfo"]["statusCheckInterval"].asInt();
			mGatewayInfo.status_check_info.cpu_usage_threshold = root["statusCheckInfo"]["cpuUsageThreshold"].asFloat();
			mGatewayInfo.status_check_info.memory_usage_threshold = root["statusCheckInfo"]["memoryUsageThreshold"].asFloat();
			mGatewayInfo.status_check_info.disk_usage_threshold = root["statusCheckInfo"]["diskUsageThreshold"].asFloat();
			mGatewayInfo.status_check_info.cpu_temperature_threshold = root["statusCheckInfo"]["cpuTemperatureThreshold"].asFloat();
			mGatewayInfo.status_check_info.iot_sensor_battery_threshold = root["statusCheckInfo"]["iotSensorBatteryThreshold"].asFloat();
		}
		catch(...)
		{
			res = false;
			//rc = ERROR_MQTT_MESSAGE_FORMAT;
			LOGE(TAG, "Parsing Error #2");
		}
	}
	else
	{
		//rc = ERROR_MQTT_MESSAGE_PARSING;
		LOGE(TAG, "Parsing Error #1");
	}

	LOGD(TAG, "==========================================================");
	LOGD(TAG, "Gateway ID: %02X %02X %02X %02X %02X %02X", mGatewayInfo.gateway_id[0], mGatewayInfo.gateway_id[1], mGatewayInfo.gateway_id[2], mGatewayInfo.gateway_id[3], mGatewayInfo.gateway_id[4], mGatewayInfo.gateway_id[5]);
	LOGD(TAG, "Gateway Version: %s", mGatewayInfo.gateway_version);
	LOGD(TAG, "IoT Sensor List: %d", mGatewayInfo.num_iot_sensor);
	for (int i = 0; i < mGatewayInfo.num_iot_sensor; i++)
	{
		LOGD(TAG, "BLE: %02X %02X %02X %02X %02X %02X, WiFi: %02X %02X %02X %02X %02X %02X, Type: %c, Location: %hhu, Direction: %hhu",
				mGatewayInfo.iot_sensor_info_list[i].ble[0], mGatewayInfo.iot_sensor_info_list[i].ble[1], mGatewayInfo.iot_sensor_info_list[i].ble[2], mGatewayInfo.iot_sensor_info_list[i].ble[3], mGatewayInfo.iot_sensor_info_list[i].ble[4], mGatewayInfo.iot_sensor_info_list[i].ble[5],
				mGatewayInfo.iot_sensor_info_list[i].wifi[0], mGatewayInfo.iot_sensor_info_list[i].wifi[1], mGatewayInfo.iot_sensor_info_list[i].wifi[2], mGatewayInfo.iot_sensor_info_list[i].wifi[3], mGatewayInfo.iot_sensor_info_list[i].wifi[4], mGatewayInfo.iot_sensor_info_list[i].wifi[5],
				mGatewayInfo.iot_sensor_info_list[i].type, mGatewayInfo.iot_sensor_info_list[i].location, mGatewayInfo.iot_sensor_info_list[i].direction);
	}

	LOGD(TAG, "SSID: %s, Auth Type: %d, Password: %s, IP Address: %d.%d.%d.%d, Port: %d",
			mGatewayInfo.iot_sensor_ap_info.ssid, mGatewayInfo.iot_sensor_ap_info.auth_type, mGatewayInfo.iot_sensor_ap_info.password, mGatewayInfo.iot_sensor_ap_info.ip_address[0], mGatewayInfo.iot_sensor_ap_info.ip_address[1], mGatewayInfo.iot_sensor_ap_info.ip_address[2], mGatewayInfo.iot_sensor_ap_info.ip_address[3], mGatewayInfo.iot_sensor_ap_info.port);
	LOGD(TAG, "Start Time: %02hhu:%02hhu, Stop Time: %02hhu:%02hhu, Sound Measurement Interval: %d",
			mGatewayInfo.regular_measurement_info.start_hour, mGatewayInfo.regular_measurement_info.start_minute, mGatewayInfo.regular_measurement_info.stop_hour, mGatewayInfo.regular_measurement_info.stop_minute, mGatewayInfo.regular_measurement_info.measurement_info.interval);

	LOGD(TAG, "=== Vibration Threshold Measurement Info ===");
	LOGD(TAG, "Measurement Time: %d, Sampling Rate: %d, # of Measurement: %d",
			mGatewayInfo.vibration_threshold_measurement_info.measurement_info.measurement_time, mGatewayInfo.vibration_threshold_measurement_info.measurement_info.sampling_rate, mGatewayInfo.vibration_threshold_measurement_info.measurement_info.num_measurement);

	LOGD(TAG, "IoT Sensor Measurement Info: noise: %d, %d, vibration %d, %d",
			mGatewayInfo.iot_sensor_measurement_info.noise_sensor_measurement_info.measurement_time, mGatewayInfo.iot_sensor_measurement_info.noise_sensor_measurement_info.sampling_rate,
			mGatewayInfo.iot_sensor_measurement_info.vibration_sensor_measurement_info.measurement_time, mGatewayInfo.iot_sensor_measurement_info.vibration_sensor_measurement_info.measurement_time);

	LOGD(TAG, "Equipment ID: %s, location: %d, Number of Data Stored: %d", mGatewayInfo.operating_info.equipment_id, mGatewayInfo.operating_info.location, mGatewayInfo.operating_info.num_data_stored);
	LOGD(TAG, "Equipment Info File: %s", mGatewayFile[FILE_EQUIPMENT_INFORMATION]);
	LOGD(TAG, "Fault Frequency File: %s", mGatewayFile[FILE_FAULT_FREQUENCY]);
	LOGD(TAG, "RMS Shaft Bearing File: %s", mGatewayFile[FILE_RMS_SHAFT_BEARING]);
	LOGD(TAG, "RMS Motor File: %s", mGatewayFile[FILE_RMS_MOTOR]);
	LOGD(TAG, "Vibration Threshold File: %s", mGatewayFile[FILE_VIBRATION_THRESHOLD]);
	LOGD(TAG, "Noise Threshold File: %s", mGatewayFile[FILE_NOISE_THRESHOLD]);
	LOGD(TAG, "Accumulated Noise Indicator: %s", mGatewayFile[FILE_ACCUMULATED_NOISE_INDICATOR]);
	LOGD(TAG, "==========================================================");
	free(tmp);
}

void CGatewayManager::WriteGatewayConfigFile()
{
#if 0
	Json::Value root;
	Json::Value operatingInfo;
	Json::Value measurementInfo;
	Json::Value iotSensorList;
	Json::Value iotSensorApInfo;
	Json::Value fileInfo;
	char tmp[30];
	Json::Value strValue;

	memset(tmp, 0, sizeof(tmp));
	ConvertHexToHexStr(mGatewayInfo.gateway_id, tmp, sizeof(mGatewayInfo.gateway_id));
	root["gatewayId"] = tmp;
	root["gatewayVersion"] = (char *)mGatewayInfo.gateway_version;
	root["isConfig"] = mGatewayInfo.is_config;

	operatingInfo["equipmentId"] = (char *)mGatewayInfo.operating_info.equipment_id;
	if(mGatewayInfo.operating_info.location == 1)
	{
		operatingInfo["location"] = "In";
	}
	else if(mGatewayInfo.operating_info.location == 2)
	{
		operatingInfo["location"] = "Out";
	}
	operatingInfo["numData"] = mGatewayInfo.operating_info.num_data_stored;
	root["operatingInfo"] = operatingInfo;

	memset(tmp,0,sizeof(tmp));
	sprintf(tmp,"%02hhu:%02hhu",mGatewayInfo.regular_measurement_info.start_hour,mGatewayInfo.regular_measurement_info.start_minute);
	measurementInfo["startTime"] = tmp;
	memset(tmp,0,sizeof(tmp));
	sprintf(tmp,"%02hhu:%02hhu",mGatewayInfo.regular_measurement_info.stop_hour,mGatewayInfo.regular_measurement_info.stop_minute);
	measurementInfo["stopTime"] = tmp;
	measurementInfo["soundMeasurementInterval"] = mGatewayInfo.regular_measurement_info.sound_measurement_interval;
	//measurementInfo["resultReportInterval"] = mGatewayInfo.regular_measurement_info.result_report_interval;
	//measurementInfo["isOverDay"] = mGatewayInfo.regular_measurement_info.is_over_day;
	//measurementInfo["soundMeasurementTime"] = mGatewayInfo.regular_measurement_info.sound_measurement_time;
	root["measurementInfo"] = measurementInfo;

	for(int index = 0 ; index < mGatewayInfo.num_iot_sensor; index++)
	{
		Json::Value iotSensorInfo;
		memset(tmp, 0, sizeof(tmp));
		ConvertHexToHexStr(mGatewayInfo.iot_sensor_info_list[index].ble, tmp, sizeof(mGatewayInfo.iot_sensor_info_list[index].ble));
		iotSensorInfo["mac"] = tmp;
		memset(tmp, 0, sizeof(tmp));
		ConvertHexToHexStr(mGatewayInfo.iot_sensor_info_list[index].wifi, tmp, sizeof(mGatewayInfo.iot_sensor_info_list[index].wifi));
		iotSensorInfo["wifi"] = tmp;
		memset(tmp, 0, sizeof(tmp));
		sprintf(tmp,"%c",mGatewayInfo.iot_sensor_info_list[index].type);
		iotSensorInfo["type"] = tmp;
		iotSensorInfo["location"] = mGatewayInfo.iot_sensor_info_list[index].location;
		iotSensorInfo["direction"] = mGatewayInfo.iot_sensor_info_list[index].direction;
		iotSensorList.append(iotSensorInfo);
	}
	root["iotSensorList"] = iotSensorList;

	iotSensorApInfo["ssid"] = (char *)mGatewayInfo.iot_sensor_ap_info.ssid;
	iotSensorApInfo["authType"] = mGatewayInfo.iot_sensor_ap_info.auth_type;
	iotSensorApInfo["password"] = (char *)mGatewayInfo.iot_sensor_ap_info.password;
	memset(tmp,0,sizeof(tmp));
	sprintf(tmp,"%d.%d.%d.%d",mGatewayInfo.iot_sensor_ap_info.ip_address[0],mGatewayInfo.iot_sensor_ap_info.ip_address[1],mGatewayInfo.iot_sensor_ap_info.ip_address[2],mGatewayInfo.iot_sensor_ap_info.ip_address[3]);
	iotSensorApInfo["ipAddress"] = tmp;
	iotSensorApInfo["port"] = mGatewayInfo.iot_sensor_ap_info.port;
	root["iotSensorApInfo"] = iotSensorApInfo;

	fileInfo["equipmentInfoFile"] = mGatewayFile[FILE_EQUIPMENT_INFORMATION];
	fileInfo["faultFrequencyFile"] = mGatewayFile[FILE_FAULT_FREQUENCY];
	fileInfo["rmsShaftBearingFile"] = mGatewayFile[FILE_RMS_SHAFT_BEARING];
	fileInfo["rmsMotorFile"] = mGatewayFile[FILE_RMS_MOTOR];
	fileInfo["vibrationThresholdFile"] = mGatewayFile[FILE_VIBRATION_THRESHOLD];
	fileInfo["noiseThresholdFile"] = mGatewayFile[FILE_NOISE_THRESHOLD];
	fileInfo["accumulatedNoiseIndicatorFile"] = mGatewayFile[FILE_ACCUMULATED_NOISE_INDICATOR];
	root["fileInfo"] = fileInfo;

#if 0
	FILE *fp = fopen(GATEWAY_INFO_FILE, "w");

	if (fp == NULL)
	{
		LOGE(TAG, "Gateway info file open error: %s", GATEWAY_INFO_FILE);
		return;
	}
#endif

	Json::StreamWriterBuilder Builder;
	std::unique_ptr<Json::StreamWriter> writer(Builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s, SIZE : %d", output.c_str(), strlen(output.c_str()));

#if 0
	fwrite(output.c_str(), strlen(output.c_str()), 1 ,fp);

	fclose(fp);
#endif
#endif
}

void CGatewayManager::RegisterGateway(COMMAND_TYPE lastCmd)
{
	switch(lastCmd)
	{
	case CMD_REQUEST_REGISTER_GATEWAY:
		{
			if (mStateMain != GATEWAY_STATE_IDLE)
			{
				LOGE(TAG, "Gateway is busy");
				break;
			}

			mStateMain = GATEWAY_STATE_REGISTER_GATEWAY;
			// 게이트웨이 ID 획득 -> BLE MAC Address
			MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_GET_MAC_ADDRESS, NULL, 0);
		}
		break;
	case CMD_GET_MAC_ADDRESS_RESPONSE:
		{
			// 게이트웨이 등록 메시지 전송
			MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_SERVERCOMM, CMD_REQUEST_REGISTER_GATEWAY, &mGatewayInfo, sizeof(struct GatewayInfo));
			// 타이머 동작, 일정 시간 내에 응답 메시지 없으면 재전송
		}
		break;
	case CMD_REQUEST_REGISTER_GATEWAY_RESPONSE:
		{
			// 타이머 정지
			mStateMain = GATEWAY_STATE_IDLE;

			// 게이트웨이 초기 설정이 되어 있으면, 상시 측정
		}
		break;
	default:
		{
		}
		break;
	}
}

void CGatewayManager::CmdGetMacAddressResponse(void *data, int size)
{
	char *mac = (char *)data;
	LOGD(TAG, "MAC: %02X %02X %02X %02X %02X %02X", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
	memcpy(mGatewayInfo.gateway_id, data, size);

	if (mStateMain == GATEWAY_STATE_REGISTER_GATEWAY)
	{
		RegisterGateway(CMD_GET_MAC_ADDRESS_RESPONSE);
	}
}

void CGatewayManager::CmdTimerExpired(void *data, int size)
{
	int timerId = size;

	switch(timerId)
	{
	case TIMER_HEART_BEAT:
		{
			LOGD(TAG, "TIMER_HEART_BEAT");
			//CheckHeartBeat();
		}
		break;
	case TIMER_REGULAR_MEASUREMENT:
		{
			LOGD(TAG, "TIMER_REGULAR_MEASUREMENT");
			DoRegularMeasurement();
		}
		break;
#ifdef REPORT_REGULAR_MEASUREMENT_RESULT
	case TIMER_REGULAR_MEASUREMENT_RESULT_REPORT:
		{
			LOGD(TAG, "TIMER_REGULAR_MEASUREMENT_RESULT_REPORT");
			ReportRegularMeasurementResult();
		}
		break;
#endif
	case TIMER_IOT_SENSOR_MEASUREMENT_WAIT:
		{
			LOGD(TAG, "TIMER_IOT_SENSOR_MEASUREMENT_WAIT");
			CTimer::GetInstance()->StopTimer(TIMER_IOT_SENSOR_MEASUREMENT_WAIT);
			switch(mStateMain)
			{
			case GATEWAY_STATE_MANUAL_MEASUREMENT:
				{
					DoManualMeasurement(CMD_REQUEST_IOT_SENSOR_MEASUREMENT_RESPONSE, NULL, 0);
				}
				break;
			case GATEWAY_STATE_VIBRATION_THRESHOLD_MEASUREMENT:
				{
					DoVibrationThresholdMeasurement(CMD_REQUEST_IOT_SENSOR_MEASUREMENT_RESPONSE, NULL, 0);
				}
				break;
			default:
				{
				}
				break;
			}
		}
		break;
	case TIMER_NOISE_THRESHOLD_MEASUREMENT:
		{
			LOGD(TAG, "TIMER_NOISE_THRESHOLD_MEASUREMENT");
			DoNoiseThresholdMeasurement(CMD_TIMER_EXPIRED, data, size);
		}
		break;
	case TIMER_STATUS_CHECK:
		{
			LOGD(TAG, "TIMER_STATUS_CHECK");
			DoStatusCheck();
		}
		break;
	default:
		{
			LOGE(TAG, "Not supported timer: %d", timerId);
		}
		break;
	}
}

void CGatewayManager::CmdSetOperatingInfo(void *data, int size)
{
	LOGD(TAG, "FUNC IN");

	struct GatewayInfo *recv = (struct GatewayInfo *)data;

	LOGD(TAG, "MAC: %02X %02X %02X %02X %02X %02X, Equipment Id: %s, Location: %d, Num Data: %d", recv->gateway_id[0], recv->gateway_id[1], recv->gateway_id[2], recv->gateway_id[3], recv->gateway_id[4], recv->gateway_id[5], recv->operating_info.equipment_id, recv->operating_info.location, recv->operating_info.num_data_stored);

	strcpy(mGatewayInfo.operating_info.equipment_id, recv->operating_info.equipment_id);
	mGatewayInfo.operating_info.location = recv->operating_info.location;
	mGatewayInfo.operating_info.num_data_stored = recv->operating_info.num_data_stored;

	MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_SERVERCOMM, CMD_SET_OPERATING_INFO_RESPONSE, &mGatewayInfo, sizeof(struct GatewayInfo));

	LOGD(TAG, "FUNC OUT");
}

void CGatewayManager::CmdSetMeasurementInfo(void *data, int size)
{
	LOGD(TAG, "FUNC IN");

	struct GatewayInfo *recv = (struct GatewayInfo *)data;

	LOGD(TAG, "MAC: %02X %02X %02X %02X %02X %02X, Start: %02d:%02d, Stop: %02d:%02d, Measurement Interval: %d", recv->gateway_id[0], recv->gateway_id[1], recv->gateway_id[2], recv->gateway_id[3], recv->gateway_id[4], recv->gateway_id[5],
			recv->regular_measurement_info.start_hour, recv->regular_measurement_info.start_minute, recv->regular_measurement_info.stop_hour, recv->regular_measurement_info.stop_minute, recv->regular_measurement_info.measurement_info.interval);

	mGatewayInfo.regular_measurement_info.start_hour = recv->regular_measurement_info.start_hour;
	mGatewayInfo.regular_measurement_info.start_minute = recv->regular_measurement_info.start_minute;
	mGatewayInfo.regular_measurement_info.stop_hour = recv->regular_measurement_info.stop_hour;
	mGatewayInfo.regular_measurement_info.stop_minute = recv->regular_measurement_info.stop_minute;
	mGatewayInfo.regular_measurement_info.measurement_info.interval = recv->regular_measurement_info.measurement_info.interval;
	mGatewayInfo.regular_measurement_info.result_report_interval = recv->regular_measurement_info.result_report_interval;

	MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_SERVERCOMM, CMD_SET_MEASUREMENT_INFO_RESPONSE, &mGatewayInfo, sizeof(struct GatewayInfo));

	LOGD(TAG, "FUNC OUT");
}
#if 0
void CGatewayManager::CheckHeartBeat()
{
	LOGD(TAG, "M1 Modem: %d, EmRouter: %d, Mcu: %d", mHeartBeatCount[HEART_BEAT_M1MODEM], mHeartBeatCount[HEART_BEAT_EMROUTER], mHeartBeatCount[HEART_BEAT_MCU]);

	// 카운터 값 체크, threshold 보다 낮으면 heart beat 요청 보냄. 높으면 이벤트 통보
}
#endif
// ********************************************
// IoT Sensor Register, Info & Reset
// ********************************************
void CGatewayManager::CmdSetIotSensorListInfo(void *data, int size)
{
	LOGD(TAG, "FUNC IN");

	struct GatewayInfo *recv = (struct GatewayInfo *)data;

	LOGD(TAG, "MAC: %02X %02X %02X %02X %02X %02X, num: %d", recv->gateway_id[0], recv->gateway_id[1], recv->gateway_id[2], recv->gateway_id[3], recv->gateway_id[4], recv->gateway_id[5], recv->num_iot_sensor);

	memset(mGatewayInfo.iot_sensor_info_list, 0x00, sizeof(struct IotSensorInfo) * 10);

	mTargetDeviceList.clear();

	for (int i = 0; i < recv->num_iot_sensor; i++)
	{
		LOGD(TAG, "MAC: %02X %02X %02X %02X %02X %02X, WiFi: %02X %02X %02X %02X %02X %02X, Type: %d, Location: %d, Direction: %d",
				recv->iot_sensor_info_list[i].ble[0], recv->iot_sensor_info_list[i].ble[1], recv->iot_sensor_info_list[i].ble[2], recv->iot_sensor_info_list[i].ble[3], recv->iot_sensor_info_list[i].ble[4], recv->iot_sensor_info_list[i].ble[5],
				recv->iot_sensor_info_list[i].wifi[0], recv->iot_sensor_info_list[i].wifi[1], recv->iot_sensor_info_list[i].wifi[2], recv->iot_sensor_info_list[i].wifi[3], recv->iot_sensor_info_list[i].wifi[4], recv->iot_sensor_info_list[i].wifi[5],
				recv->iot_sensor_info_list[i].type, recv->iot_sensor_info_list[i].location, recv->iot_sensor_info_list[i].direction);

		memcpy(mGatewayInfo.iot_sensor_info_list[i].ble, recv->iot_sensor_info_list[i].ble, 6);
		memcpy(mGatewayInfo.iot_sensor_info_list[i].wifi, recv->iot_sensor_info_list[i].wifi, 6);
		mGatewayInfo.iot_sensor_info_list[i].type = recv->iot_sensor_info_list[i].type;
		mGatewayInfo.iot_sensor_info_list[i].location = recv->iot_sensor_info_list[i].location;
		mGatewayInfo.iot_sensor_info_list[i].direction = recv->iot_sensor_info_list[i].direction;

		char buf[13];
		memset(buf, 0x00, 13);
		ConvertCharMacToStrMac(recv->iot_sensor_info_list[i].ble, 6, buf, 13);

		mTargetDeviceList.push_back(i);
	}

	RegisterIotSensor(CMD_REQUEST_REGISTER_IOT_SENSOR, NULL, 0);
	LOGD(TAG, "FUNC OUT");
}

void CGatewayManager::RegisterIotSensor(COMMAND_TYPE lastCmd, void *data, int size)
{
	LOGD(TAG, "Device List = %d, Cmd: %d", mTargetDeviceList.size(), lastCmd);

	if (mTargetDeviceList.size() == 0)
	{
		LOGE(TAG, "Device List is empty");
		return;
	}
	uint8_t mac[6];

	switch (lastCmd)
	{
	case CMD_REQUEST_REGISTER_IOT_SENSOR:
		{
			if (mStateMain != GATEWAY_STATE_IDLE)
			{
				LOGE(TAG, "Gateway is busy. state: %d", mStateMain);
				return;
			}
			mStateMain = GATEWAY_STATE_REGISTER_IOT_SENSOR;

			// 디바이스 목록을 읽어와서 mac 주소 결정
			mCurrentIndex = 0;
			memcpy(mac, mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[mCurrentIndex]].ble, IOT_SENSOR_BLE_MAC_ADDRESS_LENGTH);
			LOGD(TAG, "%d/%d : %d) %02X %02X %02X %02X %02X %02X", mCurrentIndex + 1, mTargetDeviceList.size(), mTargetDeviceList[mCurrentIndex], mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
			mCurrentIndex++;

			CTimer::GetInstance()->SetTimer(MODULE_GATEWAY, TIMER_BLE_CONNECTION, BLE_SENSOR_CONNECTION_WAIT, 0);

			MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_REQUEST_CONNECT_DEVICE, mac, 6);
		}
		break;
#if 0
	case CMD_REQUEST_CONNECT_DEVICE_RESPONSE:
		{
		}
		break;
	case CMD_REQUEST_START_SCAN_RESPONSE:
		MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_REQUEST_DEVICE_FIRMWARE_VERSION, NULL, 0);
		break;
	case CMD_REQUEST_DEVICE_FIRMWARE_VERSION_RESPONSE:
		MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_GET_DEVICE_INFO, NULL, 0);
		break;
	case CMD_GET_DEVICE_INFO_RESPONSE:
		MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_REQUEST_VALIDATION, NULL, 0);
		break;
	case CMD_REQUEST_VALIDATION_RESPONSE:
		// validation이 완료되면 새로운 디바이스를 추가
		ConvertAndAddDeviceList((uint8_t *)data, 6);

		MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_REQUEST_STOP_SCAN, NULL, 0);
		break;
	case CMD_REQUEST_STOP_SCAN_RESPONSE:
		LOGD(TAG, "Stop Scan");
		//StopTimer(&stateTimer);
		//ResponsePendingCmd();
		MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_MODULE_RESET, NULL, 0);
		mStateMain = GATEWAY_STATE_IDLE;
		break;
#endif
	default:
		break;
	}
}

void CGatewayManager::CmdGetIotSensorInfo(void *data, int size)
{
	GetIotSensorInfo(CMD_GET_IOT_SENSOR_INFO, data, size);
}

void CGatewayManager::GetIotSensorInfo(COMMAND_TYPE lastCmd, void *data, int size)
{
	uint8_t mac[IOT_SENSOR_BLE_MAC_ADDRESS_LENGTH] = {0x00};

	switch(lastCmd)
	{
	case CMD_GET_IOT_SENSOR_INFO:
		{
			if (mStateMain != GATEWAY_STATE_IDLE)
			{
				LOGE(TAG, "Gateway is busy");
				break;
			}

			mStateMain = GATEWAY_STATE_GET_IOT_SENSOR_INFO;
			memcpy(mac, data, IOT_SENSOR_BLE_MAC_ADDRESS_LENGTH);
			LOGD(TAG, "MAC: %02X %02X %02X %02X %02X %02X", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
			MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_REQUEST_CONNECT_DEVICE, mac, 6);
		}
		break;
	case CMD_REQUEST_CONNECT_DEVICE_RESPONSE:
		{
			MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_GET_DEVICE_INFO, NULL, 0);
		}
		break;
	case CMD_GET_DEVICE_INFO_RESPONSE:
		{
			/// 배터리 정보 업데이트
			MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_REQUEST_DISCONNECT_DEVICE, NULL, 0);
		}
		break;
	case CMD_REQUEST_DISCONNECT_DEVICE_RESPONSE:
		{
			LOGD(TAG, "Done");
			mStateMain = GATEWAY_STATE_IDLE;
		}
		break;
	default:
		{
		}
		break;
	}
}

void CGatewayManager::CmdRequestFactoryResetIotSensor(void *data, int size)
{
	ResetIotSensor(CMD_REQUEST_FACTORY_RESET_IOT_SENSOR, data, size);
}

void CGatewayManager::ResetIotSensor(COMMAND_TYPE lastCmd, void *data, int size)
{
	uint8_t mac[IOT_SENSOR_BLE_MAC_ADDRESS_LENGTH] = {0x00};
	uint8_t reset_param_file[1] = {0x01};

	switch(lastCmd)
	{
	case CMD_REQUEST_FACTORY_RESET_IOT_SENSOR:
		{
			if (mStateMain != GATEWAY_STATE_IDLE)
			{
				LOGE(TAG, "Gateway is busy");
				break;
			}

			mStateMain = GATEWAY_STATE_RESET_IOT_SENSOR;
			memcpy(mac, data, IOT_SENSOR_BLE_MAC_ADDRESS_LENGTH);
			LOGD(TAG, "MAC: %02X %02X %02X %02X %02X %02X", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
			MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_REQUEST_CONNECT_DEVICE, mac, 6);
		}
		break;
	case CMD_REQUEST_CONNECT_DEVICE_RESPONSE:
		{
			MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_GET_DEVICE_INFO, NULL, 0);
		}
		break;
	case CMD_GET_DEVICE_INFO_RESPONSE:
		{
			/// 배터리 정보 업데이트
			MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_RESET_SENSOR_INFO, reset_param_file, 1);
			sleep(1);
			MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_REQUEST_DISCONNECT_DEVICE, NULL, 0);
		}
		break;
	case CMD_REQUEST_DISCONNECT_DEVICE_RESPONSE:
		{
			LOGD(TAG, "Done");
			mStateMain = GATEWAY_STATE_IDLE;
		}
		break;
	default:
		{
		}
		break;
	}
}
// ********************************************
// Init Process
// ********************************************
void CGatewayManager::CmdRequestStartInitProcess()
{
	// 내부 상태를 초기화 상태로

	MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_SERVERCOMM, CMD_REQUEST_START_INIT_PROCESS_RESPONSE, NULL, 0);
}

void CGatewayManager::CmdRequestEndInitProcess()
{
	// 내부 상태를 초기화 종료 상태로

	MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_SERVERCOMM, CMD_REQUEST_END_INIT_PROCESS_RESPONSE, NULL, 0);
}

// ********************************************
// Regular Measurement
// ********************************************
void CGatewayManager::DoRegularMeasurement()
{
	time_t ttStart, ttNow, ttStop;
	struct tm tmStart, tmNow, tmStop;

	ttNow = time(NULL);
	localtime_r(&ttNow, &tmNow);

	tmStart.tm_year = tmNow.tm_year;
	tmStart.tm_mon = tmNow.tm_mon;
	tmStart.tm_mday = tmNow.tm_mday;
	tmStart.tm_hour = mGatewayInfo.regular_measurement_info.start_hour;
	tmStart.tm_min = mGatewayInfo.regular_measurement_info.start_minute;
	tmStart.tm_sec = 0;

	tmStop.tm_year = tmNow.tm_year;
	tmStop.tm_mon = tmNow.tm_mon;
	tmStop.tm_mday = tmNow.tm_mday + (mGatewayInfo.regular_measurement_info.is_over_day == true ? 1: 0);
	tmStop.tm_hour = mGatewayInfo.regular_measurement_info.stop_hour;
	tmStop.tm_min = mGatewayInfo.regular_measurement_info.stop_minute;
	tmStop.tm_sec = 59;

	ttStart = mktime(&tmStart);
	ttStop = mktime(&tmStop);

	LOGD(TAG, "Start: %02d:%02d.%02d (%d), NOW: %02d:%02d.%02d (%d), Stop: %02d:%02d.%02d (%d)",
		tmStart.tm_hour, tmStart.tm_min, tmStart.tm_sec, ttStart, tmNow.tm_hour, tmNow.tm_min, tmNow.tm_sec, ttNow, tmStop.tm_hour, tmStop.tm_min, tmStop.tm_sec, ttStop);

	if ((ttStart <= ttNow) && (ttNow <= ttStop))
	{
		LOGD(TAG, "Regular Measurement Time!");

		struct MeasurementDataFileInfo info;
		memset(&info, 0x00, sizeof(struct MeasurementDataFileInfo));

		strcpy(info.equipment_id, "ICTR01");
		info.location = 'I';
		info.measurement_time = 5;
		info.sample_rate = 50000;
		info.channel = 1;
		info.tag = 'G';
		strcpy(info.sub_dir_name, "regular");

		MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_ADC, CMD_REQUEST_REGULAR_MEASUREMENT, &info, sizeof(struct MeasurementDataFileInfo));
	}
	else
	{
		LOGD(TAG, "NOT Regular Measurement Time!");
	}
}

void CGatewayManager::CmdRegularMeasurementResponse(void *data, int size)
{
	struct MeasurementDataFileInfo *info = (struct MeasurementDataFileInfo *)data;

	LOGD(TAG, "equipment_id: %s, location: %d, timestamp: %d.%d, measurement_time: %d, sample_rate: %d, channel: %d, tag: %d, file_name: %s",
			info->equipment_id, info->location, info->timestamp.tv_sec, info->timestamp.tv_nsec, info->measurement_time, info->sample_rate, info->channel, info->tag, info->file_name);

	diagnostic_info diagInfo;
	memset(&diagInfo, 0x00, sizeof(struct diagnostic_info));

	diagInfo.timestamp.data = info->timestamp;

	char numFile[FILE_PATH_LENGTH];
	memset(numFile, 0x00, FILE_PATH_LENGTH);
	strcpy(numFile, info->file_name);
	ChangeFileExt(numFile, "num");
	LOGD(TAG, "Num File Name: %s", numFile);

	ConvertRawFileToNumFile(info->file_name, numFile, 1);

	strcpy(diagInfo.info_file, mGatewayFile[FILE_EQUIPMENT_INFORMATION]);
	strcpy(diagInfo.data_file[0], numFile);
	strcpy(diagInfo.data_file[1], mGatewayFile[FILE_ACCUMULATED_NOISE_INDICATOR]);
	strcpy(diagInfo.data_file[2], mGatewayFile[FILE_NOISE_THRESHOLD]);
	diagInfo.value8 = mGatewayInfo.operating_info.location;

	MessageQueue::GetInstance()->SendMessage(MODULE_SYSTEM, MODULE_DIAGNOSTIC, CMD_DIAGNOSE_NOISE_ANOMALY, &diagInfo, sizeof(struct diagnostic_info));
}

void CGatewayManager::CmdDiagnoseNoiseAnomalyResponse(void *data, int size)
{
	struct diagnostic_result *diagRes = (struct diagnostic_result *)data;

	LOGD(TAG, "Time: %d.%09d - (%d) - %d.%09d - (%d) - %d.%09d, Operation: %d, anomaly: %d, Index: %f",
			diagRes->timestamp.data.tv_sec, diagRes->timestamp.data.tv_nsec, (diagRes->timestamp.request.tv_sec - diagRes->timestamp.data.tv_sec) * 1000 + (diagRes->timestamp.request.tv_nsec - diagRes->timestamp.data.tv_nsec) / 1000 / 1000,
			diagRes->timestamp.request.tv_sec, diagRes->timestamp.request.tv_nsec, (diagRes->timestamp.response.tv_sec - diagRes->timestamp.request.tv_sec) * 1000 + (diagRes->timestamp.response.tv_nsec - diagRes->timestamp.request.tv_nsec) / 1000 / 1000,
			diagRes->timestamp.response.tv_sec, diagRes->timestamp.response.tv_nsec,
			diagRes->extra_info.noise_anomaly.operation, diagRes->extra_info.noise_anomaly.anomaly, diagRes->extra_info.noise_anomaly.index);

#ifdef REPORT_REGULAR_MEASUREMENT_RESULT
	struct RegularMeasurementResult res;
	res.timestamp = diagRes->timestamp.data;
	res.operation = diagRes->extra_info.noise_anomaly.operation;
	res.anomaly = diagRes->extra_info.noise_anomaly.anomaly;
	res.indicator = diagRes->extra_info.noise_anomaly.index;
	mRegularMeasurementResultList.push_back(res);
#endif
	// 진단 알고리즘 결과에 따라 동작
	// 운행 상태 변경 -> 서버로 알림
	// 운행 중 + 상태 이상 -> 정밀 진단
	// 운행 중 + 샘플 데이터 수집 -> 샘플 데이터 디렉토리로 복사
}

#ifdef REPORT_REGULAR_MEASUREMENT_RESULT
void CGatewayManager::ReportRegularMeasurementResult()
{
	int numRes = mRegularMeasurementResultList.size();

	struct RegularMeasurementResultSet resultSet;
	memset(&resultSet, 0x00, sizeof(struct RegularMeasurementResultSet));

	for (int i = 0; i < numRes; i++)
	{
		struct RegularMeasurementResult res = mRegularMeasurementResultList.front();
		LOGD(TAG, "timestamp: %d", res.timestamp.tv_sec);
		memcpy(&resultSet.res[i], &res, sizeof(struct RegularMeasurementResult));
	}
	resultSet.num_result = numRes;
	LOGD(TAG, "List: %d", mRegularMeasurementResultList.size());

	MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_SERVERCOMM, CMD_SET_REGULAR_MEASUREMENT_RESULT, &resultSet, sizeof(struct RegularMeasurementResultSet));
}
#endif

// ********************************************
// IoT Sensor Measurement & Data Download
// ********************************************
void CGatewayManager::SetTargetSyncTime(uint32_t sec)
{
	clock_gettime(CLOCK_REALTIME, &mTargetSyncTime);

	mTargetSyncTime.tv_sec += sec;

	struct tm tmNow;
	localtime_r(&mTargetSyncTime.tv_sec, &tmNow);

	LOGD(TAG, "TargetTime: %02d-%02d-%02d(%1d) %02d:%02d:%02d",
		tmNow.tm_year - 100, tmNow.tm_mon + 1, tmNow.tm_mday, (tmNow.tm_wday == 0) ? 7 : tmNow.tm_wday, tmNow.tm_hour, tmNow.tm_min, tmNow.tm_sec);
}

void CGatewayManager::CmdRequestIotSensorMeasurement(void *data, int size)
{
	// Target Device List 설정

	DoIotSensorMeasurement(CMD_REQUEST_IOT_SENSOR_MEASUREMENT, data, size);
}

void CGatewayManager::DoIotSensorMeasurement(COMMAND_TYPE lastCmd, void* data, int size)
{
	LOGD(TAG, "Device List = %d, Cmd: %d", mTargetDeviceList.size(), lastCmd);

	if (mTargetDeviceList.size() == 0)
	{
		LOGE(TAG, "Device List is empty");
		return;
	}

	int syncTime = 10 * mTargetDeviceList.size();

	uint8_t mac[6] = {0x00};

	switch (lastCmd)
	{
	case CMD_REQUEST_IOT_SENSOR_MEASUREMENT:
		mIsAllDeviceStartMeasurement = true;

		SetTargetSyncTime(syncTime);

		mCurrentIndex = 0;
		memcpy(mac, mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[mCurrentIndex]].ble, IOT_SENSOR_BLE_MAC_ADDRESS_LENGTH);
		LOGD(TAG, "%d/%d : %d) %02X %02X %02X %02X %02X %02X", mCurrentIndex + 1, mTargetDeviceList.size(), mTargetDeviceList[mCurrentIndex], mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);

		CTimer::GetInstance()->SetTimer(MODULE_GATEWAY, TIMER_BLE_CONNECTION, BLE_SENSOR_CONNECTION_WAIT, 0);

		MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_REQUEST_CONNECT_DEVICE, mac, 6);
		break;
	case CMD_REQUEST_CONNECT_DEVICE_RESPONSE:
		{
			struct MeasurementDataFileInfo info;
			memset(&info, 0x00, sizeof(struct MeasurementDataFileInfo));

			LOGD(TAG, "Type: %c", mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[mCurrentIndex]].type);
			switch(mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[mCurrentIndex]].type)
			{
			case 'V':
				{
					if (mStateMain == GATEWAY_STATE_VIBRATION_THRESHOLD_MEASUREMENT)
					{
						info.measurement_time = mGatewayInfo.vibration_threshold_measurement_info.measurement_info.measurement_time * mGatewayInfo.vibration_threshold_measurement_info.measurement_info.num_measurement;
						info.sample_rate = mGatewayInfo.vibration_threshold_measurement_info.measurement_info.sampling_rate;
					}
					else
					{
						info.measurement_time = mGatewayInfo.iot_sensor_measurement_info.vibration_sensor_measurement_info.measurement_time;
						info.sample_rate = mGatewayInfo.iot_sensor_measurement_info.vibration_sensor_measurement_info.sampling_rate;
					}
					LOGD(TAG, "Set Vibration Sensor, Measurement Time: %d, Sampling Rate: %d", info.measurement_time, info.sample_rate);
				}
				break;
			case 'N':
				{
					LOGD(TAG, "Set Noise Sensor, Measurement Time: %d, Sampling Rate: %d", mGatewayInfo.iot_sensor_measurement_info.noise_sensor_measurement_info.measurement_time, mGatewayInfo.iot_sensor_measurement_info.noise_sensor_measurement_info.sampling_rate);
					info.measurement_time = mGatewayInfo.iot_sensor_measurement_info.noise_sensor_measurement_info.measurement_time;
					info.sample_rate = mGatewayInfo.iot_sensor_measurement_info.noise_sensor_measurement_info.sampling_rate;
				}
				break;
			default:
				{
					LOGD(TAG, "Set Noise Sensor, Measurement Time: %d, Sampling Rate: %d", mGatewayInfo.iot_sensor_measurement_info.noise_sensor_measurement_info.measurement_time, mGatewayInfo.iot_sensor_measurement_info.noise_sensor_measurement_info.sampling_rate);
					info.measurement_time = mGatewayInfo.iot_sensor_measurement_info.noise_sensor_measurement_info.measurement_time;
					info.sample_rate = mGatewayInfo.iot_sensor_measurement_info.noise_sensor_measurement_info.sampling_rate;
				}
				break;
			}

			MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_SET_MEASUREMENT_CONFIG, &info, sizeof(struct MeasurementDataFileInfo));
		}
		break;
	case CMD_SET_MEASUREMENT_CONFIG_RESPONSE:
		MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_GET_DEVICE_INFO, NULL, 0);
		break;
	case CMD_GET_DEVICE_INFO_RESPONSE:
		//MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_REQUEST_DISCONNECT_DEVICE, NULL, 0);
		MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_REQUEST_TIME_SYNC, (void *)&mTargetSyncTime, sizeof(mTargetSyncTime));
		break;
	case CMD_REQUEST_TIME_SYNC_RESPONSE:
		MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_REQUEST_DISCONNECT_DEVICE, NULL, 0);
		break;
	case CMD_REQUEST_DISCONNECT_DEVICE_RESPONSE:
		CTimer::GetInstance()->StopTimer(TIMER_BLE_CONNECTION);
		mCurrentIndex++;
		if (mCurrentIndex >= mTargetDeviceList.size())
		{
			LOGD(TAG, "All Done, mIsAllDeviceStartMeasurement: %d", mIsAllDeviceStartMeasurement);

			struct timespec tsNow;
			clock_gettime(CLOCK_REALTIME, &tsNow);

			int diff = (mTargetSyncTime.tv_sec - tsNow.tv_sec) * 1000 + (mTargetSyncTime.tv_nsec - tsNow.tv_nsec) / (1000 * 1000);

			int measurementTime;
			if (mStateMain == GATEWAY_STATE_VIBRATION_THRESHOLD_MEASUREMENT)
			{
				measurementTime = mGatewayInfo.vibration_threshold_measurement_info.measurement_info.measurement_time * mGatewayInfo.vibration_threshold_measurement_info.measurement_info.num_measurement;
			}
			else
			{
				measurementTime = Max(mGatewayInfo.iot_sensor_measurement_info.noise_sensor_measurement_info.measurement_time, mGatewayInfo.iot_sensor_measurement_info.vibration_sensor_measurement_info.measurement_time);
			}
			int end = diff + (measurementTime + 2) * 1000;

			CTimer::GetInstance()->SetTimer(MODULE_GATEWAY, TIMER_IOT_SENSOR_MEASUREMENT_WAIT, end / 1000, end % 1000);
		}
		else
		{
			// 리스트의 다음 mac 주소
			memcpy(mac, mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[mCurrentIndex]].ble, IOT_SENSOR_BLE_MAC_ADDRESS_LENGTH);

			LOGD(TAG, "%d/%d : %d) %02X %02X %02X %02X %02X %02X", mCurrentIndex + 1, mTargetDeviceList.size(), mTargetDeviceList[mCurrentIndex], mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);

			CTimer::GetInstance()->SetTimer(MODULE_GATEWAY, TIMER_BLE_CONNECTION, BLE_SENSOR_CONNECTION_WAIT, 0);
			MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_REQUEST_CONNECT_DEVICE, mac, 6);
		}
		break;
	default:
		break;
	}
}

void CGatewayManager::DownloadDataFromSingleDevice(COMMAND_TYPE lastCmd, void* data, int size)
{
	// const int wifiConnectionTimeout = 40;
	LOGD(TAG, "FUNC IN");

	int isError = false;
	uint8_t *ack = (uint8_t *)data;

	uint8_t mac[IOT_SENSOR_BLE_MAC_ADDRESS_LENGTH] = {0x00};

	uint8_t file_index[2] = {0x00, 0x01};
	uint8_t reset_param_file[1] = {0x01};

	switch (lastCmd)
	{
	case CMD_REQUEST_DOWNLOAD_DATA_SINGLE_DEVICE:
		{
			LOGD(TAG, "CMD_REQUEST_DOWNLOAD_DATA_SINGLE_DEVICE");

			mIsDownloadSuccess = false;
			memcpy(mac, data, IOT_SENSOR_BLE_MAC_ADDRESS_LENGTH);
			LOGD(TAG, "MAC: %02X %02X %02X %02X %02X %02X", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
			MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_REQUEST_CONNECT_DEVICE, mac, 6);
		}
		break;
	case CMD_REQUEST_CONNECT_DEVICE_RESPONSE:
		{
			MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_GET_DEVICE_INFO, NULL, 0);
		}
		break;
	case CMD_GET_DEVICE_INFO_RESPONSE:
		{
			/// 배터리 정보 업데이트
			MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_GET_DEVICE_NAME, NULL, 0);
		}
		break;
	case CMD_GET_DEVICE_NAME_RESPONSE:
		{
			char iotSensorName[IOT_SENSOR_MAX_NAME_LENGTH] = {0x00};
			memcpy(iotSensorName, data, size);
			LOGD(TAG, "IoT Sensor Name: %s", iotSensorName);

			MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_GET_FILE_LIST, NULL, 0);
		}
		break;
	case CMD_GET_FILE_LIST_RESPONSE:
		{
			isError = ReadFileList(data, size);
			LOGD(TAG, "isError: %d, mSensorStoredFileList size: %d", isError, mSensorStoredFileList.size());

			if (isError == true)
			{
				MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_RESET_SENSOR_INFO, reset_param_file, 1);
				sleep(1);
				MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_REQUEST_DISCONNECT_DEVICE, NULL, 0);
			}
			else if (mSensorStoredFileList.empty())
			{
				MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_REQUEST_DISCONNECT_DEVICE, NULL, 0);
			}
			else
			{
				MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_WIFI, CMD_START_AP, NULL, 0);
			}
		}
		break;
	case CMD_START_AP_RESPONSE:
		{
			struct WifiApInfo wifi;
			memset(&wifi, 0x00, sizeof(struct WifiApInfo));

			wifi.control[0] = 0x01;
			wifi.control[1] = 0x01;
			strcpy(wifi.ssid, mGatewayInfo.iot_sensor_ap_info.ssid);
			wifi.auth_type = mGatewayInfo.iot_sensor_ap_info.auth_type;
			strcpy(wifi.password, mGatewayInfo.iot_sensor_ap_info.password);
			wifi.ip_address[0] = mGatewayInfo.iot_sensor_ap_info.ip_address[0];
			wifi.ip_address[1] = mGatewayInfo.iot_sensor_ap_info.ip_address[1];
			wifi.ip_address[2] = mGatewayInfo.iot_sensor_ap_info.ip_address[2];
			wifi.ip_address[3] = mGatewayInfo.iot_sensor_ap_info.ip_address[3];
			wifi.port = mGatewayInfo.iot_sensor_ap_info.port;

			MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_OPEN_WIFI, &wifi, sizeof(struct WifiApInfo));
		}
		break;
	case CMD_OPEN_WIFI_RESPONSE:
		{
			LOGD(TAG, "CMD_OPEN_WIFI_RESPONSE Request!! ACK: %02X", ack[0]);
			switch(ack[0])
			{
			case 0x12:
				{
					// Open
					LOGD(TAG, "Open");
#if 0
					struct wifi_response *res = (struct wifi_response *)data;
					//LOGD(TAG, "IP: %d.%d,%d,%d, Port: %d, MAC: %02X:%02X:%02X:%02X:%02X:%02X", res->ip[0], res->ip[1], res->ip[2], res->ip[3], (res->port[0] << 8) + res->port[1], res->mac[0], res->mac[1], res->mac[2], res->mac[3], res->mac[4], res->mac[5]);
					memcpy(mWifiMac, res->mac, 6);
					//StopTimer(&stateTimer);
					StopTimer(&mTimerWifiConnectionWait);
					LOGD(TAG, "BLE Device Name: %s (Len = %d), WiFi MAC: %02X:%02X:%02X:%02X:%02X:%02X", mBleDeviceName, mBleDeviceNameLength, mWifiMac[0], mWifiMac[1], mWifiMac[2], mWifiMac[3], mWifiMac[4], mWifiMac[5]);
					SetTimer(TIMER_WIFI_CONNECTION, &mTimerWifiConnectionWait, WIFI_CONNECTION_TIMEOUT, 0);
					MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_WIFI, CMD_CONNECT_WIFI, mWifiMac, 6);
					mOpenWifiRetryCount = 0;
#endif
				}
				break;
			case 0x13:
			case 0x14:
			case 0x15:
				{
					// Open Error
					LOGD(TAG, "Open Error");
#if 0
					StopTimer(&mTimerWifiConnectionWait);
					MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_OPEN_WIFI, wifi_control_param_close, 3);
#endif
				}
				break;
			case 0x21:
				{
					// close
					LOGD(TAG, "Close");
					MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_WIFI, CMD_STOP_AP, NULL, 0);
				}
				break;
			case 0x11:
				{
					LOGD(TAG, "Connected");
#if 0
					StopTimer(&mTimerWifiConnectionWait);
#endif

#if 0
					SetTimer(TIMER_WIFI_CONNECTION, &mTimerWifiConnectionWait, 30, 0);
#endif

					usleep(500 * 1000);

					struct MeasurementDataFileInfo *fileInfo;
					fileInfo = mSensorStoredFileList.back();

					strcpy(fileInfo->equipment_id, "ICTR01");
					fileInfo->location = mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[mCurrentIndex]].location;
					switch(mStateMain)
					{
					case GATEWAY_STATE_EMERGENCY_DIAGNOSIS:
						strcpy(fileInfo->sub_dir_name, "emergency");
						break;
					case GATEWAY_STATE_MANUAL_DIAGNOSIS:
						strcpy(fileInfo->sub_dir_name, "manual");
						break;
					case GATEWAY_STATE_PERIODIC_DIAGNOSIS:
						strcpy(fileInfo->sub_dir_name, "periodic");
						break;
					case GATEWAY_STATE_VIBRATION_THRESHOLD_DIAGNOSIS:
						strcpy(fileInfo->sub_dir_name, "vib_threshold");
						break;
					default:
						strcpy(fileInfo->sub_dir_name, "unknown");
						break;
					}

					LOGD(TAG, "Index: %d, Size: %d, Type: %d, Name: %s", fileInfo->index, fileInfo->size, fileInfo->tag, fileInfo->file_name);
					MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_WIFI, CMD_DOWNLOAD_FILE, fileInfo, sizeof(struct MeasurementDataFileInfo));

					file_index[1] = mSensorStoredFileList.size();
					LOGD(TAG, "File Index: %02x %02x", file_index[0], file_index[1]);
					MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_DOWNLOAD_FILE, file_index, 2);
				}
				break;
			default:
				LOGD(TAG, "Unkonw ACK: %02X", ack[0]);
			}
		}
		break;
	case CMD_DOWNLOAD_FILE_RESPONSE:
		{
			LOGD(TAG, "CMD_DOWNLOAD_FILE_RESPONSE, ACK: %02X", ack[0]);

			switch(ack[0])
			{
			case 0x02: // In Progress
				break;
			case 0x01: // Success
				mIsDownloadSuccess = true;
			case 0x03: // Fail
			case 0x04: // Checksum Error, for Debugging
			case 0x05: // Socket Connection Fail
			default:
				{
					struct WifiApInfo wifi;
					memset(&wifi, 0x00, sizeof(struct WifiApInfo));

					wifi.control[0] = 0x02;
					wifi.control[1] = 0x01;
					strcpy(wifi.ssid, mGatewayInfo.iot_sensor_ap_info.ssid);
					wifi.auth_type = mGatewayInfo.iot_sensor_ap_info.auth_type;
					strcpy(wifi.password, mGatewayInfo.iot_sensor_ap_info.password);
					wifi.ip_address[0] = mGatewayInfo.iot_sensor_ap_info.ip_address[0];
					wifi.ip_address[1] = mGatewayInfo.iot_sensor_ap_info.ip_address[1];
					wifi.ip_address[2] = mGatewayInfo.iot_sensor_ap_info.ip_address[2];
					wifi.ip_address[3] = mGatewayInfo.iot_sensor_ap_info.ip_address[3];
					wifi.port = mGatewayInfo.iot_sensor_ap_info.port;

					MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_OPEN_WIFI, &wifi, sizeof(struct WifiApInfo));
				}
				break;
			}
		}
		break;
	case CMD_STOP_AP_RESPONSE:
		{
			// 여기서 파일명 받을 것
			LOGD(TAG, "Downlaod Success: %d", mIsDownloadSuccess);
			if (mIsDownloadSuccess == true)
			{
				LOGD(TAG, "mCurrentIndex: %d, List Index: %d", mCurrentIndex, mTargetDeviceList[mCurrentIndex]);
				memcpy(mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[mCurrentIndex]].data_info, data, size);
				LOGD(TAG, "Raw file: %s, data: %p, size: %d", mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[mCurrentIndex]].data_info, data, size);

				MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_RESET_SENSOR_INFO, reset_param_file, 1);

				sleep(1);
			}

			MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_REQUEST_DISCONNECT_DEVICE, NULL, 0);

#if 0
					if (mOpenWifiRetryCount > 0)
					{
						MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_OPEN_WIFI, wifi_control_param_open, 3);
						mOpenWifiRetryCount--;
						LOGD(TAG, "Open Wi-Fi Retry! Count = %d", mOpenWifiRetryCount);
					}
					else
					{
						LOGD(TAG, "Wi-Fi Close, mIsDownloadSuccess: %d, mDownloadRetryCount: %d", mIsDownloadSuccess, mDownloadRetryCount);
						if ((mIsDownloadSuccess == true) || (mDownloadRetryCount == 0))
						{
							MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_RESET_SENSOR_INFO, reset_param_file, 1);
						}
						sleep(1);
						MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_REQUEST_DISCONNECT_DEVICE, NULL, 0);
					}
#endif
		}
		break;
	case CMD_REQUEST_DISCONNECT_DEVICE_RESPONSE:
#if 0
		if (mIsDownloadSuccess == false)
		{
			LOGD(TAG, "Error Device: Pos: %d, MAC: %s", mCurrentIndex, mTargetDeviceList[mCurrentIndex].c_str());
			mErrorDeviceList.push_back(mTargetDeviceList[mCurrentIndex]);
		}
		StopTimer(&mTimerWifiConnectionWait);
		//StopTimer(&stateTimer);	// 다운로드할 파일이 없는 경우 바로 disconnect가 되는데, 이 때도 Stop이 필요하다 (정상적으로 disconnect 되는 경우와의 충돌없는지 확인 필요)
		if (mBleDeviceName != NULL)
		{
			free(mBleDeviceName);
		}
		mBleDeviceName = NULL;
		mBleDeviceName = 0;

		//gpioWifiReset.Toggle();
		//sleep(1);
		//gpioWifiReset.Write(GPIO_HIGH);

		MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_GATEWAY, CMD_REQUEST_DOWNLOAD_DATA_SINGLE_DEVICE_RESPONSE, NULL, 0);
#endif
		LOGD(TAG, "Done");
		MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_GATEWAY, CMD_REQUEST_DOWNLOAD_DATA_SINGLE_DEVICE_RESPONSE, NULL, 0);
		break;
#if 0
	case CMD_REQUEST_DOWNLOAD_DATA_SINGLE_DEVICE:
		LOGD(TAG, "mCurrentIndex: %d, mTargetDeviceList: %d", mCurrentIndex, mTargetDeviceList.size());
		if (mCurrentIndex < 0 || mCurrentIndex > mTargetDeviceList.size())
		{
			//CmdRequestDownloadData(CMD_REQUEST_DOWNLOAD_DATA_SINGLE_DEVICE_RESPONSE, NULL, 0);
			break;
		}

		if (mBleDeviceName != NULL)
		{
			LOGD(TAG, "mBleDeviceName is not NULL!!");
		}
		mBleDeviceName = NULL;

		mIsDownloadSuccess = false;

		memcpy(mac, mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[mCurrentIndex]].ble, IOT_SENSOR_BLE_MAC_ADDRESS_LENGTH);
		//ConvertStrMacToCharMac(mTargetDeviceList[mCurrentIndex].c_str(), mac, 6);
		LOGD(TAG, "%d/%d : %d) %02X %02X %02X %02X %02X %02X", mCurrentIndex + 1, mTargetDeviceList.size(), mTargetDeviceList[mCurrentIndex], mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);

		//SetTimer(TIMER_GATEWAY_STATE, &stateTimer, 10, 0);
		SetTimer(TIMER_WIFI_CONNECTION, &mTimerWifiConnectionWait, 10, 0);

		mOpenWifiRetryCount = mConnectWifiRetryCount = 2;
		break;
	case CMD_OPEN_SOCKET_RESPONSE:
		file_index[1] = mSensorStoredFileList.size();
		LOGD(TAG, "File Index: %02x %02x", file_index[0], file_index[1]);
		MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_DOWNLOAD_FILE, file_index, 2);
		break;

#if 0
	case CMD_CONNECT_WIFI_RESPONSE:
		LOGD(TAG, "CMD_CONNECT_WIFI_RESPONSE Request!! ACK: %02X", ack[0]);
		switch(ack[0])
		{
		case 0x01:
			// 성공
			mConnectWifiRetryCount = 0;
			//StopTimer(&stateTimer);
			//LOGD(TAG, "fileList size: %d", fileList.size());
			//struct file_download_info *fileInfo;
			//fileInfo = fileList.back();
			//MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_WIFI, CMD_SPI_READ, fileInfo, sizeof(struct file_download_info));
#if 0
			//free(fileInfo);
			//fileList.pop();
#endif
			sleep(3);
			//file_index[1] = fileList.size();
			//LOGD(TAG, "File Index: %02x %02x", file_index[0], file_index[1]);
			//MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_DOWNLOAD_FILE, file_index, 2);
			break;
		case 0x02:
			// 진행 중
			LOGD(TAG, "Connecting....");
			break;
		case 0x03:
		case 0x04:
		case 0x05:
			// 실패 -> Reset 후 재접속 시도
			// data reset -> disconnect
			LOGD(TAG, "Error...... mIsDownloadSuccess: %d, mDownloadRetryCount: %d", mIsDownloadSuccess, mDownloadRetryCount);
			if ((mIsDownloadSuccess == true) || (mDownloadRetryCount == 0))
			{
				MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_RESET_SENSOR_INFO, reset_param_file, 1);
			}
			sleep(1);
			MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_REQUEST_DISCONNECT_DEVICE, NULL, 0);
			break;
		}
		break;
#endif
	case CMD_CLOSE_SOCKET_RESPONSE:
		//LOGD(TAG, "CMD_SPI_DATA_READ_RESPONSE Request!! fileList size: %d", fileList.size());
		if (data != NULL)
		{
			LOGD(TAG, "MAC: %s, File: %s", mTargetDeviceList[mCurrentIndex].c_str(), (char *)data);
			//LOGD(TAG, "Device Info File: %s", deviceInfoFile);
			//listUploadFiles.push_back(deviceInfoFile);
			//LOGD(TAG, "Txt File: %s", (char *)data);
			UpdateSensorData(mTargetDeviceList[mCurrentIndex].c_str(), (char *)data);
			mUploadFileList.push_back((char *)data);
			mIsDownloadSuccess = true;
		}
#if 0
		if (!fileList.empty())
		{
			// Download Data
			//struct file_download_info *fileInfo;
			//fileInfo = fileList.front();
			//MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_WIFI, CMD_SPI_READ, fileInfo, sizeof(struct file_download_info));
			//free(fileInfo);
			//fileList.pop();
			//sleep(3);
			// file_index 갱신 -> 항상 1개만
			MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_DOWNLOAD_FILE, file_index, 2);
		}
		else
#endif
		{
			// Disconnect Wifi
			StopTimer(&mTimerWifiConnectionWait);

			//SetTimer(TIMER_GATEWAY_STATE, &stateTimer, 10, 0);
			SetTimer(TIMER_WIFI_CONNECTION, &mTimerWifiConnectionWait, 10, 0);

			MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_BLE, CMD_OPEN_WIFI, wifi_control_param_close, 3);
		}
		break;
#endif
	default:
		{
		}
		break;
	}
}

int CGatewayManager::ReadFileList(void *data, int size)
{
	int isError = false;

	char *fileName = (char *)malloc(sizeof(char) * size + 1);
	memset(fileName, 0x00, size + 1);
	memcpy(fileName, data, size);
	LOGD(TAG, "File Name: %s", fileName);

	// File List를 초기화
#if 1
	while(!mSensorStoredFileList.empty())
	{
		struct MeasurementDataFileInfo *fileInfo;
		fileInfo = mSensorStoredFileList.front();
		//LOGD(TAG, "File List: %p, index: %d, size: %d, type: %c, name: %s", fileInfo, fileInfo->index, fileInfo->size, fileInfo->type, fileInfo->name);
		delete(fileInfo);
		mSensorStoredFileList.pop();
	}
#endif

	FILE* fp = fopen(fileName, "r");
	if (fp == NULL)
	{
		LOGD(TAG, "File open fail. [%s]", fileName);
		isError = true;
		return isError;
	}

	char buf[80], name[32], tmpDay[7], tmpTime[5];
	while(1)
	{
		fgets(buf, 80, fp);
		if (feof(fp))
		{
			break;
		}
		struct MeasurementDataFileInfo *fileInfo = new(struct MeasurementDataFileInfo);
		memset(fileInfo, 0x00, sizeof(struct MeasurementDataFileInfo));
		sscanf(buf, "%hu,%d,%c,%s", &(fileInfo->index), &(fileInfo->size), &(fileInfo->tag), name);

		memset(tmpDay, 0x00, 7);
		memset(tmpTime, 0x00, 5);

		memcpy(tmpDay, name, 6);
		memcpy(tmpTime, name + 7, 4);

		sprintf(fileInfo->file_name, "%s%s00", tmpDay, tmpTime);

		LOGD(TAG, "index: %d, size: %d, type: %c, name: %s", fileInfo->index, fileInfo->size, fileInfo->tag, fileInfo->file_name);
		if ((fileInfo->tag == 'V') || (fileInfo->tag == 'N'))
		{
			mSensorStoredFileList.push(fileInfo);
			//strncpy(fileDate, bufDate, 15);
		}
		else
		{
			isError = true;
		}
	}
	fclose(fp);

	LOGD(TAG, "Delete File: %s", fileName);
	remove(fileName);

	free(fileName);

	return isError;
}

// ********************************************
// Equipment Info & Fault Frequency
// ********************************************
void CGatewayManager::CmdSetEquipmentInformation(void *data, int size)
{
	LOGD(TAG, "FUNC IN");
	// 서버에 응답 메시지 보냄

	MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_SERVERCOMM, CMD_SET_EQUIPMENT_INFORMATION_RESPONSE, NULL, 0);

	// 진단 알고리즘에게 던짐

	diagnostic_info diagInfo;
	memset(&diagInfo, 0x00, sizeof(struct diagnostic_info));

	//diagInfo.timestamp.data = info->timestamp;

	strcpy(diagInfo.info_file, mGatewayFile[FILE_EQUIPMENT_INFORMATION]);

	MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_DIAGNOSTIC, CMD_DIAGNOSE_FAULT_FREQUENCY, &diagInfo, sizeof(struct diagnostic_info));
	LOGD(TAG, "FUNC OUT");
}

void CGatewayManager::CmdDiagnoseFaultFrequencyResponse(void *data, int size)
{
	LOGD(TAG, "FUNC IN");

	// 진단 결과를 받으면 임시 파일을 암호화하여 저장 -> 서버로 결과 응답

	MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_SERVERCOMM, CMD_SET_FAULT_FREQUENCY, NULL, 0);
	LOGD(TAG, "FUNC OUT");
}

// ********************************************
// Noise Threshold Measurement
// ********************************************
void CGatewayManager::CmdRequestNoiseThresholdMeasurement(void *data, int size)
{
	// 측정 횟수 저장

	// DoNoiseThresholdMeasurement 호출
	DoNoiseThresholdMeasurement(CMD_REQUEST_NOISE_THRESHOLD_MEASUREMENT, data, size);
}

void CGatewayManager::CmdRequestNoiseThresholdDiagnosis(void *data, int size)
{
	// 저장된 파일 정보를 기반으로 진단 알고리즘 호출

	diagnostic_info info;
	memset(&info, 0x00, sizeof(struct diagnostic_info));

	strcpy(info.info_file, mGatewayFile[FILE_EQUIPMENT_INFORMATION]);

#if 0
	std::vector<std::string>::iterator it;
	for (it = mNoiseThresholdMeasurementFiles.begin(); it != mNoiseThresholdMeasurementFiles.end(); it++)
	{
		LOGD(TAG, "FILE: %s", (*it).c_str());
	}
#endif

	for (int i = 0; i < mNoiseThresholdMeasurementFiles.size(); i++)
	{
		LOGD(TAG, "FILE: %s", mNoiseThresholdMeasurementFiles[i].c_str());
		strcpy(info.data_file[i], mNoiseThresholdMeasurementFiles[i].c_str());
	}
	info.num_data_file = mNoiseThresholdMeasurementFiles.size();

	MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_DIAGNOSTIC, CMD_DIAGNOSE_NOISE_THRESHOLD, &info, sizeof(struct diagnostic_info));
}

void CGatewayManager::CmdDiagnoseNoiseThresholdResponse(void *data, int size)
{
	// 진단 알고리즘 응답 결과를 서버로 전송

	MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_SERVERCOMM, CMD_REQUEST_NOISE_THRESHOLD_DIAGNOSIS_RESPONSE, NULL, 0);
}

void CGatewayManager::CmdSetNoiseThreshold(void *data, int size)
{
	// 서버가 전송한 데이터를 저장
	
	// 서버로 응답
	MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_SERVERCOMM, CMD_SET_NOISE_THRESHOLD_RESPONSE, NULL, 0);
}

void CGatewayManager::SendNoiseThresholdMeasurementMessage()
{
	struct MeasurementDataFileInfo info;
	memset(&info, 0x00, sizeof(struct MeasurementDataFileInfo));

	strcpy(info.equipment_id, "ICTR01");
	info.location = 'I';
	info.measurement_time = 5;
	info.sample_rate = 50000;
	info.channel = 2;
	info.tag = 'G';
	strcpy(info.sub_dir_name, "noise");

	mNoiseThresholdMeasurementCount++;

	MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_ADC, CMD_REQUEST_NOISE_THRESHOLD_MEASUREMENT, &info, sizeof(struct MeasurementDataFileInfo));
}

void CGatewayManager::DoNoiseThresholdMeasurement(const COMMAND_TYPE lastCmd, const void *data, const int size)
{
	LOGD(TAG, "CMD: %d", lastCmd);
	switch(lastCmd)
	{
	case CMD_REQUEST_NOISE_THRESHOLD_MEASUREMENT:
		{
			if ((mStateMain != GATEWAY_STATE_IDLE) && (mStateMain != GATEWAY_STATE_INIT_PROCESS))
			{
				LOGE(TAG, "Gateway is busy. %d", mStateMain);
				break;
			}

			if (mStateMain == GATEWAY_STATE_IDLE)
			{
				mStateMain = GATEWAY_STATE_NOISE_THRESHOLD;
			}

			mNoiseThresholdMeasurementCount = 0;
			mNoiseThresholdMeasurementFiles.clear();

			// 상시 점검용 타이머 정지, 데이터 전송 정지

			// 소음 측정용 타이머 동작, 측정
			LOGD(TAG, "interval: %d", mGatewayInfo.noise_threshold_measurement_info.measurement_info.interval);
			CTimer::GetInstance()->SetTimer(MODULE_GATEWAY, TIMER_NOISE_THRESHOLD_MEASUREMENT, mGatewayInfo.noise_threshold_measurement_info.measurement_info.interval, 0);

			SendNoiseThresholdMeasurementMessage();
		}
		break;
	case CMD_REQUEST_NOISE_THRESHOLD_MEASUREMENT_RESPONSE:
		{
			LOGD(TAG, "Noise Threshold Measurement: %d/%d", mNoiseThresholdMeasurementCount, mGatewayInfo.noise_threshold_measurement_info.measurement_info.num_measurement);
			// 측정 완료하면, 파일명 저장 -> 지정된 횟수 만큼 반복
			struct MeasurementDataFileInfo *info = (struct MeasurementDataFileInfo *)data;

			LOGD(TAG, "%s", info->file_name);
			mNoiseThresholdMeasurementFiles.push_back(info->file_name);

			if (mNoiseThresholdMeasurementCount >= mGatewayInfo.noise_threshold_measurement_info.measurement_info.num_measurement)
			{
				CTimer::GetInstance()->StopTimer(TIMER_NOISE_THRESHOLD_MEASUREMENT);

				std::vector<std::string>::iterator it;
				for (it = mNoiseThresholdMeasurementFiles.begin(); it != mNoiseThresholdMeasurementFiles.end(); it++)
				{
					LOGD(TAG, "FILE: %s", (*it).c_str());
				}

				// 횟수만큼 수행했으면 서버로 응답
				MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_SERVERCOMM, CMD_REQUEST_NOISE_THRESHOLD_MEASUREMENT_RESPONSE, NULL, 0);
			}
		}
		break;
	case CMD_TIMER_EXPIRED:
		{
			LOGD(TAG, "Noise Threshold Measurement: %d", mNoiseThresholdMeasurementCount);
			if (mNoiseThresholdMeasurementCount < mGatewayInfo.noise_threshold_measurement_info.measurement_info.num_measurement)
			{
				SendNoiseThresholdMeasurementMessage();
			}
		}
		break;
#if 0
	case :
		{
		}
		break;
#endif
	default:
		{
		}
		break;
	}
}

// ********************************************
// Vibration Threshold Measurement
// ********************************************
void CGatewayManager::CmdRequestVibrationThresholdMeasurement(void *data, int size)
{
	// 측정 횟수 저장

	// DoVibrationThresholdMeasurement 호출
}

void CGatewayManager::CmdRequestVibrationThresholdDiagnosis(void *data, int size)
{
	// 저장된 파일 정보를 기반으로 진단 알고리즘 호출

	MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_DIAGNOSTIC, CMD_DIAGNOSE_VIBRATION_THRESHOLD, NULL, 0);
}

void CGatewayManager::CmdDiagnoseVibrationThresholdResponse(void *data, int size)
{
	// 진단 알고리즘 응답 결과를 서버로 전송

	MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_SERVERCOMM, CMD_REQUEST_VIBRATION_THRESHOLD_DIAGNOSIS_RESPONSE, NULL, 0);
}

void CGatewayManager::CmdSetVibrationThreshold(void *data, int size)
{
	// 서버가 전송한 데이터를 저장
	
	// 서버로 응답
	MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_SERVERCOMM, CMD_SET_VIBRATION_THRESHOLD_RESPONSE, NULL, 0);
}

void CGatewayManager::DoVibrationThresholdMeasurement(const COMMAND_TYPE lastCmd, void *data, int size)
{
	// 상시 점검용 타이머 정지, 데이터 전송 정지

	// 진동 센서만 타겟 디바이스 리스트에 추가

	switch(lastCmd)
	{
	case CMD_REQUEST_VIBRATION_THRESHOLD_MEASUREMENT:
		{
			LOGD(TAG, "CMD_REQUEST_VIBRATION_THRESHOLD_MEASUREMENT");

			if (mStateMain != GATEWAY_STATE_IDLE)
			{
				LOGE(TAG, "Gateway is busy. %d", mStateMain);
				return;
			}
			mStateMain = GATEWAY_STATE_VIBRATION_THRESHOLD_MEASUREMENT;

			// 타겟 디바이스 목록을 만들고 IoT 센서 측정
			mTargetDeviceList.clear();
			for (int i = 0; i < mGatewayInfo.num_iot_sensor; i++)
			{
				char buf[13];
				memset(buf, 0x00, 13);
				ConvertCharMacToStrMac(mGatewayInfo.iot_sensor_info_list[i].ble, 6, buf, 13);

				LOGD(TAG, "MAC: %s, Type: %c", buf, mGatewayInfo.iot_sensor_info_list[i].type);

				if (mGatewayInfo.iot_sensor_info_list[i].type == 'V')
				{
					mTargetDeviceList.push_back(i);
				}
			}

			mCurrentRetryCount = 0;
			MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_GATEWAY, CMD_REQUEST_IOT_SENSOR_MEASUREMENT, NULL, 0);
		}
		break;
	case CMD_REQUEST_IOT_SENSOR_MEASUREMENT_RESPONSE:
		{
			LOGD(TAG, "CMD_REQUEST_IOT_SENSOR_MEASUREMENT_RESPONSE");
			LOGD(TAG, "mIsAllDeviceStartMeasurement: %d, mCurrentRetryCount: %d", mIsAllDeviceStartMeasurement, mCurrentRetryCount);
			if (mIsAllDeviceStartMeasurement == true)
			{
				mStateMain = GATEWAY_STATE_VIBRATION_THRESHOLD_DIAGNOSIS;

				mCurrentIndex = 0;
				mCurrentRetryCount = 0;
				DownloadDataFromSingleDevice(CMD_REQUEST_DOWNLOAD_DATA_SINGLE_DEVICE, mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[mCurrentIndex]].ble, IOT_SENSOR_BLE_MAC_ADDRESS_LENGTH);
			}
			else if (mCurrentRetryCount < 3)
			{
				// 다시 측정
				MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_GATEWAY, CMD_REQUEST_IOT_SENSOR_MEASUREMENT, NULL, 0);
			}
			else
			{
				// 측정 실패
				LOGE(TAG, "Measurement Fail");
			}
		}
		break;
	case CMD_REQUEST_DOWNLOAD_DATA_SINGLE_DEVICE_RESPONSE:
		{
			LOGD(TAG, "CMD_REQUEST_DOWNLOAD_DATA_SINGLE_DEVICE_RESPONSE");
			LOGD(TAG, "mIsDownloadSuccess: %d, mCurrentRetryCount: %d", mIsDownloadSuccess, mCurrentRetryCount);

			if (mIsDownloadSuccess == true)
			{
				mCurrentIndex++;
				if (mCurrentIndex == mTargetDeviceList.size())
				{
					LOGD(TAG, "All Done");

					diagnostic_info diagInfo;
					memset(&diagInfo, 0x00, sizeof(struct diagnostic_info));

					//diagInfo.timestamp.data = info->timestamp;

					for (int i = 0; i < mTargetDeviceList.size(); i++)
					{
						LOGD(TAG, "[%d %d] MAC: %02X %02X %02X %02X %02X %02X, Type: %c, Location: %d, Direction: %d, File: %s", i, mTargetDeviceList[i],
								mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].ble[0], mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].ble[1], mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].ble[2],
								mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].ble[3], mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].ble[4], mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].ble[5],
								mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].type, mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].location, mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].direction,
								mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].data_info);

						FILE *fp = fopen(mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].data_info, "rb");
						if (fp == NULL)
						{
							continue;
						}

						fseek(fp, 0, SEEK_END);
						long int totalFileSize = ftell(fp);
						fseek(fp, 0, SEEK_SET);

						char *tmp = (char *)malloc(totalFileSize);
						fread(tmp, totalFileSize, 1, fp);

						fclose(fp);

						// 부분 파일 크기 계산
						const int NUM_AXIS = 3;
						int subFileSize = sizeof(uint16_t) * NUM_AXIS * mGatewayInfo.vibration_threshold_measurement_info.measurement_info.sampling_rate * mGatewayInfo.vibration_threshold_measurement_info.measurement_info.measurement_time;
						int numFiles = totalFileSize / subFileSize;
						LOGD(TAG, "Total: %d, Sub: %d, Num Files: %d", totalFileSize, subFileSize, numFiles);

						for (int j = 0; j < numFiles; j++)
						{
							char subFileName[FILE_PATH_LENGTH];
							memset(subFileName, 0x00, FILE_PATH_LENGTH);
							sprintf(subFileName, "%s.%d", mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].data_info, j + 1);
							LOGD(TAG, "Sub File: %s", subFileName);

							FILE *fpSub = fopen(subFileName, "wb");
							if (fpSub == NULL)
							{
								continue;
							}

							fwrite(tmp + j * subFileSize, subFileSize, 1, fpSub);
							fclose(fpSub);

							// 파일 변환
							char numFile[FILE_PATH_LENGTH];
							memset(numFile, 0x00, FILE_PATH_LENGTH);
							sprintf(numFile, "%s.num", subFileName);
							LOGD(TAG, "Num File Name: %s", numFile);

							ConvertRawFileToNumFile(subFileName, numFile, 3);

							// 파일 배치
							if (mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].location == 1)
							{
								strcpy(diagInfo.data_file[j * 2 + 0], numFile);
							}
							else
							{
								strcpy(diagInfo.data_file[j * 2 + 1], numFile);
							}
							diagInfo.num_data_file++;
						}
					}
					// 진단 요청
					strcpy(diagInfo.info_file, mGatewayFile[FILE_EQUIPMENT_INFORMATION]);

					MessageQueue::GetInstance()->SendMessage(MODULE_SYSTEM, MODULE_DIAGNOSTIC, CMD_DIAGNOSE_VIBRATION_THRESHOLD, &diagInfo, sizeof(struct diagnostic_info));

					mStateMain = GATEWAY_STATE_IDLE;
				}
				else
				{
					DownloadDataFromSingleDevice(CMD_REQUEST_DOWNLOAD_DATA_SINGLE_DEVICE, mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[mCurrentIndex]].ble, IOT_SENSOR_BLE_MAC_ADDRESS_LENGTH);
				}
			}
			else if (mCurrentRetryCount < 3)
			{
				// 재시도
				DownloadDataFromSingleDevice(CMD_REQUEST_DOWNLOAD_DATA_SINGLE_DEVICE, mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[mCurrentIndex]].ble, IOT_SENSOR_BLE_MAC_ADDRESS_LENGTH);
			}
			else
			{
				// 다운로드 실패
				LOGE(TAG, "Download fail");
			}
		}
		break;
#if 0
	case :
		{
			LOGD(TAG, "");
		}
		break;
#endif
	default:
		{
		}
		break;
	}
	// IoT Sensor 측정
	
	// IoT Sensor 데이터 다운로드
	
	// 진단 알고리즘 호출





	// 측정 -> 데이터 다운로드

#if 0
	// 알고리즘 호출
	diagnostic_info diagInfo;
	memset(&diagInfo, 0x00, sizeof(struct diagnostic_info));

	//diagInfo.timestamp.data = info->timestamp;

	strcpy(diagInfo.info_file, mGatewayFile[FILE_EQUIPMENT_INFORMATION]);
	strcpy(diagInfo.data_file[0], "/home/intsain/workspace/ictr/gateway3/main/data/manual/210617/ICTR01_1_V_210617165400.num");
	strcpy(diagInfo.data_file[1], "/home/intsain/workspace/ictr/gateway3/main/data/manual/210617/ICTR01_3_V_210617153900.num");
	strcpy(diagInfo.data_file[2], "/home/intsain/workspace/ictr/gateway3/main/data/manual/210617/ICTR01_3_V_210617154400.num");
	strcpy(diagInfo.data_file[3], "/home/intsain/workspace/ictr/gateway3/main/data/manual/210617/ICTR01_3_V_210617154600.num");
	strcpy(diagInfo.data_file[4], "/home/intsain/workspace/ictr/gateway3/main/data/manual/210617/ICTR01_3_V_210617155000.num");
	strcpy(diagInfo.data_file[5], "/home/intsain/workspace/ictr/gateway3/main/data/manual/210617/ICTR01_3_V_210617155600.num");
	strcpy(diagInfo.data_file[6], "/home/intsain/workspace/ictr/gateway3/main/data/manual/210617/ICTR01_3_V_210617160000.num");
	strcpy(diagInfo.data_file[7], "/home/intsain/workspace/ictr/gateway3/main/data/manual/210617/ICTR01_3_V_210617165400.num");
	diagInfo.num_data_file = 8;

	MessageQueue::GetInstance()->SendMessage(MODULE_SYSTEM, MODULE_DIAGNOSTIC, CMD_DIAGNOSE_VIBRATION_THRESHOLD, &diagInfo, sizeof(struct diagnostic_info));
#endif
	// 횟수만큼 수행했으면 서버로 응답
	//MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_SERVERCOMM, CMD_REQUEST_VIBRATION_THRESHOLD_MEASUREMENT_RESPONSE, NULL, 0);
}

// ********************************************
// Status Check
// ********************************************
void CGatewayManager::DoStatusCheck()
{
	char buf[1024];

	float value;

	value = GetCpuLoad(buf, 1024);
	LOGD(TAG, "CPU Load: %f (%s)", value, buf);

	value = GetMemoryUsage(buf, 1024);
	LOGD(TAG, "Memory: %f (%s)", value, buf);

	value = GetDiskUsage(buf, 1024);
	LOGD(TAG, "Disk: %f (%s)", value, buf);

	value = GetCpuTemperature(buf, 1024);
	LOGD(TAG, "CPU Temp: %f (%s)", value, buf);
}

// ********************************************
// Emergency, Manaual & Periodic Measurement
// ********************************************
void CGatewayManager::CmdRequestManualMeasurement(const void *data, const int size)
{
	DoManualMeasurement(CMD_REQUEST_MANUAL_MEASUREMENT, NULL, 0);
}

void CGatewayManager::CmdRequestPeriodicMeasurement()
{
}

void CGatewayManager::DoEmergencyMeasurement()
{
}

void CGatewayManager::DoManualMeasurement(const COMMAND_TYPE lastCmd, const void *data, const int size)
{
	switch(lastCmd)
	{
	case CMD_REQUEST_MANUAL_MEASUREMENT:
		{
			LOGD(TAG, "CMD_REQUEST_MANUAL_MEASUREMENT");

			if (mStateMain != GATEWAY_STATE_IDLE)
			{
				LOGE(TAG, "Gateway is busy. %d", mStateMain);
				return;
			}
			mStateMain = GATEWAY_STATE_MANUAL_MEASUREMENT;

			// 타겟 디바이스 목록을 만들고 IoT 센서 측정
			mTargetDeviceList.clear();
			for (int i = 0; i < mGatewayInfo.num_iot_sensor; i++)
			{
				char buf[13];
				memset(buf, 0x00, 13);
				ConvertCharMacToStrMac(mGatewayInfo.iot_sensor_info_list[i].ble, 6, buf, 13);

				LOGD(TAG, "MAC: %s, Type: %c", buf, mGatewayInfo.iot_sensor_info_list[i].type);

				mTargetDeviceList.push_back(i);
			}

			mCurrentRetryCount = 0;
			MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_GATEWAY, CMD_REQUEST_IOT_SENSOR_MEASUREMENT, NULL, 0);
		}
		break;
	case CMD_REQUEST_IOT_SENSOR_MEASUREMENT_RESPONSE:
		{
			LOGD(TAG, "CMD_REQUEST_IOT_SENSOR_MEASUREMENT_RESPONSE");
			LOGD(TAG, "mIsAllDeviceStartMeasurement: %d, mCurrentRetryCount: %d", mIsAllDeviceStartMeasurement, mCurrentRetryCount);
			if (mIsAllDeviceStartMeasurement == true)
			{
				mStateMain = GATEWAY_STATE_MANUAL_DIAGNOSIS;

				mCurrentIndex = 0;
				mCurrentRetryCount = 0;
				DownloadDataFromSingleDevice(CMD_REQUEST_DOWNLOAD_DATA_SINGLE_DEVICE, mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[mCurrentIndex]].ble, IOT_SENSOR_BLE_MAC_ADDRESS_LENGTH);
			}
			else if (mCurrentRetryCount < 3)
			{
				// 다시 측정
				MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_GATEWAY, CMD_REQUEST_IOT_SENSOR_MEASUREMENT, NULL, 0);
			}
			else
			{
				// 측정 실패
				LOGE(TAG, "Measurement Fail");
			}
		}
		break;
	case CMD_REQUEST_DOWNLOAD_DATA_SINGLE_DEVICE_RESPONSE:
		{
			LOGD(TAG, "CMD_REQUEST_DOWNLOAD_DATA_SINGLE_DEVICE_RESPONSE");
			LOGD(TAG, "mIsDownloadSuccess: %d, mCurrentRetryCount: %d", mIsDownloadSuccess, mCurrentRetryCount);

			if (mIsDownloadSuccess == true)
			{
				mCurrentIndex++;
				if (mCurrentIndex == mTargetDeviceList.size())
				{
					LOGD(TAG, "All Done");
					// 알고리즘 호출

					diagnostic_info elongationDiagInfo;
					memset(&elongationDiagInfo, 0x00, sizeof(struct diagnostic_info));

					//elongationDiagInfo.timestamp.data = info->timestamp;

					for (int i = 0; i < mTargetDeviceList.size(); i++)
					{
						LOGD(TAG, "[%d %d] MAC: %02X %02X %02X %02X %02X %02X, Type: %c, Location: %d, Direction: %d, File: %s", i, mTargetDeviceList[i],
								mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].ble[0], mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].ble[1], mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].ble[2],
								mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].ble[3], mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].ble[4], mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].ble[5],
								mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].type, mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].location, mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].direction,
								mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].data_info);

						switch(mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].type)
						{
						case 'V':
							{
								diagnostic_info diagInfo;

								char numFile[FILE_PATH_LENGTH];
								memset(numFile, 0x00, FILE_PATH_LENGTH);
								strcpy(numFile, mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].data_info);
								ChangeFileExt(numFile, "num");
								LOGD(TAG, "Num File Name: %s", numFile);

								ConvertRawFileToNumFile(mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].data_info, numFile, 3);

								// 진동 등급
								memset(&diagInfo, 0x00, sizeof(struct diagnostic_info));

								//diagInfo.timestamp.data = info->timestamp;

								strcpy(diagInfo.info_file, mGatewayFile[FILE_EQUIPMENT_INFORMATION]);
								strcpy(diagInfo.data_file[0], numFile);
								strcpy(diagInfo.data_file[1], mGatewayFile[FILE_RMS_SHAFT_BEARING]);
								diagInfo.value8 = mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].location;

								MessageQueue::GetInstance()->SendMessage(MODULE_SYSTEM, MODULE_DIAGNOSTIC, CMD_DIAGNOSE_VIBRATION_RATING, &diagInfo, sizeof(struct diagnostic_info));

								sleep(3);

								// 진동 진단
								memset(&diagInfo, 0x00, sizeof(struct diagnostic_info));

								//diagInfo.timestamp.data = info->timestamp;

								strcpy(diagInfo.info_file, mGatewayFile[FILE_EQUIPMENT_INFORMATION]);
								strcpy(diagInfo.data_file[0], numFile);
								strcpy(diagInfo.data_file[1], mGatewayFile[FILE_FAULT_FREQUENCY]);
								strcpy(diagInfo.data_file[2], mGatewayFile[FILE_VIBRATION_THRESHOLD]);
								diagInfo.value16 = mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].location * 0x100 + mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].direction;

								MessageQueue::GetInstance()->SendMessage(MODULE_SYSTEM, MODULE_DIAGNOSTIC, CMD_DIAGNOSE_VIBRATION_DIAGNOSIS, &diagInfo, sizeof(struct diagnostic_info));

								if (mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].location == 1)
								{
									strcpy(elongationDiagInfo.data_file[0], numFile);
								}
								else
								{
									strcpy(elongationDiagInfo.data_file[1], numFile);
								}
							}
							break;
						case 'N':
							{
								char numFile[FILE_PATH_LENGTH];
								memset(numFile, 0x00, FILE_PATH_LENGTH);
								strcpy(numFile, mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].data_info);
								ChangeFileExt(numFile, "num");
								LOGD(TAG, "Num File Name: %s", numFile);

								ConvertRawFileToNumFile(mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[i]].data_info, numFile, 1);

								strcpy(elongationDiagInfo.data_file[2], numFile);
							}
							break;
						default:
							{
							}
							break;
						}
					}
					// 늘어짐

					strcpy(elongationDiagInfo.info_file, mGatewayFile[FILE_EQUIPMENT_INFORMATION]);
					strcpy(elongationDiagInfo.data_file[3], mGatewayFile[FILE_RMS_SHAFT_BEARING]);
					strcpy(elongationDiagInfo.data_file[4], mGatewayFile[FILE_FAULT_FREQUENCY]);
					strcpy(elongationDiagInfo.data_file[5], mGatewayFile[FILE_VIBRATION_THRESHOLD]);
					sleep(5); //20210701 code add by skh
					MessageQueue::GetInstance()->SendMessage(MODULE_SYSTEM, MODULE_DIAGNOSTIC, CMD_DIAGNOSE_VBELT_ELONGATION, &elongationDiagInfo, sizeof(struct diagnostic_info));

					mStateMain = GATEWAY_STATE_IDLE;
				}
				else
				{
					DownloadDataFromSingleDevice(CMD_REQUEST_DOWNLOAD_DATA_SINGLE_DEVICE, mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[mCurrentIndex]].ble, IOT_SENSOR_BLE_MAC_ADDRESS_LENGTH);
				}
			}
			else if (mCurrentRetryCount < 3)
			{
				// 재시도
				DownloadDataFromSingleDevice(CMD_REQUEST_DOWNLOAD_DATA_SINGLE_DEVICE, mGatewayInfo.iot_sensor_info_list[mTargetDeviceList[mCurrentIndex]].ble, IOT_SENSOR_BLE_MAC_ADDRESS_LENGTH);
			}
			else
			{
				// 다운로드 실패
				LOGE(TAG, "Download fail");
			}
		}
		break;
#if 0
	case :
		{
			LOGD(TAG, "");
		}
		break;
#endif
	default:
		{
		}
		break;
	}
	// IoT Sensor 측정
	
	// IoT Sensor 데이터 다운로드
	
	// 진단 알고리즘 호출
}

void CGatewayManager::DoPeriodicMeasurement()
{
}

// ********************************************
// Helper
// ********************************************

// ********************************************
// Test
// ********************************************
void CGatewayManager::CmdTestModuleCommunication(const void *data, const int size)
{
	switch(size)
	{
	case CMD_REQUEST_REGULAR_MEASUREMENT:	// 'r'
		{
			LOGD(TAG, "CMD_REQUEST_REGULAR_MEASUREMENT");
			DoRegularMeasurement();
		}
		break;
	case CMD_REQUEST_MANUAL_MEASUREMENT:	// 'm'
		{
			LOGD(TAG, "CMD_REQUEST_MANUAL_MEASUREMENT");
			CmdRequestManualMeasurement(NULL, 0);
		}
		break;
	case CMD_REQUEST_PERIODIC_MEASUREMENT:	// 'p'
		{
			LOGD(TAG, "CMD_REQUEST_PERIODIC_MEASUREMENT");
			MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_GATEWAY, CMD_REQUEST_PERIODIC_MEASUREMENT, NULL, 0);
		}
		break;
	case CMD_REQUEST_NOISE_THRESHOLD_MEASUREMENT:	// 'n'
		{
			LOGD(TAG, "CMD_REQUEST_NOISE_THRESHOLD_MEASUREMENT");
			MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_GATEWAY, CMD_REQUEST_NOISE_THRESHOLD_MEASUREMENT, NULL, 0);
		}
		break;
	case CMD_REQUEST_NOISE_THRESHOLD_DIAGNOSIS:	// 'd'
		{
			LOGD(TAG, "CMD_REQUEST_NOISE_THRESHOLD_DIAGNOSIS");
			MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_GATEWAY, CMD_REQUEST_NOISE_THRESHOLD_DIAGNOSIS, NULL, 0);
		}
		break;
	case CMD_REQUEST_VIBRATION_THRESHOLD_MEASUREMENT:	// 'v'
		{
			LOGD(TAG, "CMD_REQUEST_VIBRATION_THRESHOLD_MEASUREMENT");
			DoVibrationThresholdMeasurement(CMD_REQUEST_VIBRATION_THRESHOLD_MEASUREMENT, NULL, 0);
		}
		break;
	case CMD_REQUEST_VIBRATION_THRESHOLD_DIAGNOSIS:		// 't'
		{
			LOGD(TAG, "CMD_REQUEST_VIBRATION_THRESHOLD_DIAGNOSIS");
		}
		break;
	case CMD_SET_EQUIPMENT_INFORMATION:		// 'f'
		{
			LOGD(TAG, "CMD_SET_EQUIPMENT_INFORMATION");
			CmdSetEquipmentInformation(NULL, 0);
		}
		break;
	case CMD_GET_IOT_SENSOR_INFO:	// 'i'
		{
			LOGD(TAG, "CMD_GET_IOT_SENSOR_INFO");
			char mac[6] = {0xA4, 0x34, 0xF1, 0xAB, 0x67, 0x2A};
			CmdGetIotSensorInfo(mac, 6);
		}
		break;
	case CMD_REQUEST_FACTORY_RESET_IOT_SENSOR:	// 's'
		{
			LOGD(TAG, "CMD_REQUEST_FACTORY_RESET_IOT_SENSOR");
			char mac[6] = {0xA4, 0x34, 0xF1, 0xAB, 0x67, 0x2A};
			CmdRequestFactoryResetIotSensor(mac, 6);
		}
		break;
	case CMD_REQUEST_DOWNLOAD_DATA_SINGLE_DEVICE:	// 'o'
		{
			LOGD(TAG, "CMD_REQUEST_DOWNLOAD_DATA_SINGLE_DEVICE");
			MessageQueue::GetInstance()->SendMessage(MODULE_GATEWAY, MODULE_GATEWAY, CMD_REQUEST_DOWNLOAD_DATA_SINGLE_DEVICE, NULL, 0);
		}
		break;
#if 0
	case :
		{
			LOGD(TAG, "");
		}
		break;
#endif
	default:
		{
			LOGE(TAG, "Not Supported Cmd: %d", size);
		}
		break;
	}
}



#ifndef DIAGNOSTICMANAGER_H
#define DIAGNOSTICMANAGER_H

#include "base/Base.h"
#include "ssl/SocketClientController.h"

#include "util/Util.h"

#pragma pack(push, 1)

typedef struct
{
	uint8_t stx;
	uint8_t type;
	uint16_t length;
} DIAGNOSTIC_HEAD;

typedef struct
{
	DIAGNOSTIC_HEAD head1;
	uint8_t code;
	DIAGNOSTIC_HEAD head2;
} DIAGNOSTIC_ERROR;

typedef struct
{
	float rms_x;
	float rms_y;
	float rms_z;
	uint8_t grade_x;
	uint8_t grade_y;
	uint8_t grade_z;
	uint8_t over_x;
	uint8_t over_y;
	uint8_t over_z;
} VIBRATION_RATING_RESULT;

#pragma pack(pop)

enum DIAGNOSTIC_PROTOCOL_TYPE
{
	DIAGNOSTIC_NOISE_ANOMALY_SOUND_DATA = 0x01,
	DIAGNOSTIC_NOISE_ANOMALY_ACCUMULATED_NOISE_INDICATOR = 0x02,
	DIAGNOSTIC_NOISE_ANOMALY_EQUIPMENT_INFO = 0x03,
	DIAGNOSTIC_NOISE_ANOMALY_NOISE_THRESHOLD = 0x04,
	DIAGNOSTIC_NOISE_ANOMALY_GATEWAY_LOCATION = 0x05,

	DIAGNOSTIC_NOISE_ANOMALY_RESULT = 0x0A,
	DIAGNOSTIC_NOISE_ANOMALY_NOISE_INDICATOR = 0x0B,
	DIAGNOSTIC_NOISE_ANOMALY_ERROR_CODE = 0x0C,
	DIAGNOSTIC_NOISE_ANOMALY_ERROR_STRING = 0x0D,

	DIAGNOSTIC_VIBRATION_RATING_VIBRATION_DATA = 0x11,
	DIAGNOSTIC_VIBRATION_RATING_CUMULATED_VIBRATION_RMS = 0x12,
	DIAGNOSTIC_VIBRATION_RATING_VIBRATION_SENSOR_LOCATION = 0x13,
	DIAGNOSTIC_VIBRATION_RATING_EQUIPMENT_INFO = 0x14,

	DIAGNOSTIC_VIBRATION_RATING_FFT_FILE = 0x1A,
	DIAGNOSTIC_VIBRATION_RATING_RESULT = 0x1B,
	DIAGNOSTIC_VIBRATION_RATING_ERROR_CODE = 0x1C,
	DIAGNOSTIC_VIBRATION_RATING_ERROR_STRING = 0x01D,

	DIAGNOSTIC_VIBRATION_DIAGNOSIS_VIBRATION_DATA = 0x21,
	DIAGNOSTIC_VIBRATION_DIAGNOSIS_FAULT_FREQUENCY = 0x22,
	DIAGNOSTIC_VIBRATION_DIAGNOSIS_VIBRATION_THRESHOLD = 0x23,
	DIAGNOSTIC_VIBRATION_DIAGNOSIS_VIBRATION_SENSOR_DIRECTION = 0x24,
	DIAGNOSTIC_VIBRATION_DIAGNOSIS_EQUIPMENT_INFO = 0x25,

	DIAGNOSTIC_VIBRATION_DIAGNOSIS_RESULT = 0x2A,
	DIAGNOSTIC_VIBRATION_DIAGNOSIS_ERROR_CODE = 0x2B,
	DIAGNOSTIC_VIBRATION_DIAGNOSIS_ERROR_STRING = 0x2C,

	DIAGNOSTIC_VBELT_ELONGATION_MOTOR_VIBRATION_DATA = 0x41,
	DIAGNOSTIC_VBELT_ELONGATION_BEARING_VIBRATION_DATA = 0x42,
	DIAGNOSTIC_VBELT_ELONGATION_SOUND_DATA = 0x43,
	DIAGNOSTIC_VBELT_ELONGATION_CUMULATED_VELOCITY_DATA = 0x44,
	DIAGNOSTIC_VBELT_ELONGATION_FAULT_FREQUENCY = 0x45,
	DIAGNOSTIC_VBELT_ELONGATION_VIBRATION_THRESHOLD = 0x46,
	DIAGNOSTIC_VBELT_ELONGATION_EQUIPMENT_INFO = 0x47,

	DIAGNOSTIC_VBELT_ELONGATION_RESULT = 0x4A,
	DIAGNOSTIC_VBELT_ELONGATION_RATING = 0x4B,
	DIAGNOSTIC_VBELT_ELONGATION_PULLEY_SPEED = 0x4C,
	DIAGNOSTIC_VBELT_ELONGATION_ERROR_CODE = 0x4D,
	DIAGNOSTIC_VBELT_ELONGATION_ERROR_STRING = 0x4E,

	DIAGNOSTIC_NOISE_THRESHOLD_SOUND_DATA = 0x51,
	DIAGNOSTIC_NOISE_THRESHOLD_EQUIPMENT_INFO = 0x5B,

	DIAGNOSTIC_NOISE_THRESHOLD_RESULT = 0x5C,
	DIAGNOSTIC_NOISE_THRESHOLD_NOISE_INDICATOR = 0x5D,
	DIAGNOSTIC_NOISE_THRESHOLD_ERROR_CODE= 0x5E,
	DIAGNOSTIC_NOISE_THRESHOLD_ERROR_STRING = 0x5F,

	DIAGNOSTIC_VIBRATION_THRESHOLD_MOTOR_VIBRATION_DATA = 0x61,
	DIAGNOSTIC_VIBRATION_THRESHOLD_BEARING_VIBRATION_DATA = 0x62,
	DIAGNOSTIC_VIBRATION_THRESHOLD_EQUIPMENT_INFO = 0x6B,

	DIAGNOSTIC_VIBRATION_THRESHOLD_RESULT = 0x6C,
	DIAGNOSTIC_VIBRATION_THRESHOLD_CUMULATED_VIBRATION_RMS = 0x6D,
	DIAGNOSTIC_VIBRATION_THRESHOLD_ERROR_CODE = 0x6E,
	DIAGNOSTIC_VIBRATION_THRESHOLD_ERROR_STRING = 0x6F,

	DIAGNOSTIC_FAULT_FREQUENCY_EQUIPMENT_INFO = 0x71,

	DIAGNOSTIC_FAULT_FREQUENCY_RESULT = 0x7A,
	DIAGNOSTIC_FAULT_FREQUENCY_ERROR_CODE = 0x7B,
	DIAGNOSTIC_FAULT_FREQUENCY_ERROR_STRING = 0x7C,
};

class CDiagnosticManager : public CBase, public IDataListener
{
public:
	CDiagnosticManager();
	~CDiagnosticManager();

	void Init();

private:
	const char *TAG = "DIAG";

	void MessageHandler(MODULE_TYPE sender, COMMAND_TYPE cmd, void *data, int size);

	void SendInternalMessage(MODULE_TYPE receiver, COMMAND_TYPE cmd, void *data, int size);

	// Socket
	CSocketClientController mSocketClient;

	const uint8_t DIAGNOSTIC_PROTOCOL_STX = 0x02;
	const char *DIAGNOSTIC_SERVER_IP_ADDRESS = "127.0.0.1";
	const int DIAGNOSTIC_SERVER_PORT = 9300;
	int mSocketFd;
	void Read(const void *data, const unsigned int size);
	void Write(const uint8_t *data, const int size);

	// Sensor Info
	uint8_t mSensorMac[6];

	// Last Request
	struct diagnostic_info mLastDiagnosticRequest;

	void PrintDiagnosticInfo(const diagnostic_info *info);

	void SendDiagnoseNoiseAnomaly(const void *data, const int size);
	void ReceiveDiagnoseNoiseAnomalyResult(const void *data, const int size);

	void SendDiagnoseVibrationRating(const void *data, const int size);
	void ReceiveDiagnoseVibrationRatingResult(const void *data, const int size);

	void SendDiagnoseVibrationDiagnosis(const void *data, const int size);
	void ReceiveDiagnoseVibrationDiagnosisResult(const void *data, const int size);

	void SendDiagnoseVbeltElongation(const void *data, const int size);
	void ReceiveDiagnoseVbeltElongationResult(const void *data, const int size);

	void SendDiagnoseNoiseThreshold(const void *data, const int size);
	void ReceiveDiagnoseNoiseThresholdResult(const void *data, const int size);

	void SendDiagnoseVibrationThreshold(const void *data, const int size);
	void ReceiveDiagnoseVibrationThresholdResult(const void *data, const int size);

	void SendDiagnoseFaultFrequency(const void *data, const int size);
	void ReceiveDiagnoseFaultFrequencyResult(const void *data, const int size);
};
#endif

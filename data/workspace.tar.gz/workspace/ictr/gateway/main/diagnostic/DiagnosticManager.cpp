#include "DiagnosticManager.h"
#include "mq/MessageQueue.h"
#include "util/Util.h"

// For socket
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//#define DIAGNOSTIC_TEST

CDiagnosticManager::CDiagnosticManager()
{
	memset(&mLastDiagnosticRequest, 0x00, sizeof(struct diagnostic_info));
}

CDiagnosticManager::~CDiagnosticManager()
{
}

void CDiagnosticManager::Init()
{
	mSocketClient.Init("127.0.0.1", 9300);
	mSocketClient.Start();
	mSocketClient.RegisterListener(this);

	MessageQueue::GetInstance()->RegisterListener(MODULE_DIAGNOSTIC, this);
}

void CDiagnosticManager::MessageHandler(MODULE_TYPE sender, COMMAND_TYPE cmd, void *data, int size)
{
#ifndef DIAGNOSTIC_TEST
	switch(cmd)
	{
	case CMD_DIAGNOSE_NOISE_ANOMALY:
		{
			LOGD(TAG, "CMD_DIAGNOSE_NOISE_ANOMALY");
			SendDiagnoseNoiseAnomaly(data, size);
		}
		break;
	case CMD_DIAGNOSE_VIBRATION_RATING:
		{
			LOGD(TAG, "CMD_DIAGNOSE_VIBRATION_RATING");
			SendDiagnoseVibrationRating(data, size);
		}
		break;
	case CMD_DIAGNOSE_VIBRATION_DIAGNOSIS:
		{
			LOGD(TAG, "CMD_DIAGNOSE_VIBRATION_DIAGNOSIS");
			SendDiagnoseVibrationDiagnosis(data, size);
		}
		break;
	case CMD_DIAGNOSE_VBELT_ELONGATION:
		{
			LOGD(TAG, "CMD_DIAGNOSE_VBELT_ELONGATION");
			SendDiagnoseVbeltElongation(data, size);
		}
		break;
	case CMD_DIAGNOSE_NOISE_THRESHOLD:
		{
			LOGD(TAG, "CMD_DIAGNOSE_NOISE_THRESHOLD");
			SendDiagnoseNoiseThreshold(data, size);
		}
		break;
	case CMD_DIAGNOSE_VIBRATION_THRESHOLD:
		{
			LOGD(TAG, "CMD_DIAGNOSE_VIBRATION_THRESHOLD");
			SendDiagnoseVibrationThreshold(data, size);
		}
		break;
	case CMD_DIAGNOSE_FAULT_FREQUENCY:
		{
			LOGD(TAG, "CMD_DIAGNOSE_FAULT_FREQUENCY");
			SendDiagnoseFaultFrequency(data, size);
		}
		break;
	default:
		{
			LOGE(TAG, "Not supported cmd: %02x", cmd);
		}
		break;
	}
#else
	switch(cmd)
	{
	case CMD_DIAGNOSE_NOISE_ANOMALY:
		{
			LOGD(TAG, "CMD_DIAGNOSE_NOISE_ANOMALY");
			diagnostic_result info;
			memset(&info, 0x00, sizeof(diagnostic_result));

			SendInternalMessage(MODULE_GATEWAY, CMD_DIAGNOSE_NOISE_ANOMALY_RESPONSE, &info, sizeof(diagnostic_result));
		}
		break;
	case CMD_DIAGNOSE_VIBRATION_RATING:
		{
			LOGD(TAG, "CMD_DIAGNOSE_VIBRATION_RATING");
			diagnostic_result info;
			memset(&info, 0x00, sizeof(diagnostic_result));

			SendInternalMessage(MODULE_GATEWAY, CMD_DIAGNOSE_VIBRATION_RATING_RESPONSE, &info, sizeof(diagnostic_result));
		}
		break;
	case CMD_DIAGNOSE_VIBRATION_DIAGNOSIS:
		{
			LOGD(TAG, "CMD_DIAGNOSE_VIBRATION_DIAGNOSIS");
			diagnostic_result info;
			memset(&info, 0x00, sizeof(diagnostic_result));
			SendInternalMessage(MODULE_GATEWAY, CMD_DIAGNOSE_VIBRATION_DIAGNOSIS_RESPONSE, &info, sizeof(diagnostic_result));
		}
		break;
	case CMD_DIAGNOSE_VBELT_ELONGATION:
		{
			LOGD(TAG, "CMD_DIAGNOSE_VBELT_ELONGATION");
			diagnostic_result info;
			memset(&info, 0x00, sizeof(diagnostic_result));
			SendInternalMessage(MODULE_GATEWAY, CMD_DIAGNOSE_VBELT_ELONGATION_RESPONSE, &info, sizeof(diagnostic_result));
		}
		break;
	case CMD_DIAGNOSE_NOISE_THRESHOLD:
		{
			LOGD(TAG, "CMD_DIAGNOSE_NOISE_THRESHOLD");
			diagnostic_result info;
			memset(&info, 0x00, sizeof(diagnostic_result));
			SendInternalMessage(MODULE_GATEWAY, CMD_DIAGNOSE_NOISE_THRESHOLD_RESPONSE, &info, sizeof(diagnostic_result));
		}
		break;
	case CMD_DIAGNOSE_VIBRATION_THREHSOLD:
		{
			LOGD(TAG, "CMD_DIAGNOSE_VIBRATION_THREHSOLD");
			diagnostic_result info;
			memset(&info, 0x00, sizeof(diagnostic_result));
			SendInternalMessage(MODULE_GATEWAY, CMD_DIAGNOSE_VIBRATION_THREHSOLD_RESPONSE, &info, sizeof(diagnostic_result));
		}
		break;
	case CMD_DIAGNOSE_FAULT_FREQUENCY:
		{
			LOGD(TAG, "CMD_DIAGNOSE_FAULT_FREQUENCY");
			diagnostic_result info;
			memset(&info, 0x00, sizeof(diagnostic_result));
			SendInternalMessage(MODULE_GATEWAY, CMD_DIAGNOSE_FAULT_FREQUENCY_RESPONSE, &info, sizeof(diagnostic_result));
		}
		break;
	default:
		{
			LOGE(TAG, "Not supported cmd: %02x", cmd);
		}
		break;
	}
#endif
}

void CDiagnosticManager::SendInternalMessage(MODULE_TYPE receiver, COMMAND_TYPE cmd, void *data, int size)
{
	MessageQueue::GetInstance()->SendMessage(MODULE_DIAGNOSTIC, receiver, cmd, data, size);
}

void CDiagnosticManager::Write(const uint8_t *data, const int size)
{
	PrintPacket(TAG, "[WR]", (char *)data, size);

	mSocketClient.Write((char *)data, size);
}

void CDiagnosticManager::Read(const void *data, const unsigned int size)
{
	PrintPacket(TAG, "[RD]", (char *)data, size);

	DIAGNOSTIC_HEAD *head = (DIAGNOSTIC_HEAD *)data;

	switch(head->type)
	{
	case DIAGNOSTIC_NOISE_ANOMALY_RESULT:
		{
			LOGD(TAG, "DIAGNOSTIC_NOISE_ANOMALY_RESULT");
			ReceiveDiagnoseNoiseAnomalyResult(data, size);
		}
		break;
	case DIAGNOSTIC_VIBRATION_RATING_FFT_FILE:
		{
			LOGD(TAG, "DIAGNOSTIC_VIBRATION_RATING_FFT_FILE");
			ReceiveDiagnoseVibrationRatingResult(data, size);
		}
		break;
	case DIAGNOSTIC_VIBRATION_DIAGNOSIS_RESULT:
		{
			LOGD(TAG, "DIAGNOSTIC_VIBRATION_DIAGNOSIS_RESULT");
			ReceiveDiagnoseVibrationDiagnosisResult(data, size);
		}
		break;
	case DIAGNOSTIC_VBELT_ELONGATION_RESULT:
		{
			LOGD(TAG, "DIAGNOSTIC_VBELT_ELONGATION_RESULT");
			ReceiveDiagnoseVbeltElongationResult(data, size);
		}
		break;
	case DIAGNOSTIC_NOISE_THRESHOLD_RESULT:
		{
			LOGD(TAG, "DIAGNOSTIC_NOISE_THRESHOLD_RESULT");
			ReceiveDiagnoseNoiseThresholdResult(data, size);
		}
		break;
	case DIAGNOSTIC_VIBRATION_THRESHOLD_RESULT:
		{
			LOGD(TAG, "DIAGNOSTIC_VIBRATION_THRESHOLD_RESULT");
			ReceiveDiagnoseVibrationThresholdResult(data, size);
		}
		break;
	case DIAGNOSTIC_FAULT_FREQUENCY_RESULT:
		{
			LOGD(TAG, "DIAGNOSTIC_FAULT_FREQUENCY_RESULT");
			ReceiveDiagnoseFaultFrequencyResult(data, size);
		}
		break;
	default:
		{
			LOGE(TAG, "Not supported protocol: %02x", head->type);
		}
		break;
	}
}

void CDiagnosticManager::PrintDiagnosticInfo(const diagnostic_info *info)
{
	LOGD(TAG, "MAC: %02X:%02X:%02X:%02X:%02X:%02X", info->mac[0], info->mac[1], info->mac[2], info->mac[3], info->mac[4], info->mac[5]);

	LOGD(TAG, "Time    Data: %d.%09d", info->timestamp.data.tv_sec, info->timestamp.data.tv_nsec);
	LOGD(TAG, "Time Request: %d.%09d", info->timestamp.request.tv_sec, info->timestamp.request.tv_nsec);

	if (strlen(info->info_file) > 0)
	{
		LOGD(TAG, "Info File: %s (%d)", info->info_file, strlen(info->info_file));
	}

	for (int i = 0; i < MAX_NUM_OF_DATA_FILE; i++)
	{
		if (strlen(info->data_file[i]) > 0)
		{
			LOGD(TAG, "Data File %02d: %s (%d)", i, info->data_file[i], strlen(info->data_file[i]));
		}
	}

	LOGD(TAG, "Value: %d %d %d %.4lf", info->value8, info->value16, info->value32, info->real);
}

void CDiagnosticManager::SendDiagnoseNoiseAnomaly(const void *data, const int size)
{
	diagnostic_info *info = (diagnostic_info *)data;

	struct timespec tsNow;
	clock_gettime(CLOCK_REALTIME, &tsNow);

	memcpy(&mLastDiagnosticRequest, info, sizeof(struct diagnostic_info));

	mLastDiagnosticRequest.timestamp.request = tsNow;

	PrintDiagnosticInfo(info);

	int packet_len = 0;

	packet_len += sizeof(DIAGNOSTIC_HEAD) + strlen(info->data_file[0]);
	packet_len += sizeof(DIAGNOSTIC_HEAD) + strlen(info->data_file[1]);
	packet_len += sizeof(DIAGNOSTIC_HEAD) + strlen(info->info_file);
	packet_len += sizeof(DIAGNOSTIC_HEAD) + strlen(info->data_file[2]);
	packet_len += sizeof(DIAGNOSTIC_HEAD) + sizeof(uint8_t);

	LOGD(TAG, "packet_len: %d", packet_len);

	uint8_t *packet = (uint8_t *)malloc(sizeof(uint8_t) * packet_len);
	memset(packet, 0x00, packet_len);

	char *pos = (char *)packet;
	DIAGNOSTIC_HEAD *head;

	// 1st
	head = (DIAGNOSTIC_HEAD *)pos;
	head->stx = DIAGNOSTIC_PROTOCOL_STX;
	head->type = DIAGNOSTIC_NOISE_ANOMALY_SOUND_DATA;
	head->length = ConvertEndian2(strlen(info->data_file[0]));
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(pos, info->data_file[0], strlen(info->data_file[0]));
	pos += strlen(info->data_file[0]);

	// 2nd
	head = (DIAGNOSTIC_HEAD *)pos;
	head->stx = DIAGNOSTIC_PROTOCOL_STX;
	head->type = DIAGNOSTIC_NOISE_ANOMALY_ACCUMULATED_NOISE_INDICATOR;
	head->length = ConvertEndian2(strlen(info->data_file[1]));
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(pos, info->data_file[1], strlen(info->data_file[1]));
	pos += strlen(info->data_file[1]);

	// 3rd
	head = (DIAGNOSTIC_HEAD *)pos;
	head->stx = DIAGNOSTIC_PROTOCOL_STX;
	head->type = DIAGNOSTIC_NOISE_ANOMALY_EQUIPMENT_INFO;
	head->length = ConvertEndian2(strlen(info->info_file));
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(pos, info->info_file, strlen(info->info_file));
	pos += strlen(info->info_file);

	// 4th
	head = (DIAGNOSTIC_HEAD *)pos;
	head->stx = DIAGNOSTIC_PROTOCOL_STX;
	head->type = DIAGNOSTIC_NOISE_ANOMALY_NOISE_THRESHOLD;
	head->length = ConvertEndian2(strlen(info->data_file[2]));
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(pos, info->data_file[2], strlen(info->data_file[2]));
	pos += strlen(info->data_file[2]);

	// 5th
	head = (DIAGNOSTIC_HEAD *)pos;
	head->stx = DIAGNOSTIC_PROTOCOL_STX;
	head->type = DIAGNOSTIC_NOISE_ANOMALY_GATEWAY_LOCATION;
	head->length = ConvertEndian2(sizeof(uint8_t));
	pos += sizeof(DIAGNOSTIC_HEAD);

	*pos = info->value8;
	pos += 1;

#ifndef DIAGNOSTIC_TEST
	Write(packet, packet_len);
#else
	diagnostic_result diagRes;
	memset(&diagRes, 0x00, sizeof(diagnostic_result));

	diagRes.timestamp.data = mLastDiagnosticRequest.timestamp.data;

	SendInternalMessage(MODULE_GATEWAY, CMD_DIAGNOSE_NOISE_ANOMALY_RESPONSE, &diagRes, sizeof(diagnostic_result));
#endif
}

void CDiagnosticManager::ReceiveDiagnoseNoiseAnomalyResult(const void *data, const int size)
{
	diagnostic_result info;
	memset(&info, 0x00, sizeof(diagnostic_result));

	clock_gettime(CLOCK_REALTIME, &info.timestamp.response);

	info.timestamp.data = mLastDiagnosticRequest.timestamp.data;
	info.timestamp.request = mLastDiagnosticRequest.timestamp.request;

	char *pos = (char *)data;
	DIAGNOSTIC_HEAD *head;

	// 1st
	head = (DIAGNOSTIC_HEAD *)pos;
	LOGD(TAG, "stx: %01X, type: %02X, length: %02X(%d)", head->stx, head->type, head->length, ConvertEndian2(head->length));
	if ((head->stx != DIAGNOSTIC_PROTOCOL_STX) || (head->type != DIAGNOSTIC_NOISE_ANOMALY_RESULT))
	{
		return;
	}
	pos += sizeof(DIAGNOSTIC_HEAD);

	info.extra_info.noise_anomaly.operation = pos[0];
	info.extra_info.noise_anomaly.anomaly = pos[1];
	LOGD(TAG, "operating: %d, anomaly: %d", info.extra_info.noise_anomaly.operation, info.extra_info.noise_anomaly.anomaly);
	pos += ConvertEndian2(head->length);

	// 2nd
	head = (DIAGNOSTIC_HEAD *)pos;
	LOGD(TAG, "stx: %01X, type: %02X, length: %02X(%d)", head->stx, head->type, head->length, ConvertEndian2(head->length));
	if ((head->stx != DIAGNOSTIC_PROTOCOL_STX) || (head->type != DIAGNOSTIC_NOISE_ANOMALY_NOISE_INDICATOR))
	{
		return;
	}
	pos += sizeof(DIAGNOSTIC_HEAD);

	float soundIndex = *(float *)pos;
	info.extra_info.noise_anomaly.index = ConvertEndianFloat(soundIndex);
	LOGD(TAG, "sound index: %f", info.extra_info.noise_anomaly.index);
	pos += ConvertEndian2(head->length);

	// 3rd
	head = (DIAGNOSTIC_HEAD *)pos;
	LOGD(TAG, "stx: %01X, type: %02X, length: %02X(%d)", head->stx, head->type, head->length, ConvertEndian2(head->length));
	if ((head->stx != DIAGNOSTIC_PROTOCOL_STX) || (head->type != DIAGNOSTIC_NOISE_ANOMALY_ERROR_CODE))
	{
		return;
	}
	pos += sizeof(DIAGNOSTIC_HEAD);

	info.error_code = *pos;
	LOGD(TAG, "error code: %d", info.error_code);
	pos += ConvertEndian2(head->length);

	// 4th
	head = (DIAGNOSTIC_HEAD *)pos;
	LOGD(TAG, "stx: %01X, type: %02X, length: %02X(%d)", head->stx, head->type, head->length, ConvertEndian2(head->length));
	if ((head->stx != DIAGNOSTIC_PROTOCOL_STX) || (head->type != DIAGNOSTIC_NOISE_ANOMALY_ERROR_STRING))
	{
		return;
	}
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(info.error_string, pos, Min(ConvertEndian2(head->length), ERROR_STRING_LENGTH - 1));
	LOGD(TAG, "error string: %s", info.error_string);
	pos += ConvertEndian2(head->length);

	SendInternalMessage(MODULE_GATEWAY, CMD_DIAGNOSE_NOISE_ANOMALY_RESPONSE, &info, sizeof(diagnostic_result));
}

void CDiagnosticManager::SendDiagnoseVibrationRating(const void *data, const int size)
{
	diagnostic_info *info = (diagnostic_info *)data;

	PrintDiagnosticInfo(info);

	int packet_len = 0;

	packet_len += sizeof(DIAGNOSTIC_HEAD) + strlen(info->data_file[0]);
	packet_len += sizeof(DIAGNOSTIC_HEAD) + strlen(info->data_file[1]);
	packet_len += sizeof(DIAGNOSTIC_HEAD) + strlen(info->info_file);
	packet_len += sizeof(DIAGNOSTIC_HEAD) + sizeof(uint8_t);

	LOGD(TAG, "packet_len: %d", packet_len);

	uint8_t *packet = (uint8_t *)malloc(sizeof(uint8_t) * packet_len);
	memset(packet, 0x00, packet_len);

	char *pos = (char *)packet;
	DIAGNOSTIC_HEAD *head;

	// 1st
	head = (DIAGNOSTIC_HEAD *)pos;
	head->stx = DIAGNOSTIC_PROTOCOL_STX;
	head->type = DIAGNOSTIC_VIBRATION_RATING_VIBRATION_DATA;
	head->length = ConvertEndian2(strlen(info->data_file[0]));
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(pos, info->data_file[0], strlen(info->data_file[0]));
	pos += strlen(info->data_file[0]);

	// 2nd
	head = (DIAGNOSTIC_HEAD *)pos;
	head->stx = DIAGNOSTIC_PROTOCOL_STX;
	head->type = DIAGNOSTIC_VIBRATION_RATING_CUMULATED_VIBRATION_RMS;
	head->length = ConvertEndian2(strlen(info->data_file[1]));
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(pos, info->data_file[1], strlen(info->data_file[1]));
	pos += strlen(info->data_file[1]);

	// 3rd
	head = (DIAGNOSTIC_HEAD *)pos;
	head->stx = DIAGNOSTIC_PROTOCOL_STX;
	head->type = DIAGNOSTIC_VIBRATION_RATING_VIBRATION_SENSOR_LOCATION;
	head->length = ConvertEndian2(sizeof(uint8_t));
	pos += sizeof(DIAGNOSTIC_HEAD);

	*pos = info->value8;
	pos += sizeof(uint8_t);

	// 4th
	head = (DIAGNOSTIC_HEAD *)pos;
	head->stx = DIAGNOSTIC_PROTOCOL_STX;
	head->type = DIAGNOSTIC_VIBRATION_RATING_EQUIPMENT_INFO;
	head->length = ConvertEndian2(strlen(info->info_file));
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(pos, info->info_file, strlen(info->info_file));
	pos += strlen(info->info_file);

	Write(packet, packet_len);
}

void CDiagnosticManager::ReceiveDiagnoseVibrationRatingResult(const void *data, const int size)
{
	diagnostic_result info;
	memset(&info, 0x00, sizeof(diagnostic_result));

	char *pos = (char *)data;
	DIAGNOSTIC_HEAD *head;

	// 1st
	head = (DIAGNOSTIC_HEAD *)pos;
	LOGD(TAG, "stx: %01X, type: %02X, length: %02X(%d)", head->stx, head->type, head->length, ConvertEndian2(head->length));
	if ((head->stx != DIAGNOSTIC_PROTOCOL_STX) || (head->type != DIAGNOSTIC_VIBRATION_RATING_FFT_FILE))
	{
		return;
	}
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(info.extra_info.vibration_rating.fft_file, pos, Min(ConvertEndian2(head->length), FILE_PATH_LENGTH - 1));
	LOGD(TAG, "FFT file: %s", info.extra_info.vibration_rating.fft_file);
	pos += ConvertEndian2(head->length);

	// 2nd
	head = (DIAGNOSTIC_HEAD *)pos;
	LOGD(TAG, "stx: %01X, type: %02X, length: %02X(%d)", head->stx, head->type, head->length, ConvertEndian2(head->length));
	if ((head->stx != DIAGNOSTIC_PROTOCOL_STX) || (head->type != DIAGNOSTIC_VIBRATION_RATING_RESULT))
	{
		return;
	}
	pos += sizeof(DIAGNOSTIC_HEAD);

	VIBRATION_RATING_RESULT *res = (VIBRATION_RATING_RESULT *)(pos + sizeof(DIAGNOSTIC_HEAD));
	info.extra_info.vibration_rating.rms_x = ConvertEndianFloat(res->rms_x);
	info.extra_info.vibration_rating.rms_y = ConvertEndianFloat(res->rms_y);
	info.extra_info.vibration_rating.rms_z = ConvertEndianFloat(res->rms_z);
	info.extra_info.vibration_rating.grade_x = res->grade_x;
	info.extra_info.vibration_rating.grade_y = res->grade_y;
	info.extra_info.vibration_rating.grade_z = res->grade_z;
	info.extra_info.vibration_rating.over_x = res->over_x;
	info.extra_info.vibration_rating.over_y = res->over_y;
	info.extra_info.vibration_rating.over_z = res->over_z;
	LOGD(TAG, "RMS: %f, %f, %f, Grade: %c, %c, %c, Over: %d, %d, %d",
			res->rms_x, res->rms_y, res->rms_z, res->grade_x, res->grade_y, res->grade_z, res->over_x, res->over_y, res->over_z);
	pos += ConvertEndian2(head->length);

	// 3rd
	head = (DIAGNOSTIC_HEAD *)pos;
	LOGD(TAG, "stx: %01X, type: %02X, length: %02X(%d)", head->stx, head->type, head->length, ConvertEndian2(head->length));
	if ((head->stx != DIAGNOSTIC_PROTOCOL_STX) || (head->type != DIAGNOSTIC_VIBRATION_RATING_ERROR_CODE))
	{
		return;
	}
	pos += sizeof(DIAGNOSTIC_HEAD);

	info.error_code = *pos;
	LOGD(TAG, "error code: %d", info.error_code);
	pos += ConvertEndian2(head->length);

	// 4th
	head = (DIAGNOSTIC_HEAD *)pos;
	LOGD(TAG, "stx: %01X, type: %02X, length: %02X(%d)", head->stx, head->type, head->length, ConvertEndian2(head->length));
	if ((head->stx != DIAGNOSTIC_PROTOCOL_STX) || (head->type != DIAGNOSTIC_VIBRATION_RATING_ERROR_STRING))
	{
		return;
	}
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(info.error_string, pos, Min(ConvertEndian2(head->length), ERROR_STRING_LENGTH - 1));
	LOGD(TAG, "error string: %s", info.error_string);
	pos += ConvertEndian2(head->length);

	SendInternalMessage(MODULE_GATEWAY, CMD_DIAGNOSE_VIBRATION_RATING_RESPONSE, &info, sizeof(diagnostic_result));
}

void CDiagnosticManager::SendDiagnoseVibrationDiagnosis(const void *data, const int size)
{
	diagnostic_info *info = (diagnostic_info *)data;

	PrintDiagnosticInfo(info);

	int packet_len = 0;

	packet_len += sizeof(DIAGNOSTIC_HEAD) + strlen(info->data_file[0]);
	packet_len += sizeof(DIAGNOSTIC_HEAD) + strlen(info->data_file[1]);
	packet_len += sizeof(DIAGNOSTIC_HEAD) + strlen(info->data_file[2]);
	packet_len += sizeof(DIAGNOSTIC_HEAD) + sizeof(uint16_t);
	packet_len += sizeof(DIAGNOSTIC_HEAD) + strlen(info->info_file);

	LOGD(TAG, "packet_len: %d", packet_len);

	uint8_t *packet = (uint8_t *)malloc(sizeof(uint8_t) * packet_len);
	memset(packet, 0x00, packet_len);

	char *pos = (char *)packet;
	DIAGNOSTIC_HEAD *head;

	// 1st
	head = (DIAGNOSTIC_HEAD *)pos;
	head->stx = DIAGNOSTIC_PROTOCOL_STX;
	head->type = DIAGNOSTIC_VIBRATION_DIAGNOSIS_VIBRATION_DATA;
	head->length = ConvertEndian2(strlen(info->data_file[0]));
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(pos, info->data_file[0], strlen(info->data_file[0]));
	pos += strlen(info->data_file[0]);

	// 2nd
	head = (DIAGNOSTIC_HEAD *)pos;
	head->stx = DIAGNOSTIC_PROTOCOL_STX;
	head->type = DIAGNOSTIC_VIBRATION_DIAGNOSIS_FAULT_FREQUENCY;
	head->length = ConvertEndian2(strlen(info->data_file[1]));
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(pos, info->data_file[1], strlen(info->data_file[1]));
	pos += strlen(info->data_file[1]);

	// 3rd
	head = (DIAGNOSTIC_HEAD *)pos;
	head->stx = DIAGNOSTIC_PROTOCOL_STX;
	head->type = DIAGNOSTIC_VIBRATION_DIAGNOSIS_VIBRATION_THRESHOLD;
	head->length = ConvertEndian2(strlen(info->data_file[2]));
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(pos, info->data_file[2], strlen(info->data_file[2]));
	pos += strlen(info->data_file[2]);

	// 4th
	head = (DIAGNOSTIC_HEAD *)pos;
	head->stx = DIAGNOSTIC_PROTOCOL_STX;
	head->type = DIAGNOSTIC_VIBRATION_DIAGNOSIS_VIBRATION_SENSOR_DIRECTION;
	head->length = ConvertEndian2(sizeof(uint16_t));
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(pos, &info->value16, sizeof(uint16_t));
	pos += sizeof(uint16_t);

	// 5th
	head = (DIAGNOSTIC_HEAD *)pos;
	head->stx = DIAGNOSTIC_PROTOCOL_STX;
	head->type = DIAGNOSTIC_VIBRATION_DIAGNOSIS_EQUIPMENT_INFO;
	head->length = ConvertEndian2(strlen(info->info_file));
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(pos, info->info_file, strlen(info->info_file));
	pos += strlen(info->info_file);

	Write(packet, packet_len);
}

void CDiagnosticManager::ReceiveDiagnoseVibrationDiagnosisResult(const void *data, const int size)
{
	diagnostic_result info;
	memset(&info, 0x00, sizeof(diagnostic_result));

	char *pos = (char *)data;
	DIAGNOSTIC_HEAD *head;

	// 1st
	head = (DIAGNOSTIC_HEAD *)pos;
	LOGD(TAG, "stx: %01X, type: %02X, length: %02X(%d)", head->stx, head->type, head->length, ConvertEndian2(head->length));
	if ((head->stx != DIAGNOSTIC_PROTOCOL_STX) || (head->type != DIAGNOSTIC_VIBRATION_DIAGNOSIS_RESULT))
	{
		return;
	}
	pos += sizeof(DIAGNOSTIC_HEAD);

	info.extra_info.vibration_diagnosis.length = ConvertEndian2(head->length);
	for (int i = 0; i < ConvertEndian2(head->length); i++)
	{
		info.extra_info.vibration_diagnosis.diagnosis[i] = *(pos + i);
		LOGD(TAG, "mal: %d/%d Type: %02x", i, info.extra_info.vibration_diagnosis.length, info.extra_info.vibration_diagnosis.diagnosis[i]);
	}
	pos += ConvertEndian2(head->length);

	// 2nd
	head = (DIAGNOSTIC_HEAD *)pos;
	LOGD(TAG, "stx: %01X, type: %02X, length: %02X(%d)", head->stx, head->type, head->length, ConvertEndian2(head->length));
	if ((head->stx != DIAGNOSTIC_PROTOCOL_STX) || (head->type != DIAGNOSTIC_VIBRATION_DIAGNOSIS_ERROR_CODE))
	{
		return;
	}
	pos += sizeof(DIAGNOSTIC_HEAD);

	info.error_code = *pos;
	LOGD(TAG, "error code: %d", info.error_code);
	pos += ConvertEndian2(head->length);

	// 3rd
	head = (DIAGNOSTIC_HEAD *)pos;
	LOGD(TAG, "stx: %01X, type: %02X, length: %02X(%d)", head->stx, head->type, head->length, ConvertEndian2(head->length));
	if ((head->stx != DIAGNOSTIC_PROTOCOL_STX) || (head->type != DIAGNOSTIC_VIBRATION_DIAGNOSIS_ERROR_STRING))
	{
		return;
	}
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(info.error_string, pos, Min(ConvertEndian2(head->length), ERROR_STRING_LENGTH - 1));
	LOGD(TAG, "error string: %s", info.error_string);
	pos += ConvertEndian2(head->length);

	SendInternalMessage(MODULE_GATEWAY, CMD_DIAGNOSE_VIBRATION_DIAGNOSIS_RESPONSE, &info, sizeof(diagnostic_result));
}

void CDiagnosticManager::SendDiagnoseVbeltElongation(const void *data, const int size)
{
	diagnostic_info *info = (diagnostic_info *)data;

	PrintDiagnosticInfo(info);

	int packet_len = 0;

	packet_len += sizeof(DIAGNOSTIC_HEAD) + strlen(info->data_file[0]);
	packet_len += sizeof(DIAGNOSTIC_HEAD) + strlen(info->data_file[1]);
	packet_len += sizeof(DIAGNOSTIC_HEAD) + strlen(info->data_file[2]);
	packet_len += sizeof(DIAGNOSTIC_HEAD) + strlen(info->data_file[3]);
	packet_len += sizeof(DIAGNOSTIC_HEAD) + strlen(info->data_file[4]);
	packet_len += sizeof(DIAGNOSTIC_HEAD) + strlen(info->data_file[5]);
	packet_len += sizeof(DIAGNOSTIC_HEAD) + strlen(info->info_file);

	LOGD(TAG, "packet_len: %d", packet_len);

	uint8_t *packet = (uint8_t *)malloc(sizeof(uint8_t) * packet_len);
	memset(packet, 0x00, packet_len);

	char *pos = (char *)packet;
	DIAGNOSTIC_HEAD *head;

	// 1st
	head = (DIAGNOSTIC_HEAD *)pos;
	head->stx = DIAGNOSTIC_PROTOCOL_STX;
	head->type = DIAGNOSTIC_VBELT_ELONGATION_MOTOR_VIBRATION_DATA;
	head->length = ConvertEndian2(strlen(info->data_file[0]));
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(pos, info->data_file[0], strlen(info->data_file[0]));
	pos += strlen(info->data_file[0]);

	// 2nd
	head = (DIAGNOSTIC_HEAD *)pos;
	head->stx = DIAGNOSTIC_PROTOCOL_STX;
	head->type = DIAGNOSTIC_VBELT_ELONGATION_BEARING_VIBRATION_DATA;
	head->length = ConvertEndian2(strlen(info->data_file[1]));
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(pos, info->data_file[1], strlen(info->data_file[1]));
	pos += strlen(info->data_file[1]);

	// 3rd
	head = (DIAGNOSTIC_HEAD *)pos;
	head->stx = DIAGNOSTIC_PROTOCOL_STX;
	head->type = DIAGNOSTIC_VBELT_ELONGATION_SOUND_DATA;
	head->length = ConvertEndian2(strlen(info->data_file[2]));
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(pos, info->data_file[2], strlen(info->data_file[2]));
	pos += strlen(info->data_file[2]);

	// 4th
	head = (DIAGNOSTIC_HEAD *)pos;
	head->stx = DIAGNOSTIC_PROTOCOL_STX;
	head->type = DIAGNOSTIC_VBELT_ELONGATION_CUMULATED_VELOCITY_DATA;
	head->length = ConvertEndian2(strlen(info->data_file[3]));
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(pos, info->data_file[3], strlen(info->data_file[3]));
	pos += strlen(info->data_file[3]);

	// 5th
	head = (DIAGNOSTIC_HEAD *)pos;
	head->stx = DIAGNOSTIC_PROTOCOL_STX;
	head->type = DIAGNOSTIC_VBELT_ELONGATION_FAULT_FREQUENCY;
	head->length = ConvertEndian2(strlen(info->data_file[4]));
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(pos, info->data_file[4], strlen(info->data_file[4]));
	pos += strlen(info->data_file[4]);

	// 6th
	head = (DIAGNOSTIC_HEAD *)pos;
	head->stx = DIAGNOSTIC_PROTOCOL_STX;
	head->type = DIAGNOSTIC_VBELT_ELONGATION_VIBRATION_THRESHOLD;
	head->length = ConvertEndian2(strlen(info->data_file[5]));
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(pos, info->data_file[5], strlen(info->data_file[5]));
	pos += strlen(info->data_file[5]);

	// 7th
	head = (DIAGNOSTIC_HEAD *)pos;
	head->stx = DIAGNOSTIC_PROTOCOL_STX;
	head->type = DIAGNOSTIC_VBELT_ELONGATION_EQUIPMENT_INFO;
	head->length = ConvertEndian2(strlen(info->info_file));
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(pos, info->info_file, strlen(info->info_file));
	pos += strlen(info->info_file);

	Write(packet, packet_len);
}

void CDiagnosticManager::ReceiveDiagnoseVbeltElongationResult(const void *data, const int size)
{
	diagnostic_result info;
	memset(&info, 0x00, sizeof(diagnostic_result));

	char *pos = (char *)data;
	DIAGNOSTIC_HEAD *head;

	// 1st
	head = (DIAGNOSTIC_HEAD *)pos;
	LOGD(TAG, "stx: %01X, type: %02X, length: %02X(%d)", head->stx, head->type, head->length, ConvertEndian2(head->length));
	if ((head->stx != DIAGNOSTIC_PROTOCOL_STX) || (head->type != DIAGNOSTIC_VBELT_ELONGATION_RESULT))
	{
		return;
	}
	pos += sizeof(DIAGNOSTIC_HEAD);

	float elongation = *(float *)pos;
	info.extra_info.vbelt_elongation.elongation = ConvertEndianFloat(elongation);
	LOGD(TAG, "Elongation: %lf", info.extra_info.vbelt_elongation.elongation);
	pos += ConvertEndian2(head->length);

	// 2nd
	head = (DIAGNOSTIC_HEAD *)pos;
	LOGD(TAG, "stx: %01X, type: %02X, length: %02X(%d)", head->stx, head->type, head->length, ConvertEndian2(head->length));
	if ((head->stx != DIAGNOSTIC_PROTOCOL_STX) || (head->type != DIAGNOSTIC_VBELT_ELONGATION_RATING))
	{
		return;
	}
	pos += sizeof(DIAGNOSTIC_HEAD);

	info.extra_info.vbelt_elongation.grade = *pos;
	pos += ConvertEndian2(head->length);

	// 3rd
	head = (DIAGNOSTIC_HEAD *)pos;
	LOGD(TAG, "stx: %01X, type: %02X, length: %02X(%d)", head->stx, head->type, head->length, ConvertEndian2(head->length));
	if ((head->stx != DIAGNOSTIC_PROTOCOL_STX) || (head->type != DIAGNOSTIC_VBELT_ELONGATION_PULLEY_SPEED))
	{
		return;
	}
	pos += sizeof(DIAGNOSTIC_HEAD);

	struct _speed { float speed1, speed2; } *speed = (struct _speed *)pos;
	info.extra_info.vbelt_elongation.pulley_speed1 = ConvertEndianFloat(speed->speed1);
	info.extra_info.vbelt_elongation.pulley_speed2 = ConvertEndianFloat(speed->speed2);
	LOGD(TAG, "Speed1: %lf, Speed2: %lf", info.extra_info.vbelt_elongation.pulley_speed1, info.extra_info.vbelt_elongation.pulley_speed2);
	pos += ConvertEndian2(head->length);

	// 4th
	head = (DIAGNOSTIC_HEAD *)pos;
	LOGD(TAG, "stx: %01X, type: %02X, length: %02X(%d)", head->stx, head->type, head->length, ConvertEndian2(head->length));
	if ((head->stx != DIAGNOSTIC_PROTOCOL_STX) || (head->type != DIAGNOSTIC_VBELT_ELONGATION_ERROR_CODE))
	{
		return;
	}
	pos += sizeof(DIAGNOSTIC_HEAD);

	info.error_code = *pos;
	LOGD(TAG, "error code: %d", info.error_code);
	pos += ConvertEndian2(head->length);

	// 5th
	head = (DIAGNOSTIC_HEAD *)pos;
	LOGD(TAG, "stx: %01X, type: %02X, length: %02X(%d)", head->stx, head->type, head->length, ConvertEndian2(head->length));
	if ((head->stx != DIAGNOSTIC_PROTOCOL_STX) || (head->type != DIAGNOSTIC_VBELT_ELONGATION_ERROR_STRING))
	{
		return;
	}
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(info.error_string, pos, Min(ConvertEndian2(head->length), ERROR_STRING_LENGTH - 1));
	LOGD(TAG, "error string: %s", info.error_string);
	pos += ConvertEndian2(head->length);

	SendInternalMessage(MODULE_GATEWAY, CMD_DIAGNOSE_VBELT_ELONGATION_RESPONSE, &info, sizeof(diagnostic_result));
}

void CDiagnosticManager::SendDiagnoseNoiseThreshold(const void *data, const int size)
{
	diagnostic_info *info = (diagnostic_info *)data;

	PrintDiagnosticInfo(info);

	int packet_len = 0;

	for(int i = 0 ;i < info->num_data_file; i++)
	{
		packet_len += sizeof(DIAGNOSTIC_HEAD) + strlen(info->data_file[i]);
	}
	packet_len += sizeof(DIAGNOSTIC_HEAD) + strlen(info->info_file);

	LOGD(TAG, "packet_len: %d", packet_len);

	uint8_t *packet = (uint8_t *)malloc(sizeof(uint8_t) * packet_len);
	memset(packet, 0x00, packet_len);

	char *pos = (char *)packet;
	DIAGNOSTIC_HEAD *head;

	// 1st ~ 10th
	for(int i = 0; i < info->num_data_file; i++)
	{
		head = (DIAGNOSTIC_HEAD *)pos;
		head->stx = DIAGNOSTIC_PROTOCOL_STX;
		head->type = DIAGNOSTIC_NOISE_THRESHOLD_SOUND_DATA + i;
		head->length = ConvertEndian2(strlen(info->data_file[i]));
		pos += sizeof(DIAGNOSTIC_HEAD);

		memcpy(pos, info->data_file[i], strlen(info->data_file[i]));
		pos += strlen(info->data_file[i]);
	}

	// 11th
	head = (DIAGNOSTIC_HEAD *)pos;
	head->stx = DIAGNOSTIC_PROTOCOL_STX;
	head->type = DIAGNOSTIC_NOISE_THRESHOLD_EQUIPMENT_INFO;
	head->length = ConvertEndian2(strlen(info->info_file));
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(pos, info->info_file, strlen(info->info_file));
	pos += strlen(info->info_file);

	Write(packet, packet_len);
}

void CDiagnosticManager::ReceiveDiagnoseNoiseThresholdResult(const void *data, const int size)
{
	diagnostic_result info;
	memset(&info, 0x00, sizeof(diagnostic_result));

	char *pos = (char *)data;
	DIAGNOSTIC_HEAD *head;

	// 1st
	head = (DIAGNOSTIC_HEAD *)pos;
	LOGD(TAG, "stx: %01X, type: %02X, length: %02X(%d)", head->stx, head->type, head->length, ConvertEndian2(head->length));
	if ((head->stx != DIAGNOSTIC_PROTOCOL_STX) || (head->type != DIAGNOSTIC_NOISE_THRESHOLD_RESULT))
	{
		return;
	}
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(info.extra_info.noise_threshold.noise_threshold_file, pos, ConvertEndian2(head->length));
	LOGD(TAG, "Sound Threshold File: %s", info.extra_info.noise_threshold.noise_threshold_file);
	pos += ConvertEndian2(head->length);

	// 2nd
	head = (DIAGNOSTIC_HEAD *)pos;
	LOGD(TAG, "stx: %01X, type: %02X, length: %02X(%d)", head->stx, head->type, head->length, ConvertEndian2(head->length));
	if ((head->stx != DIAGNOSTIC_PROTOCOL_STX) || (head->type != DIAGNOSTIC_NOISE_THRESHOLD_NOISE_INDICATOR))
	{
		return;
	}
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(info.extra_info.noise_threshold.accumulated_noise_indicator_file, pos, ConvertEndian2(head->length));
	LOGD(TAG, "Sound Index File: %s", info.extra_info.noise_threshold.accumulated_noise_indicator_file);
	pos += ConvertEndian2(head->length);

	// 3rd
	head = (DIAGNOSTIC_HEAD *)pos;
	LOGD(TAG, "stx: %01X, type: %02X, length: %02X(%d)", head->stx, head->type, head->length, ConvertEndian2(head->length));
	if ((head->stx != DIAGNOSTIC_PROTOCOL_STX) || (head->type != DIAGNOSTIC_NOISE_THRESHOLD_ERROR_CODE))
	{
		return;
	}
	pos += sizeof(DIAGNOSTIC_HEAD);

	info.error_code = *pos;
	LOGD(TAG, "error code: %d", info.error_code);
	pos += ConvertEndian2(head->length);

	// 4th
	head = (DIAGNOSTIC_HEAD *)pos;
	LOGD(TAG, "stx: %01X, type: %02X, length: %02X(%d)", head->stx, head->type, head->length, ConvertEndian2(head->length));
	if ((head->stx != DIAGNOSTIC_PROTOCOL_STX) || (head->type != DIAGNOSTIC_NOISE_THRESHOLD_ERROR_STRING))
	{
		return;
	}
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(info.error_string, pos, Min(ConvertEndian2(head->length), ERROR_STRING_LENGTH - 1));
	LOGD(TAG, "error string: %s", info.error_string);
	pos += ConvertEndian2(head->length);

	SendInternalMessage(MODULE_GATEWAY, CMD_DIAGNOSE_NOISE_THRESHOLD_RESPONSE, &info, sizeof(diagnostic_result));
}

void CDiagnosticManager::SendDiagnoseVibrationThreshold(const void *data, const int size)
{
	diagnostic_info *info = (diagnostic_info *)data;

	PrintDiagnosticInfo(info);

	int packet_len = 0;

	for(int i = 0 ;i < info->num_data_file; i++)
	{
		packet_len += sizeof(DIAGNOSTIC_HEAD) + strlen(info->data_file[i]);
	}
	packet_len += sizeof(DIAGNOSTIC_HEAD) + strlen(info->info_file);

	LOGD(TAG, "packet_len: %d", packet_len);

	uint8_t *packet = (uint8_t *)malloc(sizeof(uint8_t) * packet_len);
	memset(packet, 0x00, packet_len);

	char *pos = (char *)packet;
	DIAGNOSTIC_HEAD *head;

	// 1st ~ 10th
	for(int i = 0; i < info->num_data_file; i = i + 2)
	{
		head = (DIAGNOSTIC_HEAD *)pos;
		head->stx = DIAGNOSTIC_PROTOCOL_STX;
		head->type = DIAGNOSTIC_VIBRATION_THRESHOLD_MOTOR_VIBRATION_DATA + i;
		head->length = ConvertEndian2(strlen(info->data_file[i]));
		pos += sizeof(DIAGNOSTIC_HEAD);

		memcpy(pos, info->data_file[i], strlen(info->data_file[i]));
		pos += strlen(info->data_file[i]);

		head = (DIAGNOSTIC_HEAD *)pos;
		head->stx = DIAGNOSTIC_PROTOCOL_STX;
		head->type = DIAGNOSTIC_VIBRATION_THRESHOLD_BEARING_VIBRATION_DATA + i;
		head->length = ConvertEndian2(strlen(info->data_file[i + 1]));
		pos += sizeof(DIAGNOSTIC_HEAD);

		memcpy(pos, info->data_file[i + 1], strlen(info->data_file[i + 1]));
		pos += strlen(info->data_file[i + 1]);
	}

	// 11th
	head = (DIAGNOSTIC_HEAD *)pos;
	head->stx = DIAGNOSTIC_PROTOCOL_STX;
	head->type = DIAGNOSTIC_VIBRATION_THRESHOLD_EQUIPMENT_INFO;
	head->length = ConvertEndian2(strlen(info->info_file));
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(pos, info->info_file, strlen(info->info_file));
	pos += strlen(info->info_file);

	Write(packet, packet_len);
}

void CDiagnosticManager::ReceiveDiagnoseVibrationThresholdResult(const void *data, const int size)
{
	diagnostic_result info;
	memset(&info, 0x00, sizeof(diagnostic_result));

	char *pos = (char *)data;
	DIAGNOSTIC_HEAD *head;

	// 1st
	head = (DIAGNOSTIC_HEAD *)pos;
	LOGD(TAG, "stx: %01X, type: %02X, length: %02X(%d)", head->stx, head->type, head->length, ConvertEndian2(head->length));
	if ((head->stx != DIAGNOSTIC_PROTOCOL_STX) || (head->type != DIAGNOSTIC_VIBRATION_THRESHOLD_RESULT))
	{
		return;
	}
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(info.extra_info.vibration_threshold.vibration_threshold_file, pos, ConvertEndian2(head->length));
	LOGD(TAG, "Vibration Threshold File: %s", info.extra_info.vibration_threshold.vibration_threshold_file);
	pos += ConvertEndian2(head->length);

	// 2nd
	head = (DIAGNOSTIC_HEAD *)pos;
	LOGD(TAG, "stx: %01X, type: %02X, length: %02X(%d)", head->stx, head->type, head->length, ConvertEndian2(head->length));
	if ((head->stx != DIAGNOSTIC_PROTOCOL_STX) || (head->type != DIAGNOSTIC_VIBRATION_THRESHOLD_CUMULATED_VIBRATION_RMS))
	{
		return;
	}
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(info.extra_info.vibration_threshold.accumulated_vibration_rms_file, pos, ConvertEndian2(head->length));
	LOGD(TAG, "Sound Index File: %s", info.extra_info.vibration_threshold.accumulated_vibration_rms_file);
	pos += ConvertEndian2(head->length);

	// 3rd
	head = (DIAGNOSTIC_HEAD *)pos;
	LOGD(TAG, "stx: %01X, type: %02X, length: %02X(%d)", head->stx, head->type, head->length, ConvertEndian2(head->length));
	if ((head->stx != DIAGNOSTIC_PROTOCOL_STX) || (head->type != DIAGNOSTIC_VIBRATION_THRESHOLD_ERROR_CODE))
	{
		return;
	}
	pos += sizeof(DIAGNOSTIC_HEAD);

	info.error_code = *pos;
	LOGD(TAG, "error code: %d", info.error_code);
	pos += ConvertEndian2(head->length);

	// 4th
	head = (DIAGNOSTIC_HEAD *)pos;
	LOGD(TAG, "stx: %01X, type: %02X, length: %02X(%d)", head->stx, head->type, head->length, ConvertEndian2(head->length));
	if ((head->stx != DIAGNOSTIC_PROTOCOL_STX) || (head->type != DIAGNOSTIC_VIBRATION_THRESHOLD_ERROR_STRING))
	{
		return;
	}
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(info.error_string, pos, Min(ConvertEndian2(head->length), ERROR_STRING_LENGTH - 1));
	LOGD(TAG, "error string: %s", info.error_string);
	pos += ConvertEndian2(head->length);

	SendInternalMessage(MODULE_GATEWAY, CMD_DIAGNOSE_VIBRATION_THRESHOLD_RESPONSE, &info, sizeof(diagnostic_result));
}

void CDiagnosticManager::SendDiagnoseFaultFrequency(const void *data, const int size)
{
	diagnostic_info *info = (diagnostic_info *)data;

	PrintDiagnosticInfo(info);

	int packet_len = 0;

	packet_len += sizeof(DIAGNOSTIC_HEAD) + strlen(info->info_file);

	LOGD(TAG, "packet_len: %d", packet_len);

	uint8_t *packet = (uint8_t *)malloc(sizeof(uint8_t) * packet_len);
	memset(packet, 0x00, packet_len);

	char *pos = (char *)packet;
	DIAGNOSTIC_HEAD *head;

	// 1st
	head = (DIAGNOSTIC_HEAD *)pos;
	head->stx = DIAGNOSTIC_PROTOCOL_STX;
	head->type = DIAGNOSTIC_FAULT_FREQUENCY_EQUIPMENT_INFO;
	head->length = ConvertEndian2(strlen(info->info_file));
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(pos, info->info_file, strlen(info->info_file));
	pos += strlen(info->info_file);

	Write(packet, packet_len);
}

void CDiagnosticManager::ReceiveDiagnoseFaultFrequencyResult(const void *data, const int size)
{
	diagnostic_result info;
	memset(&info, 0x00, sizeof(diagnostic_result));

	char *pos = (char *)data;
	DIAGNOSTIC_HEAD *head;

	// 1st
	head = (DIAGNOSTIC_HEAD *)pos;
	LOGD(TAG, "stx: %01X, type: %02X, length: %02X(%d)", head->stx, head->type, head->length, ConvertEndian2(head->length));
	if ((head->stx != DIAGNOSTIC_PROTOCOL_STX) || (head->type != DIAGNOSTIC_FAULT_FREQUENCY_RESULT))
	{
		return;
	}
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(info.extra_info.fault_frequency.fault_frequency_file, pos, ConvertEndian2(head->length));
	LOGD(TAG, "Defect frequency file: %s", info.extra_info.fault_frequency.fault_frequency_file);
	pos += ConvertEndian2(head->length);

	// 2nd
	head = (DIAGNOSTIC_HEAD *)pos;
	LOGD(TAG, "stx: %01X, type: %02X, length: %02X(%d)", head->stx, head->type, head->length, ConvertEndian2(head->length));
	if ((head->stx != DIAGNOSTIC_PROTOCOL_STX) || (head->type != DIAGNOSTIC_FAULT_FREQUENCY_ERROR_CODE))
	{
		return;
	}
	pos += sizeof(DIAGNOSTIC_HEAD);

	info.error_code = *pos;
	LOGD(TAG, "error code: %d", info.error_code);
	pos += ConvertEndian2(head->length);

	// 3rd
	head = (DIAGNOSTIC_HEAD *)pos;
	LOGD(TAG, "stx: %01X, type: %02X, length: %02X(%d)", head->stx, head->type, head->length, ConvertEndian2(head->length));
	if ((head->stx != DIAGNOSTIC_PROTOCOL_STX) || (head->type != DIAGNOSTIC_FAULT_FREQUENCY_ERROR_STRING))
	{
		return;
	}
	pos += sizeof(DIAGNOSTIC_HEAD);

	memcpy(info.error_string, pos, Min(ConvertEndian2(head->length), ERROR_STRING_LENGTH - 1));
	LOGD(TAG, "error string: %s", info.error_string);
	pos += ConvertEndian2(head->length);

	SendInternalMessage(MODULE_GATEWAY, CMD_DIAGNOSE_FAULT_FREQUENCY_RESPONSE, &info, sizeof(diagnostic_result));
}

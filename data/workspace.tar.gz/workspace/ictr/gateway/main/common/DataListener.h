#pragma once

class IDataListener
{
public:
	virtual void Read(const void *data, const unsigned int size) = 0;
};

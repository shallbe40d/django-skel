#pragma once

#include "MessageDefine.h"
#include <memory>
#include <memory.h>
#include <stdio.h>
#include <log/Log.h>

class Message : std::enable_shared_from_this<Message>
{
public:
	Message(int id, MODULE_TYPE sender, MODULE_TYPE receiver, COMMAND_TYPE cmd, void * data, int size)
	{
		//LOGD("MSG", "[Constructor] Id: %d, Cmd: %d, Data: %p, Size: %d", id, cmd, data, size);
#if 0
		clock_gettime(CLOCK_REALTIME, &tsIn);
#endif

		mId = id;

		mSender = sender;
		mReceiver = receiver;
		mCmd = cmd;

		if ((data != NULL) && (size > 0))
		{
			mData = new uint8_t[size];
			//LOGD("MSG", "Allocate: %p, size: %d", mData, size);
			memcpy(mData, data, size);
		}
		else
		{
			mData = NULL;
		}
		mSize = size;
	}

	~Message()
	{
		//LOGD("MSG", "destroy: %d", mId);
#if 0
		clock_gettime(CLOCK_REALTIME, &tsEnd);
#endif

#if 0
		//int diffQueue = (msg->tsOut.tv_sec - msg->tsIn.tv_sec) * 1000 * 1000 + (msg->tsOut.tv_nsec - msg->tsIn.tv_nsec) / 1000;
		int diffProcess = (this->tsEnd.tv_sec - this->tsOut.tv_sec) * 1000 * 1000 + (this->tsEnd.tv_nsec - this->tsOut.tv_nsec) / 1000;
		//LOGD(TAG, "[%u][%04u][Queue: %u][Process: %u] %d(%s) -> %d(%s) : cmd: %d [%s]", std::this_thread::get_id(), msg->id, diffQueue, diffProcess, msg->sender, senderName, msg->receiver, receiverName, msg->cmd, cmdName);
#endif

		if (mData != NULL)
		{
			//LOGD("MSG", "Free: %p, size: %d", mData, mSize);
			delete((uint8_t *)mData);
			mData = NULL;
		}
	}

public:
	unsigned int mId;
	struct timespec tsIn;
	struct timespec tsOut;
	struct timespec tsEnd;

	MODULE_TYPE mSender;
	MODULE_TYPE mReceiver;
	COMMAND_TYPE mCmd;
	void *mData;
	int mSize;
};

class IMessageListener
{
public:
	//virtual void Notify(MODULE_TYPE sender, COMMAND_TYPE cmd, void *data, int size) = 0;
	virtual void Notify(std::shared_ptr<Message> msg) = 0;
};

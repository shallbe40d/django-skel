#ifndef MESSAGEDEFINE_H
#define MESSAGEDEFINE_H

#include <stdint.h>
#include <time.h>

const int MAX_MODULE_NAME_LENGTH = 16;
const int MAX_MESSAGE_NAME_LENGTH = 64;
const int MAX_ID_LENGTH = 64;

enum MODULE_TYPE
{
	MODULE_SYSTEM,
	MODULE_MAIN,
	MODULE_GATEWAY,
	MODULE_MCU,
	MODULE_ADC,
	MODULE_BLE,
	MODULE_WIFI,
	MODULE_DIAGNOSTIC,
	MODULE_SERVERCOMM,
	MODULE_EMROUTER,
	MODULE_MAX
};

enum COMMAND_TYPE
{
	CMD_TEST_MODULE_COMMUNICATION,

	// Common
	CMD_REQUEST_HEART_BEAT,
	CMD_REQUEST_HEART_BEAT_RESPONSE,

	// Gateway
	CMD_REQUEST_REGISTER_IOT_SENSOR,

	CMD_REQUEST_IOT_SENSOR_MEASUREMENT,
	CMD_REQUEST_IOT_SENSOR_MEASUREMENT_RESPONSE,

	CMD_REQUEST_DOWNLOAD_DATA_SINGLE_DEVICE,
	CMD_REQUEST_DOWNLOAD_DATA_SINGLE_DEVICE_RESPONSE,

	// Gateway <-> Server
	CMD_REQUEST_REGISTER_GATEWAY,
	CMD_REQUEST_REGISTER_GATEWAY_RESPONSE,

	CMD_SET_OPERATING_INFO,
	CMD_SET_OPERATING_INFO_RESPONSE,
	CMD_GET_OPERATING_INFO,
	CMD_GET_OPERATING_INFO_RESPONSE,

	CMD_SET_MEASUREMENT_INFO,
	CMD_SET_MEASUREMENT_INFO_RESPONSE,
	CMD_GET_MEASUREMENT_INFO,
	CMD_GET_MEASUREMENT_INFO_RESPONSE,

	CMD_SET_IOT_SENSOR_LIST_INFO,
	CMD_SET_IOT_SENSOR_LIST_INFO_RESPONSE,
	CMD_GET_IOT_SENSOR_LIST_INFO,
	CMD_GET_IOT_SENSOR_LIST_INFO_RESPONSE,
	CMD_GET_IOT_SENSOR_INFO,
	CMD_GET_IOT_SENSOR_INFO_RESPONSE,

	CMD_REQUEST_MANUAL_MEASUREMENT,
	CMD_REQUEST_MANUAL_MEASUREMENT_RESPONSE,

	CMD_REQUEST_PERIODIC_MEASUREMENT,
	CMD_REQUEST_PERIODIC_MEASUREMENT_RESPONSE,

	CMD_SET_REGULAR_MEASUREMENT_RESULT,
	CMD_SET_REGULAR_MEASUREMENT_RESULT_RESPONSE,
	CMD_SET_VIBRATION_RATING_RESULT,
	CMD_SET_VIBRATION_RATING_RESULT_RESPONSE,
	CMD_SET_VIBRATION_DIAGNOSIS_RESULT,
	CMD_SET_VIBRATION_DIAGNOSIS_RESULT_RESPONSE,
	CMD_SET_VBELT_ELONGATION_RESULT,
	CMD_SET_VBELT_ELONGATION_RESULT_RESPONSE,

	CMD_REQUEST_START_INIT_PROCESS,
	CMD_REQUEST_START_INIT_PROCESS_RESPONSE,

	CMD_SET_EQUIPMENT_INFORMATION,
	CMD_SET_EQUIPMENT_INFORMATION_RESPONSE,
	CMD_GET_EQUIPMENT_INFORMATION,
	CMD_GET_EQUIPMENT_INFORMATION_RESPONSE,

	CMD_SET_FAULT_FREQUENCY,
	CMD_SET_FAULT_FREQUENCY_RESPONSE,
	CMD_GET_FAULT_FREQUENCY,
	CMD_GET_FAULT_FREQUENCY_RESPONSE,

	CMD_REQUEST_NOISE_THRESHOLD_MEASUREMENT,
	CMD_REQUEST_NOISE_THRESHOLD_MEASUREMENT_RESPONSE,
	CMD_REQUEST_NOISE_THRESHOLD_DIAGNOSIS,
	CMD_REQUEST_NOISE_THRESHOLD_DIAGNOSIS_RESPONSE,
	CMD_SET_NOISE_THRESHOLD,
	CMD_SET_NOISE_THRESHOLD_RESPONSE,

	CMD_REQUEST_VIBRATION_THRESHOLD_MEASUREMENT,
	CMD_REQUEST_VIBRATION_THRESHOLD_MEASUREMENT_RESPONSE,
	CMD_REQUEST_VIBRATION_THRESHOLD_DIAGNOSIS,
	CMD_REQUEST_VIBRATION_THRESHOLD_DIAGNOSIS_RESPONSE,
	CMD_SET_VIBRATION_THRESHOLD,
	CMD_SET_VIBRATION_THRESHOLD_RESPONSE,

	CMD_REQUEST_END_INIT_PROCESS,
	CMD_REQUEST_END_INIT_PROCESS_RESPONSE,

	CMD_SET_SOUND_SAMPLE_DATA,
	CMD_SET_SOUND_SAMPLE_DATA_RESPONSE,

	CMD_SET_IOT_SENSOR_SAMPLE_DATA,
	CMD_SET_IOT_SENSOR_SAMPLE_DATA_RESPONSE,

	CMD_REQUEST_FACTORY_RESET_GATEWAY,
	CMD_REQUEST_FACTORY_RESET_GATEWAY_RESPONSE,

	CMD_REQUEST_FACTORY_RESET_IOT_SENSOR,
	CMD_REQUEST_FACTORY_RESET_IOT_SENSOR_RESPONSE,

	CMD_REQUEST_FIRMWARE_UPDATE,
	CMD_REQUEST_FIRMWARE_UPDATE_RESPONSE,

	// MCU
	CMD_REQUEST_SET_IO_STATE,
	CMD_RESPONSE_SET_IO_STATE,

	CMD_REQUEST_POWER_CONTROL,
	CMD_RESPONSE_POWER_CONTROL,
	CMD_REQUEST_SOFTWARE_RESET,

	// BLE
	CMD_GET_MAC_ADDRESS,
	CMD_GET_MAC_ADDRESS_RESPONSE,

	CMD_REQUEST_CONNECT_DEVICE,
	CMD_REQUEST_CONNECT_DEVICE_RESPONSE,

	CMD_REQUEST_DISCONNECT_DEVICE,
	CMD_REQUEST_DISCONNECT_DEVICE_RESPONSE,

	CMD_SET_MEASUREMENT_CONFIG,
	CMD_SET_MEASUREMENT_CONFIG_RESPONSE,

	CMD_REQUEST_TIME_SYNC,
	CMD_REQUEST_TIME_SYNC_RESPONSE,

#if 0
	CMD_READ_FIRMWARE_VERSION,
	CMD_READ_FIRMWARE_VERSION_RESPONSE,

	CMD_REQUEST_START_SCAN,
	CMD_REQUEST_START_SCAN_RESPONSE,

	CMD_REQUEST_VALIDATION,
	CMD_REQUEST_VALIDATION_RESPONSE,

	CMD_REQUEST_STOP_SCAN,
	CMD_REQUEST_STOP_SCAN_RESPONSE,

#endif

	CMD_GET_DEVICE_INFO,
	CMD_GET_DEVICE_INFO_RESPONSE,

	CMD_GET_DEVICE_NAME,
	CMD_GET_DEVICE_NAME_RESPONSE,

	CMD_GET_FILE_LIST,
	CMD_GET_FILE_LIST_RESPONSE,

	CMD_OPEN_WIFI,
	CMD_OPEN_WIFI_RESPONSE,

	CMD_DOWNLOAD_FILE,
	CMD_DOWNLOAD_FILE_RESPONSE,



	CMD_REQUEST_DEVICE_FIRMWARE_VERSION,
	CMD_REQUEST_DEVICE_FIRMWARE_VERSION_RESPONSE,




	CMD_DOWNLOAD_DATA,



	CMD_CONNECT_WIFI,
	CMD_CONNECT_WIFI_RESPONSE,


	CMD_SPI_READ,
	CMD_SPI_READ_RESPONSE,


	CMD_REQUEST_RESET_DEVICE,

	CMD_RESET_SENSOR_INFO,
	CMD_RESET_SENSOR_INFO_RESPONSE,

	CMD_DISCONNECT_WIFI,
	CMD_DISCONNECT_WIFI_RESPONSE,


	CMD_SET_DEVICE_NAME,
	CMD_SET_DEVICE_NAME_RESPONSE,


	// WiFi
	CMD_START_AP,
	CMD_START_AP_RESPONSE,

	CMD_STOP_AP,
	CMD_STOP_AP_RESPONSE,

	CMD_OPEN_SOCKET,
	CMD_OPEN_SOCKET_RESPONSE,

	CMD_CLOSE_SOCKET,
	CMD_CLOSE_SOCKET_RESPONSE,

	// ADC
	CMD_REQUEST_REGULAR_MEASUREMENT,
	CMD_REQUEST_REGULAR_MEASUREMENT_RESPONSE,
	CMD_REQUEST_STOP_MEASUREMENT,

	// Diagnostic Algorithm
	CMD_DIAGNOSE_NOISE_ANOMALY,
	CMD_DIAGNOSE_NOISE_ANOMALY_RESPONSE,
	CMD_DIAGNOSE_VIBRATION_RATING,
	CMD_DIAGNOSE_VIBRATION_RATING_RESPONSE,
	CMD_DIAGNOSE_VIBRATION_DIAGNOSIS,
	CMD_DIAGNOSE_VIBRATION_DIAGNOSIS_RESPONSE,
	CMD_DIAGNOSE_VBELT_ELONGATION,
	CMD_DIAGNOSE_VBELT_ELONGATION_RESPONSE,
	CMD_DIAGNOSE_NOISE_THRESHOLD,
	CMD_DIAGNOSE_NOISE_THRESHOLD_RESPONSE,
	CMD_DIAGNOSE_VIBRATION_THRESHOLD,
	CMD_DIAGNOSE_VIBRATION_THRESHOLD_RESPONSE,
	CMD_DIAGNOSE_FAULT_FREQUENCY,
	CMD_DIAGNOSE_FAULT_FREQUENCY_RESPONSE,

	// Gateway <-> Embedded Router
	CMD_SET_WIFI_CONNECTION,
	CMD_SET_WIFI_CONNECTION_RESPONSE,
	CMD_GET_WIFI_CONNECTION,
	CMD_GET_WIFI_CONNECTION_RESPONSE,

	CMD_SET_LOCAL_NETWORK_CONFIG,
	CMD_SET_LOCAL_NETWORK_CONFIG_RESPONSE,
	CMD_GET_LOCAL_NETWORK_CONFIG,
	CMD_GET_LOCAL_NETWORK_CONFIG_RESPONSE,

	CMD_GET_WIFI_MAC_ADDRESS,
	CMD_GET_WIFI_MAC_ADDRESS_RESPONSE,

	CMD_TIMER_EXPIRED,
	CMD_PROCESS_TERMINATE,

	CMD_MAX
};

enum IO_CONTROL_TYPE
{
	IO_ADC_APP,
	IO_ADC_BOOT,
	IO_ADC_RESET_HIGH,
	IO_ADC_RESET_LOW,
	IO_ADC_MEASUREMENT_START,
	IO_ADC_MEASUREMENT_STOP,
	IO_ADC_RESET,
	IO_BLE_APP,
	IO_BLE_BOOT,
	IO_BLE_RESET_LOW,
	IO_BLE_RESET_HIGH,
	IO_BLE_RESET,
};

enum TIMER_ID
{
	TIMER_HEART_BEAT,
	TIMER_REGULAR_MEASUREMENT,
#ifdef REPORT_REGULAR_MEASUREMENT_RESULT
	TIMER_REGULAR_MEASUREMENT_RESULT_REPORT,
#endif
	TIMER_IOT_SENSOR_MEASUREMENT_WAIT,
	TIMER_EMBEDDED_ROUTER_HEART_BEAT,
	TIMER_STATUS_CHECK,
	TIMER_BLE_CONNECTION,
	TIMER_BLE_RETRY,
	TIMER_NOISE_THRESHOLD_MEASUREMENT,
	TIMER_ID_MAX
};

const int FILE_PATH_LENGTH = 256;

const int ERROR_STRING_LENGTH = 256;

const int MAX_NUM_OF_DATA_FILE = 10;

const int MAX_EQUIPMENT_ID_LENGTH = 32;



struct OperatingInfo
{
	char equipment_id[MAX_EQUIPMENT_ID_LENGTH + 1];
	uint8_t location;
	uint16_t num_data_stored;
	uint16_t heart_beat_interval;
	uint8_t heart_beat_threshold;
};

struct MeasurementInfo
{
	uint32_t interval;
	uint32_t measurement_time;
	uint32_t num_measurement;
	uint32_t sampling_rate;
};

struct RegularMeasurementInfo
{
	uint8_t start_hour;
	uint8_t start_minute;
	uint8_t stop_hour;
	uint8_t stop_minute;
	bool is_over_day;
	uint32_t result_report_interval;

	struct MeasurementInfo measurement_info;
};

struct NoiseThresholdMeasurementInfo
{
	struct MeasurementInfo measurement_info;
};

struct VibrationThresholdMeasurementInfo
{
	struct MeasurementInfo measurement_info;
};

struct IotSensorMeasurementInfo
{
	struct MeasurementInfo noise_sensor_measurement_info;
	struct MeasurementInfo vibration_sensor_measurement_info;
};

const int IOT_SENSOR_BLE_MAC_ADDRESS_LENGTH = 6;
const int IOT_SENSOR_WIFI_MAC_ADDRESS_LENGTH = 6;
const int IOT_SENSOR_MAX_NAME_LENGTH = 33;
const int IOT_SENSOR_MAX_VERSION_LENGTH = 16;

struct IotSensorInfo
{
	uint8_t ble[IOT_SENSOR_BLE_MAC_ADDRESS_LENGTH];
	uint8_t wifi[IOT_SENSOR_WIFI_MAC_ADDRESS_LENGTH];
	uint8_t type;
	uint8_t location;
	uint8_t direction;

	// from IoT Sensor
	char name[IOT_SENSOR_MAX_NAME_LENGTH];
	char version_mcu[IOT_SENSOR_MAX_VERSION_LENGTH];
	char version_wifi[IOT_SENSOR_MAX_VERSION_LENGTH];
	char version_ble[IOT_SENSOR_MAX_VERSION_LENGTH];
	char version_hw[IOT_SENSOR_MAX_VERSION_LENGTH];

	uint8_t battery;
	uint8_t date[4];
	uint8_t time[3];
	uint8_t storage_interval;
	uint8_t storage_time[3];
	uint8_t measurement_time[2];
	uint16_t sample_rate;
	uint8_t sensor_option;
	uint32_t flash_max_size;
	uint32_t flash_current_size;
	uint8_t pairing_status;
	uint8_t threshold_setting;

	// extra info
	char data_info[FILE_PATH_LENGTH];
};

struct WifiApInfo
{
	uint8_t control[2];
	char ssid[32];
	uint8_t auth_type;
	char password[32];
	uint8_t ip_address[4];
	uint32_t port;
};

struct StatusCheckInfo
{
	int status_check_interval;
	float cpu_usage_threshold;
	float memory_usage_threshold;
	float disk_usage_threshold;
	float cpu_temperature_threshold;
	float iot_sensor_battery_threshold;
};

struct GatewayInfo
{
	uint8_t gateway_id[6];
	uint8_t gateway_version[10];
	bool is_config;
	struct OperatingInfo operating_info;
	struct RegularMeasurementInfo regular_measurement_info;
	struct NoiseThresholdMeasurementInfo noise_threshold_measurement_info;
	struct VibrationThresholdMeasurementInfo vibration_threshold_measurement_info;
	struct IotSensorMeasurementInfo iot_sensor_measurement_info;
	int num_iot_sensor;
	struct IotSensorInfo iot_sensor_info_list[10];
	struct WifiApInfo iot_sensor_ap_info;
	struct StatusCheckInfo status_check_info;
	int error;
};

struct MeasurementDataFileInfo
{
	uint16_t index;
	char equipment_id[MAX_ID_LENGTH];
	uint8_t location;
	struct timespec timestamp;
	uint32_t measurement_time;
	uint32_t sample_rate;
	uint8_t channel;
	uint8_t tag;
	char sub_dir_name[FILE_PATH_LENGTH];
	char file_name[FILE_PATH_LENGTH];
	uint32_t size;
};

struct diagnostic_info
{
	uint8_t mac[6];

	struct
	{
		struct timespec data;
		struct timespec request;
		struct timespec response;
	} timestamp;

	char info_file[FILE_PATH_LENGTH];
	char data_file[MAX_NUM_OF_DATA_FILE][FILE_PATH_LENGTH];
	int num_data_file;

	uint8_t value8;
	uint16_t value16;
	uint32_t value32;
	float real;
};

struct diagnostic_result
{
	char error_code;
	char error_string[ERROR_STRING_LENGTH];

	uint8_t mac[6];
	struct
	{
		struct timespec data;
		struct timespec request;
		struct timespec response;
	} timestamp;

	union
	{
		struct
		{
			uint8_t operation;
			uint8_t anomaly;
			float index;
		} noise_anomaly;
		struct
		{
			float rms_x;
			float rms_y;
			float rms_z;
			uint8_t grade_x;
			uint8_t grade_y;
			uint8_t grade_z;
			uint8_t over_x;
			uint8_t over_y;
			uint8_t over_z;
			char fft_file[256];
		} vibration_rating;
		struct
		{
			uint8_t diagnosis[256];
			uint8_t length;
		} vibration_diagnosis;
		struct
		{
			float elongation;
			char grade;
			float pulley_speed1, pulley_speed2;
		} vbelt_elongation;
		struct
		{
			char noise_threshold_file[FILE_PATH_LENGTH];
			char accumulated_noise_indicator_file[FILE_PATH_LENGTH];
		} noise_threshold;
		struct
		{
			char vibration_threshold_file[FILE_PATH_LENGTH];
			char accumulated_vibration_rms_file[FILE_PATH_LENGTH];
		} vibration_threshold;
		struct
		{
			char fault_frequency_file[FILE_PATH_LENGTH];
		} fault_frequency;
	} extra_info;
};

#ifdef REPORT_REGULAR_MEASUREMENT_RESULT
struct RegularMeasurementResult
{
	struct timespec timestamp;
	uint8_t operation;
	uint8_t anomaly;
	float indicator;
};

struct RegularMeasurementResultSet
{
	uint8_t id[6];
	int num_result;
	struct RegularMeasurementResult res[30];
};
#endif

const int MAX_CRYPTO_KEY_LENGTH = 32;

enum CRYPTO_MODE_TYPE
{
	CRYPTO_NONE = 0,
	CRYPTO_AES128_ECB = 0xA1,
	CRYPTO_AES192_ECB = 0xA2,
	CRYPTO_AES256_ECB = 0xA3,
	CRYPTO_AES128_CBC = 0xA4,
	CRYPTO_AES192_CBC = 0xA5,
	CRYPTO_AES256_CBC = 0xA6,
	CRYPTO_MAX
};

#endif

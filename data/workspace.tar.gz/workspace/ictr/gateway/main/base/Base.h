#ifndef BASE_H
#define BASE_H

#include "common/MessageListener.h"
#include "common/SafeQueue.h"

#include <thread>
#include <memory>
#include <vector>

template<typename T>
struct message_handler
{
	COMMAND_TYPE cmd;
	char name[64];
	void (T::*handler)(void *, int);
};

class CBase : public IMessageListener
{
public:
	CBase();
	~CBase();

protected:
	MODULE_TYPE mModuleType;
	int mWorkInterval;
	void SendInternalMessage(MODULE_TYPE receiver, COMMAND_TYPE cmd, void *data, int size);
	virtual void MessageHandler(MODULE_TYPE sender, COMMAND_TYPE cmd, void *data, int size);

private:
	const char *TAG = "BASE";
	void Notify(std::shared_ptr<Message> msg);

	std::vector<message_handler<CBase>> mMessageHandlerList;
	void AddMessageHandler(COMMAND_TYPE cmd, const char *name, void (CBase::*handler)(void *, int));

	struct timespec mLastWorkTime;
	SafeQueue<std::shared_ptr<Message>> mWorkQueue;
	std::thread* mWorker;
	bool mIsWorkerStart;
	void WorkerThread();

	//void Send(void *data, int size);
};

#endif

#include "CommunicationBase.h"

void CCommunicationBase::RegisterListener(IDataListener* obs)
{
	mDataListenerList.push_back(obs);
}

void CCommunicationBase::UnregisterListener(IDataListener* obs)
{
}

void CCommunicationBase::NotifyListener(const void *data, const int size)
{
	for(auto listener : mDataListenerList)
	{
		listener->Read(data, size);
	}
}

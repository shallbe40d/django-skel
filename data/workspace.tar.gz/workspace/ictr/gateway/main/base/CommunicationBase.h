#ifndef _COMMUNICATION_BASE_H
#define _COMMUNICATION_BASE_H

#include "common/DataListener.h"

#include <vector>

class CCommunicationBase
{
public:
	virtual size_t Write(const char *data, const int size, const char *tag = NULL) = 0;

	void RegisterListener(IDataListener* obj);
	void UnregisterListener(IDataListener* obj);

protected:
	void NotifyListener(const void* data = NULL, const int size = 0);

private:
	std::vector<IDataListener*> mDataListenerList;
};

#endif

#include "Base.h"
#include "mq/MessageQueue.h"
#include "util/Util.h"

CBase::CBase()
{
	mModuleType = MODULE_SYSTEM;
	mWorkInterval = 100;
	mWorker = new std::thread([&]() { WorkerThread(); });
}

CBase::~CBase()
{
}

void CBase::Notify(std::shared_ptr<Message> msg)
{
	mWorkQueue.push_back(msg);
}

void CBase::SendInternalMessage(MODULE_TYPE receiver, COMMAND_TYPE cmd, void *data, int size)
{
	MessageQueue::GetInstance()->SendMessage(mModuleType, receiver, cmd, data, size);
}

void CBase::WorkerThread()
{
	mIsWorkerStart = true;
	clock_gettime(CLOCK_MONOTONIC, &mLastWorkTime);

	while (mIsWorkerStart == true)
	{
		std::shared_ptr<Message> msg = mWorkQueue.front();

		struct timespec tsNow;
		clock_gettime(CLOCK_MONOTONIC, &tsNow);

		int diff = (tsNow.tv_sec - mLastWorkTime.tv_sec) * 1000 + (tsNow.tv_nsec - mLastWorkTime.tv_nsec) / (1000 * 1000);
		if (diff < mWorkInterval)
		{
			//LOGD(TAG, "Now: %ld.%09ld, Last: %ld.%09ld, Diff: %dms Sleep: %dms", tsNow.tv_sec, tsNow.tv_nsec, mLastWorkTime.tv_sec, mLastWorkTime.tv_nsec, diff, (mWorkInterval - diff));
			usleep((mWorkInterval - diff) * 1000);
		}

		MessageHandler(msg->mSender, msg->mCmd, msg->mData, msg->mSize);

		clock_gettime(CLOCK_MONOTONIC, &mLastWorkTime);
	}
	LOGD(TAG, "Worker Thread Exit");
}

void CBase::AddMessageHandler(COMMAND_TYPE cmd, const char *name, void (CBase::*handler)(void *, int))
{
	message_handler<CBase> h;

	h.cmd = cmd;
	snprintf(h.name, 64, "%s", name);
	h.handler = handler;

	mMessageHandlerList.push_back(h);
}

void CBase::MessageHandler(MODULE_TYPE sender, COMMAND_TYPE cmd, void *data, int size)
{
	switch(cmd)
	{
		case CMD_PROCESS_TERMINATE:
		{
			mIsWorkerStart = false;
		}
		break;
		default:
		{
			LOGE(TAG, "Not supported cmd: %d", cmd);
		}
		break;
	}
}

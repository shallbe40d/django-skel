#include "ServerCommunicationManager.h"
#include "mq/MessageQueue.h"

#include "json/json.h"
#include "json/base64.h"

#include "log/Log.h"
#include "util/Util.h"

// For socket
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Rapid JSON
#define RAPIDJSON_HAS_STDSTRING 1
#include "rapidjson/document.h"
#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"



CServerCommunicationManager ::CServerCommunicationManager ()
{
}

CServerCommunicationManager ::~CServerCommunicationManager ()
{
}

void CServerCommunicationManager::Init(CCommunicationBase *channel)
{
	mTransmitChannel = channel;
	mTransmitChannel->RegisterListener(this);

	MessageQueue::GetInstance()->RegisterListener(MODULE_SERVERCOMM, this);

	// Json Message Map
	mMapJsonCommand.insert(std::make_pair("REQUEST_REGISTER_GATEWAY_RESPONSE", CMD_REQUEST_REGISTER_GATEWAY_RESPONSE));
	mMapJsonCommand.insert(std::make_pair("SET_OPERATING_INFO", CMD_SET_OPERATING_INFO));
	mMapJsonCommand.insert(std::make_pair("SET_MEASUREMENT_INFO", CMD_SET_MEASUREMENT_INFO));
	mMapJsonCommand.insert(std::make_pair("SET_IOT_SENSOR_LIST_INFO", CMD_SET_IOT_SENSOR_LIST_INFO));

	mMapJsonCommand.insert(std::make_pair("SET_EQUIPMENT_INFORMATION", CMD_SET_EQUIPMENT_INFORMATION));

	mMapJsonCommand.insert(std::make_pair("REQUEST_NOISE_THRESHOLD_MEASUREMENT", CMD_REQUEST_NOISE_THRESHOLD_MEASUREMENT));
	mMapJsonCommand.insert(std::make_pair("REQUEST_NOISE_THRESHOLD_DIAGNOSIS", CMD_REQUEST_NOISE_THRESHOLD_DIAGNOSIS));
	mMapJsonCommand.insert(std::make_pair("SET_NOISE_THRESHOLD", CMD_SET_NOISE_THRESHOLD));

	mMapJsonCommand.insert(std::make_pair("REQUEST_VIBRATION_THRESHOLD_MEASUREMENT", CMD_REQUEST_VIBRATION_THRESHOLD_MEASUREMENT));
	mMapJsonCommand.insert(std::make_pair("REQUEST_VIBRATION_THRESHOLD_MEASUREMENT", CMD_REQUEST_NOISE_THRESHOLD_MEASUREMENT));
	mMapJsonCommand.insert(std::make_pair("SET_VIBRATION_THRESHOLD", CMD_SET_NOISE_THRESHOLD));

#if 0
	mMapJsonCommand.insert(std::make_pair("GET_OPERATING_INFO_RESPONSE", CMD_GET_OPERATING_INFO_RESPONSE));
	mMapJsonCommand.insert(std::make_pair("GET_MEASUREMENT_INFO_RESPONSE", CMD_GET_MEASUREMENT_INFO_RESPONSE));
	mMapJsonCommand.insert(std::make_pair("SET_IOT_SENSOR_LIST_INFO_RESPONSE", CMD_SET_IOT_SENSOR_LIST_INFO_RESPONSE));
	mMapJsonCommand.insert(std::make_pair("GET_IOT_SENSOR_LIST_INFO_RESPONSE", CMD_GET_IOT_SENSOR_LIST_INFO_RESPONSE));
	mMapJsonCommand.insert(std::make_pair("GET_IOT_SENSOR_INFO_RESPONSE", CMD_GET_IOT_SENSOR_INFO_RESPONSE));
	mMapJsonCommand.insert(std::make_pair("REQUEST_MANUAL_MEASUREMENT_RESPONSE", CMD_REQUEST_MANUAL_MEASUREMENT_RESPONSE));
	mMapJsonCommand.insert(std::make_pair("REQUEST_PERIODIC_MEASUREMENT_RESPONSE", CMD_REQUEST_PERIODIC_MEASUREMENT_RESPONSE));
	mMapJsonCommand.insert(std::make_pair("SET_REGULAR_MEASUREMENT_RESULT", CMD_SET_REGULAR_MEASUREMENT_RESULT));
	mMapJsonCommand.insert(std::make_pair("SET_VIBRATION_RATING_RESULT", CMD_SET_VIBRATION_RATING_RESULT));
	mMapJsonCommand.insert(std::make_pair("SET_VIBRATION_DIAGNOSIS_RESULT", CMD_SET_VIBRATION_DIAGNOSIS_RESULT));
	mMapJsonCommand.insert(std::make_pair("SET_VBELT_ELONGATION_RESULT", CMD_SET_VBELT_ELONGATION_RESULT));
	mMapJsonCommand.insert(std::make_pair("REQUEST_START_INIT_PROCESS_RESPONSE", CMD_REQUEST_START_INIT_PROCESS_RESPONSE));
	mMapJsonCommand.insert(std::make_pair("GET_EQUIPMENT_INFORMATION_RESPONSE", CMD_GET_EQUIPMENT_INFORMATION_RESPONSE));
	mMapJsonCommand.insert(std::make_pair("SET_FAULT_FREQUENCY_RESPONSE", CMD_SET_FAULT_FREQUENCY_RESPONSE));
	mMapJsonCommand.insert(std::make_pair("GET_FAULT_FREQUENCY_RESPONSE", CMD_GET_FAULT_FREQUENCY_RESPONSE));
	mMapJsonCommand.insert(std::make_pair("REQUEST_SOUND_THRESHOLD_DIAGNOSIS_RESPONSE", CMD_REQUEST_SOUND_THRESHOLD_DIAGNOSIS_RESPONSE));
	mMapJsonCommand.insert(std::make_pair("SET_SOUND_THRESHOLD_RESPONSE", CMD_SET_SOUND_THRESHOLD_RESPONSE));
	mMapJsonCommand.insert(std::make_pair("REQUEST_VIBRATION_THRESHOLD_MEASUREMENT_RESPONSE", CMD_REQUEST_VIBRATION_THRESHOLD_MEASUREMENT_RESPONSE));
	mMapJsonCommand.insert(std::make_pair("REQUEST_VIBRATION_THRESHOLD_DIAGNOSIS_RESPONSE", CMD_REQUEST_VIBRATION_THRESHOLD_DIAGNOSIS_RESPONSE));
	mMapJsonCommand.insert(std::make_pair("SET_VIBRATION_THRESHOLD_RESPONSE", CMD_SET_VIBRATION_THRESHOLD_RESPONSE));
	mMapJsonCommand.insert(std::make_pair("REQUEST_END_INIT_PROCESS_RESPONSE", CMD_REQUEST_END_INIT_PROCESS_RESPONSE));
	mMapJsonCommand.insert(std::make_pair("SET_SOUND_SAMPLE_DATA", CMD_SET_SOUND_SAMPLE_DATA));
	mMapJsonCommand.insert(std::make_pair("SET_IOT_SENSOR_SAMPLE_DATA", CMD_SET_IOT_SENSOR_SAMPLE_DATA));
	mMapJsonCommand.insert(std::make_pair("REQUEST_FACTORY_RESET_RESPONSE", CMD_REQUEST_FACTORY_RESET_GATEWAY_RESPONSE));
	mMapJsonCommand.insert(std::make_pair("REQUEST_FIRMWARE_UPDATE_RESPONSE", CMD_REQUEST_FIRMWARE_UPDATE_RESPONSE));
#endif

	AddMessageHandler(CMD_TEST_MODULE_COMMUNICATION, "CMD_TEST_MODULE_COMMUNICATION", &CServerCommunicationManager::CmdNotImplemented);

	AddMessageHandler(CMD_REQUEST_REGISTER_GATEWAY, "CMD_REQUEST_REGISTER_GATEWAY", &CServerCommunicationManager::CmdRequestRegisterGateway);
	AddMessageHandler(CMD_SET_OPERATING_INFO_RESPONSE, "CMD_SET_OPERATING_INFO_RESPONSE", &CServerCommunicationManager::CmdSetOperatingInfoResponse);
	AddMessageHandler(CMD_GET_OPERATING_INFO_RESPONSE, "CMD_GET_OPERATING_INFO_RESPONSE", &CServerCommunicationManager::CmdGetOperatingInfoResponse);
	AddMessageHandler(CMD_SET_MEASUREMENT_INFO_RESPONSE, "CMD_SET_MEASUREMENT_INFO_RESPONSE", &CServerCommunicationManager::CmdSetMeasurementInfoResponse);
	AddMessageHandler(CMD_GET_MEASUREMENT_INFO_RESPONSE, "CMD_GET_MEASUREMENT_INFO_RESPONSE", &CServerCommunicationManager::CmdGetMeasurementInfoResponse);
	AddMessageHandler(CMD_SET_IOT_SENSOR_LIST_INFO_RESPONSE, "CMD_SET_IOT_SENSOR_LIST_INFO_RESPONSE", &CServerCommunicationManager::CmdSetIotSensorListInfoResponse);
	AddMessageHandler(CMD_GET_IOT_SENSOR_LIST_INFO_RESPONSE, "CMD_GET_IOT_SENSOR_LIST_INFO_RESPONSE", &CServerCommunicationManager::CmdGetIotSensorListInfoResponse);
	AddMessageHandler(CMD_GET_IOT_SENSOR_INFO_RESPONSE, "CMD_GET_IOT_SENSOR_INFO_RESPONSE", &CServerCommunicationManager::CmdGetIotSensorInfoResponse);
	AddMessageHandler(CMD_REQUEST_MANUAL_MEASUREMENT_RESPONSE, "CMD_REQUEST_MANUAL_MEASUREMENT_RESPONSE", &CServerCommunicationManager::CmdRequestManualMeasurementResponse);
	AddMessageHandler(CMD_REQUEST_PERIODIC_MEASUREMENT_RESPONSE, "CMD_REQUEST_PERIODIC_MEASUREMENT_RESPONSE", &CServerCommunicationManager::CmdRequestPeriodicMeasurementResponse);
	AddMessageHandler(CMD_SET_REGULAR_MEASUREMENT_RESULT, "CMD_SET_REGULAR_MEASUREMENT_RESULT", &CServerCommunicationManager::CmdSetRegularMeasurementResult);
	AddMessageHandler(CMD_SET_VIBRATION_RATING_RESULT, "CMD_SET_VIBRATION_RATING_RESULT", &CServerCommunicationManager::CmdSetVibrationRatingResult);
	AddMessageHandler(CMD_SET_VIBRATION_DIAGNOSIS_RESULT, "CMD_SET_VIBRATION_DIAGNOSIS_RESULT", &CServerCommunicationManager::CmdSetVibrationDiagnosisResult);
	AddMessageHandler(CMD_SET_VBELT_ELONGATION_RESULT, "CMD_SET_VBELT_ELONGATION_RESULT", &CServerCommunicationManager::CmdSetVbeltElongationResult);
	AddMessageHandler(CMD_REQUEST_START_INIT_PROCESS_RESPONSE, "CMD_REQUEST_START_INIT_PROCESS_RESPONSE", &CServerCommunicationManager::CmdRequestStartInitProcessResponse);
	AddMessageHandler(CMD_SET_EQUIPMENT_INFORMATION_RESPONSE, "CMD_SET_EQUIPMENT_INFORMATION_RESPONSE", &CServerCommunicationManager::CmdSetEquipmentInformationResponse);
	AddMessageHandler(CMD_GET_EQUIPMENT_INFORMATION_RESPONSE, "CMD_GET_EQUIPMENT_INFORMATION_RESPONSE", &CServerCommunicationManager::CmdGetEquipmentInformationResponse);
	AddMessageHandler(CMD_SET_FAULT_FREQUENCY_RESPONSE, "CMD_SET_FAULT_FREQUENCY_RESPONSE", &CServerCommunicationManager::CmdSetFaultFrequencyResponse);
	AddMessageHandler(CMD_GET_FAULT_FREQUENCY_RESPONSE, "CMD_GET_FAULT_FREQUENCY_RESPONSE", &CServerCommunicationManager::CmdGetFaultFrequencyResponse);
	AddMessageHandler(CMD_REQUEST_NOISE_THRESHOLD_MEASUREMENT_RESPONSE, "CMD_REQUEST_NOISE_THRESHOLD_MEASUREMENT_RESPONSE", &CServerCommunicationManager::CmdRequestSoundThresholdMeasurementResponse);
	AddMessageHandler(CMD_REQUEST_NOISE_THRESHOLD_DIAGNOSIS_RESPONSE, "CMD_REQUEST_NOISE_THRESHOLD_DIAGNOSIS_RESPONSE", &CServerCommunicationManager::CmdRequestSoundThresholdDiagnosisResponse);
	AddMessageHandler(CMD_SET_NOISE_THRESHOLD_RESPONSE, "CMD_SET_NOISE_THRESHOLD_RESPONSE", &CServerCommunicationManager::CmdSetSoundThresholdResponse);
	AddMessageHandler(CMD_REQUEST_VIBRATION_THRESHOLD_MEASUREMENT_RESPONSE, "CMD_REQUEST_VIBRATION_THRESHOLD_MEASUREMENT_RESPONSE", &CServerCommunicationManager::CmdRequestVibrationThresholdMeasurementResponse);
	AddMessageHandler(CMD_REQUEST_VIBRATION_THRESHOLD_DIAGNOSIS_RESPONSE, "CMD_REQUEST_VIBRATION_THRESHOLD_DIAGNOSIS_RESPONSE", &CServerCommunicationManager::CmdRequestVibrationThresholdDiagnosisResponse);
	AddMessageHandler(CMD_SET_VIBRATION_THRESHOLD_RESPONSE, "CMD_SET_VIBRATION_THRESHOLD_RESPONSE", &CServerCommunicationManager::CmdSetVibrationThresholdResponse);
	AddMessageHandler(CMD_REQUEST_END_INIT_PROCESS_RESPONSE, "CMD_REQUEST_END_INIT_PROCESS_RESPONSE", &CServerCommunicationManager::CmdRequestEndInitProcessResponse);
	AddMessageHandler(CMD_SET_SOUND_SAMPLE_DATA, "CMD_SET_SOUND_SAMPLE_DATA", &CServerCommunicationManager::CmdSetSoundSampleData);
	AddMessageHandler(CMD_SET_IOT_SENSOR_SAMPLE_DATA, "CMD_SET_IOT_SENSOR_SAMPLE_DATA", &CServerCommunicationManager::CmdSetIotSensorSampleData);
	AddMessageHandler(CMD_REQUEST_FACTORY_RESET_GATEWAY_RESPONSE, "CMD_REQUEST_FACTORY_RESET_RESPONSE", &CServerCommunicationManager::CmdRequestFactoryResetResponse);
	AddMessageHandler(CMD_REQUEST_FIRMWARE_UPDATE_RESPONSE, "CMD_REQUEST_FIRMWARE_UPDATE_RESPONSE", &CServerCommunicationManager::CmdRequestFirmwareUpdateResponse);
}

void CServerCommunicationManager::AddMessageHandler(COMMAND_TYPE cmd, const char *name, void (CServerCommunicationManager::*handler)(void *, int))
{
	message_handler<CServerCommunicationManager> h;

	h.cmd = cmd;
	snprintf(h.name, 64, "%s", name);
	h.handler = handler;

	mMessageHandlerList.push_back(h);
}

void CServerCommunicationManager::MessageHandler(MODULE_TYPE sender, COMMAND_TYPE cmd, void *data, int size)
{
	int rc = 0;
	std::vector<message_handler<CServerCommunicationManager>>::iterator it;

	for (it = mMessageHandlerList.begin(); it != mMessageHandlerList.end(); it++)
	{
		if(it->cmd == cmd)
		{
			LOGD(TAG, "%s, data: %p, size: %d", it->name, data, size);
			void (CServerCommunicationManager::*fp)(void *, int) = it->handler;

			(this->*fp)(data, size);
			rc = 1;
		}
	}

	if (rc == 0)
	{
	}

#if 0
	switch(cmd)
	{
	case CMD_TEST_MODULE_COMMUNICATION:
		{
			LOGD(TAG, "CMD_TEST_MODULE_COMMUNICATION");

			struct HELLO msg;
			memset(&msg, 0x00, sizeof(struct HELLO));

			msg.head.type = 0x01;
			msg.head.command = 0x01;
			msg.head.length = ConvertEndian4(sizeof(msg.payload));

			msg.payload.gateway_id[0] = 0x01;
			msg.payload.gateway_id[1] = 0x23;
			msg.payload.gateway_id[2] = 0x45;
			msg.payload.gateway_id[3] = 0x67;
			msg.payload.gateway_id[4] = 0x89;
			msg.payload.gateway_id[5] = 0xAB;

			Write((uint8_t *)&msg, sizeof(struct HELLO));
		}
		break;
	default:
		{
			LOGE(TAG, "Not supported cmd: %02x", cmd);
		}
		break;
	}
#endif
}

void CServerCommunicationManager::Read(const void *data, const unsigned int size)
{
	PrintPacket(TAG, "[RD-RAW]", (char *)data, size);

	struct SOCKET_HEAD *head = (struct SOCKET_HEAD *)data;

	char *payload = (char *)data;
	int payloadSize = size;
	switch(head->type)
	{
	case 0x02:
		{
			payload = (char *)data + sizeof(struct SOCKET_HEAD);
			payloadSize = size - sizeof(struct SOCKET_HEAD);
		}
		break;
	default:
		{
			LOGE(TAG, "Not supported protocol: %02x", head->type);
		}
		break;
	}

	PrintPacket(TAG, "[PAYLOAD]", payload, payloadSize);

	Json::CharReaderBuilder builder;
	Json::CharReader * reader = builder.newCharReader();
	std::string error;

	Json::Value root;

	bool res = reader->parse(payload, payload + payloadSize, &root, &error);

	if (res == true)
	{
		try
		{
			//LOGD(TAG, "Gateway ID: %s, Time: %d, CMD: %s, Error: %d", root["gatewayId"].asCString(), root["timestamp"].asInt(), root["cmd"].asCString(), root["error"].asInt());

			std::string cmd = root["cmd"].asString();
			LOGD(TAG, "CMD: %s", cmd.c_str());

			std::map<std::string, COMMAND_TYPE>::iterator it;
			it = mMapJsonCommand.find(cmd);

			if (it != mMapJsonCommand.end())
			{
				switch(it->second)
				{
				case CMD_REQUEST_REGISTER_GATEWAY_RESPONSE:
					{
						CmdRequestRegisterGatewayResponse(payload, payloadSize);
					}
					break;
				case CMD_SET_OPERATING_INFO:
					{
						CmdSetOperatingInfo(payload, payloadSize);
					}
					break;
				case CMD_SET_MEASUREMENT_INFO:
					{
						CmdSetMeasurementInfo(payload, payloadSize);
					}
					break;
				case CMD_SET_IOT_SENSOR_LIST_INFO:
					{
						CmdSetIotSensorListInfo(payload, payloadSize);
					}
					break;
				case CMD_SET_EQUIPMENT_INFORMATION:
					{
						CmdSetEquipmentInformation(payload, payloadSize);
					}
					break;
				default:
					{
					}
					break;
				}
			}
		}
		catch(...)
		{
			res = false;
			LOGD(TAG, "Parsing Error");
		}
	}
	else
	{
		LOGD(TAG, "Parsing Error");
	}
}

void CServerCommunicationManager::Write(const uint8_t *data, const int size)
{
	PrintPacket(TAG, "[WR-RAW]", (char *)data, size);

	uint32_t packetLength = sizeof(struct SOCKET_HEAD) + size;
	char *packet = (char *)malloc(packetLength);
	memset(packet, 0x00, packetLength);

	struct SOCKET_HEAD *head = (struct SOCKET_HEAD *)packet;
	head->type = 0x02;
	head->length = size;
	memcpy(packet + sizeof(struct SOCKET_HEAD), data, size);

	mTransmitChannel->Write(packet, packetLength);
	free(packet);
}

void CServerCommunicationManager::WriteControlPacket(const uint8_t command, const uint8_t *data, const int size)
{
	PrintPacket(TAG, "[WR-RAW]", (char *)data, size);

	uint32_t packetLength = sizeof(struct SOCKET_HEAD) + size;
	char *packet = (char *)malloc(packetLength);
	memset(packet, 0x00, packetLength);

	struct SOCKET_HEAD *head = (struct SOCKET_HEAD *)packet;
	head->type = 0x01;
	head->command = command;
	head->length = size;
	memcpy(packet + sizeof(struct SOCKET_HEAD), data, size);

	mTransmitChannel->Write(packet, packetLength);
	free(packet);
}

void CServerCommunicationManager::SendInternalMessage(MODULE_TYPE receiver, COMMAND_TYPE cmd, void *data, int size)
{
	MessageQueue::GetInstance()->SendMessage(MODULE_SERVERCOMM, receiver, cmd, data, size);
}

void CServerCommunicationManager::CmdNotImplemented(void *data, int size)
{
	LOGE(TAG, "Function is not implemented");
}

void CServerCommunicationManager::CmdRequestRegisterGateway(void *data, int size)
{
	struct GatewayInfo *info = (struct GatewayInfo *)data;

	// Control Packet
	WriteControlPacket(0x01, info->gateway_id, 6);

	Json::Value root;
	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	char id[13];
	memset(id, 0x00, 13);
	ConvertCharMacToStrMac(info->gateway_id, 6, id, 13);

	root["gatewayId"] = id;
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "REQUEST_REGISTER_GATEWAY";
	root["error"] = 0;

	Json::Value extra;
	extra["isConfig"] = info->is_config;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}

void CServerCommunicationManager::CmdRequestRegisterGatewayResponse(void *data, int size)
{
	LOGD(TAG, "FUNC IN");
	SendInternalMessage(MODULE_GATEWAY, CMD_REQUEST_REGISTER_GATEWAY_RESPONSE, NULL, 0);
	LOGD(TAG, "FUNC OUT");
}

void CServerCommunicationManager::CmdSetOperatingInfo(void *data, int size)
{
	LOGD(TAG, "FUNC IN");
	LOGD(TAG, "JSON:\n%s", (char *)data);

	struct GatewayInfo info;
	memset(&info, 0x00, sizeof(struct GatewayInfo));

	Json::CharReaderBuilder builder;
	Json::CharReader * reader = builder.newCharReader();
	std::string error;

	Json::Value root;

	bool res = reader->parse((char *)data, (char *)data + size, &root, &error);

	if (res == true)
	{
		try
		{
			ConvertStrMacToCharMac(root["gatewayId"].asCString(), info.gateway_id, 6);
			strcpy(info.operating_info.equipment_id, root["extra"]["equipmentId"].asCString());
			info.operating_info.location = root["extra"]["location"].asInt();
			info.operating_info.num_data_stored = root["extra"]["numData"].asInt();
		}
		catch(...)
		{
			LOGE(TAG, "Parsing Error");
		}
	}

	SendInternalMessage(MODULE_GATEWAY, CMD_SET_OPERATING_INFO, &info, sizeof(struct GatewayInfo));
	LOGD(TAG, "FUNC OUT");
}

void CServerCommunicationManager::CmdSetOperatingInfoResponse(void *data, int size)
{
	struct GatewayInfo *info = (struct GatewayInfo *)data;

	Json::Value root;

	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	char id[13];
	memset(id, 0x00, 13);
	ConvertCharMacToStrMac(info->gateway_id, 6, id, 13);

	root["gatewayId"] = std::string(id);
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "SET_OPERATING_INFO_RESPONSE";
	root["error"] = 0;

	Json::Value extra;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}

void CServerCommunicationManager::CmdGetOperatingInfoResponse(void *data, int size)
{
	Json::Value root;
	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	root["gatewayId"] = "ABCDEF012345";
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "GET_OPERATING_INFO_RESPONSE";
	root["error"] = 0;

	Json::Value extra;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	//Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}

void CServerCommunicationManager::CmdSetMeasurementInfo(void *data, int size)
{
	LOGD(TAG, "FUNC IN");
	LOGD(TAG, "JSON:\n%s", (char *)data);

	struct GatewayInfo info;
	memset(&info, 0x00, sizeof(struct GatewayInfo));

	Json::CharReaderBuilder builder;
	Json::CharReader * reader = builder.newCharReader();
	std::string error;

	Json::Value root;

	bool res = reader->parse((char *)data, (char *)data + size, &root, &error);

	if (res == true)
	{
		try
		{
			ConvertStrMacToCharMac(root["gatewayId"].asCString(), info.gateway_id, 6);
			sscanf(root["extra"]["startTime"].asCString(),"%hhu:%hhu", &info.regular_measurement_info.start_hour, &info.regular_measurement_info.start_minute);
			sscanf(root["extra"]["stopTime"].asCString(),"%hhu:%hhu", &info.regular_measurement_info.stop_hour, &info.regular_measurement_info.stop_minute);
			info.regular_measurement_info.measurement_info.interval = root["extra"]["soundMeasurementInterval"].asInt();
			//info.regular_measurement_info.result_report_interval = root["extra"]["resultReportInterval"].asInt();
		}
		catch(...)
		{
			LOGE(TAG, "Parsing Error");
		}
	}

	SendInternalMessage(MODULE_GATEWAY, CMD_SET_MEASUREMENT_INFO, &info, sizeof(struct GatewayInfo));
	LOGD(TAG, "FUNC OUT");
}

void CServerCommunicationManager::CmdSetMeasurementInfoResponse(void *data, int size)
{
	struct GatewayInfo *info = (struct GatewayInfo *)data;

	Json::Value root;

	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	char id[13];
	memset(id, 0x00, 13);
	ConvertCharMacToStrMac(info->gateway_id, 6, id, 13);

	root["gatewayId"] = std::string(id);
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "SET_MEASUREMENT_INFO_RESPONSE";
	root["error"] = 0;

	Json::Value extra;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}

void CServerCommunicationManager::CmdGetMeasurementInfoResponse(void *data, int size)
{
	Json::Value root;
	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	root["gatewayId"] = "ABCDEF012345";
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "GET_MEASUREMENT_INFO_RESPONSE";
	root["error"] = 0;

	Json::Value extra;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	//Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}

void CServerCommunicationManager::CmdSetIotSensorListInfo(void *data, int size)
{
	LOGD(TAG, "FUNC IN");
	LOGD(TAG, "JSON:\n%s", (char *)data);

	struct GatewayInfo info;
	memset(&info, 0x00, sizeof(struct GatewayInfo));

	Json::CharReaderBuilder builder;
	Json::CharReader * reader = builder.newCharReader();
	std::string error;

	Json::Value root;

	bool res = reader->parse((char *)data, (char *)data + size, &root, &error);

	if (res == true)
	{
		try
		{
			ConvertStrMacToCharMac(root["gatewayId"].asCString(), info.gateway_id, 6);

			Json::Value iotSensorList = root["extra"]["deviceList"];
			if (iotSensorList.size() < 10)
			{
				for (unsigned int index = 0; index < iotSensorList.size(); index++)
				{
					ConvertStrMacToCharMac(iotSensorList[index]["mac"].asCString(), info.iot_sensor_info_list[index].ble, 6);
					ConvertStrMacToCharMac(iotSensorList[index]["wifi"].asCString(), info.iot_sensor_info_list[index].wifi, 6);
					info.iot_sensor_info_list[index].type = *iotSensorList[index]["type"].asString().c_str();
					info.iot_sensor_info_list[index].location = iotSensorList[index]["location"].asInt();
					info.iot_sensor_info_list[index].direction = iotSensorList[index]["direction"].asInt();
				}
				info.num_iot_sensor = iotSensorList.size();
			}

		}
		catch(...)
		{
			LOGE(TAG, "Parsing Error");
		}
	}

	SendInternalMessage(MODULE_GATEWAY, CMD_SET_IOT_SENSOR_LIST_INFO, &info, sizeof(struct GatewayInfo));
	LOGD(TAG, "FUNC OUT");
}

void CServerCommunicationManager::CmdSetIotSensorListInfoResponse(void *data, int size)
{
	Json::Value root;
	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	root["gatewayId"] = "ABCDEF012345";
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "SET_IOT_SENSOR_LIST_INFO_RESPONSE";
	root["error"] = 0;

	Json::Value extra;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	//Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}

void CServerCommunicationManager::CmdGetIotSensorListInfoResponse(void *data, int size)
{
	Json::Value root;
	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	root["gatewayId"] = "ABCDEF012345";
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "GET_IOT_SENSOR_LIST_INFO_RESPONSE";
	root["error"] = 0;

	Json::Value extra;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	//Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}

void CServerCommunicationManager::CmdGetIotSensorInfoResponse(void *data, int size)
{
	Json::Value root;
	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	root["gatewayId"] = "ABCDEF012345";
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "GET_IOT_SENSOR_INFO_RESPONSE";
	root["error"] = 0;

	Json::Value extra;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	//Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}

void CServerCommunicationManager::CmdRequestManualMeasurementResponse(void *data, int size)
{
	Json::Value root;
	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	root["gatewayId"] = "ABCDEF012345";
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "REQUEST_MANUAL_MEASUREMENT_RESPONSE";
	root["error"] = 0;

	Json::Value extra;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	//Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}

void CServerCommunicationManager::CmdRequestPeriodicMeasurementResponse(void *data, int size)
{
	Json::Value root;
	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	root["gatewayId"] = "ABCDEF012345";
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "REQUEST_PERIODIC_MEASUREMENT_RESPONSE";
	root["error"] = 0;

	Json::Value extra;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	//Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}

void CServerCommunicationManager::CmdSetRegularMeasurementResult(void *data, int size)
{
	Json::Value root;
	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	root["gatewayId"] = "ABCDEF012345";
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "SET_REGULAR_MEASUREMENT_RESULT";
	root["error"] = 0;

	Json::Value extra;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	//Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}

void CServerCommunicationManager::CmdSetVibrationRatingResult(void *data, int size)
{
	Json::Value root;
	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	root["gatewayId"] = "ABCDEF012345";
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "SET_VIBRATION_RATING_RESULT";
	root["error"] = 0;

	Json::Value extra;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	//Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}

void CServerCommunicationManager::CmdSetVibrationDiagnosisResult(void *data, int size)
{
	Json::Value root;
	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	root["gatewayId"] = "ABCDEF012345";
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "SET_VIBRATION_DIAGNOSIS_RESULT";
	root["error"] = 0;

	Json::Value extra;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	//Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}

void CServerCommunicationManager::CmdSetVbeltElongationResult(void *data, int size)
{
	Json::Value root;
	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	root["gatewayId"] = "ABCDEF012345";
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "SET_VBELT_ELONGATION_RESULT";
	root["error"] = 0;

	Json::Value extra;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	//Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}

void CServerCommunicationManager::CmdRequestStartInitProcessResponse(void *data, int size)
{
	Json::Value root;
	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	root["gatewayId"] = "ABCDEF012345";
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "REQUEST_START_INIT_PROCESS_RESPONSE";
	root["error"] = 0;

	Json::Value extra;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	//Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}

void CServerCommunicationManager::CmdSetEquipmentInformation(void *data, int size)
{
	LOGD(TAG, "FUNC IN");

	// base64 디코딩 -> 임시 파일로 저장 -> 알고리즘 호출 -> 알고리즘 응답 받으면 -> 암호화해서 지정 경로에 저장

	SendInternalMessage(MODULE_GATEWAY, CMD_SET_EQUIPMENT_INFORMATION, NULL, 0);

	LOGD(TAG, "FUNC OUT");
}

void CServerCommunicationManager::CmdSetEquipmentInformationResponse(void *data, int size)
{
	Json::Value root;
	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	root["gatewayId"] = "ABCDEF012345";
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "SET_EQUIPMENT_INFORMATION_RESPONSE";
	root["error"] = 0;

	Json::Value extra;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	//Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}

void CServerCommunicationManager::CmdGetEquipmentInformationResponse(void *data, int size)
{
	Json::Value root;
	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	root["gatewayId"] = "ABCDEF012345";
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "GET_EQUIPMENT_INFORMATION_RESPONSE";
	root["error"] = 0;

	Json::Value extra;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	//Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}

void CServerCommunicationManager::CmdSetFaultFrequencyResponse(void *data, int size)
{
	Json::Value root;
	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	root["gatewayId"] = "ABCDEF012345";
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "SET_FAULT_FREQUENCY_RESPONSE";
	root["error"] = 0;

	Json::Value extra;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	//Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}

void CServerCommunicationManager::CmdGetFaultFrequencyResponse(void *data, int size)
{
	Json::Value root;
	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	root["gatewayId"] = "ABCDEF012345";
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "GET_FAULT_FREQUENCY_RESPONSE";
	root["error"] = 0;

	Json::Value extra;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	//Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}

void CServerCommunicationManager::CmdRequestSoundThresholdMeasurementResponse(void *data, int size)
{
	Json::Value root;
	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	root["gatewayId"] = "ABCDEF012345";
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "REQUEST_SOUND_THRESHOLD_MEASUREMENT_RESPONSE";
	root["error"] = 0;

	Json::Value extra;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	//Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}

void CServerCommunicationManager::CmdRequestSoundThresholdDiagnosisResponse(void *data, int size)
{
	Json::Value root;
	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	root["gatewayId"] = "ABCDEF012345";
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "REQUEST_SOUND_THRESHOLD_DIAGNOSIS_RESPONSE";
	root["error"] = 0;

	Json::Value extra;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	//Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}

void CServerCommunicationManager::CmdSetSoundThresholdResponse(void *data, int size)
{
	Json::Value root;
	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	root["gatewayId"] = "ABCDEF012345";
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "SET_SOUND_THRESHOLD_RESPONSE";
	root["error"] = 0;

	Json::Value extra;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	//Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}

void CServerCommunicationManager::CmdRequestVibrationThresholdMeasurementResponse(void *data, int size)
{
	Json::Value root;
	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	root["gatewayId"] = "ABCDEF012345";
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "REQUEST_VIBRATION_THRESHOLD_MEASUREMENT_RESPONSE";
	root["error"] = 0;

	Json::Value extra;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	//Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}

void CServerCommunicationManager::CmdRequestVibrationThresholdDiagnosisResponse(void *data, int size)
{
	Json::Value root;
	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	root["gatewayId"] = "ABCDEF012345";
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "REQUEST_VIBRATION_THRESHOLD_DIAGNOSIS_RESPONSE";
	root["error"] = 0;

	Json::Value extra;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	//Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}

void CServerCommunicationManager::CmdSetVibrationThresholdResponse(void *data, int size)
{
	Json::Value root;
	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	root["gatewayId"] = "ABCDEF012345";
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "SET_VIBRATION_THRESHOLD_RESPONSE";
	root["error"] = 0;

	Json::Value extra;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	//Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}

void CServerCommunicationManager::CmdRequestEndInitProcessResponse(void *data, int size)
{
	Json::Value root;
	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	root["gatewayId"] = "ABCDEF012345";
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "REQUEST_END_INIT_PROCESS_RESPONSE";
	root["error"] = 0;

	Json::Value extra;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	//Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}

void CServerCommunicationManager::CmdSetSoundSampleData(void *data, int size)
{
	Json::Value root;
	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	root["gatewayId"] = "ABCDEF012345";
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "SET_SOUND_SAMPLE_DATA";
	root["error"] = 0;

	Json::Value extra;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	//Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}

void CServerCommunicationManager::CmdSetIotSensorSampleData(void *data, int size)
{
	Json::Value root;
	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	root["gatewayId"] = "ABCDEF012345";
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "SET_IOT_SENSOR_SAMPLE_DATA";
	root["error"] = 0;

	Json::Value extra;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	//Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}

void CServerCommunicationManager::CmdRequestFactoryResetResponse(void *data, int size)
{
	Json::Value root;
	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	root["gatewayId"] = "ABCDEF012345";
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "REQUEST_FACTORY_RESET_RESPONSE";
	root["error"] = 0;

	Json::Value extra;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	//Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}

void CServerCommunicationManager::CmdRequestFirmwareUpdateResponse(void *data, int size)
{
	Json::Value root;
	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	root["gatewayId"] = "ABCDEF012345";
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "REQUEST_FIRMWARE_UPDATE_RESPONSE";
	root["error"] = 0;

	Json::Value extra;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	//Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}
#include "EmRouterManager.h"
#include "mq/MessageQueue.h"

#include "json/json.h"
#include "log/Log.h"
#include "util/Util.h"

// For socket
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

CEmRouterManager::CEmRouterManager()
{
}

CEmRouterManager::~CEmRouterManager()
{
}

void CEmRouterManager::Init(CCommunicationBase *channel)
{
	mTransmitChannel = channel;
	mTransmitChannel->RegisterListener(this);

	MessageQueue::GetInstance()->RegisterListener(MODULE_EMROUTER, this);

	AddMessageHandler(CMD_GET_WIFI_MAC_ADDRESS, "CMD_GET_WIFI_MAC_ADDRESS", &CEmRouterManager::CmdGetWifiMacAddress);
}

void CEmRouterManager::AddMessageHandler(COMMAND_TYPE cmd, const char *name, void (CEmRouterManager::*handler)(void *, int))
{
	message_handler<CEmRouterManager> h;

	h.cmd = cmd;
	snprintf(h.name, 64, "%s", name);
	h.handler = handler;

	mMessageHandlerList.push_back(h);
}

void CEmRouterManager::MessageHandler(MODULE_TYPE sender, COMMAND_TYPE cmd, void *data, int size)
{
	int rc = 0;
	std::vector<message_handler<CEmRouterManager>>::iterator it;

	for (it = mMessageHandlerList.begin(); it != mMessageHandlerList.end(); it++)
	{
		if (it->cmd == cmd)
		{
			LOGD(TAG, "%s, data: %p, size: %d", it->name, data, size);
			void (CEmRouterManager::*fp)(void *, int) = it->handler;

			(this->*fp)(data, size);
			rc = 1;
		}
	}

	if (rc == 0)
	{
	}
}

void CEmRouterManager::Read(const void *data, const unsigned int size)
{
	PrintPacket(TAG, "[RD-RAW]", (char *)data, size);

	//struct SOCKET_HEAD *head = (struct SOCKET_HEAD *)data;

	char *payload = (char *)data;
	int payloadSize = size;
#if 0
	switch (head->type)
	{
	case 0x02:
	{
		payload = (char *)data + sizeof(struct SOCKET_HEAD);
		payloadSize = size - sizeof(struct SOCKET_HEAD);
	}
	break;
	default:
	{
		LOGE(TAG, "Not supported protocol: %02x", head->type);
	}
	break;
	}
#endif
	PrintPacket(TAG, "[PAYLOAD]", payload, payloadSize);

	Json::CharReaderBuilder builder;
	Json::CharReader *reader = builder.newCharReader();
	std::string error;

	Json::Value root;

	bool res = reader->parse(payload, payload + payloadSize, &root, &error);

	if (res == true)
	{
		try
		{
			//LOGD(TAG, "Gateway ID: %s, Time: %d, CMD: %s, Error: %d", root["gatewayId"].asCString(), root["timestamp"].asInt(), root["cmd"].asCString(), root["error"].asInt());

			std::string cmd = root["cmd"].asString();
			LOGD(TAG, "CMD: %s", cmd.c_str());
		}
		catch (...)
		{
			res = false;
			LOGD(TAG, "Parsing Error");
		}
	}
	else
	{
		LOGD(TAG, "Parsing Error");
	}
}

void CEmRouterManager::Write(const uint8_t *data, const int size)
{
	PrintPacket(TAG, "[WR-RAW]", (char *)data, size);
#if 0
	uint32_t packetLength = sizeof(struct SOCKET_HEAD) + size;
	char *packet = (char *)malloc(packetLength);
	memset(packet, 0x00, packetLength);

	struct SOCKET_HEAD *head = (struct SOCKET_HEAD *)packet;
	head->type = 0x02;
	head->length = size;
	memcpy(packet + sizeof(struct SOCKET_HEAD), data, size);

	mTransmitChannel->Write(packet, packetLength);
	free(packet);
#endif
	mTransmitChannel->Write((char *)data, size);
}

void CEmRouterManager::SendInternalMessage(MODULE_TYPE receiver, COMMAND_TYPE cmd, void *data, int size)
{
	MessageQueue::GetInstance()->SendMessage(MODULE_EMROUTER, receiver, cmd, data, size);
}

void CEmRouterManager::CmdGetWifiMacAddress(void *data, int size)
{
	struct GatewayInfo *info = (struct GatewayInfo *)data;

	Json::Value root;
	timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);

	char id[13];
	memset(id, 0x00, 13);
	//ConvertCharMacToStrMac(info->gateway_id, 6, id, 13);

	root["gatewayId"] = id;
	root["timestamp"] = ts.tv_sec;
	root["cmd"] = "GET_WIFI_MAC_ADDRESS";
	root["error"] = 0;

	Json::Value extra;

	root["extra"] = extra;

	Json::StreamWriterBuilder builder;
	std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());

	std::ostringstream outStream;
	writer->write(root, &outStream);

	std::string output = outStream.str();

	LOGD(TAG, "JSON: %s", output.c_str());
	Write((uint8_t *)output.c_str(), strlen(output.c_str()));
}
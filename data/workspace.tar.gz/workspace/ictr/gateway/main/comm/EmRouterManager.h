#ifndef EM_ROUTER_MANAGER_H
#define EM_ROUTER_MANAGER_H

#include "base/Base.h"
#include "base/CommunicationBase.h"

#pragma pack(push, 1)
#if 0
struct SOCKET_HEAD
{
	uint8_t type;
	uint8_t reserved[2];
	uint8_t command;
	uint32_t length;
};
#endif
#pragma pack(pop)

class CEmRouterManager : public CBase, public IDataListener
{
public:
	CEmRouterManager();
	~CEmRouterManager();

	void Init(CCommunicationBase *channel);

private:
	const char *TAG = "EMR";

	CCommunicationBase *mTransmitChannel;

	std::vector<message_handler<CEmRouterManager>> mMessageHandlerList;
	void AddMessageHandler(COMMAND_TYPE cmd, const char *name, void (CEmRouterManager::*handler)(void *, int));

	void MessageHandler(MODULE_TYPE sender, COMMAND_TYPE cmd, void *data, int size);

	void SendInternalMessage(MODULE_TYPE receiver, COMMAND_TYPE cmd, void *data, int size);

	void Read(const void *data, const unsigned int size);
	void Write(const uint8_t *data, const int size);

	void CmdGetWifiMacAddress(void *data, int size);
};
#endif
#ifndef SERVERCOMMUNICATIONMANAGER_H
#define SERVERCOMMUNICATIONMANAGER_H

#include "base/Base.h"
#include "base/CommunicationBase.h"

#include <map>

#pragma pack(push, 1)

struct SOCKET_HEAD
{
	uint8_t type;
	uint8_t reserved[2];
	uint8_t command;
	uint32_t length;
};

#pragma pack(pop)

class CServerCommunicationManager : public CBase, public IDataListener
{
public:
	CServerCommunicationManager();
	~CServerCommunicationManager();

	void Init(CCommunicationBase *channel);

private:
	const char *TAG = "COMM";

	CCommunicationBase *mTransmitChannel;

	std::vector<message_handler<CServerCommunicationManager>> mMessageHandlerList;
	void AddMessageHandler(COMMAND_TYPE cmd, const char *name, void (CServerCommunicationManager::*handler)(void *, int));

	void MessageHandler(MODULE_TYPE sender, COMMAND_TYPE cmd, void *data, int size);

	void SendInternalMessage(MODULE_TYPE receiver, COMMAND_TYPE cmd, void *data, int size);

	void Read(const void *data, const unsigned int size);
	void Write(const uint8_t *data, const int size);
	void WriteControlPacket(const uint8_t command, const uint8_t *data, const int size);

	// Json message map
	std::map<std::string, COMMAND_TYPE> mMapJsonCommand;

	void CmdNotImplemented(void *data, int size);

	void CmdRequestRegisterGateway(void *data, int size);
	void CmdRequestRegisterGatewayResponse(void *data, int size);

	void CmdSetOperatingInfo(void *data, int size);
	void CmdSetOperatingInfoResponse(void *data, int size);
	void CmdGetOperatingInfoResponse(void *data, int size);

	void CmdSetMeasurementInfo(void *data, int size);
	void CmdSetMeasurementInfoResponse(void *data, int size);
	void CmdGetMeasurementInfoResponse(void *data, int size);

	void CmdSetIotSensorListInfo(void *data, int size);
	void CmdSetIotSensorListInfoResponse(void *data, int size);
	void CmdGetIotSensorListInfoResponse(void *data, int size);
	void CmdGetIotSensorInfoResponse(void *data, int size);

	void CmdRequestManualMeasurementResponse(void *data, int size);
	void CmdRequestPeriodicMeasurementResponse(void *data, int size);
	void CmdSetRegularMeasurementResult(void *data, int size);
	void CmdSetVibrationRatingResult(void *data, int size);
	void CmdSetVibrationDiagnosisResult(void *data, int size);
	void CmdSetVbeltElongationResult(void *data, int size);
	void CmdRequestStartInitProcessResponse(void *data, int size);

	void CmdSetEquipmentInformation(void *data, int size);
	void CmdSetEquipmentInformationResponse(void *data, int size);
	void CmdGetEquipmentInformationResponse(void *data, int size);
	void CmdSetFaultFrequencyResponse(void *data, int size);
	void CmdGetFaultFrequencyResponse(void *data, int size);
	void CmdRequestSoundThresholdMeasurementResponse(void *data, int size);
	void CmdRequestSoundThresholdDiagnosisResponse(void *data, int size);
	void CmdSetSoundThresholdResponse(void *data, int size);
	void CmdRequestVibrationThresholdMeasurementResponse(void *data, int size);
	void CmdRequestVibrationThresholdDiagnosisResponse(void *data, int size);
	void CmdSetVibrationThresholdResponse(void *data, int size);
	void CmdRequestEndInitProcessResponse(void *data, int size);
	void CmdSetSoundSampleData(void *data, int size);
	void CmdSetIotSensorSampleData(void *data, int size);
	void CmdRequestFactoryResetResponse(void *data, int size);
	void CmdRequestFirmwareUpdateResponse(void *data, int size);
};
#endif

#include "SubGatewayCommunicationManager.h"
#include "mq/MessageQueue.h"

#include "json/json.h"
#include "log/Log.h"
#include "util/Util.h"

// For socket
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

CSubGatewayCommunicationManager ::CSubGatewayCommunicationManager()
{
}

CSubGatewayCommunicationManager ::~CSubGatewayCommunicationManager()
{
}

void CSubGatewayCommunicationManager::Init(CCommunicationBase *channel)
{
	mTransmitChannel = channel;
	mTransmitChannel->RegisterListener(this);

	MessageQueue::GetInstance()->RegisterListener(MODULE_SUBGCOMM, this);
}

void CSubGatewayCommunicationManager::AddMessageHandler(COMMAND_TYPE cmd, const char *name, void (CSubGatewayCommunicationManager::*handler)(void *, int))
{
	message_handler<CSubGatewayCommunicationManager> h;

	h.cmd = cmd;
	snprintf(h.name, 64, "%s", name);
	h.handler = handler;

	mMessageHandlerList.push_back(h);
}

void CSubGatewayCommunicationManager::MessageHandler(MODULE_TYPE sender, COMMAND_TYPE cmd, void *data, int size)
{
	int rc = 0;
	std::vector<message_handler<CSubGatewayCommunicationManager>>::iterator it;

	for (it = mMessageHandlerList.begin(); it != mMessageHandlerList.end(); it++)
	{
		if (it->cmd == cmd)
		{
			LOGD(TAG, "%s, data: %p, size: %d", it->name, data, size);
			void (CSubGatewayCommunicationManager::*fp)(void *, int) = it->handler;

			(this->*fp)(data, size);
			rc = 1;
		}
	}

	if (rc == 0)
	{
	}
}

void CSubGatewayCommunicationManager::Read(const void *data, const unsigned int size)
{
	PrintPacket(TAG, "[RD-RAW]", (char *)data, size);

	struct SOCKET_HEAD *head = (struct SOCKET_HEAD *)data;

	char *payload = (char *)data;
	int payloadSize = size;
	switch (head->type)
	{
	case 0x02:
	{
		payload = (char *)data + sizeof(struct SOCKET_HEAD);
		payloadSize = size - sizeof(struct SOCKET_HEAD);
	}
	break;
	default:
	{
		LOGE(TAG, "Not supported protocol: %02x", head->type);
	}
	break;
	}

	PrintPacket(TAG, "[PAYLOAD]", payload, payloadSize);

	Json::CharReaderBuilder builder;
	Json::CharReader *reader = builder.newCharReader();
	std::string error;

	Json::Value root;

	bool res = reader->parse(payload, payload + payloadSize, &root, &error);

	if (res == true)
	{
		try
		{
			//LOGD(TAG, "Gateway ID: %s, Time: %d, CMD: %s, Error: %d", root["gatewayId"].asCString(), root["timestamp"].asInt(), root["cmd"].asCString(), root["error"].asInt());

			std::string cmd = root["cmd"].asString();
			LOGD(TAG, "CMD: %s", cmd.c_str());
		}
		catch (...)
		{
			res = false;
			LOGD(TAG, "Parsing Error");
		}
	}
	else
	{
		LOGD(TAG, "Parsing Error");
	}
}

void CSubGatewayCommunicationManager::Write(const uint8_t *data, const int size)
{
	PrintPacket(TAG, "[WR-RAW]", (char *)data, size);

	uint32_t packetLength = sizeof(struct SOCKET_HEAD) + size;
	char *packet = (char *)malloc(packetLength);
	memset(packet, 0x00, packetLength);

	struct SOCKET_HEAD *head = (struct SOCKET_HEAD *)packet;
	head->type = 0x02;
	head->length = size;
	memcpy(packet + sizeof(struct SOCKET_HEAD), data, size);

	mTransmitChannel->Write(packet, packetLength);
	free(packet);
}

void CSubGatewayCommunicationManager::SendInternalMessage(MODULE_TYPE receiver, COMMAND_TYPE cmd, void *data, int size)
{
	MessageQueue::GetInstance()->SendMessage(MODULE_SUBGCOMM, receiver, cmd, data, size);
}
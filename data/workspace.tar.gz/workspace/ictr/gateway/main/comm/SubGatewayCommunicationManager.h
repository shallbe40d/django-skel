#ifndef SUBGATEWAYCOMMUNICATIONMANAGER_H
#define SUBGATEWAYCOMMUNICATIONMANAGER_H

#include "base/Base.h"
#include "base/CommunicationBase.h"

#pragma pack(push, 1)

struct SOCKET_HEAD
{
	uint8_t type;
	uint8_t reserved[2];
	uint8_t command;
	uint32_t length;
};

#pragma pack(pop)

class CSubGatewayCommunicationManager : public CBase, public IDataListener
{
public:
	CSubGatewayCommunicationManager();
	~CSubGatewayCommunicationManager();

	void Init(CCommunicationBase *channel);

private:
	const char *TAG = "SUBGWCOMM";

	CCommunicationBase *mTransmitChannel;

	std::vector<message_handler<CSubGatewayCommunicationManager>> mMessageHandlerList;
	void AddMessageHandler(COMMAND_TYPE cmd, const char *name, void (CSubGatewayCommunicationManager::*handler)(void *, int));

	void MessageHandler(MODULE_TYPE sender, COMMAND_TYPE cmd, void *data, int size);

	void SendInternalMessage(MODULE_TYPE receiver, COMMAND_TYPE cmd, void *data, int size);

	void Read(const void *data, const unsigned int size);
	void Write(const uint8_t *data, const int size);
}
#endif
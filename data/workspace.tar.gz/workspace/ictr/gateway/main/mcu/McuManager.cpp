#include "McuManager.h"

#include "log/Log.h"
#include "util/Util.h"

CMcuManager::CMcuManager()
{
	mWorkInterval = 10;
}

CMcuManager::~CMcuManager()
{
}

void CMcuManager::Init(CCommunicationBase *channel)
{
	mTransmitChannel = channel;
	mTransmitChannel->RegisterListener(this);

	MessageQueue::GetInstance()->RegisterListener(MODULE_MCU, this);
}

void CMcuManager::Write(const void *data, const int size)
{
	mTransmitChannel->Write((char *)data, size);
}

void CMcuManager::Read(const void *data, const unsigned int size)
{
	LOGD(TAG, "FUNC IN");
	LOGD(TAG, "FUNC OUT");
}

void CMcuManager::MessageHandler(MODULE_TYPE sender, COMMAND_TYPE cmd, void *data, int size)
{
	switch(cmd)
	{
	case CMD_REQUEST_SOFTWARE_RESET:
		{
			LOGD(TAG, "CMD_SOFTWARE_RESET");
			CmdRequestSoftwareReset();
		}
		break;
	case CMD_REQUEST_POWER_CONTROL:
		{
			LOGD(TAG, "CMD_POWER_CONTROL");
			CmdRequestPowerControl(data, size);
		}
		break;
	case CMD_REQUEST_SET_IO_STATE:
		{
			LOGD(TAG, "CMD_IO_CONTROL");
			CmdRequestSetIoControl(data, size);
		}
		break;
#if 0
	case CMD_REQUEST_HEALTH:
		{
			LOGD(TAG, "CMD_REQUEST_HEALTH");
			CmdRequestHealth();
		}
		break;
#endif
	default:
		{
			CBase::MessageHandler(sender, cmd, data, size);
		}
		break;
	}
}

void CMcuManager::CmdRequestSoftwareReset()
{
	MCU_REQUEST_SOFT_RESET info;
	memset(&info, 0x00, sizeof(MCU_REQUEST_SOFT_RESET));

	info.head.stx = MCU_PROTOCOL_STX;
	info.head.op_code = MCU_OP_REQUEST_SOFTWARE_RESET;
	info.head.length = 0 ;

	info.tail.crc8 = crc8ccitt(&info, sizeof(MCU_REQUEST_SOFT_RESET) - sizeof(MCU_PROTOCOL_TAIL));
	info.tail.etx = MCU_PROTOCOL_ETX;

	Write(&info, sizeof(MCU_REQUEST_SOFT_RESET));
}

void CMcuManager::CmdRequestPowerControl(void *data, int size)
{
	bool *isPowerOn = (bool *)data;

	MCU_REQUEST_POWER_CONTROL info;
	memset(&info, 0x00, sizeof(MCU_REQUEST_POWER_CONTROL));

	info.head.stx = MCU_PROTOCOL_STX;
	info.head.op_code = MCU_OP_REQUEST_POWER_CONTROL;
	info.head.length = sizeof(info.payload);

	if (*isPowerOn == false)
	{
		info.payload.value = 0x00;
	}
	else
	{
		info.payload.value = 0x03;
	}

	info.tail.crc8 = crc8ccitt(&info.payload, sizeof(info.payload));
	info.tail.etx = MCU_PROTOCOL_ETX;

	Write(&info, sizeof(MCU_REQUEST_POWER_CONTROL));
}

void CMcuManager::CmdRequestSetIoControl(void *data, int size)
{
	IO_CONTROL_TYPE *req = (IO_CONTROL_TYPE *)data;

	MCU_REQUEST_SET_IO_STATE info;
	memset(&info, 0x00, sizeof(MCU_REQUEST_SET_IO_STATE));

	info.head.stx = MCU_PROTOCOL_STX;
	info.head.length = sizeof(info.payload);

	switch(*req)
	{
	case IO_ADC_APP:
		{
			info.head.op_code = MCU_OP_REQUEST_SET_IO_STATE_ADC;
			info.payload.io_select = 0x02;
			info.payload.io_config = 0x01;
			info.payload.value[0] = 0x00;
			info.payload.value[1] = 0x00;
		}
		break;
	case IO_ADC_BOOT:
		{
			info.head.op_code = MCU_OP_REQUEST_SET_IO_STATE_ADC;
			info.payload.io_select = 0x02;
			info.payload.io_config = 0x01;
			info.payload.value[0] = 0x00;
			info.payload.value[1] = 0x01;
		}
		break;
	case IO_ADC_RESET_HIGH:
		{
			info.head.op_code = MCU_OP_REQUEST_SET_IO_STATE_ADC;
			info.payload.io_select = 0x01;
			info.payload.io_config = 0x01;
			info.payload.value[0] = 0x00;
			info.payload.value[1] = 0x01;
		}
		break;
	case IO_ADC_RESET_LOW:
		{
			info.head.op_code = MCU_OP_REQUEST_SET_IO_STATE_ADC;
			info.payload.io_select = 0x01;
			info.payload.io_config = 0x01;
			info.payload.value[0] = 0x00;
			info.payload.value[1] = 0x00;
		}
		break;
	case IO_ADC_MEASUREMENT_START:
		{
			info.head.op_code = MCU_OP_REQUEST_SET_IO_STATE_ADC;
			info.payload.io_select = 0x04;
			info.payload.io_config = 0x01;
			info.payload.value[0] = 0x00;
			info.payload.value[1] = 0x01;
		}
		break;
	case IO_ADC_MEASUREMENT_STOP:
		{
			info.head.op_code = MCU_OP_REQUEST_SET_IO_STATE_ADC;
			info.payload.io_select = 0x04;
			info.payload.io_config = 0x01;
			info.payload.value[0] = 0x00;
			info.payload.value[1] = 0x00;
		}
		break;
	case IO_ADC_RESET:
		{
			info.head.op_code = MCU_OP_REQUEST_SET_IO_STATE_ADC;
			info.payload.io_select = 0x01;
			info.payload.io_config = 0x02;
			info.payload.value[0] = 0x11;
			info.payload.value[1] = 0xF4;
		}
		break;
	case IO_BLE_APP:
		{
			info.head.op_code = MCU_OP_REQUEST_SET_IO_STATE_BLE;
			info.payload.io_select = 0x02;
			info.payload.io_config = 0x01;
			info.payload.value[0] = 0x00;
			info.payload.value[1] = 0x01;
		}
		break;
	case IO_BLE_BOOT:
		{
			info.head.op_code = MCU_OP_REQUEST_SET_IO_STATE_BLE;
			info.payload.io_select = 0x02;
			info.payload.io_config = 0x01;
			info.payload.value[0] = 0x00;
			info.payload.value[1] = 0x00;
		}
		break;
	case IO_BLE_RESET_LOW:
		{
			info.head.op_code = MCU_OP_REQUEST_SET_IO_STATE_BLE;
			info.payload.io_select = 0x01;
			info.payload.io_config = 0x01;
			info.payload.value[0] = 0x00;
			info.payload.value[1] = 0x00;
		}
		break;
	case IO_BLE_RESET_HIGH:
		{
			info.head.op_code = MCU_OP_REQUEST_SET_IO_STATE_BLE;
			info.payload.io_select = 0x01;
			info.payload.io_config = 0x01;
			info.payload.value[0] = 0x00;
			info.payload.value[1] = 0x01;
		}
		break;
	case IO_BLE_RESET:
		{
			info.head.op_code = MCU_OP_REQUEST_SET_IO_STATE_BLE;
			info.payload.io_select = 0x01;
			info.payload.io_config = 0x02;
			info.payload.value[0] = 0x11;
			info.payload.value[1] = 0xF4;
		}
		break;
	default:
		{
		}
		break;
	}

	info.tail.crc8 = crc8ccitt(&info.payload, sizeof(info.payload));
	info.tail.etx = MCU_PROTOCOL_ETX;

	Write(&info, sizeof(MCU_REQUEST_SET_IO_STATE));
}

void CMcuManager::CmdRequestHealth()
{
	MCU_REQUEST_HEALTH info;
	memset(&info, 0x00, sizeof(MCU_REQUEST_HEALTH));

	info.head.stx = MCU_PROTOCOL_STX;
	info.head.op_code = MCU_OP_REQUEST_HEALTH;
	info.head.length = 0;

	info.tail.crc8 = crc8ccitt(&info, sizeof(MCU_REQUEST_HEALTH) - sizeof(MCU_PROTOCOL_TAIL));
	info.tail.etx = MCU_PROTOCOL_ETX;

	Write(&info, sizeof(MCU_REQUEST_HEALTH));
}

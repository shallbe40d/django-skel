#include "base/Base.h"
#include "base/CommunicationBase.h"

#pragma pack(push, 1)
typedef struct _MCU_PROTOCOL_HEAD
{
	uint8_t stx;
	uint8_t op_code;
	uint8_t length;
} MCU_PROTOCOL_HEAD;

typedef struct _MCU_PROTOCOL_TAIL
{
	uint8_t crc8;
	uint8_t etx;
} MCU_PROTOCOL_TAIL;

typedef struct _MCU_PAYLOAD_HEAD
{
	uint8_t mode;
	uint8_t result;
} MCU_PAYLOAD_HEAD;

typedef struct _MCU_PAYLOAD_VERSION
{
	uint8_t major;
	uint8_t minor;
	uint8_t revision;
} MCU_PAYLOAD_VERSION;

typedef struct _MCU_PAYLOAD_LED
{
	uint8_t status;
	uint8_t blink_on_time;
	uint8_t blink_off_time;
	uint8_t operation_time;
} MCU_PAYLOAD_LED;

typedef struct _MCU_PROTOCOL_ERROR
{
	MCU_PROTOCOL_HEAD head;
	struct {
		MCU_PAYLOAD_HEAD head;
	} payload;
	MCU_PROTOCOL_TAIL tail;
} MCU_PROTOCOL_ERROR;

typedef struct _MCU_NOTIFY_BOOT
{
	MCU_PROTOCOL_HEAD head;
	struct {
		MCU_PAYLOAD_HEAD head;
		MCU_PAYLOAD_VERSION version;
	} payload;
	MCU_PROTOCOL_TAIL tail;
} MCU_NOTIFY_BOOT;

typedef struct _MCU_NOTIFY_KEY_EVENT
{
	MCU_PROTOCOL_HEAD head;
	struct {
		MCU_PAYLOAD_HEAD head;
		uint8_t key_event[3];
	} payload;
	MCU_PROTOCOL_TAIL tail;
} MCU_NOTIFY_KEY_EVENT;

typedef struct _MCU_RESPONSE_KEY_EVENT
{
	MCU_PROTOCOL_HEAD head;
	struct {
		uint8_t result;
	} payload;
	MCU_PROTOCOL_TAIL tail;
} MCU_RESPONSE_KEY_EVENT;

typedef struct _MCU_NOTIFY_POWER_TYPE
{
	MCU_PROTOCOL_HEAD head;
	struct {
		MCU_PAYLOAD_HEAD head;
		uint8_t value;
	} payload;
	MCU_PROTOCOL_TAIL tail;
} MCU_NOTIFY_POWER_TYPE;

typedef struct _MCU_RESPONSE_POWER_TYPE
{
	MCU_PROTOCOL_HEAD head;
	struct {
		uint8_t result;
	} payload;
	MCU_PROTOCOL_TAIL tail;
} MCU_RESPONSE_POWER_TYPE;

typedef struct _MCU_NOTIFY_BLE_RESET
{
	MCU_PROTOCOL_HEAD head;
	struct {
		MCU_PAYLOAD_HEAD head;
	} paylaod;
	MCU_PROTOCOL_TAIL tail;
} MCU_NOTIFY_BLE_RESET;

typedef struct _MCU_RESPONSE_BLE_RESET
{
	MCU_PROTOCOL_HEAD head;
	struct {
		uint8_t result;
	} payload;
	MCU_PROTOCOL_TAIL tail;
} MCU_RESPONSE_BLE_RESET;

typedef struct _MCU_REQUEST_HEALTH
{
	MCU_PROTOCOL_HEAD head;
	struct {
		uint8_t reserved;
	} payload;
	MCU_PROTOCOL_TAIL tail;
} MCU_REQUEST_HEALTH;

typedef struct _MCU_RESPONSE_HEALTH
{
	MCU_PROTOCOL_HEAD head;
	struct {
		MCU_PAYLOAD_HEAD head;
	} payload;
	MCU_PROTOCOL_TAIL tail;
} MCU_RESPONSE_HEALTH;

typedef struct _MCU_REQUEST_GET_OP_MODE
{
	MCU_PROTOCOL_HEAD head;
	struct {
		uint8_t reserved;
	} payload;
	MCU_PROTOCOL_TAIL tail;
} MCU_REQUEST_GET_OP_MODE;

typedef struct _MCU_RESPONSE_GET_OP_MODE_BOOT
{
	MCU_PROTOCOL_HEAD head;
	struct {
		MCU_PAYLOAD_HEAD head;
		MCU_PAYLOAD_VERSION version;
	} payload;
	MCU_PROTOCOL_TAIL tail;
} MCU_RESPONSE_GET_OP_MODE_BOOT;

typedef struct _MCU_RESPONSE_GET_OP_MODE_APP
{
	MCU_PROTOCOL_HEAD head;
	struct {
		MCU_PAYLOAD_HEAD head;
	} payload;
	MCU_PROTOCOL_TAIL tail;
} MCU_RESPONSE_GET_OP_MODE_APP;

typedef struct _MCU_REQUEST_SET_IO_STATE
{
	MCU_PROTOCOL_HEAD head;
	struct {
		uint8_t io_select;
		uint8_t io_config;
		uint8_t value[2];
	} payload;
	MCU_PROTOCOL_TAIL tail;
} MCU_REQUEST_SET_IO_STATE;

typedef struct _MCU_RESPONSE_SET_IO_STATE
{
	MCU_PROTOCOL_HEAD head;
	struct {
		MCU_PAYLOAD_HEAD head;
	} payload;
	MCU_PROTOCOL_TAIL tail;
} MCU_RESPONSE_SET_IO_STATE;

typedef struct _MCU_REQUEST_GET_IO_STATE
{
	MCU_PROTOCOL_HEAD head;
	struct {
		uint8_t reserved;
	} payload;
	MCU_PROTOCOL_TAIL tail;
} MCU_REQUEST_GET_IO_STATE;

#if 0
typedef struct _MCU_RESPONSE_GET_IO_STATE
{
	MCU_PROTOCOL_HEAD head;
	struct {
		MCU_PAYLOAD_HEAD head;
		// 가변 길이 데이터
	} payload;
	MCU_PROTOCOL_TAIL tail;
} MCU_RESPONSE_SET_IO_STATE;
#endif

typedef struct _MCU_REQUEST_SOFT_RESET
{
	MCU_PROTOCOL_HEAD head;
	struct {
		uint8_t reserved;
	} payload;
	MCU_PROTOCOL_TAIL tail;
} MCU_REQUEST_SOFT_RESET;

typedef struct _MCU_RESPONSE_SOFT_RESET
{
	MCU_PROTOCOL_HEAD head;
	struct {
		MCU_PAYLOAD_HEAD head;
	} payload;
	MCU_PROTOCOL_TAIL tail;
} MCU_RESPONSE_SOFT_RESET;

typedef struct _MCU_REQUEST_SET_OP_MODE
{
	MCU_PROTOCOL_HEAD head;
	struct {
		uint8_t mode;
	} payload;
	MCU_PROTOCOL_TAIL tail;
} MCU_REQUEST_SET_OP_MODE;

typedef struct _MCU_RESPONSE_SET_OP_MODE
{
	MCU_PROTOCOL_HEAD head;
	struct {
		MCU_PAYLOAD_HEAD head;
	} payload;
	MCU_PROTOCOL_TAIL tail;
} MCU_RESPONSE_SET_OP_MODE;

typedef struct _MCU_REQUEST_CONTROL_LED
{
	MCU_PROTOCOL_HEAD head;
	struct {
		uint8_t led_id;
		MCU_PAYLOAD_LED led;
	} payload;
	MCU_PROTOCOL_TAIL tail;
} MCU_REQUEST_CONTROL_LED;

typedef struct _MCU_REQUEST_POWER_CONTROL
{
	MCU_PROTOCOL_HEAD head;
	struct {
		uint8_t value;
	} payload;
	MCU_PROTOCOL_TAIL tail;
} MCU_REQUEST_POWER_CONTROL;

typedef struct _MCU_RESPONSE_POWER_CONTROL
{
	MCU_PROTOCOL_HEAD head;
	struct {
		MCU_PAYLOAD_HEAD payload;
	} payload;
	MCU_PROTOCOL_TAIL tail;
} MCU_RESPONSE_POWER_CONTROL;

#if 0 // 확인 필요
typedef struct _MCU_REQUEST_UPDATE_FIRMWARE
{
	MCU_PROTOCOL_HEAD head;
	struct {
		uint8_t reserved;
	} payload;
	MCU_PROTOCOL_TAIL tail;
} MCU_REQUEST_UPDATE_FIRMWARE;

typedef struct _MCU_RESPONSE_UPDATE_FIRMWARE
{
	MCU_PROTOCOL_HEAD head;
	struct {
		MCU_PAYLOAD_HEAD head;
		uint32_t value;
	} payload;
	MCU_PROTOCOL_TAIL tail;
} MCU_RESPONSE_UPDATE_FIRMWARE;

typedef struct _MCU_REQUEST_UPLOAD_FIRMWARE
{
	MCU_PROTOCOL_HEAD head;
	struct {
		uint8_t reserved;
	} payload;
	MCU_PROTOCOL_TAIL tail;
} MCU_REQUEST_UPLOAD_FIRMWARE;

typedef struct _MCU_RESPONSE_UPLOAD_FIRMWARE
{
	MCU_PROTOCOL_HEAD head;
	struct {
		MCU_PAYLOAD_HEAD head;
		uint32_t value;
	} payload;
	MCU_PROTOCOL_TAIL tail;
} MCU_RESPONSE_UPLOAD_FIRMWARE;
#endif

const uint8_t MCU_PROTOCOL_STX = 0x02;
const uint8_t MCU_PROTOCOL_ETX = 0x03;

enum MCU_OP_CODE
{
	MCU_OP_PROTOCOL_ERROR = 0x00,
	MCU_OP_NOTIFY_BOOT = 0xFF,

	MCU_OP_NOTIFY_KEY_EVENT = 0x13,
	MCU_OP_RESPONSE_KEY_EVENT = 0x93,

	MCU_OP_NOTIFY_POWER_TYPE = 0x1A,
	MCU_OP_RESPONSE_POWER_TYPE = 0x9A,

	MCU_OP_NOTIFY_BLE_RESET = 0x14,
	MCU_OP_RESPONSE_BLE_RESET = 0x94,

	MCU_OP_REQUEST_HEALTH = 0x40,
	MCU_OP_RESPONSE_HEALTH = 0xC0,

	MCU_OP_REQUEST_GET_OP_MODE = 0x30,
	MCU_OP_RESPONSE_GET_OP_MODE = 0xB0,
	MCU_OP_REQUEST_SET_OP_MODE = 0x25,
	MCU_OP_RESPONSE_SET_OP_MODE = 0xA5,

	MCU_OP_REQUEST_SET_IO_STATE_BLE = 0x02,
	MCU_OP_RESPONSE_SET_IO_STATE_BLE = 0x82,
	MCU_OP_REQUEST_GET_IO_STATE_BLE = 0x32,
	MCU_OP_RESPONSE_GET_IO_STATE_BLE = 0xB2,

	MCU_OP_REQUEST_SET_IO_STATE_ADC = 0x07,
	MCU_OP_RESPONSE_SET_IO_STATE_ADC = 0x87,
	MCU_OP_REQUEST_GET_IO_STATE_ADC = 0x37,
	MCU_OP_RESPONSE_GET_IO_STATE_ADC = 0xB7,

	MCU_OP_REQUEST_SOFTWARE_RESET = 0x04,
	MCU_OP_RESPONSE_SOFTWARE_RESET = 0x84,

	MCU_OP_CONTROL_LED = 0x01,

	MCU_OP_REQUEST_POWER_CONTROL = 0x0B,
	MCU_OP_RESPONSE_POWER_CONTROL = 0x8B,

	MCU_OP_REQUEST_UPDATE_FIRMWARE = 0x06,
	MCU_OP_RESPONSE_UPDATE_FIRMWARE = 0x86,

	MCU_OP_REQUEST_UPLOAD_FIRMWARE = 0x36,
	MCU_OP_RESPONSE_UPLOAD_FIRMWAER = 0xB6,
};

#pragma pack(pop)

class CMcuManager : public IDataListener, public CBase
{
public:
	CMcuManager();
	~CMcuManager();

	void Init(CCommunicationBase *channel);

private:
	const char* TAG = "MCUMGR";

	CCommunicationBase *mTransmitChannel;

	void Write(const void *data, const int size);
	void Read(const void *data, const unsigned int size);

	void MessageHandler(MODULE_TYPE sender, COMMAND_TYPE cmd, void *data, int size);

	void CmdRequestSoftwareReset();
	void CmdRequestPowerControl(void *data, int size);
	void CmdRequestSetIoControl(void *data, int size);
	void CmdRequestHealth();
};

#ifndef MESSAGEQUEUE_H
#define MESSAGEQUEUE_H

#include <vector>
#include <map>
#include <thread>
#include <memory>

#include "common/MessageListener.h"
#include "common/SafeQueue.h"

class MessageQueue
{
public:
	void SendMessage(MODULE_TYPE sender, MODULE_TYPE receiver, COMMAND_TYPE cmd, void* data = NULL, int size = 0);

	void RegisterListener(MODULE_TYPE type, IMessageListener* obj);
	void UnregisterListener(MODULE_TYPE type, IMessageListener* obj);

	static MessageQueue* GetInstance()
	{
		if (instance == nullptr)
		{
			instance = new MessageQueue();
			mqId = 0;
		}

		return instance;
	}

	MessageQueue();
	~MessageQueue();

	static unsigned int mqId;

	void AddModuleName(MODULE_TYPE module, const char *name);
	void AddCommandName(COMMAND_TYPE command, const char *name);

private:
	const char* TAG = "MQ";
	const int MAX_WORKER = 1;
	static MessageQueue* instance;
	std::vector<IMessageListener*> messageObserver[MODULE_MAX];

	SafeQueue<std::shared_ptr<Message>> mq;
	std::thread **workers;
	void WorkerThread(int id);
	//void NotifyListener(MODULE_TYPE sender, MODULE_TYPE receiver, COMMAND_TYPE cmd, void* data = NULL, int size = 0);
	void NotifyListener(std::shared_ptr<Message> msg);

	// Module Name
	std::map<MODULE_TYPE, std::string> mModuleNameMap;
	void GetModuleName(const MODULE_TYPE module, char *name, const unsigned int size);

	// Command Name
	std::map<COMMAND_TYPE, std::string> mCommandNameMap;
	void GetCommandName(const COMMAND_TYPE command, char *name, const unsigned int size);
};
#endif
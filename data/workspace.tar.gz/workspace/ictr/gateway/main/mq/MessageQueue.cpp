#include "MessageQueue.h"
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <pthread.h>

#include "../util/Util.h"

MessageQueue* MessageQueue::instance = nullptr;
unsigned int MessageQueue::mqId = 0;

MessageQueue::MessageQueue()
{
	workers = NULL;
	workers = (std::thread **)malloc(sizeof(std::thread *) * MAX_WORKER);

	for (int i = 0; i < MAX_WORKER; i++)
	{
		workers[i] = new std::thread([&]() { WorkerThread(i); });
	}
}

MessageQueue::~MessageQueue()
{
	if (workers != NULL)
	{
		free(workers);
	}
}

void MessageQueue::SendMessage(MODULE_TYPE sender, MODULE_TYPE receiver, COMMAND_TYPE cmd, void* data, int size)
{
	std::shared_ptr<Message> msg = std::make_shared<Message>(MessageQueue::mqId++, sender, receiver, cmd, data, size);

	mq.push_back(msg);
}

void MessageQueue::RegisterListener(MODULE_TYPE type, IMessageListener* obs)
{
	messageObserver[type].push_back(obs);
}

void MessageQueue::UnregisterListener(MODULE_TYPE type, IMessageListener* obs)
{
}

void MessageQueue::NotifyListener(std::shared_ptr<Message> msg)
{
	for(auto Observer : messageObserver[msg->mReceiver])
	{
		Observer->Notify(msg);
	}
}

#if 0
void MessageQueue::NotifyListener(MODULE_TYPE sender, MODULE_TYPE receiver, COMMAND_TYPE cmd, void *data, int size)
{
	for(auto Observer : messageObserver[receiver])
	{
		Observer->Notify(sender, cmd, data, size);
	}
}
#endif

void MessageQueue::WorkerThread(int id)
{
	char senderName[MAX_MODULE_NAME_LENGTH], receiverName[MAX_MODULE_NAME_LENGTH], cmdName[MAX_MESSAGE_NAME_LENGTH];

	while (1)
	{
		std::shared_ptr<Message> msg = mq.front();
		//LOGD(TAG, "msg: %p, cnt: %d", msg);

		memset(senderName, 0x00, MAX_MODULE_NAME_LENGTH);
		memset(receiverName, 0x00, MAX_MODULE_NAME_LENGTH);
		memset(cmdName, 0x00, MAX_MESSAGE_NAME_LENGTH);

		GetModuleName(msg->mSender, senderName, MAX_MODULE_NAME_LENGTH);
		GetModuleName(msg->mReceiver, receiverName, MAX_MODULE_NAME_LENGTH);
		GetCommandName(msg->mCmd, cmdName, MAX_MESSAGE_NAME_LENGTH);
		LOGD(TAG, "[%u][%04u] %d(%s) -> %d(%s) : cmd: %d [%s]", std::this_thread::get_id(), msg->mId, msg->mSender, senderName, msg->mReceiver, receiverName, msg->mCmd, cmdName);

		//NotifyListener(msg->sender, msg->receiver, msg->cmd, msg->data, msg->size);
		NotifyListener(msg);
		//LOGD(TAG, "msg: %p, cnt: %d", msg, msg.use_count());
	}
}

void MessageQueue::AddModuleName(const MODULE_TYPE module, const char *name)
{
	mModuleNameMap.insert(make_pair(module, std::string(name)));
}

void MessageQueue::GetModuleName(const MODULE_TYPE module, char *name, const unsigned int size)
{
	std::map<MODULE_TYPE, std::string>::iterator it;
	it = mModuleNameMap.find(module);

	if (it != mModuleNameMap.end())
	{
		snprintf(name, size, "%s", it->second.c_str());
	}
}

void MessageQueue::AddCommandName(const COMMAND_TYPE command, const char *name)
{
	mCommandNameMap.insert(make_pair(command, std::string(name)));
}

void MessageQueue::GetCommandName(const COMMAND_TYPE command, char *name, const unsigned int size)
{
	std::map<COMMAND_TYPE, std::string>::iterator it;
	it = mCommandNameMap.find(command);

	if (it != mCommandNameMap.end())
	{
		snprintf(name, size, "%s", it->second.c_str());
	}
}

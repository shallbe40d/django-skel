#ifndef LOG_H
#define LOG_H
#include "common/SafeQueue.h"
#include "common/MessageDefine.h"

#include <thread>
#include <unistd.h>

enum LOG_LEVEL
{
	LOG_TRACE,
	LOG_DEBUG,
	LOG_INFO,
	LOG_WARNING,
	LOG_ERROR,
	LOG_FATAL,
	LOG_MAX,
};

enum LOG_CONTROL_TYPE
{
	LOG_EXIT,
	LOG_WRITE,
	LOG_DELETE,
};

struct log_message
{
	LOG_CONTROL_TYPE cmd;
	struct timespec monotonic;
	struct timespec realtime;
	LOG_LEVEL level;
	int pid;
	char tag[16];
	char file[256];
	char func[256];
	int line_no;
	int msg_len;
	char *msg;
};

class CLog
{
public:
	static CLog* GetInstance()
	{
		if (instance == nullptr)
		{
			instance = new CLog();
		}

		return instance;
	}

	void SetLogLevel(const LOG_LEVEL level) { mLogLevel = level; }
	LOG_LEVEL GetLogLevel() { return mLogLevel; }

	void SetMaxLogSize(long int size) { mMaxLogSize = size; }
	long int GetMaxLogSize() { return mMaxLogSize; }

	void PrintLog(const LOG_LEVEL level, const int pid, const char *file, const char *func, const int line_no, const char *tag,  const char *fmt, ...);

	void DeleteLogFile();

private:
	const char* TAG = "LOG";
	static CLog* instance;
	CLog();
	~CLog();

	const int MAX_LOG_LENGTH = 8 * 1024;

	const char *LOG_FILE_SET[2] = {"gateway.1.log", "gateway.2.log"};
	FILE *mFpLogFile;

	LOG_LEVEL mLogLevel;
	long int mMaxLogSize, mCurrentLogSize;

	SafeQueue<log_message *> mLogQueue;
	std::thread* worker;
	void WorkerThread();

	void CmdWriteLog(log_message* msg);
	void CmdDeleteLogFile();

	void PrintLogWithoutWrite(const LOG_LEVEL level, const int pid, const char *file, const char *func, const int line_no, const char *tag,  const char *fmt, ...);
};

#define LOGT(tag, fmt, args...) CLog::GetInstance()->PrintLog(LOG_TRACE, getpid(), __FILE__, __func__, __LINE__, tag, fmt, ## args)
#define LOGD(tag, fmt, args...) CLog::GetInstance()->PrintLog(LOG_DEBUG, getpid(), __FILE__, __func__, __LINE__, tag, fmt, ## args)
#define LOGI(tag, fmt, args...) CLog::GetInstance()->PrintLog(LOG_INFO, getpid(), __FILE__, __func__, __LINE__, tag, fmt, ## args)
#define LOGW(tag, fmt, args...) CLog::GetInstance()->PrintLog(LOG_WARNING, getpid(), __FILE__, __func__, __LINE__, tag, fmt, ## args)
#define LOGE(tag, fmt, args...) CLog::GetInstance()->PrintLog(LOG_ERROR, getpid(), __FILE__, __func__, __LINE__, tag, fmt, ## args)
#define LOGF(tag, fmt, args...) CLog::GetInstance()->PrintLog(LOG_FATAL, getpid(), __FILE__, __func__, __LINE__, tag, fmt, ## args)
#endif

#include "Log.h"

#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <unistd.h>
#include <time.h>

CLog* CLog::instance = nullptr;

CLog::CLog()
{
	mMaxLogSize = 100 * 1024 * 1024; // 1M
	mCurrentLogSize = 0;

	mFpLogFile = NULL;

	mLogLevel = LOG_TRACE;
	worker = new std::thread([&]() { WorkerThread(); });
}

CLog::~CLog()
{
}

void CLog::WorkerThread()
{
	log_message* msg = NULL;

	while (1)
	{
		msg = mLogQueue.front();

		if (msg == NULL)
		{
			continue;
		}

		switch(msg->cmd)
		{
		case LOG_EXIT:
			{
				PrintLogWithoutWrite(LOG_DEBUG, 0, __FILE__, __func__, __LINE__, TAG, "Log Thread Exit is not implemented");
			}
			break;
		case LOG_WRITE:
			{
				CmdWriteLog(msg);
			}
			break;
		case LOG_DELETE:
			{
				CmdDeleteLogFile();
			}
			break;
		default:
			{
				PrintLogWithoutWrite(LOG_ERROR, 0, __FILE__, __func__, __LINE__, TAG, "Error! Not supported type: %d", msg->cmd);
			}
			break;
		}

		if (msg->msg != NULL)
		{
			free((uint8_t*)msg->msg);
			msg->msg = NULL;
		}
		free(msg);
		msg = NULL;
	}
}

void CLog::PrintLogWithoutWrite(const LOG_LEVEL level, const int pid, const char *file, const char *func, const int line_no, const char *tag,  const char *fmt, ...)
{
	if (level < mLogLevel)
	{
		return;
	}

	struct timespec tsNow;
	clock_gettime(CLOCK_REALTIME, &tsNow);

	va_list ap;

	int sz = 0;

	struct tm tmNow;
	localtime_r(&tsNow.tv_sec, &tmNow);

	const int MAX_LOG_LENGTH = 4 * 1024;
	char strLog[MAX_LOG_LENGTH + 1] = {0x00};

	sz += snprintf(strLog + sz, MAX_LOG_LENGTH - sz, "(%d) ", level);

	sz += snprintf(strLog + sz, MAX_LOG_LENGTH - sz, "%02d%02d%02d-%02d%02d%02d.%06ld ",
			tmNow.tm_year - 100, tmNow.tm_mon + 1, tmNow.tm_mday, tmNow.tm_hour, tmNow.tm_min, tmNow.tm_sec, tsNow.tv_nsec / 1000);

	sz += snprintf(strLog + sz, MAX_LOG_LENGTH - sz, "[%6s] ", tag);
	sz += snprintf(strLog + sz, MAX_LOG_LENGTH - sz, "%s:%d ", func, line_no);

	va_start(ap, fmt);

	sz += vsnprintf(strLog + sz, MAX_LOG_LENGTH - sz, fmt, ap);

	va_end(ap);

	printf("%s\n", strLog);
}

void CLog::PrintLog(const LOG_LEVEL level, const int pid, const char *file, const char *func, const int line_no, const char *tag,  const char *fmt, ...)
{
	if (level < mLogLevel)
	{
		return;
	}

	log_message* log = (log_message *)malloc(sizeof(log_message));

	log->cmd = LOG_WRITE;
	//clock_gettime(CLOCK_MONOTONIC_RAW, &log->monotonic);
	clock_gettime(CLOCK_REALTIME, &log->realtime);
	log->level = level;
	log->pid = pid;

#if 0
	memset(log->tag, 0x00, 16);
	snprintf(log->tag, 15, "%s", tag);

	memset(log->file, 0x00, 256);
	snprintf(log->file, 255, "%s", file);

	memset(log->func, 0x00, 256);
	snprintf(log->func, 255, "%s", func);

	log->line_no = line_no;
#endif

	log->msg_len = 0;
	log->msg = NULL;

	va_list ap;

	int sz = 0;

	struct tm tmNow;
	localtime_r(&log->realtime.tv_sec, &tmNow);

	const int MAX_LOG_LENGTH = 4 * 1024;
	char strLog[MAX_LOG_LENGTH + 1] = {0x00};

	sz += snprintf(strLog + sz, MAX_LOG_LENGTH - sz, "(%d) ", level);

	sz += snprintf(strLog + sz, MAX_LOG_LENGTH - sz, "%02d%02d%02d-%02d%02d%02d.%06ld ",
			tmNow.tm_year - 100, tmNow.tm_mon + 1, tmNow.tm_mday, tmNow.tm_hour, tmNow.tm_min, tmNow.tm_sec, log->realtime.tv_nsec / 1000);

	sz += snprintf(strLog + sz, MAX_LOG_LENGTH - sz, "[%6s] ", tag);
	sz += snprintf(strLog + sz, MAX_LOG_LENGTH - sz, "%s:%d ", func, line_no);

	va_start(ap, fmt);

	sz += vsnprintf(strLog + sz, MAX_LOG_LENGTH - sz, fmt, ap);

	va_end(ap);

	if (sz > 0)
	{
		log->msg_len = sz + 1;
		log->msg = (char *)malloc(sizeof(char) * (sz + 1));
		memcpy(log->msg, strLog, sz + 1);
	}

	//mLogQueue.push_back(log);

	printf("%s\n", strLog);
}

void CLog::DeleteLogFile()
{
	log_message* log = (log_message *)malloc(sizeof(log_message));
	memset(log, 0x00, sizeof(log_message));

	log->cmd = LOG_DELETE;
	clock_gettime(CLOCK_REALTIME, &log->realtime);

	mLogQueue.push_back(log);
}

void CLog::CmdWriteLog(log_message* msg)
{
	if (mFpLogFile == NULL)
	{
		mFpLogFile = fopen(LOG_FILE_SET[0], "a");
		if (mFpLogFile == NULL)
		{
			PrintLogWithoutWrite(LOG_ERROR, 0, __FILE__, __func__, __LINE__, TAG, "mFpLogFile is NULL, Queue: %d", mLogQueue.size());
			return;
		}
	}

	long int fileSize = ftell(mFpLogFile);

	if (fileSize + msg->msg_len > mMaxLogSize)
	{
		fclose(mFpLogFile);

		int rc;
		rc = access(LOG_FILE_SET[1], F_OK);
		if (rc == 0)
		{
			rc = remove(LOG_FILE_SET[1]);
			PrintLogWithoutWrite(LOG_DEBUG, 0, __FILE__, __func__, __LINE__, TAG, "remove() rc: %d", rc);
		}
		rc = rename(LOG_FILE_SET[0], LOG_FILE_SET[1]);
		PrintLogWithoutWrite(LOG_DEBUG, 0, __FILE__, __func__, __LINE__, TAG, "rename() rc: %d", rc);

		mFpLogFile = fopen(LOG_FILE_SET[0], "a");
		if (mFpLogFile == NULL)
		{
			PrintLogWithoutWrite(LOG_ERROR, 0, __FILE__, __func__, __LINE__, TAG, "mFpLogFile is NULL");
			return;
		}
	}

	//fwrite(msg->msg, sizeof(uint8_t), msg->msg_len, mFpLogFile);
	fprintf(mFpLogFile, "%s\n", msg->msg);

	if (mLogQueue.size() == 0)
	{
		//PrintLog(LOG_ERROR, 0, __FILE__, __func__, __LINE__, TAG, "mFpLogFile is closed");
		fclose(mFpLogFile);
		mFpLogFile = NULL;
	}
}

void CLog::CmdDeleteLogFile()
{
	int rc;
	rc = access(LOG_FILE_SET[0], F_OK);
	if (rc == 0)
	{
		rc = remove(LOG_FILE_SET[0]);
		PrintLog(LOG_DEBUG, 0, __FILE__, __func__, __LINE__, TAG, "remove() rc: %d", rc);
	}
	rc = access(LOG_FILE_SET[1], F_OK);
	if (rc == 0)
	{
		rc = remove(LOG_FILE_SET[1]);
		PrintLog(LOG_DEBUG, 0, __FILE__, __func__, __LINE__, TAG, "remove() rc: %d", rc);
	}
}


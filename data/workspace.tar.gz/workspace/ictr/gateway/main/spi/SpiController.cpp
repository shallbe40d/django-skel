#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <linux/spi/spidev.h>

#include "SpiController.h"

CSpiController::CSpiController()
{
	mode = 0;
	bits = 8;
	speed = 5 * 1000 * 1000;	// 5MHz
	delay = 0;;
}

CSpiController::~CSpiController()
{

}

void CSpiController::Open(std::string device)
{
	fd = open(device.c_str(), O_RDWR);
	if (fd < 0)
	{
		//printf("can't open device\n");
	}
}

void CSpiController::Close()
{
	if (fd > 0)
	{
		close(fd);
	}
	fd = -1;
}

int CSpiController::SetConfig(uint8_t mode, uint8_t bits, uint32_t speed)
{
	int ret;

	// SPI Mode
	ret = ioctl(fd, SPI_IOC_WR_MODE, &mode);
	if (ret == -1)
	{
		printf("can't set spi mode");
		return -1;
	}
	this->mode = mode;

	// Bits per Word
	ret = ioctl(fd, SPI_IOC_WR_BITS_PER_WORD, &bits);
	if (ret == -1)
	{
		printf("can't set bits per word");
		return -1;
	}
	this->bits = bits;

	// Max Speed
	ret = ioctl(fd, SPI_IOC_WR_MAX_SPEED_HZ, &speed);
	if (ret == -1)
	{
		printf("can't set max speed hz");
		return -1;
	}
	this->speed = speed;

	return 0;
}

void CSpiController::ReadConfig()
{
	int ret;

	// SPI Mode
	ret = ioctl(fd, SPI_IOC_RD_MODE, &mode);
	if (ret == -1)
	{
		printf("can't get spi mode");
		return;
	}

	// Bits per Word
	ret = ioctl(fd, SPI_IOC_RD_BITS_PER_WORD, &bits);
	if (ret == -1)
	{
		printf("can't get bits per word");
		return;
	}

	// Max Speed
	ret = ioctl(fd, SPI_IOC_RD_MAX_SPEED_HZ, &speed);
	if (ret == -1)
	{
		printf("can't get max speed hz");
		return;
	}
}

int CSpiController::Read(uint8_t* data, uint32_t size)
{
	if (fd == 0)
	{
		return -1;
	}
	
	return read(fd, data, size);
}

void CSpiController::Write(uint8_t* data, uint32_t size)
{
	if (fd == 0)
	{
		return;
	}
	write(fd, data, size);
}

#if 0
void make_bulk_transfer(int len)
{
	uint8_t *buf = malloc(len);
	if (NULL == buf)
		pabort("malloc failed");
	memset(buf, 0xCB, len);
	add_transfer(buf, len);
}

#if 0
static int toggle_cs = 0;
static int block_length = 0;
static int quiet = 0;
#endif

static void add_transfer(char * data, int len)
{
	struct spi_ioc_transfer *xfr;
	char *txbuf = malloc(len);
	char *rxbuf = malloc(len);

	memcpy(txbuf, data, len);
	memset(rxbuf, 0xff, len);
	
	ntransfers += 1;
	spi_xfrs = realloc(spi_xfrs, sizeof(*spi_xfrs) * ntransfers);
	xfr = &spi_xfrs[ntransfers - 1];

	xfr->tx_buf = (unsigned long)txbuf;
	xfr->rx_buf = (unsigned long)rxbuf;
	xfr->len = len;
	xfr->speed_hz = speed;
	xfr->delay_usecs = delay;
	xfr->bits_per_word = bits;
	xfr->cs_change =  toggle_cs;
	xfr->pad = 0;


}

void CSpiController::Transfer(uint8_t* tx, uint8_t* rx, int len)
{
	int ret;
	ret = ioctl(fd, SPI_IOC_MESSAGE(ntransfers), spi_xfrs);
	if (ret < 1)
	{
		printf("can't send spi message");
	}
}

void show_spi_xfrs(void)
{
	int i, j;
	struct spi_ioc_transfer *xfr;

	for (i = 0; i < ntransfers; ++i) {
		xfr = &spi_xfrs[i];
		for (j = 0; j < xfr->len; ++j) {
			printf(" %02X",
			       ((unsigned char *)(intptr_t)xfr->tx_buf)[j]);
		}
		printf("\n");
		for (j = 0; j < xfr->len; ++j) {
			printf(" %02X",
			       ((unsigned char *)(intptr_t)xfr->rx_buf)[j]);
		}
		printf("\n\n");
	}
}
#endif


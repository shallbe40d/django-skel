#ifndef SPI_CONTROLLER_DEFINE_H
#define SPI_CONTROLLER_DEFINE_H

#include <iostream>
#include <stdint.h>

class CSpiController
{
public:
	CSpiController();
	~CSpiController();
	
	void Open(std::string device);
	void Close();
	int SetConfig(uint8_t mode, uint8_t bits, uint32_t speed);
	void ReadConfig();
	int Read(uint8_t* data, uint32_t size);
	void Write(uint8_t* data, uint32_t size);
	void Transfer();

private:
	uint8_t mode;
	uint8_t bits;
	uint32_t speed;
	uint16_t delay;
	
	int fd;
	struct spi_ioc_transfer *spi_xfrs = NULL;
	int ntransfers = 0;
};
#endif

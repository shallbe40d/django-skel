#ifndef _SERIAL_MONITOR
#define _SERIAL_MONITOR

#include "serial.h"
#include "base/CommunicationBase.h"

#include <string>
#include <iostream>
#include <cstdio>
#include <thread>

#include <unistd.h>

using namespace serial;

enum SERIAL_STATE
{
	SERIAL_STATE_STOP,
	SERIAL_STATE_RUN,
	SERIAL_STATE_UNKNOWN
};

enum SERIAL_PRINT_PACKET_TYPE
{
	SERIAL_PRINT_PACKET_NOT_PRINT = 0x00,
	SERIAL_PRINT_PACKET_READ_ONLY = 0x01,
	SERIAL_PRINT_PACKET_WRITE_ONLY = 0x02,
	SERIAL_PRINT_PACKET_BOTH = 0x03,
};

class CSerialController : public CCommunicationBase
{
public:
	CSerialController();
	~CSerialController();

	void EnumeratePorts();
	int InitSerial(const std::string &port, const int baudrate, const int timeout = 100, const uint32_t byte = 2560, const uint32_t flag = SERIAL_PRINT_PACKET_WRITE_ONLY);
	void Run();
	void Stop();

	size_t Write(const char *data, const int size, const char *tag);

protected:
	const char* TAG = "SERIAL";

private:
	Serial* mSerialDevice;
	std::string mPort;
	SERIAL_STATE mState;
	std::thread* mReadThread;
	uint32_t mReadByte;
	uint32_t mIsPrintPacket;

	void ReadThread();
};
#endif

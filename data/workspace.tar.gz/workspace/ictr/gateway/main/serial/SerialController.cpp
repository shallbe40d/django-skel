#include <string>
#include <iostream>
#include <cstdio>
#include <thread>

#include <unistd.h>

#include "SerialController.h"
#include "../util/Util.h"

using std::string;
using std::exception;
using std::cout;
using std::cerr;
using std::endl;
using std::vector;

CSerialController::CSerialController()
{
	mSerialDevice = NULL;
	mState = SERIAL_STATE_UNKNOWN;
}

CSerialController::~CSerialController()
{
	if (mSerialDevice != NULL)
	{
		delete(mSerialDevice);
	}
}

void CSerialController::EnumeratePorts()
{
	vector<serial::PortInfo> devices_found = serial::list_ports();

	vector<serial::PortInfo>::iterator iter = devices_found.begin();

	while( iter != devices_found.end() )
	{
		serial::PortInfo device = *iter++;

		printf( "(%s, %s, %s)\n", device.port.c_str(), device.description.c_str(), device.hardware_id.c_str() );
	}
}

int CSerialController::InitSerial(const std::string &port, const int baudrate, const int timeout, const uint32_t byte, const uint32_t flag)
{
	int rc = 0;

	mReadByte = byte;
	mIsPrintPacket = flag;
	mPort = port;

	if (mSerialDevice == NULL)
	{
		mSerialDevice = new Serial(port, baudrate, serial::Timeout::simpleTimeout(timeout));

		if (mSerialDevice->isOpen())
		{
			LOGD(TAG , "Serial Port [%s] is opened", port.c_str());
			rc = 0;
		}
		else
		{
			LOGD(TAG , "Serial Port [%s] is not opened", port.c_str());
			rc = 1;
		}
	}
	else
	{
		LOGD(TAG , "Serial Port [%s] is already opened", port.c_str());
		rc = 0;
	}
	return rc;
}

void CSerialController::ReadThread()
{
	uint8_t buf[mReadByte];

	while (mState == SERIAL_STATE_RUN)
	{
		memset(buf, 0x00, mReadByte);
#ifndef PSEUDO_SERIAL_DATA 
		size_t read_bytes = mSerialDevice->read(buf, mReadByte);

		if (read_bytes > 0)
		{
			if ((mIsPrintPacket & SERIAL_PRINT_PACKET_READ_ONLY) != 0)
			{
				char info[64];
				snprintf(info, 64, "[RD][%s]", mPort.c_str());
				PrintPacket(TAG, info, (char *)buf, read_bytes);
			}
			NotifyListener(buf, read_bytes);
		}
#else
		for (int i = 0; i < mReadByte; i++)
		{
			buf[i] = (uint8_t)(i % 0xFF);
		}
		NotifyListener(buf, mReadByte);

		sleep(1);
#endif
	}

	cout << "exit read thread for serial" << endl;
}

size_t CSerialController::Write(const char *data, const int size, const char *tag)
{
	size_t bytes_wrote = 0;

	if (mSerialDevice->isOpen())
	{
		if ((mIsPrintPacket & SERIAL_PRINT_PACKET_WRITE_ONLY) != 0)
		{
			char info[64];
			snprintf(info, 64, "[WR][%s]", mPort.c_str());
			PrintPacket(TAG, info, data, size);
		}
		bytes_wrote = mSerialDevice->write((uint8_t *)data, size);
	}
	else
	{
		LOGE(TAG, "Serial is not opened");
	}

	return bytes_wrote;
}

void CSerialController::Run()
{
	mState = SERIAL_STATE_RUN;

	mReadThread = new std::thread( [&]() { ReadThread(); });
}

void CSerialController::Stop()
{
	mState = SERIAL_STATE_STOP;

	mReadThread->join();
}

#include "base/Base.h"
#include "mq/MessageQueue.h"

#include "util/Util.h"
#include "timer/Timer.h"

#include "serial/SerialController.h"
#include "ssl/SocketClientController.h"
#include "ssl/SocketServerController.h"
#include "crypto/CryptoController.h"

#include "mcu/McuManager.h"
#include "adc/AdcManager.h"
#include "diagnostic/DiagnosticManager.h"
#include "ble/BleManager.h"
#include "wifi/WifiManager.h"
#include "comm/ServerCommunicationManager.h"
#include "GatewayManager.h"

#define MANUAL_TEST

#define ENABLE_MCU
#define ENABLE_BLE
#define ENABLE_ADC
#define ENABLE_WIFI
//#define ENABLE_SERVER_COMM
#define ENABLE_DIAGNOSTIC

void InitModuleName();
void InitMessageName();

int main(int argc, char *argv[])
{
	InitModuleName();
	InitMessageName();

	int rc;

#ifdef ENABLE_MCU
	CSerialController ttyTHS1;
	std::string portTHS1 = "/dev/ttyTHS1";
	rc = ttyTHS1.InitSerial(portTHS1, 115200, 100, 1440, SERIAL_PRINT_PACKET_BOTH);
	if (rc == 0)
	{
		ttyTHS1.Run();
	}
	else
	{
		LOGE("MAIN", "%s can't run", portTHS1.c_str());
	}

	//CCryptoController crypto1(&ttyTHS1);

	CMcuManager mcu;
	mcu.Init(&ttyTHS1);
	//mcu.Init(&crypto1);

	//reset MCU
	//MessageQueue::GetInstance()->SendMessage(MODULE_SYSTEM, MODULE_MCU, CMD_REQUEST_SOFTWARE_RESET, NULL , 0 );
	bool isPowerOn;

	isPowerOn = false;
	MessageQueue::GetInstance()->SendMessage(MODULE_SYSTEM, MODULE_MCU, CMD_REQUEST_POWER_CONTROL, &isPowerOn, sizeof(isPowerOn));
	usleep(200 * 1000);

	isPowerOn = true;
	MessageQueue::GetInstance()->SendMessage(MODULE_SYSTEM, MODULE_MCU, CMD_REQUEST_POWER_CONTROL, &isPowerOn, sizeof(isPowerOn));
	usleep(100 * 1000);
#endif

	IO_CONTROL_TYPE io;

#ifdef ENABLE_BLE
	io = IO_BLE_APP;
	MessageQueue::GetInstance()->SendMessage(MODULE_SYSTEM, MODULE_MCU, CMD_REQUEST_SET_IO_STATE, &io, sizeof(IO_CONTROL_TYPE));
	usleep(100 * 1000);

	io = IO_BLE_RESET_HIGH;
	MessageQueue::GetInstance()->SendMessage(MODULE_SYSTEM, MODULE_MCU, CMD_REQUEST_SET_IO_STATE, &io, sizeof(IO_CONTROL_TYPE));
	usleep(100 * 1000);
#endif

#ifdef ENABLE_ADC
	io = IO_ADC_APP;
	MessageQueue::GetInstance()->SendMessage(MODULE_SYSTEM, MODULE_MCU, CMD_REQUEST_SET_IO_STATE, &io, sizeof(IO_CONTROL_TYPE));
	usleep(100 * 1000);

	io = IO_ADC_MEASUREMENT_STOP;
	MessageQueue::GetInstance()->SendMessage(MODULE_SYSTEM, MODULE_MCU, CMD_REQUEST_SET_IO_STATE, &io, sizeof(IO_CONTROL_TYPE));
	usleep(100 * 1000);

	io = IO_ADC_RESET_HIGH;
	MessageQueue::GetInstance()->SendMessage(MODULE_SYSTEM, MODULE_MCU, CMD_REQUEST_SET_IO_STATE, &io, sizeof(IO_CONTROL_TYPE));
	usleep(100 * 1000);
#endif

#ifdef ENABLE_BLE
	// Serial Device
	const int BLE_SERIAL_BAUD_RATE = 115200;
	const int BLE_SERIAL_READ_TIMEOUT = 10;
	const int BLE_SERIAL_READ_DATA_SIZE = 114;

	CSerialController mBleSerialController;
	std::string mBleSerialPort = "/dev/ttyUSB0";

	rc = mBleSerialController.InitSerial(mBleSerialPort, BLE_SERIAL_BAUD_RATE, BLE_SERIAL_READ_TIMEOUT, BLE_SERIAL_READ_DATA_SIZE, SERIAL_PRINT_PACKET_NOT_PRINT);
	if (rc == 0)
	{
		mBleSerialController.Run();
	}
	else
	{
		LOGE("MAIN", "Serial Port Open Error: %s", mBleSerialPort.c_str());
	}

	//CCryptoController bleCrypto(&mBleSerialController);

	CBleManager ble;
	ble.Init(&mBleSerialController);
#endif

#ifdef ENABLE_WIFI
	CSocketServerController iotServer;
	iotServer.Init();

#if 0
	CCryptoController scmCrypto(&iotServer);
	scmCrypto.SetStx(0x02);
	scmCrypto.SetCryptoMode(CRYPTO_AES256_ECB);
	const uint8_t key[32] = {0x01, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02};
	scmCrypto.SetCryptoKey(key, 32);
#endif

	CWifiManager wifi;
	wifi.Init(&iotServer);
#endif

#ifdef ENABLE_ADC
	CAdcManager adc;
	adc.Init();
#endif

#ifdef ENABLE_DIAGNOSTIC
	CDiagnosticManager diag;
	diag.Init();
#endif

#ifdef ENABLE_SERVER_COMM
	const std::string ROUTER_IP_ADDRESS = "127.0.0.1";
	const int ROUTER_PORT = 5693;

	CSocketClientController clientRouter;
	clientRouter.Init(ROUTER_IP_ADDRESS, ROUTER_PORT);
	clientRouter.Start();

	CCryptoController scmCrypto(&clientRouter);
	scmCrypto.SetStx(0x02);
	scmCrypto.SetCryptoMode(CRYPTO_AES256_ECB);
	const uint8_t key[32] = {0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02};
	scmCrypto.SetCryptoKey(key, 32);

	CServerCommunicationManager scm;
	scm.Init(&scmCrypto);

	//MessageQueue::GetInstance()->SendMessage(MODULE_SYSTEM, MODULE_SERVERCOMM, CMD_TEST_MODULE_COMMUNICATION, NULL, 0);
#endif

	CGatewayManager gw;
	gw.Init();

	while (1)
	{
#ifdef MANUAL_TEST
		int ch = getch();
		//LOGD("MAIN", "CH: %02X, %c", ch, ch);
		switch (ch)
		{
		case 'r':
			{
				// 상시 측정
				MessageQueue::GetInstance()->SendMessage(MODULE_SYSTEM, MODULE_GATEWAY, CMD_TEST_MODULE_COMMUNICATION, NULL, CMD_REQUEST_REGULAR_MEASUREMENT);
			}
			break;
		case 'm':
			{
				// 수동 측정
				MessageQueue::GetInstance()->SendMessage(MODULE_SYSTEM, MODULE_GATEWAY, CMD_TEST_MODULE_COMMUNICATION, NULL, CMD_REQUEST_MANUAL_MEASUREMENT);
			}
			break;
		case 'p':
			{
				// 주기 측정
				MessageQueue::GetInstance()->SendMessage(MODULE_SYSTEM, MODULE_GATEWAY, CMD_TEST_MODULE_COMMUNICATION, NULL, CMD_REQUEST_PERIODIC_MEASUREMENT);
			}
			break;
		case 'n':
			{
				// 소음 임계치 측정
				MessageQueue::GetInstance()->SendMessage(MODULE_SYSTEM, MODULE_GATEWAY, CMD_TEST_MODULE_COMMUNICATION, NULL, CMD_REQUEST_NOISE_THRESHOLD_MEASUREMENT);
			}
			break;
		case 'd':
			{
				// 소음 임계치 진단
				MessageQueue::GetInstance()->SendMessage(MODULE_SYSTEM, MODULE_GATEWAY, CMD_TEST_MODULE_COMMUNICATION, NULL, CMD_REQUEST_NOISE_THRESHOLD_DIAGNOSIS);
			}
			break;
		case 'v':
			{
				// 진동 임계치 측정
				MessageQueue::GetInstance()->SendMessage(MODULE_SYSTEM, MODULE_GATEWAY, CMD_TEST_MODULE_COMMUNICATION, NULL, CMD_REQUEST_VIBRATION_THRESHOLD_MEASUREMENT);
			}
			break;
		case 't':
			{
				// 소음 임계치 진단
				MessageQueue::GetInstance()->SendMessage(MODULE_SYSTEM, MODULE_GATEWAY, CMD_TEST_MODULE_COMMUNICATION, NULL, CMD_REQUEST_VIBRATION_THRESHOLD_DIAGNOSIS);
			}
			break;
		case 'f':
			{
				// 결함주파수
				MessageQueue::GetInstance()->SendMessage(MODULE_SYSTEM, MODULE_GATEWAY, CMD_TEST_MODULE_COMMUNICATION, NULL, CMD_SET_EQUIPMENT_INFORMATION);
			}
			break;
		case 'i':
			{
				// IoT 센서 정보
				MessageQueue::GetInstance()->SendMessage(MODULE_SYSTEM, MODULE_GATEWAY, CMD_TEST_MODULE_COMMUNICATION, NULL, CMD_GET_IOT_SENSOR_INFO);
			}
			break;
		case 's':
			{
				// IoT 센서 초기화
				MessageQueue::GetInstance()->SendMessage(MODULE_SYSTEM, MODULE_GATEWAY, CMD_TEST_MODULE_COMMUNICATION, NULL, CMD_REQUEST_FACTORY_RESET_IOT_SENSOR);
			}
			break;
		case 'o':
			{
				// IoT 센서 데이터 다운로드
				MessageQueue::GetInstance()->SendMessage(MODULE_SYSTEM, MODULE_GATEWAY, CMD_TEST_MODULE_COMMUNICATION, NULL, CMD_REQUEST_DOWNLOAD_DATA_SINGLE_DEVICE);
			}
			break;
		default:
			{
			}
			break;
		}
#else
		sleep(5);
#endif
	}

	return 0;
}

void InitModuleName()
{
	MessageQueue::GetInstance()->AddModuleName(MODULE_SYSTEM, "SYSTEM");
	MessageQueue::GetInstance()->AddModuleName(MODULE_MAIN, "MAIN");
	MessageQueue::GetInstance()->AddModuleName(MODULE_MCU, "MCU");
	MessageQueue::GetInstance()->AddModuleName(MODULE_BLE, "BLE");
	MessageQueue::GetInstance()->AddModuleName(MODULE_ADC, "ADC");
	MessageQueue::GetInstance()->AddModuleName(MODULE_WIFI, "WIFI");
	MessageQueue::GetInstance()->AddModuleName(MODULE_DIAGNOSTIC, "DIAGNOSTIC");
	MessageQueue::GetInstance()->AddModuleName(MODULE_SERVERCOMM, "SERVERCOMM");
	//MessageQueue::GetInstance()->AddModuleName(MODULE_SUBGWCOMM, "SUBGWCOMM");
	MessageQueue::GetInstance()->AddModuleName(MODULE_GATEWAY, "GATEWAY");
}

void InitMessageName()
{
	MessageQueue::GetInstance()->AddCommandName(CMD_TEST_MODULE_COMMUNICATION, "CMD_TEST_MODULE_COMMUNICATION");

	// Gateway
	MessageQueue::GetInstance()->AddCommandName(CMD_REQUEST_REGISTER_IOT_SENSOR, "CMD_REQUEST_REGISTER_IOT_SENSOR");
	MessageQueue::GetInstance()->AddCommandName(CMD_REQUEST_IOT_SENSOR_MEASUREMENT, "CMD_REQUEST_IOT_SENSOR_MEASUREMENT");
	MessageQueue::GetInstance()->AddCommandName(CMD_REQUEST_DOWNLOAD_DATA_SINGLE_DEVICE, "CMD_REQUEST_DOWNLOAD_DATA_SINGLE_DEVICE");

	// MCU
	MessageQueue::GetInstance()->AddCommandName(CMD_REQUEST_SOFTWARE_RESET, "CMD_REQUEST_SOFTWARE_RESET");
	MessageQueue::GetInstance()->AddCommandName(CMD_REQUEST_SET_IO_STATE, "CMD_REQUEST_SET_IO_STATE");
	MessageQueue::GetInstance()->AddCommandName(CMD_REQUEST_POWER_CONTROL, "CMD_REQUEST_POWER_CONTROL");

	// ADC
	MessageQueue::GetInstance()->AddCommandName(CMD_REQUEST_REGULAR_MEASUREMENT, "CMD_REQUEST_REGULAR_MEASUREMENT");
	MessageQueue::GetInstance()->AddCommandName(CMD_REQUEST_REGULAR_MEASUREMENT_RESPONSE, "CMD_REQUEST_REGULAR_MEASUREMENT_RESPONSE");
	MessageQueue::GetInstance()->AddCommandName(CMD_REQUEST_STOP_MEASUREMENT, "CMD_REQUEST_STOP_MEASUREMENT");

	// BLE
	MessageQueue::GetInstance()->AddCommandName(CMD_REQUEST_CONNECT_DEVICE, "CMD_REQUEST_CONNECT_DEVICE");
	MessageQueue::GetInstance()->AddCommandName(CMD_REQUEST_CONNECT_DEVICE_RESPONSE, "CMD_REQUEST_CONNECT_DEVICE_RESPONSE");
	MessageQueue::GetInstance()->AddCommandName(CMD_REQUEST_DISCONNECT_DEVICE, "CMD_REQUEST_DISCONNECT_DEVICE");
	MessageQueue::GetInstance()->AddCommandName(CMD_REQUEST_DISCONNECT_DEVICE_RESPONSE, "CMD_REQUEST_DISCONNECT_DEVICE_RESPONSE");

	MessageQueue::GetInstance()->AddCommandName(CMD_SET_MEASUREMENT_CONFIG, "CMD_SET_MEASUREMENT_CONFIG");
	MessageQueue::GetInstance()->AddCommandName(CMD_SET_MEASUREMENT_CONFIG_RESPONSE, "CMD_SET_MEASUREMENT_CONFIG_RESPONSE");
	MessageQueue::GetInstance()->AddCommandName(CMD_REQUEST_TIME_SYNC, "CMD_REQUEST_TIME_SYNC");
	MessageQueue::GetInstance()->AddCommandName(CMD_REQUEST_TIME_SYNC_RESPONSE, "CMD_REQUEST_TIME_SYNC_RESPONSE");

	MessageQueue::GetInstance()->AddCommandName(CMD_GET_DEVICE_INFO, "CMD_GET_DEVICE_INFO");
	MessageQueue::GetInstance()->AddCommandName(CMD_GET_DEVICE_INFO_RESPONSE, "CMD_GET_DEVICE_INFO_RESPONSE");
	MessageQueue::GetInstance()->AddCommandName(CMD_GET_DEVICE_NAME, "CMD_GET_DEVICE_NAME");
	MessageQueue::GetInstance()->AddCommandName(CMD_GET_DEVICE_NAME_RESPONSE, "CMD_GET_DEVICE_NAME_RESPONSE");
	MessageQueue::GetInstance()->AddCommandName(CMD_GET_FILE_LIST, "CMD_GET_FILE_LIST");
	MessageQueue::GetInstance()->AddCommandName(CMD_GET_FILE_LIST_RESPONSE, "CMD_GET_FILE_LIST_RESPONSE");
	MessageQueue::GetInstance()->AddCommandName(CMD_OPEN_WIFI, "CMD_OPEN_WIFI");
	MessageQueue::GetInstance()->AddCommandName(CMD_OPEN_WIFI_RESPONSE, "CMD_OPEN_WIFI_RESPONSE");
	MessageQueue::GetInstance()->AddCommandName(CMD_DOWNLOAD_FILE, "CMD_DOWNLOAD_FILE");
	MessageQueue::GetInstance()->AddCommandName(CMD_DOWNLOAD_FILE_RESPONSE, "CMD_DOWNLOAD_FILE_RESPONSE");

	MessageQueue::GetInstance()->AddCommandName(CMD_RESET_SENSOR_INFO, "CMD_RESET_SENSOR_INFO");
	MessageQueue::GetInstance()->AddCommandName(CMD_RESET_SENSOR_INFO_RESPONSE, "CMD_RESET_SENSOR_INFO_RESPONSE");

	// WiFi
	MessageQueue::GetInstance()->AddCommandName(CMD_START_AP, "CMD_START_AP");
	MessageQueue::GetInstance()->AddCommandName(CMD_START_AP_RESPONSE, "CMD_START_AP_RESPONSE");
	MessageQueue::GetInstance()->AddCommandName(CMD_STOP_AP, "CMD_STOP_AP");
	MessageQueue::GetInstance()->AddCommandName(CMD_STOP_AP_RESPONSE, "CMD_STOP_AP_RESPONSE");
	MessageQueue::GetInstance()->AddCommandName(CMD_OPEN_SOCKET, "CMD_OPEN_SOCKET");
	MessageQueue::GetInstance()->AddCommandName(CMD_OPEN_SOCKET_RESPONSE, "CMD_OPEN_SOCKET_RESPONSE");
	MessageQueue::GetInstance()->AddCommandName(CMD_CLOSE_SOCKET, "CMD_CLOSE_SOCKET");
	MessageQueue::GetInstance()->AddCommandName(CMD_CLOSE_SOCKET_RESPONSE, "CMD_CLOSE_SOCKET_RESPONSE");

	// For Diagnostic Manager
	MessageQueue::GetInstance()->AddCommandName(CMD_DIAGNOSE_NOISE_ANOMALY, "CMD_DIAGNOSE_NOISE_ANOMALY");
	MessageQueue::GetInstance()->AddCommandName(CMD_DIAGNOSE_NOISE_ANOMALY_RESPONSE, "CMD_DIAGNOSE_NOISE_ANOMALY_RESPONSE");
	MessageQueue::GetInstance()->AddCommandName(CMD_DIAGNOSE_VIBRATION_RATING, "CMD_DIAGNOSE_VIBRATION_RATING");
	MessageQueue::GetInstance()->AddCommandName(CMD_DIAGNOSE_VIBRATION_RATING_RESPONSE, "CMD_DIAGNOSE_VIBRATION_RATING_RESPONSE");
	MessageQueue::GetInstance()->AddCommandName(CMD_DIAGNOSE_VIBRATION_DIAGNOSIS, "CMD_DIAGNOSE_VIBRATION_DIAGNOSIS");
	MessageQueue::GetInstance()->AddCommandName(CMD_DIAGNOSE_VIBRATION_DIAGNOSIS_RESPONSE, "CMD_DIAGNOSE_VIBRATION_DIAGNOSIS_RESPONSE");
	MessageQueue::GetInstance()->AddCommandName(CMD_DIAGNOSE_VBELT_ELONGATION, "CMD_DIAGNOSE_VBELT_ELONGATION");
	MessageQueue::GetInstance()->AddCommandName(CMD_DIAGNOSE_VBELT_ELONGATION_RESPONSE, "CMD_DIAGNOSE_VBELT_ELONGATION_RESPONSE");
	MessageQueue::GetInstance()->AddCommandName(CMD_DIAGNOSE_NOISE_THRESHOLD, "CMD_DIAGNOSE_NOISE_THRESHOLD");
	MessageQueue::GetInstance()->AddCommandName(CMD_DIAGNOSE_NOISE_THRESHOLD_RESPONSE, "CMD_DIAGNOSE_NOISE_THRESHOLD_RESPONSE");
	MessageQueue::GetInstance()->AddCommandName(CMD_DIAGNOSE_VIBRATION_THRESHOLD, "CMD_DIAGNOSE_VIBRATION_THRESHOLD");
	MessageQueue::GetInstance()->AddCommandName(CMD_DIAGNOSE_VIBRATION_THRESHOLD_RESPONSE, "CMD_DIAGNOSE_VIBRATION_THRESHOLD_RESPONSE");
	MessageQueue::GetInstance()->AddCommandName(CMD_DIAGNOSE_FAULT_FREQUENCY, "CMD_DIAGNOSE_FAULT_FREQUENCY");
	MessageQueue::GetInstance()->AddCommandName(CMD_DIAGNOSE_FAULT_FREQUENCY_RESPONSE, "CMD_DIAGNOSE_FAULT_FREQUENCY_RESPONSE");

	// Gateway - Server
	MessageQueue::GetInstance()->AddCommandName(CMD_REQUEST_REGISTER_GATEWAY, "CMD_REQUEST_REGISTER_GATEWAY");
	MessageQueue::GetInstance()->AddCommandName(CMD_REQUEST_REGISTER_GATEWAY_RESPONSE, "CMD_REQUEST_REGISTER_GATEWAY_RESPONSE");
	MessageQueue::GetInstance()->AddCommandName(CMD_SET_OPERATING_INFO, "CMD_SET_OPERATING_INFO");
	MessageQueue::GetInstance()->AddCommandName(CMD_SET_OPERATING_INFO_RESPONSE, "CMD_SET_OPERATING_INFO_RESPONSE");
	MessageQueue::GetInstance()->AddCommandName(CMD_GET_OPERATING_INFO, "CMD_GET_OPERATING_INFO");
	MessageQueue::GetInstance()->AddCommandName(CMD_GET_OPERATING_INFO_RESPONSE, "CMD_GET_OPERATING_INFO_RESPONSE");
	MessageQueue::GetInstance()->AddCommandName(CMD_SET_MEASUREMENT_INFO, "CMD_SET_MEASUREMENT_INFO");
	MessageQueue::GetInstance()->AddCommandName(CMD_SET_MEASUREMENT_INFO_RESPONSE, "CMD_SET_MEASUREMENT_INFO_RESPONSE");
	MessageQueue::GetInstance()->AddCommandName(CMD_GET_MEASUREMENT_INFO, "CMD_GET_MEASUREMENT_INFO");
	MessageQueue::GetInstance()->AddCommandName(CMD_GET_MEASUREMENT_INFO_RESPONSE, "CMD_GET_MEASUREMENT_INFO_RESPONSE");
	MessageQueue::GetInstance()->AddCommandName(CMD_SET_IOT_SENSOR_LIST_INFO, "CMD_SET_IOT_SENSOR_LIST_INFO");
	MessageQueue::GetInstance()->AddCommandName(CMD_SET_IOT_SENSOR_LIST_INFO_RESPONSE, "CMD_SET_IOT_SENSOR_LIST_INFO_RESPONSE");
	MessageQueue::GetInstance()->AddCommandName(CMD_GET_IOT_SENSOR_LIST_INFO, "CMD_GET_IOT_SENSOR_LIST_INFO");
	MessageQueue::GetInstance()->AddCommandName(CMD_GET_IOT_SENSOR_LIST_INFO_RESPONSE, "CMD_GET_IOT_SENSOR_LIST_INFO_RESPONSE");
	MessageQueue::GetInstance()->AddCommandName(CMD_GET_IOT_SENSOR_INFO, "CMD_GET_IOT_SENSOR_INFO");
	MessageQueue::GetInstance()->AddCommandName(CMD_GET_IOT_SENSOR_INFO_RESPONSE, "CMD_GET_IOT_SENSOR_INFO_RESPONSE");

	MessageQueue::GetInstance()->AddCommandName(CMD_REQUEST_NOISE_THRESHOLD_MEASUREMENT, "CMD_REQUEST_NOISE_THRESHOLD_MEASUREMENT");
	MessageQueue::GetInstance()->AddCommandName(CMD_REQUEST_NOISE_THRESHOLD_MEASUREMENT_RESPONSE, "CMD_REQUEST_NOISE_THRESHOLD_MEASUREMENT_RESPONSE");
	MessageQueue::GetInstance()->AddCommandName(CMD_REQUEST_NOISE_THRESHOLD_DIAGNOSIS, "CMD_REQUEST_NOISE_THRESHOLD_DIAGNOSIS");
	MessageQueue::GetInstance()->AddCommandName(CMD_REQUEST_NOISE_THRESHOLD_DIAGNOSIS_RESPONSE, "CMD_REQUEST_NOISE_THRESHOLD_DIAGNOSIS_RESPONSE");
	MessageQueue::GetInstance()->AddCommandName(CMD_SET_NOISE_THRESHOLD, "CMD_SET_NOISE_THRESHOLD");
	MessageQueue::GetInstance()->AddCommandName(CMD_SET_NOISE_THRESHOLD_RESPONSE, "CMD_SET_NOISE_THRESHOLD_RESPONSE");

	MessageQueue::GetInstance()->AddCommandName(CMD_REQUEST_VIBRATION_THRESHOLD_MEASUREMENT, "CMD_REQUEST_VIBRATION_THRESHOLD_MEASUREMENT");
	MessageQueue::GetInstance()->AddCommandName(CMD_REQUEST_VIBRATION_THRESHOLD_MEASUREMENT_RESPONSE, "CMD_REQUEST_VIBRATION_THRESHOLD_MEASUREMENT_RESPONSE");
	MessageQueue::GetInstance()->AddCommandName(CMD_REQUEST_VIBRATION_THRESHOLD_DIAGNOSIS, "CMD_REQUEST_VIBRATION_THRESHOLD_DIAGNOSIS");
	MessageQueue::GetInstance()->AddCommandName(CMD_REQUEST_VIBRATION_THRESHOLD_DIAGNOSIS_RESPONSE, "CMD_REQUEST_VIBRATION_THRESHOLD_DIAGNOSIS_RESPONSE");
	MessageQueue::GetInstance()->AddCommandName(CMD_SET_VIBRATION_THRESHOLD, "CMD_SET_VIBRATION_THRESHOLD");
	MessageQueue::GetInstance()->AddCommandName(CMD_SET_VIBRATION_THRESHOLD_RESPONSE, "CMD_SET_VIBRATION_THRESHOLD_RESPONSE");

	MessageQueue::GetInstance()->AddCommandName(CMD_TIMER_EXPIRED, "CMD_TIMER_EXPIRED");
	MessageQueue::GetInstance()->AddCommandName(CMD_PROCESS_TERMINATE, "CMD_PROCESS_TERMINATE");
}

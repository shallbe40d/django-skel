#ifndef _UTIL_H
#define _UTIL_H

#include <stdint.h>
#include <unistd.h>
#include <bitset>
#include <string>

#include "../log/Log.h"
#include "../mq/MessageQueue.h"

extern int debugLevel;

bool IsFileExt(const char* file, const char* ext);
void ChangeFileExt(char *file, const char *ext);

uint16_t ConvertEndian2(const uint16_t data);
uint32_t ConvertEndian4(const uint32_t data);
float ConvertEndianFloat(const float data);

unsigned char ConvertIntToBcd(int n);
int ConvertBcdToInt(unsigned char bcd);

void ConvertStrMacToCharMac(const char *str, uint8_t *mac, const int size);
void ConvertCharMacToStrMac(const uint8_t *mac, int size, char *str, int len);

void ConvertStrBinToInt(const char *str, int *num);
void ConvertIntToStrBin(const int num, char *str, int size);

void ConvertHexToHexStr(const uint8_t *hexData, char *strData, int size);

void GetMacAddressWireless(const char *interface, unsigned char *mac);

// ********************************************
// Status Check
// ********************************************
float GetCpuLoad(char *str, int len);
float GetMemoryUsage(char *str, int len);
float GetDiskUsage(char *str, int len);
float GetCpuTemperature(char *str, int len);

int GetConfigString(const char* strFind, char* strReturn, const char* strFileName);

//std::string GetErrorMessageString(ERROR_MESSAGE_TYPE error);

void GetSha256Hash(const char *string, const int len, char outputBuffer[65]);

// refer to https://www.3dbrew.org/wiki/CRC-8-CCITT
uint8_t crc8ccitt(const void * data, size_t size);

uint8_t checksum(const uint8_t *packet, const uint16_t length);

int Min(int a, int b);
int Max(int a, int b);

void PrintPacket(const char *tag, const char *info, const char *data, const int size);

void CreateDirectory(const char *dir);

int getch(void);

void ConvertRawFileToNumFile(const char *raw, const char *num, const int column);
#endif

#include <map>

#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include <time.h>
#include <signal.h>
#include <pthread.h>

#include <sys/time.h>
#include <stdarg.h>

// for wireless mac
#include <fcntl.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <linux/wireless.h>

// for disk info
#include <sys/statvfs.h>

// for memory info
#include "sys/sysinfo.h"

// for SHA256 hash
//#include "openssl/sha.h"

// for getch
#include <termio.h>

#include "Util.h"

#define TAG "SYSTEM"

bool IsFileExt(const char* file, const char* ext)
{
	int len = strlen(file);
	bool ret = false;
	for (int pos = len - 1; pos >= 0; pos--)
	{
		if (file[pos] == '.')
		{
			if (strcmp(file + pos + 1, ext) == 0)
			{
				ret = true;
			}
			break;
		}
	}
	return ret;
}

void ChangeFileExt(char *file, const char *ext)
{
	char *pos = file + strlen(file);
	while(pos != file)
	{
		if (*pos == '.')
		{
			memcpy(pos + 1, ext, strlen(ext));
			break;
		}
		pos--;
	}
}

uint16_t ConvertEndian2(const uint16_t data)
{
	return ((data & 0xFF00) >> 8) | ((data & 0x00FF) << 8);
}

uint32_t ConvertEndian4(const uint32_t data)
{
	return (((data & 0xFF000000) >> 24) | ((data & 0x00FF0000) >> 8) | ((data & 0x0000FF00) << 8) | ((data & 0x000000FF) << 24));
}

float ConvertEndianFloat(const float data)
{
	float ret;
	char *pData = (char *)&data;
	char *pRet = (char*)&ret;

	pRet[0] = pData[3];
	pRet[1] = pData[2];
	pRet[2] = pData[1];
	pRet[3] = pData[0];

	return ret;
}

unsigned char ConvertIntToBcd(int n)
{
	return (n / 10) << 4 | (n % 10);
}

int ConvertBcdToInt(unsigned char bcd)
{
	return ((bcd & 0xF0) >> 4) * 10 + (bcd & 0x0F);
}

int ConvertCharToInt(char ch)
{
	if (ch >= '0' && ch <= '9')
	{
		return ch - '0';
	}
	else if (ch >= 'a' && ch <= 'f')
	{
		return ch - 'a' + 10;
	}
	else if (ch >= 'A' && ch <= 'F')
	{
		return ch - 'A' + 10;
	}
	return -1;
}

void ConvertStrMacToCharMac(const char *str, uint8_t *mac, const int size)
{
	for (int i =0; i < size; i++)
	{
		mac[i] = ConvertCharToInt(str[2*i + 0]) * 16 + ConvertCharToInt(str[2*i + 1]);
	}
}

void ConvertCharMacToStrMac(const uint8_t *mac, int size, char *str, int len)
{
	switch(size)
	{
	case 6:
		{
			snprintf(str, len, "%02X%02X%02X%02X%02X%02X", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
		}
		break;
	case 8:
		{
			snprintf(str, len, "%02X%02X%02X%02X%02X%02X%02X%02X", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5], mac[6], mac[7]);
		}
		break;
	default:
		{
			LOGE(TAG, "Not supported MAC size: %d", size);
		}
	}
}

void ConvertStrBinToInt(const char *str, int *num)
{
	unsigned int decimal = std::bitset<16>(str).to_ulong();
	*num = (int)decimal;
}

void ConvertIntToStrBin(const int num, char *str, int size)
{
	std::string binary = std::bitset<16>(num).to_string();
	snprintf(str, size, "%s", binary.c_str());
}

void ConvertHexToHexStr(const uint8_t *hexData, char *strData, int size)
{
	for(int i = 0 ;i < size; i++)
	{
		sprintf((strData+(i*2)), "%02X", *(hexData+i));
	}
}

void GetMacAddressWireless(const char *interface, unsigned char *mac)
{
	int sockfd;
	int rc;

	char * id;
	id = new char[IW_ESSID_MAX_SIZE+1];

	struct iwreq wreq;
	memset(&wreq, 0, sizeof(struct iwreq));
	wreq.u.essid.length = IW_ESSID_MAX_SIZE+1;

	sprintf(wreq.ifr_name, "%s", interface);

	sockfd = socket(AF_INET, SOCK_DGRAM, 0);
	if (sockfd == -1)
	{
		LOGE(TAG, "Cannot open socket, errno: %d", errno);
		LOGE(TAG, "Error description: %s",strerror(errno));
		return;
	}

	wreq.u.essid.pointer = id;
	rc = ioctl(sockfd, SIOCGIWESSID, &wreq);
	if (rc != 0)
	{
		LOGE(TAG, "Get ESSID ioctl failed, errno: %d", errno);
		LOGE(TAG, "Error description: %s",strerror(errno));
		return;
	}
	LOGD(TAG, "ESSID: %s", (char *)wreq.u.essid.pointer);

	rc = ioctl(sockfd, SIOCGIFHWADDR, &wreq);
	if (rc != 0)
	{
		LOGE(TAG, "Get ESSID ioctl failed, errno: %d", errno);
		LOGE(TAG, "Error description: %s",strerror(errno));
		return;
	}

	memcpy(mac, wreq.u.addr.sa_data, 6);
	LOGD(TAG, "MAC: %02X:%02X:%02X:%02X:%02X:%02X", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);

	delete(id);
}

// ********************************************
// Status Check
// ********************************************
float GetCpuLoad(char *str, int len)
{
	FILE *fp = popen("cat /proc/loadavg", "r");

	char buf[1024];
	float load1 = -1.0, load5, load15;

	if (fp != NULL)
	{
		fgets(buf, 1024, fp);

		sscanf(buf, "%f %f %f", &load1, &load5, &load15);
		snprintf(str, len, "1m: %.2f, 5m: %.2f, 15m: %.2f", load1, load5, load15);
		//LOGD(TAG, "[CPU] %s", str);

		fclose(fp);
	}
	else
	{
		snprintf(str, len, "error");
	}

	return load1;
}

float GetMemoryUsage(char *str, int len)
{
	FILE *fp = popen("free -m", "r");

	char buf[1024];
	int mem_total, mem_used, mem_free, swap_total, swap_used, swap_free;
	float usage = -1.0;

	if (fp != NULL)
	{
		fgets(buf, 1024, fp);

		fgets(buf, 1024, fp);
		sscanf(buf + 6, "%d%d%d", &mem_total, &mem_used, &mem_free);

		fgets(buf, 1024, fp);
		sscanf(buf + 6, "%d%d%d", &swap_total, &swap_used, &swap_free);

		usage = (float)mem_used/mem_total;

		snprintf(str, len, "Mem: %dM/%dM (%.3f), Swap: %dM/%dM (%.3f)", mem_used, mem_total, usage, swap_used, swap_total, (float)swap_used/swap_total);
		//LOGD(TAG, "[MEM] %s", str);

		fclose(fp);
	}
	else
	{
		snprintf(str, len, "error");
	}

	return usage;
}

float GetDiskUsage(char *str, int len)
{
	struct statvfs buf;

	float usage = -1.0;

	if (statvfs(".", &buf) == -1)
	{
		LOGE(TAG, "statvfs() error");
		snprintf(str, len, "error");
	}
	else
	{
		const double SIZE_1G = (double)(1024 * 1024 * 1024);
		const double SIZE_1M = (double)(1024 * 1024);

		char unit_avail, unit_total;
		double size_avail, size_total;
		double value_avail, value_total;

		size_avail = (double)buf.f_bavail * buf.f_frsize;
		size_total = (double)buf.f_blocks * buf.f_frsize;

		if (size_avail > SIZE_1G)
		{
			value_avail = size_avail / SIZE_1G;
			unit_avail = 'G';
		}
		else
		{
			value_avail = size_avail / SIZE_1M;
			unit_avail = 'M';
		}

		if (size_total > SIZE_1G)
		{
			value_total = size_total / SIZE_1G;
			unit_total = 'G';
		}
		else
		{
			value_total = size_total / SIZE_1M;
			unit_total = 'M';
		}
		snprintf(str, len, "%.3f%c/%.3f%c", value_avail, unit_avail, value_total, unit_total);
		usage = (float)(size_avail / size_total);
		//LOGD(TAG, "[DISK] %s", str);
	}

	return usage;
}

float GetCpuTemperature(char *str, int len)
{
	FILE *fp = popen("cat /sys/class/thermal/thermal_zone1/temp", "r");

	char buf[1024];
	int temp;
	float temperature = -1.0;

	if (fp != NULL)
	{
		fgets(buf, 1024, fp);
		temp = atoi(buf);

		temperature = (float)temp / 1000;

		snprintf(str, len, "%d", temp);
		//LOGD(TAG, "[TEMP] %s", str);

		fclose(fp);
	}
	else
	{
		snprintf(str, len, "error");
	}

	return temperature;
}

int GetConfigString(const char* strFind, char* strReturn, const char* strFileName)
{
	FILE *fpIniFile;

	char strBuf[1024];
	char *strKey, *strValue, *strNext;
	int nResult = -1;

	fpIniFile = fopen(strFileName, "r");
	if (fpIniFile == NULL)
	{
		LOGD(TAG, "INI File Open Error\n");
		return -2;
	}

	while (!feof(fpIniFile))
	{
		fgets(strBuf, sizeof(strBuf), fpIniFile);
		strKey = strtok_r(strBuf, "=", &strNext);

		if (strcmp(strFind, strKey) == 0)
		{
			strValue = strBuf + strlen(strKey) + 1;
			strValue = strtok_r(NULL, "\r\n", &strNext);
			if (strValue != NULL)
			{
				strcpy(strReturn, strValue);
				nResult = 0;
			}
			break;
		}
	}

	fclose(fpIniFile);

	return nResult;
}

#if 0
std::string GetErrorMessageString(ERROR_MESSAGE_TYPE error)
{
	std::map<ERROR_MESSAGE_TYPE, std::string> errorMessageMap;

	errorMessageMap.insert(std::make_pair(ERROR_TIMEOUT_MODULE_CONTROL, "Error occurred in operation"));
	errorMessageMap.insert(std::make_pair(ERROR_MQTT_MESSAGE_PARSING, "MQTT message parsing error"));
	errorMessageMap.insert(std::make_pair(ERROR_MQTT_MESSAGE_FORMAT, "MQTT message parsing error"));
	errorMessageMap.insert(std::make_pair(ERROR_MQTT_MESSAGE_EXCEED_PAIRING_LIST, "MQTT message parsing error"));
	errorMessageMap.insert(std::make_pair(ERROR_FILE_NOT_EXIST, "MQTT message parsing error"));
	errorMessageMap.insert(std::make_pair(ERROR_SENSOR_NOTIFY_RESULT_AS_ERROR, "Sensor RF packet parsing error"));

#if 0
	errorMessageMap.insert(std::make_pair(ERROR_NOT_SUPPORT_COMMAND, "Not Supported Command"));
	errorMessageMap.insert(std::make_pair(ERROR_FILE_OPEN, "File Open Error"));
	errorMessageMap.insert(std::make_pair(ERROR_MQTT_MESSAGE_TOPIC, "MQTT Message Topic Error"));
#endif

	std::map<ERROR_MESSAGE_TYPE, std::string>::iterator it;
	it = errorMessageMap.find(error);

	if (it != errorMessageMap.end())
	{
		return it->second;
	}
	else
	{
		return "";
	}
}
#endif

void GetSha256Hash(const char *string, const int len, char outputBuffer[65])
{
#if 0
	unsigned char hash[SHA256_DIGEST_LENGTH];

	SHA256_CTX sha256;
	SHA256_Init(&sha256);
	SHA256_Update(&sha256, string, len);
	SHA256_Final(hash, &sha256);
	int i = 0;

	for(i = 0; i < SHA256_DIGEST_LENGTH; i++)
	{
		sprintf(outputBuffer + (i * 2), "%02x", hash[i]);
	}
	outputBuffer[64] = 0;
#endif
}

// refer to https://www.3dbrew.org/wiki/CRC-8-CCITT
static const uint8_t CRC_TABLE[256] = {
	0x00, 0x07, 0x0E, 0x09, 0x1C, 0x1B, 0x12, 0x15, 0x38, 0x3F, 0x36, 0x31, 0x24, 0x23, 0x2A, 0x2D,
	0x70, 0x77, 0x7E, 0x79, 0x6C, 0x6B, 0x62, 0x65, 0x48, 0x4F, 0x46, 0x41, 0x54, 0x53, 0x5A, 0x5D,
	0xE0, 0xE7, 0xEE, 0xE9, 0xFC, 0xFB, 0xF2, 0xF5, 0xD8, 0xDF, 0xD6, 0xD1, 0xC4, 0xC3, 0xCA, 0xCD,
	0x90, 0x97, 0x9E, 0x99, 0x8C, 0x8B, 0x82, 0x85, 0xA8, 0xAF, 0xA6, 0xA1, 0xB4, 0xB3, 0xBA, 0xBD,
	0xC7, 0xC0, 0xC9, 0xCE, 0xDB, 0xDC, 0xD5, 0xD2, 0xFF, 0xF8, 0xF1, 0xF6, 0xE3, 0xE4, 0xED, 0xEA,
	0xB7, 0xB0, 0xB9, 0xBE, 0xAB, 0xAC, 0xA5, 0xA2, 0x8F, 0x88, 0x81, 0x86, 0x93, 0x94, 0x9D, 0x9A,
	0x27, 0x20, 0x29, 0x2E, 0x3B, 0x3C, 0x35, 0x32, 0x1F, 0x18, 0x11, 0x16, 0x03, 0x04, 0x0D, 0x0A,
	0x57, 0x50, 0x59, 0x5E, 0x4B, 0x4C, 0x45, 0x42, 0x6F, 0x68, 0x61, 0x66, 0x73, 0x74, 0x7D, 0x7A,
	0x89, 0x8E, 0x87, 0x80, 0x95, 0x92, 0x9B, 0x9C, 0xB1, 0xB6, 0xBF, 0xB8, 0xAD, 0xAA, 0xA3, 0xA4,
	0xF9, 0xFE, 0xF7, 0xF0, 0xE5, 0xE2, 0xEB, 0xEC, 0xC1, 0xC6, 0xCF, 0xC8, 0xDD, 0xDA, 0xD3, 0xD4,
	0x69, 0x6E, 0x67, 0x60, 0x75, 0x72, 0x7B, 0x7C, 0x51, 0x56, 0x5F, 0x58, 0x4D, 0x4A, 0x43, 0x44,
	0x19, 0x1E, 0x17, 0x10, 0x05, 0x02, 0x0B, 0x0C, 0x21, 0x26, 0x2F, 0x28, 0x3D, 0x3A, 0x33, 0x34,
	0x4E, 0x49, 0x40, 0x47, 0x52, 0x55, 0x5C, 0x5B, 0x76, 0x71, 0x78, 0x7F, 0x6A, 0x6D, 0x64, 0x63,
	0x3E, 0x39, 0x30, 0x37, 0x22, 0x25, 0x2C, 0x2B, 0x06, 0x01, 0x08, 0x0F, 0x1A, 0x1D, 0x14, 0x13,
	0xAE, 0xA9, 0xA0, 0xA7, 0xB2, 0xB5, 0xBC, 0xBB, 0x96, 0x91, 0x98, 0x9F, 0x8A, 0x8D, 0x84, 0x83,
	0xDE, 0xD9, 0xD0, 0xD7, 0xC2, 0xC5, 0xCC, 0xCB, 0xE6, 0xE1, 0xE8, 0xEF, 0xFA, 0xFD, 0xF4, 0xF3
};

uint8_t crc8ccitt(const void * data, size_t size)
{
	uint8_t val = 0;

	uint8_t * pos = (uint8_t *) data;
	uint8_t * end = pos + size;

	while (pos < end) {
		val = CRC_TABLE[val ^ *pos];
		pos++;
	}

	return val;
}

int Min(int a, int b)
{
	return (a < b) ? a : b;
}

int Max(int a, int b)
{
	return (a < b) ? b : a;
}

void CreateDirectory(const char *dir)
{
	struct stat st = {0};

	if (stat(dir, &st) == -1)
	{
		mkdir(dir, 0700);
	}
}

void PrintPacket(const char *tag, const char *info, const char *data, const int size)
{
	const int MAX_PRINT_SIZE = 2048;
	char buf[4 * MAX_PRINT_SIZE];
	int print_size = Min(size, MAX_PRINT_SIZE);
	int sz = 0;

	sz = sprintf(buf + sz, "%s[%03d/%03d]", info, print_size, size);
	//printf("\e[32m");

	for (int i = 0; i < print_size; i++)
	{
		sz += sprintf(buf + sz, " %02X", data[i]);
	}

	LOGD(tag, buf);
	//printf("%s", buf);

	//printf("\e[m\n");
}

uint8_t checksum(const uint8_t *packet, const uint16_t length)
{
	uint8_t val = 0x00;
	for (uint16_t i=0; i<length-2; i++)
	{
		val += packet[i];
	}
	//return 0xFF;
	return ((~val)+1) & 0xFF;
}

int getch(void)
{
	int ch;
	struct termios buf, save;
	tcgetattr(0,&save);
	buf = save;
	buf.c_lflag &= ~(ICANON|ECHO);
	buf.c_cc[VMIN] = 1;
	buf.c_cc[VTIME] = 0;
	tcsetattr(0, TCSAFLUSH, &buf);
	ch = getchar();
	tcsetattr(0, TCSAFLUSH, &save);
	return ch;
}

void ConvertRawFileToNumFile(const char *raw, const char *num, const int column)
{
#if 0
	char fileNameRaw[FILE_PATH_LENGTH];
	memset (fileNameRaw, 0x00, FILE_PATH_LENGTH);
	strcpy(fileNameRaw, raw);
	LOGD(TAG, "Raw File Name: %s", fileNameRaw);

	char fileNameNum[FILE_PATH_LENGTH];
	memset(fileNameNum, 0x00, FILE_PATH_LENGTH);
	strcpy(fileNameNum, fileNameRaw, strlen(fileNameRaw));
	ChangeFileExt(fileNameNum, "num");
	LOGD(TAG, "Num File Name: %s", fileNameNum);
#endif

	FILE *fpRaw, *fpNum;

	fpRaw = fopen(raw, "rb");
	if (fpRaw == NULL)
	{
		LOGE(TAG, "File open error. [%s]", raw);
		return;
	}

	fpNum = fopen(num, "w");
	if (fpNum == NULL)
	{
		LOGE(TAG, "File open error. [%s]", num);
		return;
	}

	uint16_t sample;
	int column_count = 1;
	while(1)
	{
		fread(&sample, sizeof(sample), 1, fpRaw);
		if (feof(fpRaw))
		{
			break;
		}
		fprintf(fpNum, "%d", sample);
		if (column_count == column)
		{
			fprintf(fpNum, "\n");
			column_count = 1;
		}
		else
		{
			fprintf(fpNum, " ");
			column_count++;
		}
	}

	fclose(fpRaw);
	fclose(fpNum);
}

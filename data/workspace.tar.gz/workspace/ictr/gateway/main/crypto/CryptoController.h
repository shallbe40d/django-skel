#ifndef _CRYPTO_CONTROLLER_H
#define _CRYPTO_CONTROLLER_H

#include "base/CommunicationBase.h"
#include "common/MessageDefine.h"

#include <string>

#pragma pack(push, 1)

struct CRYPTO_HEAD
{
	uint8_t stx;
	uint8_t type;
	uint8_t reserved[2];
	uint32_t timestamp;
	uint32_t length;
};

#pragma pack(pop)

class CCryptoController : public CCommunicationBase, public IDataListener
{
public:
	CCryptoController(CCommunicationBase *channel);
	~CCryptoController();

	size_t Write(const char* msg, const int size, const char *tag = NULL);
	void SetStx(uint8_t stx);
	void SetCryptoMode(CRYPTO_MODE_TYPE mode);
	void SetCryptoKey(const uint8_t *key, const int length);

protected:
	const char* TAG = "CRYPTO";

private:
	CCommunicationBase *mTransmitChannel;

	uint8_t mStx;
	uint8_t mKey[MAX_CRYPTO_KEY_LENGTH];
	int mKeyLength;
	CRYPTO_MODE_TYPE mCryptoMode;

	bool IsValidCryptoPacket(const void *data, const unsigned int size);
	void Read(const void *data, const unsigned int size);
};

#endif

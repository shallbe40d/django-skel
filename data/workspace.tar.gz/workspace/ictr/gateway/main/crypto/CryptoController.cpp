#include "CryptoController.h"
#include "log/Log.h"
#include "util/Util.h"

#include "cryptopp/cryptlib.h"
using CryptoPP::Exception;

#include "cryptopp/hex.h"
using CryptoPP::HexEncoder;
using CryptoPP::HexDecoder;

#include "cryptopp/filters.h"
using CryptoPP::StringSink;
using CryptoPP::StringSource;
using CryptoPP::StreamTransformationFilter;

#include "cryptopp/aes.h"
using CryptoPP::AES;

#include "cryptopp/modes.h"
using CryptoPP::ECB_Mode;

CCryptoController::CCryptoController(CCommunicationBase *channel)
{
	mStx = 0;
	memset(mKey, 0x00, MAX_CRYPTO_KEY_LENGTH);
	mKeyLength = 0;
	mCryptoMode = CRYPTO_NONE;

	mTransmitChannel = channel;
	mTransmitChannel->RegisterListener(this);
}

CCryptoController::~CCryptoController()
{
}

void CCryptoController::SetStx(uint8_t stx)
{
	mStx = stx;
}

void CCryptoController::SetCryptoMode(CRYPTO_MODE_TYPE mode)
{
	mCryptoMode = mode;
}

void CCryptoController::SetCryptoKey(const uint8_t *key, const int length)
{
	memcpy(mKey, key, length);
	mKeyLength = length;
}

size_t CCryptoController::Write(const char* msg, const int size, const char *tag)
{
	PrintPacket(TAG, "[WR]", msg, size);

	int packetLength = 0;
	char *packet = NULL;

	switch(mCryptoMode)
	{
	case CRYPTO_NONE:
		{
		}
		break;
	case CRYPTO_AES256_ECB:
		{
			std::string cipher, encoded;

			try
			{
				ECB_Mode<AES>::Encryption e;
				e.SetKey(mKey, mKeyLength);

				// The StreamTransformationFilter adds padding as required. ECB and CBC Mode must be padded to the block size of the cipher.
				StringSource((uint8_t *)msg, size, true, new StreamTransformationFilter(e, new StringSink(cipher)));

				packetLength = cipher.length() + sizeof(struct CRYPTO_HEAD);
				packet = (char *)malloc(packetLength);
				memset(packet, 0x00, packetLength);

				struct CRYPTO_HEAD *head = (struct CRYPTO_HEAD *)packet;
				head->stx = mStx;
				head->type = mCryptoMode;
				struct timespec now;
				clock_gettime(CLOCK_REALTIME, &now);
				head->timestamp = now.tv_sec;
				head->length = cipher.length();
				memcpy(packet + sizeof(struct CRYPTO_HEAD), cipher.c_str(), cipher.length());
			}
			catch(const CryptoPP::Exception& e)
			{
				LOGE(TAG, "AES ERROR: %s", e.what());
			}
		}
		break;
	default :
		{
		}
		break;
	}

	if ((packet != NULL) && (packetLength > 0))
	{
		mTransmitChannel->Write(packet, packetLength);
	}
}

bool CCryptoController::IsValidCryptoPacket(const void *data, const unsigned int size)
{
	struct CRYPTO_HEAD *head = (struct CRYPTO_HEAD *)data;

	bool rc = false;

	if (head->stx == 0x02)
	{
		if (head->type == CRYPTO_AES256_ECB)
		{
			rc = true;
		}
	}

	return rc;
}

void CCryptoController::Read(const void *data, const unsigned int size)
{
	PrintPacket(TAG, "[RD]", (char *)data, size);

	bool isValidCryptoPacket = IsValidCryptoPacket(data, size);

	if (isValidCryptoPacket == true)
	{
		std::string recovered;

		try
		{
			ECB_Mode<AES>::Decryption d;
			d.SetKey(mKey, mKeyLength);

			StringSource((uint8_t *)data + sizeof(struct CRYPTO_HEAD), size - sizeof(struct CRYPTO_HEAD), true, new StreamTransformationFilter(d, new StringSink(recovered)));

			NotifyListener(recovered.c_str(), recovered.length());
		}
		catch(const CryptoPP::Exception& e)
		{
			LOGE(TAG, "AES ERROR: %s", e.what());
		}
	}
	else
	{
		NotifyListener(data, size);
	}
}

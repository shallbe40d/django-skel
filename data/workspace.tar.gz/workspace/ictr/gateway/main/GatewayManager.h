#include "base/Base.h"
#include "common/SafeQueue.h"

#include <time.h>
#include <vector>
#include <string>

enum GATEWAY_STATE
{
	GATEWAY_STATE_IDLE,
	GATEWAY_STATE_REGISTER_GATEWAY,

	GATEWAY_STATE_REGISTER_IOT_SENSOR,
	GATEWAY_STATE_GET_IOT_SENSOR_INFO,
	GATEWAY_STATE_RESET_IOT_SENSOR,
	//GATEWAY_STATE_RESET_DEVICE,

	GATEWAY_STATE_EMERGENCY_MEASUREMENT,
	GATEWAY_STATE_EMERGENCY_DIAGNOSIS,
	GATEWAY_STATE_MANUAL_MEASUREMENT,
	GATEWAY_STATE_MANUAL_DIAGNOSIS,
	GATEWAY_STATE_PERIODIC_MEASUREMENT,
	GATEWAY_STATE_PERIODIC_DIAGNOSIS,

	GATEWAY_STATE_INIT_PROCESS,
	GATEWAY_STATE_NOISE_THRESHOLD,
	GATEWAY_STATE_VIBRATION_THRESHOLD_MEASUREMENT,
	GATEWAY_STATE_VIBRATION_THRESHOLD_DIAGNOSIS,
	GATEWAY_STATE_MAX
};

enum GATEWAY_FILE_TYPE
{
	FILE_EQUIPMENT_INFORMATION,
	FILE_FAULT_FREQUENCY,
	FILE_RMS_SHAFT_BEARING,
	FILE_RMS_MOTOR,
	FILE_VIBRATION_THRESHOLD,
	FILE_NOISE_THRESHOLD,
	FILE_ACCUMULATED_NOISE_INDICATOR,
	GATEWAY_FILE_MAX
};

enum GATEWAY_HEART_BEAT_TYPE
{
	HEART_BEAT_M1MODEM,
	HEART_BEAT_EMROUTER,
	HEART_BEAT_MCU,
	HEART_BEAT_MAX
};

class CGatewayManager : public CBase
{
public:
	CGatewayManager();
	~CGatewayManager();

	void Init();

private:
	const char *TAG = "GW";

	std::vector<message_handler<CGatewayManager>> mMessageHandlerList;
	void AddMessageHandler(COMMAND_TYPE cmd, const char *name, void (CGatewayManager::*handler)(void *, int));
	void MessageHandler(MODULE_TYPE sender, COMMAND_TYPE cmd, void *data, int size);

	GATEWAY_STATE mStateMain;

	// Gateway Info
	const char *GATEWAY_INFO_FILE = "config/gateway.conf";
	struct GatewayInfo mGatewayInfo;
	char mGatewayFile[GATEWAY_FILE_MAX][FILE_PATH_LENGTH];

	void ReadGatewayConfigFile();
	void WriteGatewayConfigFile();

	// Heart Beat
	int mHeartBeatCount[HEART_BEAT_MAX];

	// Gateway Register
	void RegisterGateway(COMMAND_TYPE lastCmd);
	void CmdSetOperatingInfo(void *data, int size);
	void CmdSetMeasurementInfo(void *data, int size);

	// IoT Sensor Info & Register
	void CmdSetIotSensorListInfo(void *data, int size);
	void RegisterIotSensor(COMMAND_TYPE lastCmd, void *data, int size);
	void CmdGetIotSensorInfo(void *data, int size);
	void GetIotSensorInfo(COMMAND_TYPE lastCmd, void *data, int size);
	void CmdRequestFactoryResetIotSensor(void *data, int size);
	void ResetIotSensor(COMMAND_TYPE lastCmd, void *data, int size);

	// Regular Measurement
#ifdef REPORT_REGULAR_MEASUREMENT_RESULT
	SafeQueue<struct RegularMeasurementResult> mRegularMeasurementResultList;
	void ReportRegularMeasurementResult();
#endif
	void DoRegularMeasurement();
	void CmdRegularMeasurementResponse(void *data, int size);
	void CmdDiagnoseNoiseAnomalyResponse(void *data, int size);

	// IoT Sensor Measurement
	const int BLE_SENSOR_CONNECTION_WAIT = 15;
	std::vector<int> mTargetDeviceList;
	uint32_t mCurrentIndex, mCurrentRetryCount;
	bool mIsAllDeviceStartMeasurement;
	struct timespec mTargetSyncTime;

	void SetTargetSyncTime(uint32_t sec);
	void CmdRequestIotSensorMeasurement(void *data, int size);
	void DoIotSensorMeasurement(COMMAND_TYPE lastCmd, void* data, int size);

	// IoT Sensor Data Download
	std::queue<struct MeasurementDataFileInfo *> mSensorStoredFileList;
	int ReadFileList(void *data, int size);
	bool mIsDownloadSuccess;

	void DownloadDataFromSingleDevice(COMMAND_TYPE lastCmd, void* data, int size);

	// Init Process
	void CmdRequestStartInitProcess();
	void CmdRequestEndInitProcess();

	// Equipment Info & Fault Frequency
	void CmdSetEquipmentInformation(void *data, int size);
	void CmdDiagnoseFaultFrequencyResponse(void *data, int size);

	// Noise Threshold
	int mNoiseThresholdMeasurementCount;
	std::vector<std::string> mNoiseThresholdMeasurementFiles;
	void CmdRequestNoiseThresholdMeasurement(void *data, int size);
	void CmdRequestNoiseThresholdDiagnosis(void *data, int size);
	void CmdDiagnoseNoiseThresholdResponse(void *data, int size);
	void CmdSetNoiseThreshold(void *data, int size);
	void SendNoiseThresholdMeasurementMessage();
	void DoNoiseThresholdMeasurement(const COMMAND_TYPE lastCmd, const void *data, const int size);

	// Vibration Threshold
	void CmdRequestVibrationThresholdMeasurement(void *data, int size);
	void CmdRequestVibrationThresholdDiagnosis(void *data, int size);
	void CmdDiagnoseVibrationThresholdResponse(void *data, int size);
	void CmdSetVibrationThreshold(void *data, int size);
	void DoVibrationThresholdMeasurement(const COMMAND_TYPE lastCmd, void *data, int size);

	// Status Check
	void DoStatusCheck();

	// Manual & Periodic Measurement
	void CmdRequestManualMeasurement(const void *data, const int size);
	void CmdRequestPeriodicMeasurement();
	void DoEmergencyMeasurement();
	void DoManualMeasurement(const COMMAND_TYPE lastCmd, const void *data, const int size);
	void DoPeriodicMeasurement();

	// Helper
	void CmdTimerExpired(void *data, int size);

	void CmdGetMacAddressResponse(void *data, int size);

	// Test
	void CmdTestModuleCommunication(const void *data, const int size);

};

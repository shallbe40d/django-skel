#include "AdcManager.h"
#include "log/Log.h"

CAdcManager::CAdcManager()
{
	mModuleType = MODULE_ADC;
}

CAdcManager::~CAdcManager()
{
}

void CAdcManager::Init()
{
	const uint8_t mode = 0;
	const uint8_t bits = 8;
	const uint32_t speed = 2 * 1000 * 1000;

	spi.Open("/dev/spidev0.0");
	spi.SetConfig(mode, bits, speed);

	MessageQueue::GetInstance()->RegisterListener(MODULE_ADC, this);
}

void CAdcManager::MessageHandler(MODULE_TYPE sender, COMMAND_TYPE cmd, void *data, int size)
{
	switch(cmd)
	{
	case CMD_REQUEST_REGULAR_MEASUREMENT:
		{
			LOGD(TAG, "CMD_REQUEST_REGULAR_MEASUREMENT");
			DoMeasurement(cmd, data, size);
		}
		break;
	case CMD_REQUEST_NOISE_THRESHOLD_MEASUREMENT:
		{
			LOGD(TAG, "CMD_REQUEST_NOISE_THRESHOLD_MEASUREMENT");
			DoMeasurement(cmd, data, size);
		}
		break;
	case CMD_REQUEST_STOP_MEASUREMENT:
		{
			LOGD(TAG, "CMD_REQUEST_STOP_MEASUREMENT");
			CmdRequestStopMeasurement(data, size);
		}
		break;
	default:
		{
			CBase::MessageHandler(sender, cmd, data, size);
		}
	}
}

void CAdcManager::DoMeasurement(const COMMAND_TYPE cmd, const void *data, const int size)
{
	const int READ_CHUNK_SIZE = 1000;

	uint8_t rdBuf[READ_CHUNK_SIZE];
	memset(rdBuf, 0x00, READ_CHUNK_SIZE);

	MeasurementDataFileInfo req;
	memset(&req, 0x00, sizeof(MeasurementDataFileInfo));
	memcpy(&req, data, size);

	int rc = -1;

#ifndef SPI_RANDOM_DATA
	IO_CONTROL_TYPE io;

	io = IO_ADC_MEASUREMENT_START;
	SendInternalMessage(MODULE_MCU, CMD_REQUEST_SET_IO_STATE, &io, sizeof(IO_CONTROL_TYPE));

	usleep(100 * 1000);
#endif

	LOGD(TAG, "Equipment Id: %s, Location: %c, Type: %c, Measurement Time: %d, Sample Rate: %d, Channel: %d", req.equipment_id, req.location, req.tag, req.measurement_time, req.sample_rate, req.channel);

	rc = clock_gettime(CLOCK_REALTIME, &req.timestamp);
	if (rc != 0)
	{
		LOGE(TAG, "Timestamp Error");
	}

	struct tm tmNow;
	localtime_r(&(req.timestamp.tv_sec), &tmNow);

	char dirCurrent[FILE_PATH_LENGTH], dirSave[FILE_PATH_LENGTH], rawFile[FILE_PATH_LENGTH];
	getcwd(dirCurrent, FILE_PATH_LENGTH);

	snprintf(dirSave, FILE_PATH_LENGTH, "%s/data/%s/%02d%02d%02d", dirCurrent, req.sub_dir_name, tmNow.tm_year - 100, tmNow.tm_mon + 1, tmNow.tm_mday);

	char cmdMkdir[1024];
	sprintf(cmdMkdir, "mkdir -p %s", dirSave);
	system(cmdMkdir);

	sprintf(rawFile, "%s/%s_%c_%c_%02d%02d%02d%02d%02d%02d.raw", dirSave, req.equipment_id, req.location, req.tag, tmNow.tm_year - 100, tmNow.tm_mon + 1, tmNow.tm_mday, tmNow.tm_hour, tmNow.tm_min, tmNow.tm_sec);
	LOGD(TAG, "RAW File Name: (%d) %s ", strlen(rawFile), rawFile);

	LOGD(TAG, "Measurement Time: %d [seconds]", req.measurement_time);
	int row = req.measurement_time * (req.sample_rate / 500) * req.channel;
	LOGD(TAG, "SPI Read Count: %d", row);

	FILE *fpRaw;

	fpRaw = fopen(rawFile, "wb");
	if (fpRaw == NULL)
	{
		LOGE(TAG, "fopen ERROR");
		return;
	}

	int countZeroData = 0;
	mIsStopMeasurement = false;

	for (int i = 0; i < row; i++)
	{
#ifndef SPI_RANDOM_DATA
		spi.Read(rdBuf, READ_CHUNK_SIZE);

		int start = rdBuf[1];
		bool isAllSame = true;
		for (int k = 2; k < READ_CHUNK_SIZE; k++)
		{
			if (rdBuf[k] != start)
			{
				isAllSame = false;
				break;
			}
		}

		if (isAllSame == false)
		{
			fwrite(rdBuf, READ_CHUNK_SIZE, 1, fpRaw);
			//LOGD(TAG, "data: %d / zero: %d", i, countZeroData);
		}
		else
		{
			countZeroData++;
			//LOGD(TAG, "All Same: %02x", rdBuf[1]);
			i--;
		}
		if (mIsStopMeasurement == true)
		{
			break;
		}
#else
		srand((unsigned int)time(NULL));
		for (int j = 0; j < READ_CHUNK_SIZE; j++)
		{
			rdBuf[j] = rand();
		}
		fwrite(rdBuf, READ_CHUNK_SIZE, 1, fpRaw);
#endif
	}
	fclose(fpRaw);
	LOGD(TAG, "Zero Count: %d", countZeroData);

	if (mIsStopMeasurement == true)
	{
		remove(rawFile);
		return;
	}

#ifndef SPI_RANDOM_DATA
	io = IO_ADC_MEASUREMENT_STOP;
	SendInternalMessage(MODULE_MCU, CMD_REQUEST_SET_IO_STATE, &io, sizeof(IO_CONTROL_TYPE));
#endif

#if 0
	if (req.channel == 2)
	{
		// Split
		fpRaw = fopen(rawFile, "rb");
		if (fpRaw == NULL)
		{
			LOGE(TAG, "fopen ERROR: %s", raw_file);
		}

		FILE *fp1stChannel, *fp2ndChannel;
		char channel1_file[256], channel2_file[256];

		sprintf(channel1_file, "%s/data/%d_%02d%02d%02d_%02d%02d%02d_%c.1.raw", dir, res.lift_index, tmNow.tm_year - 100, tmNow.tm_mon + 1, tmNow.tm_mday, tmNow.tm_hour, tmNow.tm_min, tmNow.tm_sec, res.tag);
		sprintf(channel2_file, "%s/data/%d_%02d%02d%02d_%02d%02d%02d_%c.2.raw", dir, res.lift_index, tmNow.tm_year - 100, tmNow.tm_mon + 1, tmNow.tm_mday, tmNow.tm_hour, tmNow.tm_min, tmNow.tm_sec, res.tag);

		LOGD(TAG, "Channel 1 File: (%d) %s, Channel 2 File: (%d) %s", strlen(channel1_file), channel1_file, strlen(channel2_file), channel2_file);

		fp1stChannel = fopen(channel1_file, "wb");
		if (fp1stChannel == NULL)
		{
			LOGE(TAG, "fopen ERROR: %s", channel1_file);
		}

		fp2ndChannel = fopen(channel2_file, "wb");
		if (fp2ndChannel == NULL)
		{
			LOGE(TAG, "fopen ERROR: %s", channel2_file);
		}

		uint16_t sample[2];
		while(1)
		{
			fread(sample, sizeof(uint16_t), 2, fpRaw);
			if (feof(fpRaw))
			{
				break;
			}
			fwrite(&sample[0], sizeof(uint16_t), 1, fp1stChannel);
			fwrite(&sample[1], sizeof(uint16_t), 1, fp2ndChannel);
		}
		fclose(fpRaw);
		fclose(fp1stChannel);
		fclose(fp2ndChannel);

		strcpy(res.file_name, channel2_file);
		remove(raw_file);
	}
	else
#endif
	{
		strcpy(req.file_name, rawFile);
	}

	switch(cmd)
	{
	case CMD_REQUEST_REGULAR_MEASUREMENT:
		{
			SendInternalMessage(MODULE_GATEWAY, CMD_REQUEST_REGULAR_MEASUREMENT_RESPONSE, &req, sizeof(struct MeasurementDataFileInfo));
		}
		break;
	case CMD_REQUEST_NOISE_THRESHOLD_MEASUREMENT:
		{
			SendInternalMessage(MODULE_GATEWAY, CMD_REQUEST_NOISE_THRESHOLD_MEASUREMENT_RESPONSE, &req, sizeof(struct MeasurementDataFileInfo));
		}
		break;
	default:
		{
		}
		break;
	}
}

void CAdcManager::CmdRequestStopMeasurement(void *data, int size)
{
	mIsStopMeasurement = true;
}

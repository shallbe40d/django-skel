#include "mq/MessageQueue.h"
#include "base/Base.h"
#include "spi/SpiController.h"

class CAdcManager : public CBase
{
public:
	CAdcManager();
	~CAdcManager();

	void Init();

private:
	const char *TAG = "ADC";
	void MessageHandler(MODULE_TYPE sender, COMMAND_TYPE cmd, void *data, int size);

	CSpiController spi;

	bool mIsStopMeasurement;
	void DoMeasurement(const COMMAND_TYPE cmd, const void *data, const int size);
	void CmdRequestStopMeasurement(void *data, int size);
};

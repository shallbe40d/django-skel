sudo modprobe cfg80211
sudo insmod wifi/88x2cu.ko
sudo ifconfig wlan0 down
sudo ifconfig wlan0 192.168.99.1 netmask 255.255.255.0 up
sudo systemctl start isc-dhcp-server
sudo hostapd /home/intsain/workspace/ictr/gateway/main/config/hostap.conf -B
